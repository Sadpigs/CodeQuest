'use strict';
/* ============ CodeQuest — курс ABAP ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.abap = {
  id: 'abap',
  title: 'ABAP',
  emoji: '🏭',
  color: '#0a6ed1',
  lang: 'abap',
  tagline: 'Язык систем SAP: 10 уровней',
  description: 'Язык, на котором работает половина мирового бизнеса: SAP ERP, логистика, финансы. За 10 уровней: WRITE и DATA, SELECT из таблиц, внутренние таблицы, структуры, циклы, условия, модуляризация, классы ABAP OO и финальный отчёт по заказам.',

  levels: [

    {
      id: 'abap-1',
      title: 'WRITE и первый отчёт',
      goal: 'Выводить текст и понимать структуру программы ABAP',
      xp: 30,
      theory: [
        { t: 'p', html: 'ABAP-программы пишутся в SAP GUI (транзакция SE38). Каждый оператор заканчивается точкой <code>.</code> (не точкой с запятой!). Вывод — <code>WRITE</code>. Комментарии — <code>* в начале строки</code> и <code>" в конце строки</code>.' },
        { t: 'code', code: `REPORT z_hello.

WRITE 'Привет, SAP!'.
WRITE / 'Новая строка'.   " / — перевод строки

DATA lv_name TYPE string VALUE 'Иван'.
WRITE / lv_name.` },
        { t: 'p', html: 'Объявление переменных: <code>DATA имя TYPE тип VALUE значение.</code>. Имена по конвенции: lv_ (локальная переменная), ls_ (структура), lt_ (таблица), iv_/ev_ (параметры). Типы: string, i (целое), p (десятичное), d (дата), t (время).' },
        { t: 'list', items: [
          '<b>REPORT zимя.</b> — заголовок программы (z — кастомная);',
          '<b>DATA lv_x TYPE тип.</b> — переменная;',
          '<b>WRITE / текст.</b> — вывод с новой строки;',
          'каждый оператор — точка.'
        ] },
        { t: 'note', html: 'Z-префикс — знак «кастомизация»: объекты SAP начинаются с других букв, а все доработки клиентов — с Z или Y. ABAP-разработчик живёт в мире z-объектов.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери программу: объявление строки и вывод.</p>',
        code: `REPORT z_demo.

{{0}} lv_city TYPE string {{1}} 'Казань'.
{{2}} / lv_city.`,
        blanks: [
          { answer: 'DATA' },
          { answer: 'VALUE' },
          { answer: 'WRITE' }
        ],
        ci: false
      },
      hints: [
        'Переменные — DATA имя TYPE тип.',
        'Начальное значение — VALUE.'
      ],
      solution: ['DATA', 'VALUE', 'WRITE']
    },

    {
      id: 'abap-2',
      title: 'Типы и структуры',
      goal: 'Элементарные типы, структуры TYPES и работа с полями',
      xp: 35,
      theory: [
        { t: 'p', html: 'Элементарные типы: <code>i</code> — целые, <code>p DECIMALS 2</code> — упакованные десятичные (деньги!), <code>d</code> — дата ГГГГММДД, <code>t</code> — время. Структура — <code>TYPES: BEGIN OF … END OF.</code> + <code>DATA</code>.' },
        { t: 'code', code: `TYPES: BEGIN OF ty_person,
         name  TYPE string,
         age   TYPE i,
       END OF ty_person.

DATA ls_person TYPE ty_person.

ls_person-name = 'Анна'.
ls_person-age  = 30.

WRITE: / ls_person-name, ls_person-age.` },
        { t: 'p', html: 'Деньги — только p DECIMALS 2: тип i округлит копейки, float даст хвосты — SAP-стандарт жёсткий. Даты — тип d: арифметика дней работает напрямую: <code>d2 = d1 + 7.</code> — неделя спустя.' },
        { t: 'code', code: `DATA lv_price TYPE p DECIMALS 2 VALUE 199.99.
DATA lv_date  TYPE d VALUE '20240301'.

lv_date = lv_date + 30.   " месяц примерно
WRITE / lv_date.          " 20240331` },
        { t: 'note', html: 'WRITE: с двоеточием — «общий префикс для цепочки операторов»: WRITE: a, b, c. — три вывода. Это сокращение делает ABAP-код плотнее.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви структуру ty_book с полями title (string) и pages (i), создай ls_book и заполни поля.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'TYPES BEGIN OF', all: ['TYPES:\\s*BEGIN\\s+OF\\s+ty_book'] },
          { desc: 'Поля title и pages', all: ['title\\s+TYPE\\s+string', 'pages\\s+TYPE\\s+i'] },
          { desc: 'END OF', all: ['END\\s+OF\\s+ty_book'] },
          { desc: 'DATA ls_book', all: ['DATA\\s+ls_book\\s+TYPE\\s+ty_book'] }
        ],
        note: 'TYPES: BEGIN OF ty_book, title TYPE string, pages TYPE i, END OF ty_book. / DATA ls_book TYPE ty_book.'
      },
      hints: [
        'Каркас: TYPES: BEGIN OF имя, поля, END OF имя.',
        'Переменная-структура — DATA ls_имя TYPE ty_имя.'
      ],
      solution: `TYPES: BEGIN OF ty_book,
         title TYPE string,
         pages TYPE i,
       END OF ty_book.

DATA ls_book TYPE ty_book.
ls_book-title = 'Дюна'.
ls_book-pages = 600.`
    },

    {
      id: 'abap-3',
      title: 'SELECT из таблиц БД',
      goal: 'Читать данные таблиц SAP: SELECT ... INTO TABLE',
      xp: 40,
      theory: [
        { t: 'p', html: 'Данные SAP живут в прозрачных таблицах БД. <code>SELECT поля FROM таблица INTO TABLE lt_таб WHERE условие.</code> — читает строки во внутреннюю таблицу. Системные таблицы: KNA1 (клиенты), VBAK (заказы), MARA (материалы).' },
        { t: 'code', code: `DATA lt_kna1 TYPE STANDARD TABLE OF kna1.

SELECT kunnr, name1, land1
  FROM kna1
  WHERE land1 = 'DE'
  INTO TABLE @lt_kna1.

WRITE: / 'Найдено:', lines( lt_kna1 ).` },
        { t: 'p', html: 'Современный синтаксис (7.40+): список колонок через запятую, <code>@</code> перед хост-переменными, INTO TABLE в конце. <code>lines( )</code> — число строк таблицы. SELECT SINGLE — одна строка в структуру.' },
        { t: 'code', code: `SELECT SINGLE name1 FROM kna1
  WHERE kunnr = @lv_id
  INTO @DATA(lv_name).        " inline-объявление!

IF sy-subrc = 0.
  WRITE / lv_name.
ENDIF.` },
        { t: 'note', html: 'sy-subrc — код возврата последней операции: 0 = успех, 4 = не найдено. Проверка sy-subrc после каждого SELECT — железное правило ABAP.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Выбери kunnr, name1 из kna1 где land1 = RU в таблицу lt_cust.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'SELECT с колонками', all: ['SELECT\\s+kunnr,\\s*name1\\s+FROM\\s+kna1'] },
          { desc: 'WHERE land1 = RU', all: ["WHERE\\s+land1\\s*=\\s*'RU'"] },
          { desc: 'INTO TABLE', all: ['INTO\\s+TABLE\\s+@?lt_cust'] }
        ],
        note: 'SELECT kunnr, name1 FROM kna1 WHERE land1 = RU INTO TABLE @lt_cust.'
      },
      hints: [
        'Современный порядок: SELECT … FROM … WHERE … INTO TABLE.',
        '@ перед переменной программы.'
      ],
      solution: `SELECT kunnr, name1
  FROM kna1
  WHERE land1 = 'RU'
  INTO TABLE @lt_cust.`
    },

    {
      id: 'abap-4',
      title: 'Внутренние таблицы',
      goal: 'Хранить наборы строк: STANDARD TABLE, LOOP и READ',
      xp: 45,
      theory: [
        { t: 'p', html: 'Внутренняя таблица — «таблица в памяти»: <code>DATA lt_x TYPE STANDARD TABLE OF структура.</code>. Обход — <code>LOOP AT lt INTO ls.</code> … <code>ENDLOOP.</code> Поиск — <code>READ TABLE lt INTO ls WITH KEY поле = знач.</code>' },
        { t: 'code', code: `LOOP AT lt_kna1 INTO DATA(ls_cust).
  WRITE: / ls_cust-kunnr, ls_cust-name1.
ENDLOOP.

READ TABLE lt_kna1 INTO ls_cust
     WITH KEY land1 = 'RU'.
IF sy-subrc = 0.
  WRITE / 'Первый из RU найден'.
ENDIF.` },
        { t: 'p', html: 'Добавление — <code>APPEND ls TO lt.</code> (в конец), <code>INSERT</code> — по индексу/ключу. Удаление — <code>DELETE lt WHERE условие.</code>. Современные выражения: <code>ls = lt[ 1 ].</code> — первая строка, <code>lt[ kunnr = 100 ]-name1</code> — поле найденной строки.' },
        { t: 'code', code: `* современный стиль:
DATA(ls_first) = lt_kna1[ 1 ].
WRITE / ls_first-name1.

TRY.
    DATA(ls_x) = lt_kna1[ kunnr = 100 ].
  CATCH cx_sy_itab_line_not_found.
    WRITE / 'нет такой строки'.
ENDTRY.` },
        { t: 'note', html: 'Индексный доступ lt[ … ] бросает исключение, если строки нет — старый READ TABLE с sy-subrc прощает. Оба стиля живут в промышленном коде.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь операции внутренней таблицы.</p>',
        code: `{{0}} AT lt_cust INTO ls_cust.
  WRITE / ls_cust-name1.
{{1}}.

{{2}} ls_new TO lt_cust.`,
        blanks: [
          { answer: 'LOOP' },
          { answer: 'ENDLOOP' },
          { answer: 'APPEND' }
        ],
        ci: false
      },
      hints: [
        'Обход — LOOP AT … ENDLOOP.',
        'Добавление строки — APPEND.'
      ],
      solution: ['LOOP', 'ENDLOOP', 'APPEND']
    },

    {
      id: 'abap-5',
      title: 'Условия и CASE',
      goal: 'IF/ELSEIF/ENDIF, CASE и логические операторы',
      xp: 45,
      theory: [
        { t: 'p', html: 'Условия: <code>IF … ELSEIF … ELSE … ENDIF.</code> Сравнения: =, &lt;&gt; (не равно), &lt;, &gt;, между — <code>BETWEEN a AND b</code>, принадлежность — <code>IN</code>. Множественный выбор — <code>CASE … WHEN … ENDCASE.</code>' },
        { t: 'code', code: `IF lv_qty > 100.
  lv_discount = 10.
ELSEIF lv_qty > 50.
  lv_discount = 5.
ELSE.
  lv_discount = 0.
ENDIF.

CASE lv_status.
  WHEN 'A'. WRITE / 'активен'.
  WHEN 'B'. WRITE / 'блок'.
  WHEN OTHERS. WRITE / 'прочее'.
ENDCASE.` },
        { t: 'p', html: 'WHEN OTHERS — «все прочие случаи» (аналог default). Логика: AND, OR, NOT. Строковые сравнения с шаблонами: <code>IF lv_name CP &apos;А*&apos;</code> — начинается на А (CP = contains pattern).' },
        { t: 'list', items: [
          '<b>&lt;&gt;</b> — не равно;',
          '<b>BETWEEN … AND …</b> — диапазон;',
          '<b>CP</b> — шаблон строки (* любой хвост);',
          '<b>CASE/WHEN/WHEN OTHERS/ENDCASE.</b>'
        ] },
        { t: 'note', html: 'Условия ABAP пишутся словами по-английски: EQ NE GT LT GE LE — синонимы =, <>, >, <, >=, <=. Старый код сплошь на EQ/NE — читать надо оба стиля.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что выведет программа при lv_x = 5?</p>',
        code: `IF lv_x BETWEEN 1 AND 10.
  WRITE 'первый'.
ELSEIF lv_x > 10.
  WRITE 'второй'.
ENDIF.`,
        options: [
          `второй`,
          `первый`,
          `ничего`,
          `ошибка`
        ],
        correct: 1,
        explain: '5 лежит в диапазоне 1..10 — сработает первая ветка, вывод "первый". ELSEIF проверяется только если IF не прошёл.'
      },
      hints: [
        'BETWEEN включает границы.',
        'Первое истинное условие выигрывает.'
      ],
      solution: `первый`
    },

    {
      id: 'abap-6',
      title: 'DO и WHILE',
      goal: 'Циклы DO/ENDDO и WHILE/ENDWHILE',
      xp: 50,
      theory: [
        { t: 'p', html: '<code>DO n TIMES. … ENDDO.</code> — n повторений, счётчик — системная переменная <code>sy-index</code>. <code>WHILE условие. … ENDWHILE.</code> — пока верно. Выход — <code>EXIT.</code>.' },
        { t: 'code', code: `DATA lv_sum TYPE i.

DO 5 TIMES.
  lv_sum = lv_sum + sy-index.
ENDDO.
WRITE / lv_sum.        " 15 (1+2+3+4+5)

WHILE lv_sum > 10.
  lv_sum = lv_sum - 5.
ENDWHILE.
WRITE / lv_sum.        " 5` },
        { t: 'p', html: 'sy-index — номер текущего прохода DO. Внутри LOOP AT роль счётчика играет sy-tabix (индекс строки таблицы). Различать их важно: sy-index в LOOP не даст ожидаемого.' },
        { t: 'code', code: `* вложенный DO и выход
DO 10 TIMES.
  IF sy-index = 4.
    EXIT.
  ENDIF.
  WRITE / sy-index.
ENDDO.` },
        { t: 'note', html: 'CONTINUE пропускает остаток прохода к следующему. Структуры sy-… (sy-subrc, sy-index, sy-tabix, sy-uname, sy-datum) — «системные регистры» ABAP, знакомство с ними — часть профессии.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что выведет WRITE? Одно число.</p>',
        code: `DATA lv_prod TYPE i VALUE 1.
DO 4 TIMES.
  lv_prod = lv_prod * sy-index.
ENDDO.
WRITE lv_prod.`,
        solution: `24`,
        ci: false
      },
      hints: [
        'sy-index: 1, 2, 3, 4.',
        '1 × 2 × 3 × 4 = 24.'
      ],
      solution: `24`
    },

    {
      id: 'abap-7',
      title: 'Модуляризация FORM и PERFORM',
      goal: 'Разбивать код: FORM-подпрограммы с параметрами',
      xp: 50,
      theory: [
        { t: 'p', html: 'Подпрограмма: <code>FORM имя USING p1 CHANGING p2. … ENDFORM.</code> Вызов — <code>PERFORM имя USING a CHANGING b.</code> USING — входной параметр, CHANGING — вход-выход (изменяется).' },
        { t: 'code', code: `DATA gv_total TYPE p DECIMALS 2.

PERFORM add_price USING 100.50
              CHANGING gv_total.
PERFORM add_price USING 250.25
              CHANGING gv_total.
WRITE / gv_total.      " 350.75

FORM add_price USING p_amt TYPE p
              CHANGING c_total TYPE p.
  c_total = c_total + p_amt.
ENDFORM.` },
        { t: 'p', html: 'Классические отчёты SAP (Z-программы) построены на FORM-ах: PERFORM read_data / PERFORM process / PERFORM write_output — три подпрограммы на три фазы. Современный мир — методы классов (следующий уровень), но FORM жив в легаси повсеместно.' },
        { t: 'note', html: 'Существуют также TABLES-параметры FORM (передача внутренних таблиц) и функциональные модули FM (SE37) — межсистемный API SAP. Иерархия модуляризации: FORM (программа) → FM (система) → методы классов (современность).' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые слова подпрограммы.</p>',
        code: `PERFORM calc {{0}} 10 {{1}} lv_result.

{{2}} calc USING p_in CHANGING c_out.
  c_out = p_in * 2.
ENDFORM.`,
        blanks: [
          { answer: 'USING' },
          { answer: 'CHANGING' },
          { answer: 'FORM' }
        ],
        ci: false
      },
      hints: [
        'Вход — USING, вход-выход — CHANGING.',
        'Определение — FORM … ENDFORM.'
      ],
      solution: ['USING', 'CHANGING', 'FORM']
    },

    {
      id: 'abap-8',
      title: 'Классы ABAP OO',
      goal: 'Классы, методы, объекты: современный ABAP',
      xp: 55,
      theory: [
        { t: 'p', html: 'Класс: <code>CLASS имя DEFINITION. … ENDCLASS.</code> + <code>CLASS имя IMPLEMENTATION. … ENDCLASS.</code>. Методы: <code>METHODS имя IMPORTING … EXPORTING …</code>. Объект — <code>CREATE OBJECT</code> / современно <code>NEW</code>.' },
        { t: 'code', code: `CLASS lcl_calc DEFINITION.
  PUBLIC SECTION.
    METHODS add
      IMPORTING iv_a        TYPE i
                iv_b        TYPE i
      RETURNING VALUE(rv_r) TYPE i.
ENDCLASS.

CLASS lcl_calc IMPLEMENTATION.
  METHOD add.
    rv_r = iv_a + iv_b.
  ENDMETHOD.
ENDCLASS.

START-OF-SELECTION.
  DATA(lo_calc) = NEW lcl_calc( ).
  DATA(lv_sum) = lo_calc->add( iv_a = 2 iv_b = 3 ).
  WRITE / lv_sum.      " 5` },
        { t: 'p', html: 'RETURNING VALUE(…) — функциональный стиль: метод можно звать в выражениях. Доступ — стрелка <code>-&gt;</code>. Секции: PUBLIC/PROTECTED/PRIVATE. Инкапсуляция ABAP OO — полноправная ООП-система.' },
        { t: 'list', items: [
          '<b>DEFINITION</b> — интерфейс, <b>IMPLEMENTATION</b> — код;',
          '<b>-&gt;</b> — доступ к членам объекта;',
          '<b>NEW класс( )</b> — создание (7.40+);',
          '<b>RETURNING VALUE()</b> — результат-выражение.'
        ] },
        { t: 'note', html: 'SAP-мир движется в ABAP OO: новые разработки в S/4HANA — классы, Clean ABAP-гайдлайны от SAP требуют методы вместо FORM. Изучай FORM для легаси, пиши классами для будущего.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Создай объект класса lcl_calc через NEW и вызови метод add с 2 и 3, сохранив результат.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Создание через NEW', all: ['NEW\\s+lcl_calc\\s*\\(\\s*\\)'] },
          { desc: 'Вызов add с параметрами', all: ['->\\s*add\\s*\\(\\s*iv_a\\s*=\\s*2\\s+iv_b\\s*=\\s*3\\s*\\)'] }
        ],
        note: 'DATA(lo) = NEW lcl_calc( ). / DATA(lv) = lo->add( iv_a = 2 iv_b = 3 ).'
      },
      hints: [
        'NEW класс( ) возвращает ссылку.',
        'Метод — объект->add( iv_a = … iv_b = … ).'
      ],
      solution: `DATA(lo_calc) = NEW lcl_calc( ).
DATA(lv_sum) = lo_calc->add( iv_a = 2 iv_b = 3 ).`
    },

    {
      id: 'abap-9',
      title: 'ALV-отчёты',
      goal: 'Выводить таблицы в грид: cl_salv_table',
      xp: 55,
      theory: [
        { t: 'p', html: 'Профессиональный вывод — ALV-грид (интерактивная таблица с сортировкой/экспортом из коробки). Современный способ — класс <code>cl_salv_table</code>: factory из внутренней таблицы, display( ), настройки колонок.' },
        { t: 'code', code: `SELECT * FROM kna1 INTO TABLE @DATA(lt_data)
  WHERE land1 = 'DE'.

cl_salv_table=>factory(
  IMPORTING r_salv_table = DATA(lo_alv)
  CHANGING  t_table      = lt_data ).

lo_alv->get_columns( )->set_optimizations( ).
lo_alv->display( ).` },
        { t: 'p', html: 'Три строки — и на экране полноценный грид: сортировка кликами, фильтры, экспорт в Excel. Вся магия UI SAP-отчётов — SALV-обёртка. Функциональные вызовы методов — <code>класс=>метод( EXPORTING … )</code> — статический доступ через =&gt;.' },
        { t: 'code', code: `* заголовок и полосатость:
lo_alv->get_display_settings( )->set_striped_pattern( abap_true ).
lo_alv->get_functions( )->set_all( abap_true ).` },
        { t: 'note', html: 'abap_true/abap_false — константы булевых значений (X / пробел). Старые ALV через FM REUSE_ALV_GRID_DISPLAY всё ещё встречаются — но новый код пиши на cl_salv_table: SAP официально рекомендует.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь вызовы SALV: factory и display.</p>',
        code: `cl_salv_table=>{{0}}(
  IMPORTING r_salv_table = DATA(lo_alv)
  CHANGING  t_table      = lt_data ).

lo_alv->{{1}}( ).`,
        blanks: [
          { answer: 'factory' },
          { answer: 'display' }
        ],
        ci: false
      },
      hints: [
        'Создание ALV — статический factory.',
        'Показ на экране — display( ).'
      ],
      solution: ['factory', 'display']
    },

    {
      id: 'abap-10',
      title: 'Проект: отчёт по заказам',
      goal: 'Собрать программу: SELECT, агрегация, ALV-вывод',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финал — типовой Z-отчёт: выбрать заказы (VBAK), посчитать суммы по клиентам, вывести ALV. Три фазы — чтение, обработка, вывод — канва практически любой ABAP-программы в мире.' },
        { t: 'code', code: `REPORT z_orders_report.

SELECT vbak~kunnr, SUM( vbak~netwr ) AS total
  FROM vbak
  GROUP BY vbak~kunnr
  INTO TABLE @DATA(lt_sum).

cl_salv_table=>factory(
  IMPORTING r_salv_table = DATA(lo_alv)
  CHANGING  t_table      = lt_sum ).

lo_alv->get_columns( )->set_optimizations( ).
lo_alv->display( ).` },
        { t: 'list', items: [
          '<b>SELECT … GROUP BY</b> — агрегация на стороне БД;',
          '<b>SUM( )</b> — суммирование колонки;',
          '<b>INTO TABLE @DATA(…)</b> — inline-таблица;',
          '<b>SALV factory + display</b> — грид за 3 строки.'
        ] },
        { t: 'note', html: 'Расширь проект: WHERE по дате (erdat BETWEEN), колонка-формула, два уровня агрегации. Ты написал программу, которую ежедневно запускают менеджеры по продажам на тысячах SAP-систем. ABAP-разработчик с таким набором — дефицитный специалист с зарплатой, которую не постесняется любой IT-рынок.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь элементы агрегирующего отчёта.</p>',
        code: `SELECT vbak~kunnr, {{0}}( vbak~netwr ) AS total
  FROM vbak
  {{1}} BY vbak~kunnr
  INTO TABLE @DATA(lt_sum).

lo_alv->{{2}}( ).`,
        blanks: [
          { answer: 'SUM' },
          { answer: 'GROUP' },
          { answer: 'display' }
        ],
        ci: false
      },
      hints: [
        'Суммирование — SUM(колонка).',
        'Группировка — GROUP BY; показ — display( ).'
      ],
      solution: ['SUM', 'GROUP', 'display']
    }
  ]
};
