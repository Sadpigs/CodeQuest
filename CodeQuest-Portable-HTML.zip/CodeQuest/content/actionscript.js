'use strict';
/* ============ CodeQuest — курс ActionScript 3 ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.actionscript = {
  id: 'actionscript',
  title: 'ActionScript 3',
  emoji: '🎞️',
  color: '#d9333f',
  lang: 'actionscript',
  tagline: 'Классика Flash: 10 уровней',
  description: 'Язык платформы Flash, на котором выросло целое поколение игр и анимаций. AS3 — полноценный ООП-язык со строгой типизацией и событийной моделью. За 10 уровней: trace и типы, функции, DisplayObject и события, классы, массивы, TextField, анимация на EnterFrame и финальная мини-игра.',

  levels: [

    {
      id: 'actionscript-1',
      title: 'trace и переменные',
      goal: 'Выводить значения и объявлять типизированные переменные var',
      xp: 30,
      theory: [
        { t: 'p', html: 'ActionScript 3 — язык платформы Flash (Adobe AIR и Flash Player). Код пишется в .as-файлах или кадрах Timeline. Вывод в консоль — <code>trace()</code>: главный инструмент отладки. Переменные объявляются <code>var имя:Тип = значение;</code> — строгая типизация, как в Java.' },
        { t: 'code', code: `var score:int = 100;
var name:String = "Игрок";
var speed:Number = 2.5;
var alive:Boolean = true;

trace("Игрок:", name, score);   // Игрок: Игрок 100` },
        { t: 'p', html: 'Каждая команда заканчивается <code>;</code>. Комментарии — <code>//</code> строковые и <code>/* … */</code> блочные. Числовые типы: <code>int</code> — целые, <code>uint</code> — беззнаковые, <code>Number</code> — дробные.' },
        { t: 'list', items: [
          '<b>int</b> — целые числа;',
          '<b>Number</b> — дробные и научные;',
          '<b>String</b> — текст в кавычках;',
          '<b>Boolean</b> — true/false;',
          '<b>void</b> — «функция ничего не возвращает».'
        ] },
        { t: 'note', html: 'Строгие типы помогают: компилятор Flash поймает ошибку «передали строку вместо числа» до запуска. Приведение типов — <code>Number("3.5")</code>, <code>int(3.9)</code> — отбрасывает дробную часть.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь типы переменных: целое, строка, дробное.</p>',
        code: `var hp:{{0}} = 100;
var title:{{1}} = "Меню";
var gravity:{{2}} = 9.8;
trace(title, hp, gravity);`,
        blanks: [
          { answer: 'int' },
          { answer: 'String' },
          { answer: 'Number' }
        ],
        ci: false
      },
      hints: [
        'Целые — int, текст — String.',
        'Дробные — Number.'
      ],
      solution: ['int', 'String', 'Number']
    },

    {
      id: 'actionscript-2',
      title: 'Функции',
      goal: 'Определять функции с типами аргументов и возвращаемых значений',
      xp: 35,
      theory: [
        { t: 'p', html: 'Функция: <code>function имя(параметр:Тип):ВозвращаемыйТип { … return значение; }</code>. Типы обязательны у параметров и результата; для «ничего не возвращает» — <code>:void</code>. Вызов — имя со скобками.' },
        { t: 'code', code: `function damage(hp:int, power:int):int {
    return hp - power;
}

function show(text:String):void {
    trace(">> " + text);
}

var hp:int = damage(100, 30);
show("Осталось: " + hp);   // >> Осталось: 70` },
        { t: 'p', html: 'Конкатенация строк — плюс <code>+</code>: число автоматически превращается в текст при сложении со строкой. Параметры по умолчанию — <code>function f(x:int = 10)</code>; произвольное число аргументов — <code>…rest</code>.' },
        { t: 'code', code: `function sum(a:int, b:int = 0):int {
    return a + b;
}

trace(sum(5));      // 5
trace(sum(5, 7));   // 12` },
        { t: 'note', html: 'AS3-функции — объекты первого класса: их можно класть в переменные и передавать. Анонимная функция: var f:Function = function(x:int):int { return x * 2; };' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши функцию <code>double</code>: принимает int, возвращает удвоенное значение.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Функция объявлена', all: ['function\\s+double\\s*\\(\\s*\\w+:\\s*int\\s*\\)\\s*:\\s*int'] },
          { desc: 'Есть return с умножением', all: ['return\\s+\\w+\\s*\\*\\s*2'] }
        ],
        note: 'function double(x:int):int { return x * 2; }'
      },
      hints: [
        'Сигнатура: function double(x:int):int.',
        'Возврат — return x * 2.'
      ],
      solution: `function double(x:int):int {
    return x * 2;
}`
    },

    {
      id: 'actionscript-3',
      title: 'if и switch',
      goal: 'Ветвления и выбор значения',
      xp: 40,
      theory: [
        { t: 'p', html: 'Условия классические C-стиля: <code>if (условие) { … } else if (…) { … } else { … }</code>. Сравнения ==, !=, &lt;, &gt;, логика &amp;&amp;, ||, !. Для выбора одного значения из многих — <code>switch</code> с <code>case</code> и обязательными <code>break</code>.' },
        { t: 'code', code: `if (hp <= 0) {
    trace("Игра окончена");
} else if (hp < 30) {
    trace("Мало жизни!");
}

switch (direction) {
    case "left":  vx = -2; break;
    case "right": vx = 2;  break;
    default:      vx = 0;
}` },
        { t: 'warn', html: 'Забытый break в switch «проваливается» в следующий case — классическая ошибка. default — ветка «остальные случаи», тоже желательно с break.' },
        { t: 'note', html: 'Строгое сравнение === проверяет ещё и тип: "5" == 5 даст true (приведение), а "5" === 5 — false. В AS3 оба существуют, как в JavaScript.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что выведет trace?</p>',
        code: `var x:int = 15;
if (x > 20) trace("A");
else if (x > 10) trace("B");
else trace("C");`,
        options: [
          `A`,
          `B`,
          `C`,
          `A и B`
        ],
        correct: 1,
        explain: '15 не больше 20, но больше 10 — сработает вторая ветка, "B". Остальные проверяются только если предыдущие дали false.'
      },
      hints: [
        'Ветви проверяются сверху вниз.',
        'Первое истинное условие завершает цепочку.'
      ],
      solution: `B`
    },

    {
      id: 'actionscript-4',
      title: 'Циклы for и while',
      goal: 'Повторения: for с счётчиком, for each и while',
      xp: 45,
      theory: [
        { t: 'p', html: 'Счётный цикл: <code>for (var i:int = 0; i &lt; 10; i++) { … }</code> — три части через точку с запятой: старт, условие, шаг. <code>while (условие)</code> крутится, пока верно; <code>do … while</code> проверяет после тела.' },
        { t: 'code', code: `var total:int = 0;
for (var i:int = 1; i <= 10; i++) {
    total += i;
}
trace(total);   // 55

var n:int = 5;
while (n > 0) {
    n -= 1;
}` },
        { t: 'p', html: 'Перебор массивов — <code>for each (var item:Тип in массив)</code> — даёт значения элементов. Выход — <code>break</code>, пропуск итерации — <code>continue</code>. Операторы накопления: <code>+=</code>, <code>-=</code>, <code>*=</code> и инкремент <code>i++</code>.' },
        { t: 'code', code: `var scores:Array = [10, 20, 30];
var sum:int = 0;
for each (var s:int in scores) {
    sum += s;
}
trace(sum);   // 60` },
        { t: 'note', html: 'for each в AS3 — прямой предок конструкции for…of современных языков. Индексная версия — for (var i:String in obj) даёт ключи объекта.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что выведет trace? Одно число.</p>',
        code: `var result:int = 1;
for (var i:int = 1; i <= 4; i++) {
    result *= i;
}
trace(result);`,
        solution: `24`,
        ci: false
      },
      hints: [
        'Цикл перемножает 1 × 2 × 3 × 4.',
        'result *= i — накопление произведения.'
      ],
      solution: `24`
    },

    {
      id: 'actionscript-5',
      title: 'Массивы и Vector',
      goal: 'Создавать массивы, методы push/sort и типизированные Vector',
      xp: 45,
      theory: [
        { t: 'p', html: 'Массив: <code>var arr:Array = [1, "два", 3.0];</code> — элементы любых типов. Методы: <code>push</code> (в конец), <code>pop</code>, <code>splice</code> (удалить/вставить), <code>indexOf</code> (найти), <code>sort</code>, <code>join</code>. Длина — <code>length</code>.' },
        { t: 'code', code: `var arr:Array = [30, 10, 20];
arr.push(40);
arr.sort(Array.NUMERIC);
trace(arr.join("-"));   // 10-20-30-40
trace(arr.indexOf(20)); // 1` },
        { t: 'p', html: 'Для однотипных данных есть <code>Vector.&lt;T&gt;</code> — типизированный массив: <code>var v:Vector.&lt;int&gt; = new Vector.&lt;int&gt;();</code>. Он быстрее Array и ловит ошибки типов на компиляции — профессиональный выбор для игр.' },
        { t: 'code', code: `var xs:Vector.<int> = new Vector.<int>();
xs.push(5);
xs.push(9);
trace(xs[0] + xs[1]);   // 14` },
        { t: 'note', html: 'Сортировка Array по умолчанию — строковая: [10, 9] отсортируется как "10, 9"! Для чисел всегда Array.NUMERIC или функция-компаратор: arr.sort(function(a,b) { return a - b; }).' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь методы массива: добавить в конец, отсортировать, склеить.</p>',
        code: `var arr:Array = [3, 1, 2];
arr.{{0}}(4);          // [3, 1, 2, 4]
arr.{{1}}(Array.NUMERIC);
trace(arr.{{2}}(","));   // 1,2,3,4`,
        blanks: [
          { answer: 'push' },
          { answer: 'sort' },
          { answer: 'join' }
        ],
        ci: false
      },
      hints: [
        'Добавление — push.',
        'Сортировка — sort, склейка — join.'
      ],
      solution: ['push', 'sort', 'join']
    },

    {
      id: 'actionscript-6',
      title: 'Классы и наследование',
      goal: 'Объявлять классы с полями, методами и extends',
      xp: 50,
      theory: [
        { t: 'p', html: 'Класс — <code>public class Имя { … }</code>, обычно один на .as-файл с тем же именем. Поля и методы с модификаторами <code>public</code>/<code>private</code>. Конструктор — метод с именем класса. Наследование — <code>extends</code>, вызов родителя — <code>super</code>.' },
        { t: 'code', code: `public class Unit {
    public var hp:int = 100;

    public function hit(power:int):void {
        hp -= power;
    }
}

public class Hero extends Unit {
    public var shield:int = 10;

    override public function hit(power:int):void {
        if (shield > 0) { shield -= power; }
        else { super.hit(power); }
    }
}` },
        { t: 'p', html: '<code>override</code> обязателен при перекрытии метода родителя — защита от опечаток. Ключевое слово <code>this</code> — «этот объект». Интерфейсы — <code>implements</code> с набором обязательных методов.' },
        { t: 'code', code: `var hero:Hero = new Hero();
hero.hit(30);
trace(hero.hp);   // 100 — щит поглотил` },
        { t: 'note', html: 'AS3-классы — почти Java по синтаксису: те же public/private, extends, override. Писал на AS3 — легко читал Java и наоборот; не случайно многие Flash-разработчики перешли в мобильную разработку.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери класс и наследование.</p>',
        code: `public {{0}} Enemy {
    public var hp:int = 50;
}

public class Boss {{1}} Enemy {
    public var rage:int = 3;
}

var b:{{2}} = new Boss();
b.hp = 200;`,
        blanks: [
          { answer: 'class' },
          { answer: 'extends' },
          { answer: 'Boss' }
        ],
        ci: false
      },
      hints: [
        'Класс — class, наследование — extends.',
        'Тип переменной — имя класса-потомка.'
      ],
      solution: ['class', 'extends', 'Boss']
    },

    {
      id: 'actionscript-7',
      title: 'События',
      goal: 'Подписываться на события через addEventListener',
      xp: 50,
      theory: [
        { t: 'p', html: 'Событийная модель — сердце AS3. Подписка: <code>объект.addEventListener(Событие.ТИП, обработчик)</code>. Обработчик получает объект event с деталями: <code>event.target</code> — кто сработал, <code>event.currentTarget</code>. Отписка — removeEventListener.' },
        { t: 'code', code: `stage.addEventListener(MouseEvent.CLICK, onClick);

function onClick(e:MouseEvent):void {
    trace("Клик в:", e.stageX, e.stageY);
}

btn.addEventListener(MouseEvent.MOUSE_DOWN, onDown);
function onDown(e:MouseEvent):void {
    trace("Нажали кнопку");
}` },
        { t: 'p', html: 'Главные события: <code>MouseEvent.CLICK / MOUSE_DOWN / MOUSE_UP / MOUSE_MOVE</code>, клавиатура — <code>KeyboardEvent.KEY_DOWN / KEY_UP</code> (код клавиши в event.keyCode), кадровый таймер — <code>Event.ENTER_FRAME</code> (о нём — уровень 8).' },
        { t: 'code', code: `stage.addEventListener(KeyboardEvent.KEY_DOWN, onKey);
function onKey(e:KeyboardEvent):void {
    switch (e.keyCode) {
        case Keyboard.LEFT:  trace("влево"); break;
        case Keyboard.RIGHT: trace("вправо"); break;
    }
}` },
        { t: 'note', html: 'События — модель DOM и браузеров: addEventListener в JS появился из тех же идей. Понимание подписок/отписок в AS3 переносится в веб-разработку один в один.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Подпишись на клик мыши (MouseEvent.CLICK) объекта btn с обработчиком onHit.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'addEventListener у btn', all: ['btn\\.addEventListener'] },
          { desc: 'Тип события MouseEvent.CLICK', all: ['MouseEvent\\.CLICK'] },
          { desc: 'Имя обработчика onHit', all: ['MouseEvent\\.CLICK,\\s*onHit\\s*\\)'] }
        ],
        note: 'btn.addEventListener(MouseEvent.CLICK, onHit);'
      },
      hints: [
        'Форма: объект.addEventListener(Событие.ТИП, функция).',
        'Тип клика — MouseEvent.CLICK.'
      ],
      solution: `btn.addEventListener(MouseEvent.CLICK, onHit);`
    },

    {
      id: 'actionscript-8',
      title: 'Анимация на ENTER_FRAME',
      goal: 'Двигать объекты каждый кадр и обрабатывать границы',
      xp: 55,
      theory: [
        { t: 'p', html: 'Событие <code>Event.ENTER_FRAME</code> срабатывает на каждом кадре (обычно 24–60 FPS) — это игровой цикл Flash. В обработчике меняют координаты объекта: <code>obj.x += 5;</code> — и объект поедает по экрану. Координаты: x — вправо, y — ВНИЗ (ось y инвертирована).' },
        { t: 'code', code: `var ball:Shape = new Shape();
ball.graphics.beginFill(0xFF0000);
ball.graphics.drawCircle(0, 0, 20);
ball.graphics.endFill();
addChild(ball);

ball.addEventListener(Event.ENTER_FRAME, onFrame);
function onFrame(e:Event):void {
    ball.x += 3;
    if (ball.x > stage.stageWidth) ball.x = 0;
}` },
        { t: 'p', html: 'Рисование — <code>graphics</code>: beginFill(цвет) — заливка (0xRRGGBB), drawCircle(x, y, радиус), drawRect, lineTo — линии, endFill. <code>addChild</code> помещает объект в список отображения — без него объект невидим.' },
        { t: 'list', items: [
          '<b>x, y</b> — позиция на экране;',
          '<b>rotation</b> — поворот в градусах;',
          '<b>alpha</b> — прозрачность 0..1;',
          '<b>scaleX / scaleY</b> — масштаб.'
        ] },
        { t: 'note', html: 'Отскок от стен — классика: if (ball.x &gt; width - 20 || ball.x &lt; 20) vx *= -1 — смена направления умножением на −1. На этом уже строится Pong.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери движение: подписка на Event.ENTER_FRAME, внутри обработчика ball.x += 5.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Подписка на ENTER_FRAME', all: ['addEventListener\\s*\\(\\s*Event\\.ENTER_FRAME'] },
          { desc: 'Обработчик сдвигает ball', all: ['ball\\.x\\s*\\+=\\s*5'] }
        ],
        note: 'ball.addEventListener(Event.ENTER_FRAME, onFrame); внутри onFrame — ball.x += 5;'
      },
      hints: [
        'Событие каждого кадра — Event.ENTER_FRAME.',
        'Сдвиг — ball.x += 5.'
      ],
      solution: `ball.addEventListener(Event.ENTER_FRAME, onFrame);
function onFrame(e:Event):void {
    ball.x += 5;
}`
    },

    {
      id: 'actionscript-9',
      title: 'TextField и интерфейс',
      goal: 'Выводить текст, счёт и ввод пользователя',
      xp: 55,
      theory: [
        { t: 'p', html: '<code>TextField</code> — текстовый объект: <code>var t:TextField = new TextField(); t.text = "Счёт: 0";</code>. Свойства: <code>.text</code> — содержание, <code>.width/.height</code>, <code>defaultTextFormat</code> — шрифт и размер (объект TextFormat), <code>.type = TextFieldType.INPUT</code> — поле для ввода.' },
        { t: 'code', code: `var tf:TextField = new TextField();
tf.x = 10; tf.y = 10;
tf.text = "Счёт: 0";
addChild(tf);

// обновление счёта
var score:int = 0;
score += 10;
tf.text = "Счёт: " + score;` },
        { t: 'p', html: 'TextFormat управляет видом: <code>var f:TextFormat = new TextFormat("Arial", 24, 0xFFFFFF);</code> — шрифт, размер, цвет; затем <code>tf.defaultTextFormat = f;</code>. Для HTML-подобного форматирования есть <code>htmlText</code> с тегами &lt;b&gt;, &lt;font&gt;.' },
        { t: 'code', code: `var fmt:TextFormat = new TextFormat("Consolas", 20, 0x00FF00);
tf.defaultTextFormat = fmt;
tf.text = "READY";` },
        { t: 'note', html: 'TextField + ENTER_FRAME — готовый HUD игры: счёт, жизни, таймер обновляются в кадре простым переприсваиванием .text. Также AS3 умеет SharedObject — локальное сохранение рекордов (аналог localStorage).' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери счёт: создание TextField, обновление текста.</p>',
        code: `var score:{{0}} = 0;
var tf:TextField = new TextField();
addChild(tf);

score += 25;
tf.{{1}} = "Счёт: " + score;`,
        blanks: [
          { answer: 'int' },
          { answer: 'text' }
        ],
        ci: false
      },
      hints: [
        'Счёт — целое число.',
        'Содержимое TextField — свойство text.'
      ],
      solution: ['int', 'text']
    },

    {
      id: 'actionscript-10',
      title: 'Проект: мини-игра «Лови кубики»',
      goal: 'Собрать игру: объект, клавиши, падающие предметы, счёт',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финал — каркас игры: игрок-платформа двигается клавишами, кубики падают сверху, ловля даёт очки. Весь игровой цикл живёт в ENTER_FRAME: читаем клавиши из состояния, двигаем игрока, двигаем кубики, проверяем пересечения через <code>hitTestObject</code>.' },
        { t: 'code', code: `var vx:Number = 0;
var falling:Array = [];
var score:int = 0;

stage.addEventListener(KeyboardEvent.KEY_DOWN, function(e:KeyboardEvent):void {
    if (e.keyCode == Keyboard.LEFT)  vx = -5;
    if (e.keyCode == Keyboard.RIGHT) vx = 5;
});

addEventListener(Event.ENTER_FRAME, function(e:Event):void {
    player.x += vx;
    for each (var cube:Shape in falling) {
        cube.y += 4;
        if (cube.hitTestObject(player)) {
            score += 10;
            tf.text = "Счёт: " + score;
            removeChild(cube);
        }
    }
});` },
        { t: 'list', items: [
          '<b>Клавиши</b> — KeyboardEvent меняет vx;',
          '<b>Падение</b> — cube.y += скорость;',
          '<b>Столкновение</b> — hitTestObject(player);',
          '<b>Счёт</b> — накопление + вывод в TextField;'
        ] },
        { t: 'note', html: 'Это скелет настоящей Flash-игры: добавь таймер спавна кубиков (getTimer), полосу жизней и сохранение рекорда в SharedObject — получится законченный продукт. Игры вроде «Mahjong» и первые Angry Birds-прототипы начинались ровно с такого кода.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые части игрового цикла.</p>',
        code: `player.x += {{0}};
for each (var cube:Shape in falling) {
    cube.{{1}} += 4;
    if (cube.hitTestObject({{2}})) {
        score += 10;
    }
}`,
        blanks: [
          { answer: 'vx' },
          { answer: 'y' },
          { answer: 'player' }
        ],
        ci: false
      },
      hints: [
        'Игрок двигается по x со скоростью vx.',
        'Кубики падают — растёт их y; столкновение проверяется с игроком.'
      ],
      solution: ['vx', 'y', 'player']
    }
  ]
};
