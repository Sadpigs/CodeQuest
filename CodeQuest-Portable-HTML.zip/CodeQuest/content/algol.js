'use strict';
/* ============ CodeQuest — курс ALGOL ============
   ALGOL не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду) и заполнением
   пропусков. Стиль — ALGOL 60, строчные идентификаторы.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.algol = {
  id: 'algol',
  title: 'ALGOL',
  emoji: '🏛️',
  color: '#4a6da7',
  lang: 'algol',
  tagline: 'Пращур языков: 6 уровней академической классики',
  description: 'ALGOL 60 — язык, который дал программированию блоки begin/end, :=, вложенные процедуры и BNF-описание синтаксиса. Его отчёт написали лучшие умы комитета ACM и GAMM, и почти всё, на чём ты пишешь сегодня, — наследник ALGOL. За 6 уровней дойдём от begin/end до проекта «Таблица квадратов и кубов»: типы, if/else, for step until, процедуры.',

  levels: [

    /* ---------- 1. Первая программа: begin/end ---------- */
    {
      id: 'algol-1',
      title: 'Первая программа: begin/end',
      goal: 'Собрать блок begin … end с выводом строки и числа через outstring и outinteger',
      xp: 30,
      theory: [
        { t: 'p', html: 'ALGOL — сокращение от «ALGOrithmic Language», алгоритмический язык. Первую версию (ALGOL 58) согласовали в Цюрихе в 1958-м, а в январе 1960 года тринадцать учёных из семи стран — от Джона Бэкуса до Адриана ван Вейнгаардена — собрались в Париже и выпустили «Отчёт об алгоритмическом языке ALGOL 60». Редактором отчёта был Питер Наур, и язык с тех пор часто называют ALGOL 60.' },
        { t: 'p', html: 'Главная революция отчёта — не сам язык, а способ его описания: синтаксис впервые записали формальной грамматикой BNF. Нотацию придумал Бэкус для ALGOL 58, а Наур довёл её до ALGOL 60 — с тех пор формула Бэкуса — Наура описывает языки повсюду. Ещё отчёт различал reference language (эталон) и publication language (для статей, там ключевые слова печатали жирным).' },
        { t: 'h', html: 'Минимальная программа' },
        { t: 'code', code: `begin
  outstring(1, "Привет, CodeQuest!");
  outinteger(1, 1960);
end` },
        { t: 'p', html: 'Блок <code>begin … end</code> — сердце ALGOL: он группирует объявления и операторы, задаёт область видимости и вкладывается сам в себя. Из этой идеи выросли блоки C, фигурные скобки Java, <code>begin…end</code> Паскаля. Программа — тоже блок: объявления, потом операторы.' },
        { t: 'p', html: 'Знаменитая скромность ALGOL 60: в стандарте нет процедур ввода-вывода — комитет не смог договориться, какие. Каждая реализация давала свои: здесь используется распространённая пара <code>outinteger(канал, число)</code> и <code>outstring(канал, строка)</code>. Первый аргумент — номер канала, для консоли обычно 1.' },
        { t: 'list', items: [
          '<b>begin … end</b> — блок: объявления, затем операторы;',
          '<b>outstring(1, &quot;текст&quot;)</b> — печать строки;',
          '<b>outinteger(1, выражение)</b> — печать числа;',
          '<b>точка с запятой</b> — разделяет операторы.'
        ] },
        { t: 'warn', html: 'Комментарии в классике пишутся словом <code>comment … ;</code>, но наш редактор подсвечивает однострочные <code>#</code> — в заданиях пользуйся ими. И не забывай точку с запятой после каждого оператора внутри блока.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первую программу: блок <code>begin … end</code>, внутри которого <code>outstring</code> печатает строку приветствия, а <code>outinteger</code> — число 1960. Не потеряй точку с запятой между операторами и убери заглушки.</p>',
        starter: `# TODO: НАПЕЧАТАЙ СТРОКУ ПРИВЕТСТВИЯ И ЧИСЛО ГОДА
begin
  # TODO: ВЫЗОВИ outstring И outinteger
end`,
        rules: [
          { desc: 'Блок открыт словом begin', all: ['\\bbegin\\b'] },
          { desc: 'Блок закрыт словом end', all: ['\\bend\\b'] },
          { desc: 'Строка напечатана: outstring(канал, "текст")', all: ['\\boutstring\\s*\\(\\s*\\d+\\s*,\\s*"[^"]*"\\s*\\)'] },
          { desc: 'Число напечатано: outinteger(канал, выражение)', all: ['\\boutinteger\\s*\\(\\s*\\d+\\s*,\\s*[^)]+\\s*\\)'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас: begin ... end — объявления и операторы внутри.',
        'Строка: outstring(1, "Привет, CodeQuest!"); — канал первый аргумент.',
        'Число: outinteger(1, 1960); — и не забудь точку с запятой.'
      ],
      solution: `begin
  outstring(1, "Привет, CodeQuest!");
  outinteger(1, 1960);
end`
    },

    /* ---------- 2. Переменные: целые и реальные ---------- */
    {
      id: 'algol-2',
      title: 'Переменные: целые и реальные',
      goal: 'Объявлять integer и real, присваивать через := и различать присваивание со сравнением',
      xp: 30,
      theory: [
        { t: 'p', html: 'Объявления пишутся до операторов, через запятую можно перечислить несколько имён: <code>integer i, j;</code>, <code>real x, y;</code>. Есть и логический тип <code>boolean</code>. Объявление задаёт тип навсегда: переменная, объявленная целой, останется целой до конца блока.' },
        { t: 'code', code: `begin
  integer ticks;
  real weight;

  ticks := 60;
  weight := 62.5;
  outinteger(1, ticks);
  outreal(1, weight)
end` },
        { t: 'p', html: 'Присваивание в ALGOL — <code>:=</code>, двоеточие со знаком равенства. Одиночное <code>=</code> — это <b>сравнение</b>, оно живёт только в условиях: <code>if x = 5 then …</code>. Перепутать — классическая ошибка, которую позже унаследовали все, кто учился по ALGOL-учебникам.' },
        { t: 'p', html: 'Деление зависит от типов: <code>60 / 8</code> при вещественных операндах даст 7.5, а для целочисленного деления в эталоне был отдельный знак ÷ (в ASCII-реализациях его писали как <code>div</code> или целую функцию). Вещественные результаты печатает <code>outreal</code>.' },
        { t: 'list', items: [
          '<b>integer / real / boolean</b> — базовые типы;',
          '<b>:=</b> — присваивание;',
          '<b>=</b> — сравнение, только в условиях;',
          'строковых переменных нет — литералы &quot;…&quot; живут в вызовах процедур.'
        ] },
        { t: 'note', html: 'Отсутствие строковых переменных — реальная особенность ALGOL 60: строка в языке существует только как литерал, который можно передать процедуре (например, outstring). Переменные — только числовые и логические.' },
        { t: 'warn', html: 'Точка с запятой разделяет операторы, а не завершает их: перед <code>end</code> её можно не ставить. Зато пропущенная точка с запятой между двумя операторами — гарантированная ошибка разбора.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни программу: впиши тип целого счётчика, общий тип для веса и отношения, знак присваивания (не сравнение!), знак вещественного деления и строковый литерал с кавычками для печати. Двоеточие и равенство впиши как единый символ.</p>',
        code: `begin
  {{0}} ticks;
  {{1}} weight, ratio;

  ticks {{2}} 60;
  weight := 62.5;
  ratio := 60 {{3}} 8;

  ticks := ticks + 1;

  outinteger(1, ticks);
  outreal(1, weight);
  outreal(1, ratio);
  outstring(1, {{4}})
end`,
        blanks: [
          { answer: 'integer', ci: true },
          { answer: 'real', ci: true },
          { answer: ':=' },
          { answer: '/' },
          { answer: '"ALGOL-60"' }
        ],
        ci: false
      },
      hints: [
        'Целый тип — integer, вещественный — real (одна объявка на две переменные через запятую).',
        'Присваивание в ALGOL — двоеточие и равенство: :=.',
        'Деление — одиночный слэш: 60 / 8 даст 7.5; строка — в кавычках: "ALGOL-60".'
      ],
      solution: ['integer', 'real', ':=', '/', '"ALGOL-60"']
    },

    /* ---------- 3. Условия: if … then … else ---------- */
    {
      id: 'algol-3',
      title: 'Условия: if … then … else',
      goal: 'Написать ветвление if … then … else со сравнением и присваиваниями внутри ветвей',
      xp: 35,
      theory: [
        { t: 'p', html: 'Условный оператор ALGOL читается как английская фраза: <code>if условие then оператор else оператор</code>. Условие — логическое выражение со сравнениями <code>=</code>, <code>&lt;</code>, <code>&gt;</code>, <code>&lt;=</code>, <code>&gt;=</code> и связками <code>and</code>, <code>or</code>, <code>not</code> (в эталоне — знаки ∧, ∨, ¬). Ветка <code>else</code> необязательна.' },
        { t: 'code', code: `if temp > 10 then
  outstring(1, "тепло")
else
  outstring(1, "холодно")` },
        { t: 'p', html: 'В каждой ветке — ровно один оператор. Нужно несколько — ставь блок: <code>then begin … end</code>. Так ALGOL решает и знаменитую проблему висячего else: в записи <code>if a then if b then S1 else S2</code> else относится к <b>внутреннему</b> if; чтобы привязать его к внешнему, внутренний if закрывают в begin…end.' },
        { t: 'code', code: `if a > 0 then
begin
  if b > 0 then
    outinteger(1, a + b)
end
else
  outinteger(1, a - b)` },
        { t: 'list', items: [
          '<b>if условие then оператор</b> — без альтернативы;',
          '<b>if … then … else …</b> — с альтернативой;',
          '<b>begin … end</b> в ветке — если операторов несколько;',
          'сравнения и and/or/not — из булевых выражений.'
        ] },
        { t: 'p', html: 'Обрати внимание: перед <code>else</code> точка с запятой не ставится — <code>if … then … else …</code> это один оператор, а точка с запятой разделяет разные операторы. Поставишь — часть компиляторов простит, но эталон считает это ошибкой.' },
        { t: 'warn', html: 'Ещё одна классика: <code>:=</code> внутри ветвей, а не <code>=</code>. Присваивание — двоеточие со знаком равенства; одиночное равенство в присваивании ALGOL просто не разберёт.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери термометр: присвой <code>temp</code> значение через <code>:=</code>, затем <code>if</code>-условие со сравнением — при температуре больше десяти печатай <code>outstring</code> со словом «тепло», иначе — со словом «холодно». Заглушки убери.</p>',
        starter: `begin
  integer temp;
  # TODO: ЗАДАЙ ТЕМПЕРАТУРУ ЧЕРЕЗ ПРИСВАИВАНИЕ
  # TODO: СОБЕРИ if-then-else С ДВУМЯ outstring-ВЕТВЯМИ
  outinteger(1, temp)
end`,
        rules: [
          { desc: 'if с условием и then', all: ['\\bif\\s+.+\\s+then\\b'] },
          { desc: 'Ветка else', all: ['\\belse\\b'] },
          { desc: 'Присваивание := в программе', all: ['\\w+\\s*:=\\s*[^;\\n]+'] },
          { desc: 'Сравнение в условии if', all: ['\\bif\\s+\\w+\\s*[<>=]'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Присваивание: temp := 7;',
        'Условие: if temp > 10 then ... else ... — перед else точка с запятой не нужна.',
        'Ветви: outstring(1, "тепло") и outstring(1, "холодно").'
      ],
      solution: `begin
  integer temp;
  temp := 7;
  if temp > 10 then
    outstring(1, "тепло")
  else
    outstring(1, "холодно")
end`
    },

    /* ---------- 4. Циклы: for … step/until/while ---------- */
    {
      id: 'algol-4',
      title: 'Циклы: for … step/until/while',
      goal: 'Написать циклы for в формах step/until и while с печатью значений',
      xp: 40,
      theory: [
        { t: 'p', html: 'Цикл <code>for</code> в ALGOL 60 — самый гибкий из тех, что существовали в 1960-м. Классическая форма: <code>for i := 1 step 1 until 10 do оператор</code> — от единицы с шагом один до десяти. Читается прямо по словам: «шаг», «пока не достигнем».' },
        { t: 'code', code: `for i := 1 step 1 until 5 do
  outinteger(1, i * i);` },
        { t: 'p', html: 'Вторая форма — с <code>while</code>: <code>for i := 1 while условие do …</code> — значение перед while задаёт стартовое значение переменной, а цикл крутится, пока условие истинно. Шаг в этой форме ты делаешь сам, в теле цикла.' },
        { t: 'code', code: `power := 1;
for i := 1 while power <= 100 do
begin
  outinteger(1, power);
  power := power * 2
end` },
        { t: 'p', html: 'После <code>for i :=</code> можно перечислить через запятую <b>несколько элементов списка</b> — например, <code>for i := 1, 3, 7 do</code> выполнит тело для каждого значения. Шаг может быть отрицательным или даже выражением: <code>for i := 10 step -2 until 0 do</code> посчитает в обратную сторону.' },
        { t: 'list', items: [
          '<b>for i := a step s until b do</b> — арифметическая форма;',
          '<b>for i := a while условие do</b> — форма с условием;',
          '<b>for i := 1, 3, 7 do</b> — список значений;',
          '<b>begin … end после do</b> — если в теле несколько операторов.'
        ] },
        { t: 'warn', html: 'Заголовок заканчивается словом <code>do</code>, и только потом идёт тело. Если цикл должен считать вниз — не забудь отрицательный <code>step</code>, иначе цикл завершится сразу: единица уже больше нуля.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери обе формы цикла: в форме <code>step/until</code> напечатай квадраты чисел от 1 до 5, в форме <code>while</code> — удвоения <code>power</code>, пока она не превысит 100 (не забывай удваивать в теле!). Оба цикла должны печатать через <code>outinteger</code>. Заглушки убери.</p>',
        starter: `begin
  integer i, power;
  # TODO: ЦИКЛ step/until ДЛЯ КВАДРАТОВ ЧИСЕЛ 1..5
  # TODO: ЦИКЛ while ДЛЯ УДВОЕНИЙ ДО 100
  power := 1
end`,
        rules: [
          { desc: 'Цикл for ... do', all: ['\\bfor\\s+\\w+\\s*:=', '\\bdo\\b'] },
          { desc: 'Форма step/until', all: ['\\bstep\\s+\\d+\\s+until\\s+\\d+'] },
          { desc: 'Форма while', all: ['\\bwhile\\s+.+\\bdo\\b'] },
          { desc: 'Значения печатаются outinteger', all: ['\\boutinteger\\s*\\(\\s*\\d+\\s*,\\s*[^)]+\\s*\\)'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Квадраты: for i := 1 step 1 until 5 do outinteger(1, i * i);',
        'Удвоения: for i := 1 while power &lt;= 100 do begin ... end — внутри печать и power := power * 2.',
        'В теле while два оператора — оберни их в begin … end.'
      ],
      solution: `begin
  integer i, power;

  for i := 1 step 1 until 5 do
    outinteger(1, i * i);

  power := 1;
  for i := 1 while power <= 100 do
  begin
    outinteger(1, power);
    power := power * 2
  end
end`
    },

    /* ---------- 5. Процедуры ---------- */
    {
      id: 'algol-5',
      title: 'Процедуры',
      goal: 'Объявить procedure с параметром и типизированную функцию-процедуру с возвратом через имя',
      xp: 40,
      theory: [
        { t: 'p', html: 'Подпрограммы в ALGOL 60 — <code>procedure</code>. Заголовок перечисляет параметры, следом идут спецификации типов, затем тело — оператор (обычно <code>begin … end</code>): <code>procedure line(n); integer n; begin … end;</code>. Вызов — просто имя с аргументами: <code>line(3)</code>.' },
        { t: 'code', code: `procedure line(n); integer n;
begin
  outinteger(1, n * n)
end;` },
        { t: 'p', html: 'Функция — процедура с типом: <code>integer procedure cube(x); integer x;</code>. Возврат значения устроен изящно: внутри тела результат присваивается <b>имени самой процедуры</b> — <code>cube := x * x * x</code>. Этот приём позже переехал в Паскаль почти без изменений.' },
        { t: 'code', code: `integer procedure cube(x); integer x;
begin
  cube := x * x * x
end;` },
        { t: 'p', html: 'Самое знаменитое решение ALGOL 60 — параметры по умолчанию передаются <b>по имени</b> (call by name): в тело процедуры текстово подставляется само выражение аргумента при каждом использовании. Отсюда парадоксальный «Device Йенсена», когда передача выражения с переменной цикла в процедуру меняет сам цикл. По значению параметр передаётся, только если указать <code>value n;</code>.' },
        { t: 'list', items: [
          '<b>procedure имя(параметры); спецификации; тело</b> — обычная процедура;',
          '<b>тип procedure имя(…)</b> — функция с возвратом значения;',
          '<b>имя := выражение</b> внутри тела — возврат результата;',
          '<b>value n;</b> — параметр по значению (иначе — по имени).'
        ] },
        { t: 'note', html: 'Рекурсия в тексте отчёта описана не была — и Дейкстра с Зонневелдом в 1960-м всё равно сделали первый компилятор ALGOL 60 с рекурсией. Комитет спорил до последнего, но именно их решение стало каноном.' },
        { t: 'warn', html: 'Спецификация параметра обязательна: <code>procedure f(n); integer n;</code> — без <code>integer n;</code> заголовок неполный. И помни: <code>end</code> тела процедуры закрывается точкой с запятой — объявление лишь часть блока.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви в блоке две подпрограммы: процедуру <code>line(n)</code> со спецификацией <code>integer n</code>, печатающую квадрат числа через <code>outinteger</code>, и функцию-процедуру <code>integer procedure cube(x)</code>, возвращающую куб через присваивание имени. В цикле вызови <code>line(i)</code>, после цикла — напечатай <code>cube(3)</code>. Заглушки убери.</p>',
        starter: `begin
  integer i;
  # TODO: ПРОЦЕДУРА line ДЛЯ ПЕЧАТИ КВАДРАТА
  # TODO: ФУНКЦИЯ-ПРОЦЕДУРА cube С ВОЗВРАТОМ ЧЕРЕЗ ИМЯ
  for i := 1 step 1 until 3 do
    outinteger(1, i)
end`,
        rules: [
          { desc: 'Обычная procedure с параметром объявлена', all: ['\\bprocedure\\s+\\w+\\s*\\([^)]*\\)\\s*;'] },
          { desc: 'Спецификация параметра: integer ИМЯ;', all: ['\\binteger\\s+\\w+\\s*;'] },
          { desc: 'Функция-процедура: integer procedure', all: ['\\binteger\\s+procedure\\b'] },
          { desc: 'Возврат значения через присваивание имени', all: ['\\w+\\s*:=\\s*\\w+\\s*\\*'] },
          { desc: 'Процедуры вызваны с аргументами', all: ['\\w+\\s*\\(\\s*\\w+\\s*\\)'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Процедура: procedure line(n); integer n; begin outinteger(1, n * n) end;',
        'Функция: integer procedure cube(x); integer x; begin cube := x * x * x end;',
        'Вызовы: line(i) в цикле и outinteger(1, cube(3)) после.'
      ],
      solution: `begin
  integer i;

  procedure line(n); integer n;
  begin
    outinteger(1, n * n)
  end;

  integer procedure cube(x); integer x;
  begin
    cube := x * x * x
  end;

  for i := 1 step 1 until 3 do
    line(i);
  outinteger(1, cube(3))
end`
    },

    /* ---------- 6. 🚀 Проект: таблица квадратов и кубов ---------- */
    {
      id: 'algol-6',
      title: '🚀 Проект: таблица квадратов и кубов',
      goal: 'Собрать процедуру печати строки таблицы и for-цикл, заполняющий квадраты и кубы чисел',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальная практика — печатная таблица «N, N², N³» для чисел от 1 до 7. Процедура <code>row(n)</code> печатает одну строку: заголовки через <code>outstring</code>, значения через <code>outinteger</code>, квадрат и куб считаются умножением. Цикл из уровня 4 просто вызывает её для каждого N.' },
        { t: 'code', code: `procedure row(n); integer n;
begin
  outstring(1, "N = ");
  outinteger(1, n);
  outstring(1, "  N^2 = ");
  outinteger(1, n * n);
  outstring(1, "  N^3 = ");
  outinteger(1, n * n * n)
end;` },
        { t: 'p', html: 'Здесь собирается весь курс: блок begin/end из уровня 1, объявления <code>integer</code> из уровня 2, процедура из уровня 5, цикл <code>step/until</code> из уровня 4. Возврат значения не нужен — процедура только печатает; зато параметр <code>n</code> передаётся по имени, как положено в ALGOL 60.' },
        { t: 'list', items: [
          '<b>procedure row(n); integer n;</b> — строка таблицы;',
          '<b>outstring + outinteger</b> — чередование подписей и чисел;',
          '<b>n * n и n * n * n</b> — квадрат и куб;',
          '<b>for i := 1 step 1 until 7 do row(i)</b> — заполнение таблицы.'
        ] },
        { t: 'note', html: 'Тони Хоар говорил об ALGOL 60: «Вот язык, настолько опередивший своё время, что он был не только улучшением своих предшественников, но и почти всех своих наследников». Доведёшь таблицу до печати — поймёшь, о чём это: маленький язык, а в нём уже есть всё, чем мы пользуемся до сих пор. После зачёта добавь сумму по столбцу или печать в обратном порядке (step -1).' },
        { t: 'warn', html: 'Не потеряй спецификацию <code>integer n;</code> в заголовке процедуры — без неё ALGOL 60 не разберёт объявление. И следи за точками с запятой: они разделяют объявления и операторы блока, но после <code>end</code> тела процедуры нужна своя точка с запятой.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери таблицу: процедуру <code>row(n)</code> со спецификацией <code>integer n</code>, которая через <code>outstring</code> и <code>outinteger</code> печатает N, квадрат (<code>n * n</code>) и куб (<code>n * n * n</code>). Затем <code>for</code>-цикл от 1 до 7, вызывающий <code>row(i)</code>. Заглушки убери.</p>',
        starter: `begin
  integer i;
  # TODO: ПРОЦЕДУРА row ДЛЯ ПЕЧАТИ ОДНОЙ СТРОКИ ТАБЛИЦЫ
  # TODO: КВАДРАТ И КУБ ЧЕРЕЗ УМНОЖЕНИЕ, ВЫВОД outstring И outinteger
  for i := 1 step 1 until 7 do
    outinteger(1, i)
end`,
        rules: [
          { desc: 'procedure row с параметром и спецификацией integer n', all: ['\\bprocedure\\s+row\\s*\\([^)]*\\)\\s*;', '\\binteger\\s+n\\s*;'] },
          { desc: 'Тело процедуры: begin … end', all: ['\\bbegin\\b', '\\bend\\b'] },
          { desc: 'Печатаются и строки (outstring), и числа (outinteger)', all: ['\\boutstring\\s*\\(\\s*\\d+\\s*,\\s*"[^"]*"\\s*\\)', '\\boutinteger\\s*\\(\\s*\\d+\\s*,\\s*[^)]+\\s*\\)'] },
          { desc: 'Квадрат и куб вычислены умножением', all: ['\\w+\\s*\\*\\s*\\w+\\s*\\*\\s*\\w+'] },
          { desc: 'for-цикл вызывает row', all: ['\\bfor\\s+\\w+\\s*:=', '\\brow\\s*\\(\\s*\\w+\\s*\\)'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Заголовок: procedure row(n); integer n; — спецификация обязательна.',
        'Внутри чередуй: outstring(1, "N = ") и outinteger(1, n); квадрат — n * n, куб — n * n * n.',
        'Цикл: for i := 1 step 1 until 7 do row(i)'
      ],
      solution: `begin
  integer i;

  procedure row(n); integer n;
  begin
    outstring(1, "N = ");
    outinteger(1, n);
    outstring(1, "  N^2 = ");
    outinteger(1, n * n);
    outstring(1, "  N^3 = ");
    outinteger(1, n * n * n)
  end;

  for i := 1 step 1 until 7 do
    row(i)
end`
    }
  ],

  cheats: [
    { title: 'Каркас блока', code: `begin
  integer i;
  real x;
  i := 7;
  x := 2.5;
  outinteger(1, i);
  outreal(1, x)
end` },
    { title: 'Типы и присваивание', list: [
      '<code>integer / real / boolean</code> — базовые типы',
      '<code>:=</code> — присваивание',
      '<code>=</code> — сравнение (только в условиях)',
      'несколько имён через запятую: <code>integer i, j;</code>',
      'строковых переменных нет — только литералы "…"'
    ] },
    { title: 'if / else', code: `if x > 10 then
  outstring(1, "тепло")
else
  outstring(1, "холодно");

if a > 0 then
begin
  if b > 0 then S1
end
else
  S2;` },
    { title: 'Цикл for', code: `for i := 1 step 1 until 10 do
  outinteger(1, i);

for i := 10 step -2 until 0 do
  outinteger(1, i);

for i := 1 while s <= 100 do
begin
  s := s * 2
end` },
    { title: 'Процедуры', code: `procedure line(n); integer n;
begin
  outinteger(1, n * n)
end;

integer procedure cube(x); integer x;
begin
  cube := x * x * x
end;

line(3);
outinteger(1, cube(3))` },
    { title: 'Ввод-вывод', list: [
      'в стандарте ALGOL 60 ввода-вывода нет — его дают реализации',
      '<code>outstring(канал, "текст")</code> — печать строки',
      '<code>outinteger(канал, выражение)</code> — печать целого',
      '<code>outreal(канал, выражение)</code> — печать вещественного',
      'канал 1 — обычно консоль'
    ] },
    { title: 'Частые ошибки', list: [
      ':= и = перепутаны — присваивание двоеточием',
      'точка с запятой перед else (эталон запрещает)',
      'нет спецификации параметра после заголовка процедуры',
      'for без do или с забытым step в убывающем цикле',
      'end тела процедуры без точки с запятой'
    ] }
  ]
};
