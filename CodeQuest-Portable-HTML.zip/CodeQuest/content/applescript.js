'use strict';
/* ============ CodeQuest — курс AppleScript ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.applescript = {
  id: 'applescript',
  title: 'AppleScript',
  emoji: '🍎',
  color: '#7a9bbf',
  lang: 'applescript',
  tagline: 'Автоматизация macOS: 10 уровней',
  description: 'Родной язык автоматизации Mac: управляет Finder, Почтой, Музыкой и сотнями приложений английскими фразами. За 10 уровней: display dialog, переменные и списки, условия, repeat-циклы, handlers-функции, разговор с приложениями через tell и финальный проект-менеджер файлов.',

  levels: [

    {
      id: 'applescript-1',
      title: 'Первый диалог',
      goal: 'Показать окно display dialog и вернуть ответ',
      xp: 30,
      theory: [
        { t: 'p', html: 'AppleScript пишется в приложении «Редактор скриптов» (Script Editor) — он есть на каждом Mac. Команда <code>display dialog "текст"</code> показывает модальное окно с кнопкой ОК. Скрипты сохраняются как .app и запускаются двойным кликом как обычные программы.' },
        { t: 'code', code: `display dialog "Привет, macOS!"

-- с заголовком и двумя кнопками
display dialog "Сохранить изменения?" ¬
    with title "Редактор" ¬
    buttons {"Отмена", "Сохранить"} ¬
    default button "Сохранить"` },
        { t: 'p', html: 'Символ <code>¬</code> — продолжение строки (option+Enter на Mac), позволяет разбить длинную команду. Комментарии — от <code>--</code> до конца строки или <code>(*)</code> блочные. Диалог возвращает запись-результат: {button returned:"Сохранить"}.' },
        { t: 'note', html: 'Английский синтаксис — фирменная черта AppleScript: команды читаются как фразы. Это делает язык дружелюбным к новичкам, но строгая грамматика за внешней простотой остаётся полноценной.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Покажи диалог "Кофе готов?" с кнопками {"Да", "Ещё 5 минут"}.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'display dialog с текстом', all: ['display\\s+dialog\\s+"Кофе готов\\?"'] },
          { desc: 'Список кнопок задан', all: ['buttons\\s*\\{\\s*"Да",\\s*"Ещё 5 минут"\\s*\\}'] }
        ],
        note: 'Форма: display dialog "…" buttons {…}'
      },
      hints: [
        'Кнопки — список в фигурных скобках.',
        'Вопросительный знак внутри строки — обычный символ.'
      ],
      solution: `display dialog "Кофе готов?" buttons {"Да", "Ещё 5 минут"}`
    },

    {
      id: 'applescript-2',
      title: 'set и переменные',
      goal: 'Присваивать значения командой set и склеивать строки',
      xp: 35,
      theory: [
        { t: 'p', html: 'Переменные создаются командой <code>set имя to значение</code> — обратите внимание на предлог to, а не знак равенства. Типы угадываются автоматически: числа, строки, списки, даты. Склейка строк — оператор <code>&</code>.' },
        { t: 'code', code: `set name to "Аня"
set age to 30
display dialog "Привет, " & name & ", тебе " & age

set message to name & " слушает музыку"
display dialog message` },
        { t: 'p', html: 'Результат диалога можно сохранить: <code>set answer to button returned of (display dialog …)</code> — вытащить, какую кнопку нажали. Операция «of» читается справа налево: «кнопка, возвращённая диалогом».' },
        { t: 'code', code: `set answer to button returned of (display dialog "Чай или кофе?" buttons {"Чай", "Кофе"})
display dialog "Вы выбрали: " & answer` },
        { t: 'note', html: 'Имена переменных могут содержать пробелы, если обёрнуты вертикальными чертами: <code>set |номер заказа| to 5</code>. Обычно пишут camelCase без пробелов.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые слова присваивания и склейки.</p>',
        code: `{{0}} user to "Мария"
{{1}} city to "Казань"
{{2}} text to user & " из " & city
display dialog text`,
        blanks: [
          { answer: 'set' },
          { answer: 'set' },
          { answer: 'set' }
        ],
        ci: false
      },
      hints: [
        'Присваивание — set … to …',
        'Склейка строк — амперсанд, но в этой задаче нужны только set.'
      ],
      solution: ['set', 'set', 'set']
    },

    {
      id: 'applescript-3',
      title: 'Списки',
      goal: 'Хранить наборы значений, обращаться по индексу и длина',
      xp: 40,
      theory: [
        { t: 'p', html: 'Список — фигурные скобки: <code>set fruits to {"яблоко", "груша"}</code>. Элементы нумеруются с ЕДИНИЦЫ: <code>item 1 of fruits</code>. Длина — <code>count of fruits</code>. Добавление — <code>set end of list to x</code> или конкатенация &.' },
        { t: 'code', code: `set fruits to {"яблоко", "груша", "слива"}

item 1 of fruits        → яблоко
count of fruits         → 3
set end of fruits to "айва"
count of fruits         → 4

first item of fruits    → яблоко
last item of fruits     → айва` },
        { t: 'p', html: 'Достать несколько — <code>items 2 thru 3 of fruits</code> (срез). Обратить список — <code>reverse of fruits</code>. Списки иммутабельны в стиле: операции возвращают новые значения, оригинал не меняется, если не присвоить обратно.' },
        { t: 'code', code: `set nums to {5, 3, 9}
reverse of nums        → {9, 3, 5}
set nums to reverse of nums   -- теперь nums = {9, 3, 5}` },
        { t: 'note', html: 'Списки — основа работы с приложениями: Finder вернёт список файлов, Музыка — список треков. Всё, что «много», приходит списком — обрабатывать их учимся на repeat (уровень 5).' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что покажет последний диалог? Напиши одно слово.</p>',
        code: `set stack to {"A", "B", "C"}
set end of stack to "D"
display dialog item 3 of stack`,
        solution: `C`,
        ci: false
      },
      hints: [
        'Индексация начинается с 1.',
        'item 3 из {A, B, C, D} — третий элемент.'
      ],
      solution: `C`
    },

    {
      id: 'applescript-4',
      title: 'if и сравнения',
      goal: 'Ветвления: if/else и операторы is, is not, is greater than',
      xp: 40,
      theory: [
        { t: 'p', html: 'Условие — <code>if условие then … else if … else … end if</code>. Сравнения читаются английскими словами: <code>is</code> (равно), <code>is not</code>, <code>is greater than</code>, <code>is less than</code>, <code>is greater than or equal to</code>. Числа и строки сравниваются одинаково.' },
        { t: 'code', code: `set temp to 28

if temp is greater than 30 then
    display dialog "Жара!"
else if temp is greater than 20 then
    display dialog "Тепло"
else
    display dialog "Прохладно"
end if` },
        { t: 'p', html: 'Логика: <code>and</code>, <code>or</code>, <code>not</code>. Сравнение строк без учёта регистра — <code>considering case</code>/игнорирование по умолчанию. Краткая форма для одной команды: <code>if x is 5 then display dialog "пять"</code> без end if.' },
        { t: 'code', code: `if score is greater than 89 and attended is true then
    display dialog "Зачёт автоматически"
end if` },
        { t: 'note', html: 'Булевы значения — true и false (строчными). Проверка «ничего не выбрано» — <code>if answer is missing value</code>: missing value — «пусто» в AppleScript.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши проверку возраста: если age больше 17 — диалог "Доступ разрешён", иначе — "Доступ закрыт".</p>',
        starter: `set age to 20
TODO`,
        rules: [
          { desc: 'Условие больше 17', all: ['if\\s+age\\s+is\\s+greater\\s+than\\s+17\\s+then'] },
          { desc: 'Есть else', all: ['else'] },
          { desc: 'Закрыт end if', all: ['end\\s+if'] },
          { desc: 'Оба диалога присутствуют', all: ['"Доступ разрешён"', '"Доступ закрыт"'] }
        ],
        note: 'Форма: if … then / else / end if'
      },
      hints: [
        'Сравнение словами: is greater than.',
        'Каждый if закрывается end if.'
      ],
      solution: `set age to 20
if age is greater than 17 then
    display dialog "Доступ разрешён"
else
    display dialog "Доступ закрыт"
end if`
    },

    {
      id: 'applescript-5',
      title: 'repeat: циклы',
      goal: 'Повторять действия: repeat N times, repeat with и repeat while',
      xp: 45,
      theory: [
        { t: 'p', html: 'Три формы циклов. <code>repeat N times</code> — фиксированное число раз. <code>repeat with x in список</code> — перебор элементов (x — ссылка на элемент). <code>repeat while условие</code> — пока верно; <code>repeat until условие</code> — до тех пор.' },
        { t: 'code', code: `repeat 3 times
    display dialog "Бип!"
end repeat

repeat with f in {"а", "б", "в"}
    display dialog f
end repeat` },
        { t: 'p', html: 'Счётный цикл собирается через переменную и repeat while — либо <code>repeat with i from 1 to 10</code>, специальная форма для диапазона:' },
        { t: 'code', code: `set total to 0
repeat with i from 1 to 10
    set total to total + i
end repeat
display dialog total    -- 55` },
        { t: 'note', html: 'Выход досрочно — <code>exit repeat</code>. Внутри repeat with элемент — ссылка (reference): для значения пишут <code>contents of x</code>, но для строк и чисел AppleScript сам разыменовывает.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что выведет диалог? Одно число.</p>',
        code: `set acc to 1
repeat with i from 1 to 4
    set acc to acc * i
end repeat
display dialog acc`,
        solution: `24`,
        ci: false
      },
      hints: [
        'Цикл перемножает 1 × 2 × 3 × 4.',
        'Это факториал четырёх.'
      ],
      solution: `24`
    },

    {
      id: 'applescript-6',
      title: 'Handlers: свои команды',
      goal: 'Определять функции (handlers) с параметрами и вызывать их',
      xp: 50,
      theory: [
        { t: 'p', html: 'Собственные команды называются <b>handlers</b>: <code>on имя(параметры) … end имя</code>. Вызов — просто <code>имя(аргументы)</code>. Handler без параметров вызывается через <code>my имя()</code> внутри tell-блоков (уровень 7).' },
        { t: 'code', code: `on greet(name, city)
    return "Привет, " & name & " из " & city & "!"
end greet

set msg to greet("Игорь", "Сочи")
display dialog msg` },
        { t: 'p', html: 'English-стиль обработчиков: <code>on greet from name in city</code> — читается фразой. Возврат значения — <code>return</code>. Переменные handler-а локальны; глобальные объявляют <code>global x</code> или свойством скрипта <code>property x : 0</code>.' },
        { t: 'code', code: `property visitCount : 0

on registerVisit()
    set visitCount to visitCount + 1
end registerVisit

registerVisit()
registerVisit()
display dialog visitCount   -- 2` },
        { t: 'note', html: 'property живёт между запусками сохранённого скрипта — простейшее хранилище состояния. Для счётчиков и настроек это работает без файлов.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери handler удвоения и его вызов.</p>',
        code: `{{0}} double(n)
    return n * 2
{{1}} double

set result to {{2}}(21)
display dialog result`,
        blanks: [
          { answer: 'on' },
          { answer: 'end' },
          { answer: 'double' }
        ],
        ci: false
      },
      hints: [
        'Handler начинается on и заканчивается end имя.',
        'Вызов — имя handler-а с аргументом в скобках.'
      ],
      solution: ['on', 'end', 'double']
    },

    {
      id: 'applescript-7',
      title: 'tell: разговор с приложениями',
      goal: 'Управлять приложениями через tell-блоки',
      xp: 50,
      theory: [
        { t: 'p', html: 'Суперсила AppleScript — <b>Apple Events</b>: скрипт посылает команды приложениям. Блок <code>tell application "Имя" … end tell</code> адресует всё содержимое приложению: внутри пишешь его команды — open, quit, activate и словарь конкретной программы.' },
        { t: 'code', code: `tell application "Finder"
    activate
    make new Finder window
end tell

tell application "Safari"
    activate
    make new document with properties {URL:"https://apple.com"}
end tell` },
        { t: 'p', html: 'У каждого приложения свой <b>словарь</b> (dictionary) команд — смотри его в Редакторе скриптов: Файл → Открыть словарь. Finder умеет файлы и папки, Музыка — треки и плейлисты, Почта — письма. Общая структура: <code>tell application … tell … to команда</code>.' },
        { t: 'code', code: `tell application "Music"
    play
    delay 5
    pause
end tell

tell application "Terminal"
    do script "ls -la"
end tell` },
        { t: 'note', html: 'delay N — пауза в секундах, полезна между действиями. Команды приложений асинхронны: tell не всегда ждёт завершения — delay даёт системе время.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери tell-блок для Finder: открыть окно и подождать.</p>',
        code: `{{0}} application "Finder"
    activate
    make new Finder window
    {{1}} 2
{{2}} tell`,
        blanks: [
          { answer: 'tell' },
          { answer: 'delay' },
          { answer: 'end' }
        ],
        ci: false
      },
      hints: [
        'Блок начинается tell application.',
        'Пауза — delay, конец блока — end tell.'
      ],
      solution: ['tell', 'delay', 'end']
    },

    {
      id: 'applescript-8',
      title: 'Finder и файлы',
      goal: 'Перечислять папки, перемещать и переименовывать файлы',
      xp: 55,
      theory: [
        { t: 'p', html: 'Finder — главный словарь файлов. <code>every file of folder "…"</code> — список файлов папки, <code>name of every file</code> — только имена. Путь записывается строкой с <code>POSIX file</code> или colon-путём "Macintosh HD:Users:…".' },
        { t: 'code', code: `tell application "Finder"
    set f to folder (POSIX file "/Users/me/Desktop")
    set names to name of every file of f
end tell

return names` },
        { t: 'p', html: 'Действия с файлами: <code>move файл to папка</code>, <code>delete</code> (в Корзину), <code>duplicate</code> — копия. Фильтрация — <code>every file of f whose name extension is "pdf"</code> — whose-фильтр, аналог SQL WHERE прямо в языке.' },
        { t: 'code', code: `tell application "Finder"
    set pdfs to every file of desktop whose name extension is "pdf"
    move pdfs to folder (POSIX file "/Users/me/Documents/PDF")
end tell` },
        { t: 'note', html: 'whose-выражения — одна из красивейших фишек AppleScript: запрос «все файлы с расширением pdf» пишется одной фразой английского языка и выполняется приложением.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что вернёт выражение?</p>',
        code: `tell application "Finder"
    set xs to name of every file of desktop whose name extension is "png"
end tell`,
        options: [
          `Список всех файлов рабочего стола`,
          `Список имён png-файлов`,
          `Число png-файлов`,
          `Ошибку`
        ],
        correct: 1,
        explain: 'whose отфильтровал по расширению, name of every file вернул СПИСОК ИМЁН отобранных png-файлов.'
      },
      hints: [
        'whose — фильтр по свойству.',
        'name of every file — именно имена.'
      ],
      solution: `Список имён png-файлов`
    },

    {
      id: 'applescript-9',
      title: 'Строки и даты',
      goal: 'Обрабатывать текст: length, text items, работа с датами',
      xp: 55,
      theory: [
        { t: 'p', html: 'Строки — тоже объекты: <code>length of s</code> — длина, <code>text 1 thru 5 of s</code> — срез, <code>offset of "x" in s</code> — позиция подстроки. Разбиение — через text item delimiters: временно меняешь разделитель, получаешь text items.' },
        { t: 'code', code: `set s to "один;два;три"
set AppleScript's text item delimiters to ";"
set parts to text items of s
set AppleScript's text item delimiters to ""
-- parts = {"один", "два", "три"}` },
        { t: 'p', html: 'Даты: <code>current date</code> — сейчас; компоненты — <code>year of d</code>, <code>month of d</code>, <code>day of d</code>, <code>time string of d</code>. Арифметика дат — просто вычитание в секундах. Форматирование собирается конкатенацией компонентов.' },
        { t: 'code', code: `set d to current date
set stamp to (year of d) & "-" & (month of d) & "-" & (day of d)
display dialog stamp` },
        { t: 'note', html: 'Обязательно возвращай разделители к пустой строке после разбиения — иначе все следующие склейки строк в скрипте сломаются. Классическая ошибка AppleScript-новичков.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь команды работы со строками: длина и срез.</p>',
        code: `set s to "AppleScript"
{{0}} of s               → 10
{{1}} 1 {{2}} 5 of s      → Apple`,
        blanks: [
          { answer: 'length' },
          { answer: 'text' },
          { answer: 'thru' }
        ],
        ci: false
      },
      hints: [
        'Длина строки — length.',
        'Срез — text N thru M of s.'
      ],
      solution: ['length', 'text', 'thru']
    },

    {
      id: 'applescript-10',
      title: 'Проект: сортировщик рабочего стола',
      goal: 'Собрать инструмент: диалог, whose-фильтры, перемещение файлов, отчёт',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финал — реальный инструмент: раскладывает файлы рабочего стола по папкам по типу. Собирается из изученного: whose-запросы Finder, списки, цикл repeat with, счётчики и финальный диалог-отчёт. Двадцать строк — и Mac сам наводит порядок.' },
        { t: 'code', code: `set movedCount to 0

tell application "Finder"
    set desk to desktop
    set images to every file of desk whose name extension is "png" or name extension is "jpg"

    if not (exists folder "Картинки" of desk) then
        make new folder at desk with properties {name:"Картинки"}
    end if

    move images to folder "Картинки" of desk
    set movedCount to count of images
end tell

display dialog "Убрано файлов: " & movedCount` },
        { t: 'list', items: [
          '<b>whose … or …</b> — составной фильтр типов;',
          '<b>if not exists folder</b> — защита от повторного создания;',
          '<b>move … to folder</b> — перенос пачки;',
          '<b>count of</b> — статистика для отчёта.'
        ] },
        { t: 'note', html: 'Расширь проект: добавь папки для PDF и документов, счётчик по каждой категории и обработчик «папка уже создана». Сохранённый как .app, этот скрипт — полноценное macOS-приложение, написанное без Xcode.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери ядро сортировщика: whose-фильтр png-файлов desktop и их перенос в папку "Картинки" внутри tell-блока Finder.</p>',
        starter: `tell application "Finder"
    TODO
end tell`,
        rules: [
          { desc: 'Фильтр png-файлов', all: ['every\\s+file\\s+of\\s+desktop\\s+whose\\s+name\\s+extension\\s+is\\s+"png"'] },
          { desc: 'Перенос в папку Картинки', all: ['move\\s+[^\\s][^\\n]*\\s+to\\s+folder\\s+"Картинки"'] }
        ],
        note: 'set imgs to every file … whose …; move imgs to folder "Картинки"'
      },
      hints: [
        'Сначала сохрани выборку в переменную.',
        'Потом move переменной to folder "Картинки".'
      ],
      solution: `tell application "Finder"
    set imgs to every file of desktop whose name extension is "png"
    move imgs to folder "Картинки"
end tell`
    }
  ]
};
