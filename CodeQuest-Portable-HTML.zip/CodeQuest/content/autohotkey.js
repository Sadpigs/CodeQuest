'use strict';
/* ============ CodeQuest — курс AutoHotkey ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.autohotkey = {
  id: 'autohotkey',
  title: 'AutoHotkey',
  emoji: '⌨️',
  color: '#6a9a1f',
  lang: 'autohotkey',
  tagline: 'Хоткеи и автоматизация Windows: 10 уровней',
  description: 'Легендарный язык макросов Windows: превращает любые комбинации клавиш в целые сценарии — автозамены, запуск программ, автоматизация окон. За 10 уровней: hotkeys и Send, переменные, условия, циклы, функции, hotstrings, управление окнами и проект-набор хоткеев.',

  levels: [

    {
      id: 'autohotkey-1',
      title: 'Первый hotkey',
      goal: 'Понять формат ::клавиша::действие и создать свой хоткей',
      xp: 30,
      theory: [
        { t: 'p', html: 'AutoHotkey (AHK) живёт в .ahk-файлах: скрипт запускается двойным кликом и висит в трее, перехватывая назначенные клавиши. Базовая конструкция — <b>hotkey</b>: <code>::клавиши::</code> и под ним действие. Модификаторы: <code>^</code> Ctrl, <code>!</code> Alt, <code>+</code> Shift, <code>#</code> Win.' },
        { t: 'code', code: `; Ctrl+Alt+T открывает Блокнот
^!t::Run notepad.exe

; Win+G — калькулятор
#g::Run calc.exe` },
        { t: 'p', html: '<code>Run</code> запускает программу, файл или URL. Комментарии — с точки с запятой <code>;</code>. Перезагрузить изменённый скрипт — правый клик по иконке в трее → Reload Script, или вынеси Reload на хоткей.' },
        { t: 'code', code: `; Win+R — перезагрузить сам скрипт
#r::Reload

; Ctrl+Escape — выход из скрипта
^Escape::ExitApp` },
        { t: 'note', html: 'Симолы-модификаторы запоминаются фразой: Caret (^) вверх — Ctrl, восклицание (bang!) — Alt, плюс — Shift, hash (#) — Win. Их можно комбинировать: ^+#s — Ctrl+Shift+Win+S.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Создай хоткей Ctrl+Shift+N (модификаторы ^ и +), запускающий notepad.exe.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Модификаторы ^ и +', all: ['\\^\\+\\w+::'] },
          { desc: 'Клавиша N', all: ['\\^\\+n::'] },
          { desc: 'Run notepad.exe', all: ['Run\\s+notepad\\.exe'] }
        ],
        note: 'Форма: ^+n::Run notepad.exe'
      },
      hints: [
        'Ctrl = ^, Shift = +.',
        'Запуск программы — команда Run.'
      ],
      solution: `^+n::Run notepad.exe`
    },

    {
      id: 'autohotkey-2',
      title: 'Send: нажатия за пользователя',
      goal: 'Посылать клавиатурные нажатия и текст в активное окно',
      xp: 35,
      theory: [
        { t: 'p', html: '<code>Send</code> эмулирует набор на клавиатуре: Send hello — напечатает hello в текущее поле ввода. Спецклавиши в фигурных скобках: <code>{Enter}</code>, <code>{Tab}</code>, <code>{Up}</code>, <code>{Ctrl down}…{Ctrl up}</code> — зажать и отпустить.' },
        { t: 'code', code: `; Ctrl+Alt+E: шаблон письма
^!e::
Send Дорогой коллега,
Send {Enter}{Enter}
Send С уважением,
return` },
        { t: 'p', html: 'Обрати внимание на <code>return</code> в конце многострочного хоткея — он закрывает блок. <code>SendInput</code> — быстрый вариант Send (надёжнее при быстрой печати), <code>Sleep 500</code> — пауза в миллисекундах между действиями.' },
        { t: 'code', code: `^!d::
Send {Ctrl down}c{Ctrl up}   ; копировать выделенное
Sleep 300
Send ^v                       ; и вставить
return` },
        { t: 'note', html: 'Send работает с текущим активным окном. Управлять тем, КАКОЕ окно активно, учимся на 8-м уровне (WinActivate).' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери хоткей: печать текста, Enter, пауза, ещё текст.</p>',
        code: `^!m::
{{0}} Привет!
{{1}} 500
Send {{2}}
return`,
        blanks: [
          { answer: 'Send' },
          { answer: 'Sleep' },
          { answer: '{Enter}' }
        ],
        ci: false
      },
      hints: [
        'Печать — Send, пауза — Sleep.',
        'Enter в фигурных скобках.'
      ],
      solution: ['Send', 'Sleep', '{Enter}']
    },

    {
      id: 'autohotkey-3',
      title: 'Переменные',
      goal: 'Присваивать значения и вставлять их в строки',
      xp: 40,
      theory: [
        { t: 'p', html: 'Переменные не требуют объявлений: <code>x = 5</code> (классический синтаксис) или современный <code>x := 5</code>. Символ <code>:=</code> — «вычислить выражение»: формулы, склейки строк через точку <code>.</code>. Подстановка значения в текст — <code>%x%</code>.' },
        { t: 'code', code: `name := "Иван"
age := 25
MsgBox Привет, %name%!

total := age * 2
full := "Итог: " . total
MsgBox %full%` },
        { t: 'p', html: '<code>MsgBox</code> — окно с сообщением. В классическом синтаксисе после MsgBox пишут текст с %переменными%; в выражениях — переменную через запятую. Двойные кавычки в выражениях обозначают строки.' },
        { t: 'code', code: `; вычисление и вывод
price := 100
count := 3
total := price * count
MsgBox Сумма: %total% руб.` },
        { t: 'warn', html: 'Два синтаксиса путают новички: <code>x = привет</code> — присвоить ТЕКСТ «привет», <code>x := привет</code> — присвоить значение ПЕРЕМЕННОЙ привет. Современный стиль — всегда := с кавычками вокруг строк.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что покажет MsgBox? Одно число.</p>',
        code: `a := 7
b := 3
c := a * b
d := c - 11
MsgBox %d%`,
        solution: `10`,
        ci: false
      },
      hints: [
        'Сначала 7 × 3 = 21.',
        'Затем 21 − 11.'
      ],
      solution: `10`
    },

    {
      id: 'autohotkey-4',
      title: 'if и сравнения',
      goal: 'Ветвления с if/else в выражениях',
      xp: 40,
      theory: [
        { t: 'p', html: 'Условия в современном AHK — <code>if (выражение)</code> со скобками: внутри обычные операторы == != &gt; &lt; &gt;= &lt;=, и оператор <code>&amp;&amp;</code> (и), <code>||</code> (или), <code>!</code> (не). Цепочка if/else if/else без then.' },
        { t: 'code', code: `hour := A_Hour

if (hour < 12) {
    MsgBox Доброе утро
} else if (hour < 18) {
    MsgBox Добрый день
} else {
    MsgBox Добрый вечер
}` },
        { t: 'p', html: 'Встроенные переменные дают системе состояние: <code>A_Hour</code> — текущий час, <code>A_ScreenWidth</code> — ширина экрана, <code>A_Now</code> — дата-время, <code>A_Clipboard</code> — буфер обмена. Через них пишутся умные хоткеи, реагирующие на контекст.' },
        { t: 'code', code: `if (A_Clipboard != "") {
    MsgBox В буфере есть текст длиной %A_ClipboardLen%
}` },
        { t: 'note', html: 'Фигурные скобки обязательны для многострочных блоков. Для однострочного действия можно писать в строку: if (x > 5) { MsgBox больше }.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши проверку буфера: если A_Clipboard не пуст (не равно ""), показать MsgBox "Есть данные", иначе — "Пусто".</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Сравнение буфера', all: ['if\\s*\\(\\s*A_Clipboard\\s*(!=|=)\\s*""\\s*\\)'] },
          { desc: 'Есть else', all: ['else'] },
          { desc: 'Оба сообщения', all: ['MsgBox[ \\t]+Есть данные', 'MsgBox[ \\t]+Пусто'] }
        ],
        note: 'Не пусто: A_Clipboard != ""'
      },
      hints: [
        'Скобки вокруг условия обязательны.',
        'Неравно в выражениях — !=.'
      ],
      solution: `if (A_Clipboard != "") {
    MsgBox Есть данные
} else {
    MsgBox Пусто
}`
    },

    {
      id: 'autohotkey-5',
      title: 'Loop',
      goal: 'Повторять действия: Loop N и Loop Parse',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>Loop N</code> повторяет блок N раз; счётчик — встроенная <code>A_Index</code> (1, 2, 3…). Выход досрочно — <code>break</code>, следующая итерация — <code>continue</code>. Для перебора строк-разделителей есть <code>Loop Parse</code>.' },
        { t: "code", code: `Loop 5 {
    MsgBox Проход номер %A_Index%
}

; таблица квадратов
Loop 10 {
    sq := A_Index * A_Index
    text .= sq . " "
}
MsgBox %text%` },
        { t: 'p', html: 'Оператор <code>.=</code> — «дописать» (конкатенация с накоплением), аналог += для строк. Loop Parse разбирает строку по разделителю — частая задача при обработке CSV и логов:' },
        { t: 'code', code: `list := "чай,кофе,какао"
Loop Parse, list, ","
{
    MsgBox Элемент: %A_LoopField%
}` },
        { t: 'note', html: 'A_LoopField — текущий элемент разбора. Loop с файлами (Loop Files, *.txt) перебирает файлы папки — готовый обход директорий без внешних инструментов.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что покажет MsgBox? Одно число.</p>',
        code: `total := 0
Loop 4 {
    total := total + A_Index
}
MsgBox %total%`,
        solution: `10`,
        ci: false
      },
      hints: [
        'A_Index пробегает 1, 2, 3, 4.',
        '1 + 2 + 3 + 4 = 10.'
      ],
      solution: `10`
    },

    {
      id: 'autohotkey-6',
      title: 'Функции',
      goal: 'Определять функции с параметрами и возвращать значения',
      xp: 50,
      theory: [
        { t: 'p', html: 'Функция — <code>Имя(параметры) { … return значение }</code>. Локальные переменные функции не видны снаружи. Вызов в выражении: <code>x := Скидка(500)</code>. Параметры по умолчанию: <code>Имя(a, b := 10)</code>.' },
        { t: 'code', code: `Скидка(price) {
    if (price > 1000)
        return price * 0.1
    return price * 0.05
}

MsgBox % Скидка(2000)    ; 200
MsgBox % Скидка(500)     ; 25` },
        { t: 'p', html: 'Функции удобно комбинировать с хоткеями: hotkey — «триггер», функция — «механика». Так один и тот же сценарий вешается на разные клавиши и вызывается из нескольких мест скрипта.' },
        { t: 'code', code: `^!1::MsgBox % Время()
^!2::MsgBox % Дата()

Время() {
    return A_Hour . ":" . A_Min
}
Дата() {
    return A_DD . "." . A_MM . "." . A_YYYY
}` },
        { t: 'note', html: 'MsgBox % функция() — знак % после MsgBox переключает его в режим выражений: без него текст принял бы значение буквально.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери функцию и её вызов.</p>',
        code: `{{0}} Площадь(w, h) {
    {{1}} w * h
}

{{2}} := Площадь(5, 4)
MsgBox %res%`,
        blanks: [
          { answer: '' },
          { answer: 'return' },
          { answer: 'res' }
        ],
        ci: false
      },
      hints: [
        'Объявление функции — просто имя со скобками и телом.',
        'Результат — return, приём — переменная :=.'
      ],
      solution: ['Площадь', 'return', 'res']
    },

    {
      id: 'autohotkey-7',
      title: 'Hotstrings',
      goal: 'Автозамены по тексту: ::abbr::расшифровка',
      xp: 50,
      theory: [
        { t: 'p', html: '<b>Hotstring</b> — срабатывание по набранному тексту: <code>::btw::by the way</code> — после набора btw и пробела AHK заменит на «by the way». Это убивает рутину: адреса, подписи, шаблоны писем одной строкой каждая.' },
        { t: 'code', code: `::btw::by the way
::адр::г. Москва, ул. Ленина, д. 1
::спс::Спасибо за помощь!
::почта::ivan@example.com` },
        { t: 'p', html: 'Опции hotstring пишутся перед первым двоеточием: <code>:*:</code> — срабатывать без пробела сразу, <code>:c:</code> — учитывать регистр, <code>:r:</code> — не расширять спецсимволы. Многострочная замена берётся в скобки-продолжение.' },
        { t: 'code', code: `:*:шаб::
(
Уважаемый клиент!
Спасибо за обращение.
С уважением, поддержка
)
return` },
        { t: 'note', html: 'Hotstrings + горячие папки — рецепт «корпоративного GPT-текстов»: набор двух букв разворачивает готовый документ. Тысячи людей экономят часы еженедельно на одной этой фиче.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Создай hotstring без ожидания пробела (:*:): набор «qqq» разворачивается в «Здравствуйте!».</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Мгновенный триггер :*:', all: [':\\*:'] },
          { desc: 'Сокращение qqq', all: [':\\*:qqq::'] },
          { desc: 'Развёрнутый текст', all: ['::Здравствуйте!'] }
        ],
        note: 'Форма: :*:qqq::Здравствуйте!'
      },
      hints: [
        'Мгновенность — опция * между двоеточиями.',
        'Расшифровка пишется после второго ::'
      ],
      solution: `:*:qqq::Здравствуйте!`
    },

    {
      id: 'autohotkey-8',
      title: 'Окна: WinActivate и WinGet',
      goal: 'Находить окна, активировать и посылать им действия',
      xp: 55,
      theory: [
        { t: 'p', html: 'Команды окон работают с <b>WinTitle</b> — заголовком или классом окна: <code>WinActivate "Калькулятор"</code> — вывести окно на передний план, <code>WinWait</code> — подождать появления, <code>IfWinExist</code> — проверить наличие, <code>WinClose</code> — закрыть.' },
        { t: 'code', code: `^!c::Run calc.exe

^!+c::
WinWait "Калькулятор", , 3
WinActivate "Калькулятор"
Send 12{Enter}
return` },
        { t: 'p', html: '<code>WinGetTitle</code> — получить заголовок активного окна, <code>WinGetClass</code> — класс. Класс окна (ahk_class Notepad) надёжнее заголовка: он не меняется от открытого документа. <code>#IfWinActive</code> — контекстные хоткеи, работающие только в заданном приложении:' },
        { t: 'code', code: `#IfWinActive ahk_class Notepad
^s::MsgBox Сохранение перехвачено в Блокноте
#IfWinActive` },
        { t: 'note', html: 'Window Spy (входит в AHK) показывает заголовок и класс любого окна под курсором — главный инструмент при написании скриптов под конкретную программу.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери сценарий: ждать окно, активировать, отправить текст.</p>',
        code: `{{0}} "Калькулятор", , 3
{{1}} "Калькулятор"
{{2}} 5{+}3{Enter}`,
        blanks: [
          { answer: 'WinWait' },
          { answer: 'WinActivate' },
          { answer: 'Send' }
        ],
        ci: false
      },
      hints: [
        'Ожидание — WinWait, активация — WinActivate.',
        'Нажатия — Send.'
      ],
      solution: ['WinWait', 'WinActivate', 'Send']
    },

    {
      id: 'autohotkey-9',
      title: 'GUI: свои окна',
      goal: 'Строить мини-формы с полями и кнопками',
      xp: 55,
      theory: [
        { t: 'p', html: 'AHK умеет строить окна: <code>Gui</code> создаёт форму, <code>Gui Add, Edit</code> — поле ввода, <code>Gui Add, Button</code> — кнопку с обработчиком gМетка, <code>Gui Show</code> — показать. Чтение поля — <code>GuiControlGet</code> или <code>ControlGetText</code>.' },
        { t: 'code', code: `Gui Add, Text,, Введите имя:
Gui Add, Edit, vUserName w200
Gui Add, Button, gShowHello Default, ОК
Gui Show
return

ShowHello:
Gui Submit
MsgBox Привет, %UserName%!
ExitApp` },
        { t: 'p', html: 'Префикс <code>v</code> в параметрах — имя переменной поля (vUserName), <code>w200</code> — ширина 200 пикселей. Метка обработчика задаётся <code>gИмяМетки</code>; <code>Gui Submit</code> сохраняет значения полей в переменные.' },
        { t: 'note', html: 'Gui + Tool — маленькое окно без рамки, Gui Show w300 h150 — фиксированный размер. На базе Gui пишут лаунчеры, меню-шорткаты и формы ввода данных за пару десятков строк.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что означает vUserName в Gui Add, Edit, vUserName w200?</p>',
        options: [
          `Имя переменной, куда сохранится значение поля`,
          `Заголовок поля`,
          `Ширину поля`,
          `Начальное значение`
        ],
        correct: 0,
        explain: 'Префикс v задаёт имя переменной поля: после Gui Submit значение поля окажется в UserName.'
      },
      hints: [
        'v — variable.',
        'Gui Submit собирает значения полей.'
      ],
      solution: `Имя переменной, куда сохранится значение поля`
    },

    {
      id: 'autohotkey-10',
      title: 'Проект: личная панель хоткеев',
      goal: 'Собрать набор: хоткеи запуска, hotstring-шаблоны, функция и Gui',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финальный проект — личная панель продуктивности: запуск программ на клавиши, шаблоны текста, умная функция даты и Gui-меню. Такой файл часто становится самым используемым скриптом пользователя — он живёт в трее годами.' },
        { t: 'code', code: `; --- Запуск программ ---
^!b::Run "C:\\Program Files\\Browser\\browser.exe"
^!n::Run notepad.exe

; --- Шаблоны ---
::@почта::ivan@example.com
::дата::
    FormatTime, today, , dd.MM.yyyy
    Send %today%
return

; --- Функция штампа времени ---
Stamp() {
    FormatTime, t, , yyyy-MM-dd HH:mm
    return t
}

^!t::MsgBox % Stamp()` },
        { t: 'list', items: [
          '<b>Run</b> — программы на хоткеи;',
          '<b>Hotstrings</b> — почта и шаблоны;',
          '<b>FormatTime</b> — форматирование даты;',
          '<b>Функция + MsgBox %</b> — вывод значения.'
        ] },
        { t: 'note', html: 'Формат FormatTime: dd.MM.yyyy — день.месяц.год, HH:mm — часы.минуты. Автозапуск панели при загрузке Windows — положить ярлык скрипта в папку shell:startup. Теперь у тебя есть всё, чтобы автоматизировать свою рабочую машину.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери часть панели: hotstring :*:прив::Здравствуйте! и хоткей ^!d, который Send-ом печатает дату через FormatTime в переменную today.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Hotstring с мгновенным триггером', all: [':\\*:прив::Здравствуйте!'] },
          { desc: 'Хоткей Ctrl+Alt+D', all: ['\\^!d::'] },
          { desc: 'Форматирование времени', all: ['FormatTime,\\s*today,\\s*,\\s*dd\\.MM\\.yyyy'] },
          { desc: 'Вставка переменной Send %today%', all: ['Send\\s+%today%'] }
        ],
        note: 'Порядок: hotstring, затем блок хоткея с FormatTime и Send.'
      },
      hints: [
        'FormatTime, today, , dd.MM.yyyy — команда с переменной-результатом.',
        'Send %today% — подстановка значения.'
      ],
      solution: `:*:прив::Здравствуйте!

^!d::
    FormatTime, today, , dd.MM.yyyy
    Send %today%
return`
    }
  ]
};
