'use strict';
/* ============ CodeQuest — курс Batch (Windows) ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.batch = {
  id: 'batch',
  title: 'Batch',
  emoji: '🪟',
  color: '#6e6e6e',
  lang: 'batch',
  tagline: 'Скрипты cmd.exe: 10 уровней',
  description: 'Язык .bat-файлов Windows: автоматизация файлов, папок и программ без установки чего-либо — cmd.exe есть на каждой машине. За 10 уровней: echo и переменные, параметры, условия, goto и циклы for, вызовы, работа с файлами и финальный скрипт-архиватор.',

  levels: [

    {
      id: 'batch-1',
      title: 'echo и первый .bat',
      goal: 'Создать bat-файл, вывести текст и отключить эхо команд',
      xp: 30,
      theory: [
        { t: 'p', html: 'Batch — язык сценариев командной строки Windows. Файл с расширением <code>.bat</code> содержит команды cmd.exe, выполняемые по строкам сверху вниз. Создай файл <code>hello.bat</code> в Блокноте, запиши две строки и запусти двойным кликом.' },
        { t: 'code', code: `@echo off
echo Привет, мир!` },
        { t: 'p', html: '<code>echo</code> печатает текст. <code>@echo off</code> — обязательная первая строка любого аккуратного скрипта: она отключает эхо (показ самих команд перед выполнением). Без неё консоль замусоривается служебным выводом, с ней — видно только результаты.' },
        { t: 'list', items: [
          '<b>@</b> перед командой — не показывать саму команду;',
          '<b>echo off</b> — отключить эхо для всех последующих;',
          '<b>echo.</b> — пустая строка;',
          '<b>pause</b> — «Нажмите любую клавишу», чтобы окно не закрылось.'
        ] },
        { t: 'note', html: 'Комментарий — <code>REM текст</code> или <code>:: текст</code>. Двойное двоеточие — быстрый хак-метка, часто используется как «комментарий-строка».' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери каркас скрипта: отключи эхо со знаком @, выведи "Начинаем работу" и поставь pause.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Эхо отключено с @', all: ['@echo\\s+off'] },
          { desc: 'Вывод текста', all: ['echo\\s+Начинаем работу'] },
          { desc: 'Пауза в конце', all: ['^\\s*pause\\s*$'] }
        ],
        note: 'Три строки: @echo off, echo …, pause'
      },
      hints: [
        'Первая строка всегда @echo off.',
        'Текст после echo пишется без кавычек.'
      ],
      solution: `@echo off
echo Начинаем работу
pause`
    },

    {
      id: 'batch-2',
      title: 'Переменные set',
      goal: 'Создавать переменные командой set и подставлять их через %…%',
      xp: 35,
      theory: [
        { t: 'p', html: 'Переменные создаются <code>set имя=значение</code> — без пробелов вокруг знака равенства! Подстановка значения — <code>%имя%</code>. Значение живёт до конца работы скрипта; пробелы в set попадают в значение, поэтому пишут set name=Иван плотно.' },
        { t: 'code', code: `@echo off
set name=Иван
set age=25
echo Меня зовут %name%, мне %age% лет` },
        { t: 'p', html: 'Арифметика — через <code>set /a</code>: команда вычислит выражение и положит результат в переменную. Поддерживаются + - * / и скобки. Ввод пользователя — <code>set /p имя=Подсказка</code>:' },
        { t: 'code', code: `set /a total = 5 * 12
echo %total%

set /p city=Где ты живёшь?
echo Город: %city%` },
        { t: 'warn', html: 'Ловушка: <code>set name=Иван </code> с пробелом в конце сохранит значение «Иван » с хвостом-пробелом. Всегда пиши set без пробелов до и после = — их любит ставить редактор автоматически.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь команды: создание переменной, арифметика, ввод с подсказкой.</p>',
        code: `@echo off
{{0}} price=100
{{1}} /a total=%price%*3
echo Итого: %total%
{{2}} /p name=Как тебя зовут?
echo Привет, %name%!`,
        blanks: [
          { answer: 'set' },
          { answer: 'set' },
          { answer: 'set' }
        ],
        ci: false
      },
      hints: [
        'Переменные создаются только командой set.',
        '/a — арифметика, /p — ввод пользователя.'
      ],
      solution: ['set', 'set', 'set']
    },

    {
      id: 'batch-3',
      title: 'Параметры %1',
      goal: 'Принимать аргументы командной строки',
      xp: 40,
      theory: [
        { t: 'p', html: 'Скрипту можно передать аргументы: <code>script.bat файл.txt 42</code>. Внутри они доступны как <code>%1</code>, <code>%2</code> … <code>%9</code> по номеру. <code>%0</code> — имя самого скрипта. Это делает .bat переиспользуемым инструментом, а не жёсткой последовательностью.' },
        { t: 'code', code: `@echo off
echo Первый аргумент: %1
echo Второй: %2
echo Всего аргументов: аргументы — %*` },
        { t: 'p', html: 'Проверка «передали ли аргумент» — через <code>if "%1"==""</code>: пустая подстановка означает, что аргумента не было. Кавычки вокруг %1 защищают от аргументов с пробелами.' },
        { t: 'code', code: `@echo off
if "%1"=="" (
    echo Использование: %0 имя_файла
    exit /b 1
)
echo Обрабатываю %1` },
        { t: 'note', html: '<code>exit /b 1</code> завершает скрипт с кодом ошибки 1 — так скрипты сообщают вызывателям о неудаче. 0 — успех, всё прочее — ошибка.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши скрипт-приветствие: если первый аргумент пуст — выведи "Укажи имя", иначе — "Привет, %1".</p>',
        starter: `@echo off
TODO`,
        rules: [
          { desc: 'Проверка пустого аргумента', all: ['if\\s+"%1"==""'] },
          { desc: 'Сообщение при пустом', all: ['echo\\s+Укажи имя'] },
          { desc: 'Приветствие с аргументом', all: ['echo\\s+Привет,\\s*%1'] }
        ],
        note: 'Образец: if "%1"=="" ( … ) else ( … )'
      },
      hints: [
        'Пустой аргумент: if "%1"=="" (…).',
        'Ветка else выводит Привет, %1.'
      ],
      solution: `@echo off
if "%1"=="" (
    echo Укажи имя
) else (
    echo Привет, %1
)`
    },

    {
      id: 'batch-4',
      title: 'if и сравнения',
      goal: 'Сравнивать строки и числа, использовать if exist',
      xp: 40,
      theory: [
        { t: 'p', html: 'Условия: <code>if условие (команда) else (команда)</code>. Для чисел — ключи <code>equ</code>, <code>neq</code>, <code>lss</code>, <code>leq</code>, <code>gtr</code>, <code>geq</code> (равно, не равно, меньше…). Для строк — просто == или <code>if /i</code> для сравнения без учёта регистра.' },
        { t: 'code', code: `if %age% gtr 17 echo взрослый
if /i "%answer%"=="да" echo согласен
if not "%pass%"=="secret" echo отказано` },
        { t: 'p', html: 'Специальные проверки файлов: <code>if exist файл</code> — существует ли файл или папка; <code>if errorlevel 1</code> — вернула ли предыдущая команда ошибку. Это основа скриптов-проверок перед копированием и удалением.' },
        { t: 'code', code: `if exist "C:\\backup" (
    echo Папка есть
) else (
    mkdir "C:\\backup"
)` },
        { t: 'note', html: 'mkdir создаёт папку (можно с вложенностью сразу: mkdir a\\b\\c). del удаляет файлы, rmdir /s — папку с содержимым. Осторожно: удаление из bat не восстанавливается из корзины!' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что выведет скрипт при age=20?</p>',
        code: `set age=20
if %age% gtr 65 (echo пенсионер) else (if %age% gtr 17 (echo взрослый) else (echo ребёнок))`,
        options: [
          `пенсионер`,
          `взрослый`,
          `ребёнок`,
          `ошибка`
        ],
        correct: 1,
        explain: '20 не больше 65 — идём в else; внутри else 20 больше 17 — вывод "взрослый". Вложенные if в Batch допустимы в скобках.'
      },
      hints: [
        'Сначала проверяется внешнее условие.',
        'gtr = «больше».'
      ],
      solution: `взрослый`
    },

    {
      id: 'batch-5',
      title: 'goto и метки',
      goal: 'Управлять потоком переходами на метки',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>goto метка</code> прыгает на строку с <code>:метка</code>. Это единственный «контроль потока» классического Batch: циклы и меню строятся переходами. В сочетании с if получаются ветвления произвольной глубины.' },
        { t: 'code', code: `@echo off
:menu
echo 1 — старт, 2 — выход
set /p choice=
if "%choice%"=="1" goto start
if "%choice%"=="2" goto end
goto menu

:start
echo Поехали!
goto end

:end
pause` },
        { t: 'p', html: 'Метки начинаются с двоеточия и занимают собственную строку. Классический паттерн — бесконечное меню: goto menu возвращает в начало до выбора валидного пункта. Структурно это то же while-цикл.' },
        { t: 'warn', html: 'goto-спагетти — реальная опасность Batch: программа с десятком переходов перестаёт читаться. Правило: метки как «главы» (menu, start, end), поток — сверху вниз, переходы только назад к началу глав или к end.' },
        { t: 'note', html: '<code>goto :eof</code> — специальная метка конца файла: выход из «функции» при call-вызове (уровень 7).' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери мини-меню: метка menu, вывод пунктов, проверка выбора 1 — переход на start, иначе goto menu. Метка start выводит "Работаю".</p>',
        starter: `@echo off
TODO`,
        rules: [
          { desc: 'Метка menu', all: ['^\\s*:menu'] },
          { desc: 'Выбор проверяется', all: ['if\\s+"%choice%"=="1"\\s+goto\\s+start'] },
          { desc: 'Возврат в меню', all: ['goto\\s+menu'] },
          { desc: 'Метка start с выводом', all: [':start', 'echo\\s+Работаю'] }
        ],
        note: 'Скелет: :menu → set /p → if → goto'
      },
      hints: [
        'Метка — строка :menu.',
        'После блока start поставь pause и не забудь остановку скрипта.'
      ],
      solution: `@echo off
:menu
echo Введи 1 для старта
set /p choice=
if "%choice%"=="1" goto start
goto menu

:start
echo Работаю
pause`
    },

    {
      id: 'batch-6',
      title: 'Цикл for',
      goal: 'Перебирать списки и файлы циклами for',
      xp: 45,
      theory: [
        { t: 'p', html: 'Batch-цикл <code>for</code> перебирает списки: <code>for %%x in (a b c) do echo %%x</code>. В файле .bat переменная цикла пишется с ДВУМЯ процентами <code>%%x</code>; в командной строке — с одним. Это постоянный источник ошибок новичков.' },
        { t: 'code', code: `@echo off
for %%i in (1 2 3) do echo Элемент %%i

:: по файлам папки
for %%f in (*.txt) do echo Файл: %%f` },
        { t: 'p', html: 'Ключи for открывают мощные режимы: <code>for /l %%i in (1,1,10)</code> — счётчик от 1 до 10 с шагом 1 (начало, шаг, конец); <code>for /d</code> — папки; <code>for /r</code> — рекурсивно по подпапкам. Числовые вычисления внутри — set /a.' },
        { t: 'code', code: `@echo off
for /l %%i in (1,1,5) do (
    set /a sq=%%i*%%i
    echo %%i в квадрате = !sq!
)` },
        { t: 'warn', html: 'В примере выше !sq! требует отложенного расширения: в начале скрипта нужен <code>setlocal enabledelayedexpansion</code>. Внутри одного блока скобок %sq% раскроется ОДИН раз до цикла — классическая ловушка Batch.' },
        { t: 'note', html: 'setlocal создаёт локальную область переменных: изменения после него не утекут в вызывающую сессию. endlocal закрывает область.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери счётный цикл 1..5 в bat-файле.</p>',
        code: `@echo off
{{0}} /l %%i in (1,1,{{1}}) do echo Шаг %%i`,
        blanks: [
          { answer: 'for' },
          { answer: '5' }
        ],
        ci: false
      },
      hints: [
        'Счётный цикл — ключ /l у for.',
        'Формат (начало, шаг, конец): конец 5.'
      ],
      solution: ['for', '5']
    },

    {
      id: 'batch-7',
      title: 'call и псевдофункции',
      goal: 'Вызывать подпрограммы-метки с параметрами',
      xp: 50,
      theory: [
        { t: 'p', html: 'В Batch нет функций, но есть <code>call :метка аргументы</code> — переход в подпрограмму с возвратом. Внутри подпрограммы аргументы видны как %1, %2, выход — <code>goto :eof</code> (конец файла) или exit /b. Возвращаемое значение передают через переменную.' },
        { t: 'code', code: `@echo off
call :greet Иван
call :add 5 7
echo Сумма: %result%
goto :eof

:greet
echo Привет, %1!
goto :eof

:add
set /a result=%1+%2
goto :eof` },
        { t: 'p', html: 'Обрати внимание: главный поток обязан закончиться <code>goto :eof</code>, иначе после него «провалится» выполнение в подпрограммы. Так собираются библиотеки-помощники: подпрограмма логирования, проверки файла, конвертации.' },
        { t: 'list', items: [
          '<b>call :метка</b> — вызов подпрограммы;',
          '<b>%1, %2</b> — параметры внутри неё;',
          '<b>exit /b N</b> — выход с кодом N;',
          '<b>goto :eof</b> — просто вернуться.'
        ] },
        { t: 'note', html: 'Реальные .bat-инструменты (сборка, деплой) строятся именно так: главная секция-диспетчер + подпрограммы-шаги. Читается как псевдо-функциональная программа.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые слова механизма подпрограмм.</p>',
        code: `@echo off
{{0}} :double 6
echo Результат: %res%
goto :eof

:double
{{1}} /a res=%1*2
{{2}} :eof`,
        blanks: [
          { answer: 'call' },
          { answer: 'set' },
          { answer: 'goto' }
        ],
        ci: false
      },
      hints: [
        'Вызов подпрограммы — call :метка.',
        'Возврат — goto :eof.'
      ],
      solution: ['call', 'set', 'goto']
    },

    {
      id: 'batch-8',
      title: 'Файлы и папки',
      goal: 'Копировать, переименовывать и проверять файлы командами',
      xp: 50,
      theory: [
        { t: 'p', html: 'Команды файловой системы: <code>copy</code> и <code>xcopy</code> — копирование (xcopy умеет папки рекурсивно с /e), <code>move</code> — перенос/переименование, <code>del</code> — удаление файлов, <code>mkdir</code>/<code>rmdir</code> — папки, <code>dir</code> — список. С ними и if exist строятся скрипты бэкапа.' },
        { t: 'code', code: `@echo off
if not exist backup mkdir backup
copy *.txt backup\\
echo Скопировано файлов: 
dir /b backup | find /c /v ""` },
        { t: 'p', html: 'Пример использует <b>конвейер</b> <code>|</code>: вывод dir передаётся find для подсчёта строк — то же перенаправление, что в Unix. Другие перенаправления: <code>&gt; файл</code> записать, <code>&gt;&gt;</code> дописать, <code>&lt;</code> прочитать из файла.' },
        { t: 'code', code: `echo Лог запуска > log.txt
echo Строка 2 >> log.txt
type log.txt` },
        { t: 'note', html: 'wildcard-шаблоны * и ? работают в copy/del/dir: *.txt — все текстовые, report?.csv — report с одним любым символом. dir /b — «только имена», /s — рекурсивно.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Скрипт бэкапа: если папки backup нет — создать (mkdir), затем скопировать все .txt в неё.</p>',
        starter: `@echo off
TODO`,
        rules: [
          { desc: 'Проверка отсутствия папки', all: ['if\\s+not\\s+exist\\s+backup'] },
          { desc: 'Создание папки', all: ['mkdir\\s+backup'] },
          { desc: 'Копирование txt-файлов', all: ['copy\\s+\\*\\.txt\\s+backup'] }
        ],
        note: 'Образец: if not exist X ( mkdir X )'
      },
      hints: [
        'Отрицание — if not exist.',
        'Шаблон всех текстовых файлов — *.txt.'
      ],
      solution: `@echo off
if not exist backup (
    mkdir backup
)
copy *.txt backup\\`
    },

    {
      id: 'batch-9',
      title: 'setlocal и коды выхода',
      goal: 'Изолировать переменные и обрабатывать ошибки команд',
      xp: 55,
      theory: [
        { t: 'p', html: 'Профессиональный скрипт начинается с <code>setlocal</code> (переменные не утекут в систему) и проверяет коды выхода: каждая команда выставляет <code>errorlevel</code> — 0 успех, не-0 ошибка. Проверка <code>if errorlevel 1</code> означает «ошибка есть» (уровень 1 или выше).' },
        { t: 'code', code: `@echo off
setlocal

copy data.csv archive\\data.csv
if errorlevel 1 (
    echo ОШИБКА: не удалось скопировать
    exit /b 1
)
echo Успешно.
endlocal
exit /b 0` },
        { t: 'p', html: 'Код выхода скрипта — последний exit /b N: его видят планировщик задач, CI-системы и другие скрипты, которые этот bat вызывают. Платформенный контракт: 0 — ок, всё прочее — проблема. Так .bat встраивается в конвейеры сборки.' },
        { t: 'list', items: [
          '<b>setlocal/endlocal</b> — область переменных;',
          '<b>errorlevel</b> — код последней команды;',
          '<b>exit /b N</b> — выход с кодом;',
          '<b>||</b> — «если ошибка»: copy x y || echo fail.'
        ] },
        { t: 'note', html: 'Операторы && и || работают как в Unix: <code>cmd1 && cmd2</code> — cmd2 при успехе cmd1. Однострочные обработчики ошибок часто пишут именно так.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Каркас надёжного скрипта: setlocal, команда del старого лога с проверкой не нужна — просто выведи "Готово" и заверши с кодом 0 (exit /b 0).</p>',
        starter: `@echo off
TODO`,
        rules: [
          { desc: 'Локальные переменные', all: ['setlocal'] },
          { desc: 'Вывод результата', all: ['echo\\s+Готово'] },
          { desc: 'Успешный выход с кодом 0', all: ['exit\\s+/b\\s+0'] }
        ],
        note: 'Три обязательных элемента каркаса.'
      },
      hints: [
        'setlocal — сразу после @echo off.',
        'Финал скрипта — exit /b 0.'
      ],
      solution: `@echo off
setlocal
echo Готово
exit /b 0`
    },

    {
      id: 'batch-10',
      title: 'Проект: скрипт резервного копирования',
      goal: 'Собрать инструмент: параметры, проверки, копирование, лог',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финальный проект — скрипт бэкапа папки: принимает исходную папку и папку назначения, создаёт папку с датой в имени, копирует файлы, пишет лог. Дата и время доступны в переменных <code>%date%</code> и <code>%time%</code> — для имени бэкапа их чистят от недопустимых символов.' },
        { t: 'code', code: `@echo off
setlocal

set src=%1
set dst=%2

if "%src%"=="" goto usage
if not exist "%src%" (
    echo Нет такой папки: %src%
    exit /b 1
)

set stamp=%date:~6,4%-%date:~3,2%-%date:~0,2%
set target=%dst%\\backup-%stamp%
mkdir "%target%"

xcopy "%src%\\*.*" "%target%\\" /e /q
echo [%date% %time%] Бэкап в %target% >> backup.log
exit /b 0

:usage
echo Использование: backup.bat источник назначение
exit /b 1` },
        { t: 'list', items: [
          '<b>Параметры %1 %2</b> — источник и назначение;',
          '<b>Проверки if</b> — аргумент передан, папка есть;',
          '<b>Срез даты %date:~6,4%</b> — подстрока с 6-й позиции 4 символа;',
          '<b>xcopy /e /q</b> — всё содержимое без болтовни;',
          '<b>&gt;&gt; backup.log</b> — журнал бэкапов.'
        ] },
        { t: 'note', html: 'Срез %переменная:~начало,длина% — единственный способ вытащить часть строки в Batch. Такой скрипт вешается на планировщик Windows и бэкапит папку каждую ночь — реальная рабочая автоматизация из 20 строк.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь недостающие команды проекта.</p>',
        code: `set src=%1
if "%src%"=="" {{0}} usage
if not exist "%src%" exit /b 1
mkdir "%dst%\\backup-%stamp%"
xcopy "%src%\\*.*" "%dst%\\backup-%stamp%\\" /{{1}} /q
echo Бэкап >> {{2}}`,
        blanks: [
          { answer: 'goto' },
          { answer: 'e' },
          { answer: 'backup.log' }
        ],
        ci: false
      },
      hints: [
        'Переход на метку ошибки — goto usage.',
        'xcopy /e копирует подпапки; лог пишется дописыванием >>.'
      ],
      solution: ['goto', 'e', 'backup.log']
    }
  ]
};
