'use strict';
/* ============ CodeQuest — курс COBOL ============
   COBOL не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
   Ключевые слова в заданиях пишутся ПРОПИСНЫМИ буквами —
   так выглядит традиционный банковский COBOL.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.cobol = {
  id: 'cobol',
  title: 'COBOL',
  emoji: '🏦',
  color: '#2f7fbf',
  lang: 'cobol',
  tagline: 'Язык банка: от DIVISION до ведомости — 10 уровней',
  description: 'Язык бизнеса 1959 года, в создании которого участвовала Грейс Хоппер. Английские слова вместо символов сделали COBOL языком банков и государств: порядка 220 миллиардов строк до сих пор работают в банкоматах, страховании и платёжных системах. За 10 уровней освоим DIVISION и PIC-картинки, глаголы MOVE и COMPUTE (ROUNDED, SIZE ERROR), таблицы OCCURS с PERFORM VARYING, файлы LINE SEQUENTIAL — и соберём две зарплатные программы (GnuCOBOL).',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'cobol-1',
      title: 'Первая программа',
      goal: 'Собрать каркас COBOL-программы: IDENTIFICATION DIVISION, PROGRAM-ID, PROCEDURE DIVISION, DISPLAY и STOP RUN',
      xp: 30,
      theory: [
        { t: 'p', html: 'COBOL (COmmon Business-Oriented Language) появился в 1959 году по заказу министерства обороны США: комитет CODASYL хотел язык, на котором бухгалтерские задачи писали бы не только математики. Огромную роль сыграла Грейс Хоппер — автор одного из первых компиляторов и идей «языка, похожего на английский». Результат: сегодня около 220 миллиардов строк COBOL обслуживают банки, страхование и госсистемы, а через банковские системы на COBOL ежедневно проходят транзакции на триллионы долларов.' },
        { t: 'h', html: 'Минимальная программа' },
        { t: 'code', code: `IDENTIFICATION DIVISION.
PROGRAM-ID. HELLO.
PROCEDURE DIVISION.
    DISPLAY "Hello, CodeQuest!".
    STOP RUN.` },
        { t: 'p', html: 'Программа на COBOL делится на разделы — <b>DIVISION</b>. <code>IDENTIFICATION DIVISION.</code> — паспорт программы: в нём <code>PROGRAM-ID.</code> задаёт имя. <code>PROCEDURE DIVISION.</code> открывает собственно код: операторы (глаголы) пишутся с отступом, каждое предложение заканчивается <b>точкой</b>. <code>DISPLAY</code> печатает, <code>STOP RUN.</code> завершает работу программы.' },
        { t: 'list', items: [
          '<b>IDENTIFICATION DIVISION.</b> — паспорт программы;',
          '<b>PROGRAM-ID. имя</b> — имя программы;',
          '<b>PROCEDURE DIVISION.</b> — начало исполняемого кода;',
          '<b>DISPLAY "текст"</b> — вывод на экран;',
          '<b>STOP RUN.</b> — конец работы.'
        ] },
        { t: 'note', html: 'Компилятор — свободный GnuCOBOL: <b>cobc -x hello.cob -o hello</b>, затем <b>./hello</b>. Ключ -x означает «собрать исполняемую программу». Классический COBOL пишется ПРОПИСНЫМИ БУКВАМИ — хотя компилятору регистр безразличен, банковский код десятилетиями велся капсом. В этом курсе все задания пишутся именно верхним регистром, и проверки ожидают ключевые слова прописными.' },
        { t: 'warn', html: 'Точка в конце предложения — часть синтаксиса: забудешь её, и компилятор приклеит следующий оператор к предыдущему. Фигурных скобок в языке нет — структура задаётся разделами, отступами и точками.' },
        { t: 'p', html: 'DISPLAY умеет несколько операндов через запятую: <code>DISPLAY "a = ", 5</code>. Собери каркас, выведи фразу и корректно завершись — и ты написал первую строку в армию из 220 миллиардов.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первую программу на COBOL: паспорт с именем <code>HELLO</code>, процедурный раздел, вывод фразы <code>Привет, CodeQuest!</code> через <code>DISPLAY</code> и корректное завершение <code>STOP RUN.</code> Не забудь точки после предложений. Ключевые слова — ПРОПИСНЫМИ.</p>',
        starter: `IDENTIFICATION DIVISION.
PROGRAM-ID. HELLO.
PROCEDURE DIVISION.
    *> TODO: выведи приветствие и заверши программу`,
        rules: [
          { desc: 'Раздел IDENTIFICATION DIVISION. на месте', all: ['IDENTIFICATION\\s+DIVISION\\s*\\.'] },
          { desc: 'Имя программы задано через PROGRAM-ID.', all: ['PROGRAM-ID\\.\\s*\\w+'] },
          { desc: 'Вывод через DISPLAY с текстом в кавычках', all: ['DISPLAY\\s+"[^"]+"'] },
          { desc: 'Выведена фраза "Привет, CodeQuest!"', all: ['"Привет, CodeQuest!"'] },
          { desc: 'Есть завершение STOP RUN., пометок TODO нет', all: ['PROCEDURE\\s+DIVISION\\s*\\.', 'STOP\\s+RUN\\s*\\.', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Первые три строки каркаса уже правильные — допиши только тело PROCEDURE DIVISION.',
        'Вывод: DISPLAY "Привет, CodeQuest!". — с точкой в конце предложения.',
        'Завершение: STOP RUN. — двумя словами и точкой.'
      ],
      solution: `IDENTIFICATION DIVISION.
PROGRAM-ID. HELLO.
PROCEDURE DIVISION.
    DISPLAY "Привет, CodeQuest!".
    STOP RUN.`
    },

    /* ---------- 2. Данные и PIC-картинки ---------- */
    {
      id: 'cobol-2',
      title: 'Данные и PIC-картинки',
      goal: 'Описывать данные в WORKING-STORAGE: уровни 01, PIC-картинки 9 и X, VALUE и глагол MOVE',
      xp: 30,
      theory: [
        { t: 'p', html: 'Переменные в COBOL живут в разделе данных. <code>DATA DIVISION.</code> открывает его, <code>WORKING-STORAGE SECTION.</code> — секция памяти программы: поля, которые создаются при старте и живут до конца работы. Каждое поле описывается строкой: уровень, имя, картинка, начальное значение.' },
        { t: 'code', code: `DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-COUNT  PIC 9(3) VALUE 120.
01 WS-NAME   PIC X(10) VALUE "АНЯ".
01 WS-PRICE  PIC 9(3)V99 VALUE 12.5.` },
        { t: 'p', html: '<code>01</code> — номер уровня записи: для простых полей всегда 01 (уровни 05, 10 и дальше группируют записи в иерархии). Имена — до 30 символов из букв, цифр и дефисов; по традиции префикс <code>WS-</code> (working storage). <code>PIC</code> (сокращение от PICTURE) — «картинка» данных: символ <b>9</b> означает цифру, <b>X</b> — любой символ, <b>A</b> — букву.' },
        { t: 'table', head: ['Картинка', 'Смысл', 'Хранит 25 как'], rows: [
          ['9(3)', 'три цифры', '025'],
          ['X(10)', '10 любых символов', '"АНЯ       "'],
          ['9(3)V99', 'три цифры, точка, две цифры', '025.00'],
          ['S9(4)', 'четыре цифры со знаком', '+0025']
        ] },
        { t: 'p', html: '<code>VALUE</code> задаёт начальное значение. Ведущие нули хранятся честно: <code>PIC 9(3) VALUE 25</code> — это ровно <code>025</code>, и DISPLAY напечатает 025. Буква <b>V</b> — мнимая десятичная точка: символа в данных она не занимает, но делит разряды при счёте — <code>9(3)V99</code> держит три цифры до копеек и две после.' },
        { t: 'p', html: 'Глагол <code>MOVE</code> копирует данные: <code>MOVE 30 TO WS-COUNT</code> или <code>MOVE "АНЯ" TO WS-NAME</code>. Получатель перезаписывается целиком, значение подгоняется под его картинку.' },
        { t: 'warn', html: 'Картинка — это жёсткая рамка: поле <code>9(2)</code> вмещает максимум 99, положишь 123 — старший разряд потеряется молча, без ошибки. Такова плата за фиксированные поля перфокарточной эпохи. И помни: ключевые слова и имена полей в этом курсе пишутся ПРОПИСНЫМИ.' },
        { t: 'note', html: 'Строки в классическом COBOL — в двойных кавычках (одинарные тоже допустимы, но в банковском коде традиционны двойные). Комментарий в свободном формате — <code>*&gt;</code> до конца строки.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни описание склада: цифра для счёта в картинке <code>PIC {{0}}(3)</code> — сам символ цифры, символ для текстового поля, начальное значение цены <code>12.5</code> и глагол, который копирует 200 в <code>WS-COUNT</code>. Ключевые слова — прописными.</p>',
        code: `IDENTIFICATION DIVISION.
PROGRAM-ID. STOCK.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-COUNT  PIC {{0}}(3) VALUE 120.
01 WS-NAME   PIC {{1}}(10) VALUE "АНЯ".
01 WS-PRICE  PIC 9(3)V99 VALUE {{2}}.
PROCEDURE DIVISION.
    {{3}} 200 TO WS-COUNT
    DISPLAY "товар: ", WS-NAME
    DISPLAY "склад: ", WS-COUNT
    STOP RUN.`,
        blanks: [
          { answer: '9' },
          { answer: 'X' },
          { answer: '12.5', alt: ['12.50'] },
          { answer: 'MOVE', ci: true }
        ],
        ci: false
      },
      hints: [
        'Цифра в PIC-картинке — символ 9, любой символ — X.',
        'Начальное значение после VALUE пишется как есть: 12.5.',
        'Глагол копирования — MOVE ... TO ...'
      ],
      solution: ['9', 'X', '12.5', 'MOVE']
    },

    /* ---------- 3. PERFORM UNTIL и IF ---------- */
    {
      id: 'cobol-3',
      title: 'PERFORM UNTIL и IF',
      goal: 'Повторять и ветвить по-коболовски: PERFORM UNTIL с END-PERFORM, IF/ELSE с END-IF и глагол ADD',
      xp: 35,
      theory: [
        { t: 'p', html: 'Цикл «пока» в COBOL — <code>PERFORM UNTIL</code>: тело между <code>PERFORM UNTIL условие</code> и <code>END-PERFORM</code> повторяется, пока условие ложно. Условие проверяется перед каждой итерацией: если оно истинно сразу, тело не выполнится ни разу.' },
        { t: 'code', code: `PERFORM UNTIL WS-I > 5
  ADD WS-I TO WS-SUM
  ADD 1 TO WS-I
END-PERFORM.` },
        { t: 'p', html: '<code>ADD a TO b</code> — то же, что b = b + a: значение a прибавляется к b. Арифметические глаголы читаются как английские фразы: <code>SUBTRACT a FROM b</code> (b − a), <code>MULTIPLY a BY b</code>, <code>DIVIDE a INTO b</code>. Условие <code>UNTIL WS-I &gt; 5</code> означает «повторяй, пока не станет больше 5» — счётчик обязан меняться внутри тела, иначе цикл вечный.' },
        { t: 'h', html: 'Ветвление: IF ... ELSE ... END-IF' },
        { t: 'code', code: `IF WS-SUM > 10
  DISPLAY "sum = ", WS-SUM
ELSE
  DISPLAY "мало"
END-IF.` },
        { t: 'p', html: 'Операции сравнения: <code>=</code> равно, <code>&gt;</code>, <code>&lt;</code>, <code>&gt;=</code>, <code>&lt;=</code>, <code>NOT</code> — отрицание. Сложные условия собираются словами <code>AND</code> и <code>OR</code>: <code>IF WS-A &gt; 10 AND WS-B &lt; 5</code>. Точка после <code>END-IF.</code> закрывает всё предложение — она завершает и цикл, и условие разом.' },
        { t: 'warn', html: 'Не путай логику UNTIL с while из других языков: <code>PERFORM UNTIL WS-I &gt; 5</code> — это «пока НЕ больше 5». И следи за картинками: сумма в <code>9(2)</code> не переживёт значение 100.' },
        { t: 'p', html: 'Задание уровня — «предскажи вывод»: прокрути цикл руками, посчитай сумму и реши, какая ветка IF сработает. DISPLAY напечатает текст и значение поля подряд.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай программу и напиши, что выведет <code>DISPLAY</code> — одну строку вывода.</p>',
        code: `IDENTIFICATION DIVISION.
PROGRAM-ID. DEMO.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-I    PIC 9(2) VALUE 1.
01 WS-SUM  PIC 9(2) VALUE 0.
PROCEDURE DIVISION.
    PERFORM UNTIL WS-I > 5
      ADD WS-I TO WS-SUM
      ADD 1 TO WS-I
    END-PERFORM.
    IF WS-SUM > 10
      DISPLAY "sum = ", WS-SUM
    ELSE
      DISPLAY "мало"
    END-IF.
    STOP RUN.`,
        answer: `sum = 15`
      },
      hints: [
        'Цикл копит 1 + 2 + 3 + 4 + 5 — пройди итерации руками.',
        'Цикл остановится, когда WS-I станет равной 6: условие UNTIL WS-I > 5 окажется истинным.',
        'WS-SUM хранится в PIC 9(2) — сумма 15 влезает и выводится без ведущих нулей.'
      ],
      solution: `sum = 15`
    },

    /* ---------- 4. Абзацы и PERFORM ---------- */
    {
      id: 'cobol-4',
      title: 'Абзацы и PERFORM',
      goal: 'Разбивать PROCEDURE DIVISION на абзацы и вызывать их через PERFORM имя-абзаца',
      xp: 40,
      theory: [
        { t: 'p', html: 'Вместо функций в COBOL — <b>абзацы</b> (paragraphs): именованные блоки кода внутри PROCEDURE DIVISION. Абзац начинается с имени и точки и длится до имени следующего абзаца. Это «функции без параметров»: главный абзац-диспетчер вызывает остальных по именам.' },
        { t: 'code', code: `PROCEDURE DIVISION.
MAIN-PARA.
    PERFORM SHOW-TOTAL
    PERFORM SHOW-BYE
    STOP RUN.
SHOW-TOTAL.
    DISPLAY "Итог: 42".
SHOW-BYE.
    DISPLAY "Пока!".` },
        { t: 'p', html: '<code>PERFORM имя-абзаца</code> — «сходи выполнить абзац и вернись»: управление переходит в абзац, после его конца — обратно, к следующему оператору вызывающего. Это главный способ структурировать COBOL-код: MAIN-PARA читается как сценарий, а абзацы SHOW-TOTAL и SHOW-BYE — его шаги.' },
        { t: 'list', items: [
          '<b>MAIN-PARA.</b> — входной абзац-диспетчер;',
          '<b>PERFORM имя</b> — выполнить абзац и вернуться;',
          '<b>имя-абзаца.</b> — метка начала абзаца (с точкой!);',
          '<b>STOP RUN.</b> — завершение, обычно в конце главного абзаца.'
        ] },
        { t: 'note', html: 'Имена абзацев по традиции состоят из глагола или существительного с дефисами: CALC-TOTAL, SHOW-MENU, READ-FILE. Настоящие банковские программы — это сотни абзацев с говорящими именами, и старые программисты читают их как пьесу.' },
        { t: 'warn', html: 'Не поставил точку после имени абзаца — следующий оператор приклеится к имени, и компилятор запутается. После последнего абзаца точка тоже нужна. И помни: код «проваливается» вниз — если уберёшь STOP RUN из MAIN-PARA, управление упадёт в первый нижележащий абзац.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери программу из абзацев: главный <code>MAIN-PARA</code> вызывает через <code>PERFORM</code> два абзаца — <code>SHOW-HELLO</code> (выводит приветствие) и <code>SHOW-BYE</code> (выводит прощание) — и завершается <code>STOP RUN.</code> Каждый абзац объяви именем с точкой и дай ему свой <code>DISPLAY</code>.</p>',
        starter: `IDENTIFICATION DIVISION.
PROGRAM-ID. DEMO.
PROCEDURE DIVISION.
MAIN-PARA.
    *> TODO: вызови два абзаца по именам и объяви их ниже
    STOP RUN.`,
        rules: [
          { desc: 'Абзац SHOW-HELLO объявлен (имя с точкой в начале строки)', all: ['^\\s*SHOW-HELLO\\s*\\.'] },
          { desc: 'Абзац SHOW-BYE объявлен', all: ['^\\s*SHOW-BYE\\s*\\.'] },
          { desc: 'SHOW-HELLO вызывается через PERFORM', all: ['PERFORM\\s+SHOW-HELLO'] },
          { desc: 'SHOW-BYE вызывается через PERFORM', all: ['PERFORM\\s+SHOW-BYE'] },
          { desc: 'Есть DISPLAY и STOP RUN., пометок TODO нет', all: ['DISPLAY\\s+"', 'STOP\\s+RUN\\s*\\.', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Вызовы в MAIN-PARA: PERFORM SHOW-HELLO и PERFORM SHOW-BYE, каждый на своей строке.',
        'Абзац объявляется именем с точкой на отдельной строке: SHOW-HELLO. — и дальше его операторы.',
        'Внутри каждого абзаца — свой DISPLAY со строкой в кавычках и точкой в конце.'
      ],
      solution: `IDENTIFICATION DIVISION.
PROGRAM-ID. DEMO.
PROCEDURE DIVISION.
MAIN-PARA.
    PERFORM SHOW-HELLO
    PERFORM SHOW-BYE
    STOP RUN.
SHOW-HELLO.
    DISPLAY "Привет из абзаца!".
SHOW-BYE.
    DISPLAY "Пока!".`
    },

    /* ---------- 5. Идиомы COBOL ---------- */
    {
      id: 'cobol-5',
      title: 'Идиомы COBOL',
      goal: 'Освоить идиомы: EVALUATE с WHEN OTHER, COMPUTE с формулами, усечение и ROUNDED, ведущие нули картинок',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>EVALUATE</code> — коболовский переключатель: сравнивает выражение с вариантами <code>WHEN</code>, вариант <code>WHEN OTHER</code> ловит всё остальное, закрывается <code>END-EVALUATE</code>. Веток может быть сколько угодно, читается как таблица решений — идеальный формат для тарифов, комиссий и категорий клиентов.' },
        { t: 'code', code: `EVALUATE WS-GRADE
  WHEN 5 DISPLAY "отлично"
  WHEN 4 DISPLAY "хорошо"
  WHEN OTHER DISPLAY "учись"
END-EVALUATE.` },
        { t: 'h', html: 'COMPUTE: формулы' },
        { t: 'p', html: '<code>COMPUTE</code> — единственный глагол, понимающий формулы: <code>COMPUTE WS-R = WS-A * WS-B + 3</code>. Операторы: <code>+ - * /</code> и <code>**</code> (степень), порядок действий как в математике, скобки допустимы. Результат усекается под картинку получателя; запись <code>COMPUTE WS-R ROUNDED = ...</code> округляет вместо усечения.' },
        { t: 'code', code: `COMPUTE WS-SALARY = WS-HOURS * WS-RATE
COMPUTE WS-R ROUNDED = WS-A / WS-B` },
        { t: 'p', html: 'Старая гвардия глаголов никуда не делась: <code>ADD a b GIVING c</code> (c = a + b), <code>SUBTRACT a FROM b</code>, <code>MULTIPLY a BY b GIVING c</code>, <code>DIVIDE a INTO b</code>. COMPUTE появился позже (стандарт COBOL-74), но теперь почти всё считают им — короче и привычнее.' },
        { t: 'warn', html: 'Деление с целыми картинками усекается: 7 / 2 даёт 3.5, но в целое поле ляжет 3 — без ROUNDED дробная часть отбрасывается. А DISPLAY покажет ведущие нули картинки честно: <code>PIC 9(3)</code> со значением 17 — это <code>017</code>. Эти две ловушки — половина багов начинающего кобольщика.' },
        { t: 'p', html: 'Ещё одна классика — редактирующие картинки для людей: <code>PIC Z(4)9</code> заменит ведущие нули пробелами, <code>PIC Z(3)9.99</code> добавит точку. DISPLAY такой картинки печатает уже «человеческое» число — так делают отчёты для того самого банка.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет <code>DISPLAY WS-R</code>?</p><pre>DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-A  PIC 9(2) VALUE 7.
01 WS-B  PIC 9(2) VALUE 2.
01 WS-R  PIC 9(3) VALUE 0.
PROCEDURE DIVISION.
    COMPUTE WS-R = WS-A / WS-B + WS-A * WS-B
    DISPLAY WS-R
    STOP RUN.</pre>`,
        options: [
          '017',
          '17',
          '018',
          'Ошибка: 7/2 — нецелое деление'
        ],
        correct: 0,
        explain: 'COMPUTE считает выражение целиком: 7 / 2 = 3.5, затем 3.5 + 7 * 2 = 17.5. При записи в целую картинку 9(3) дробная часть усекается (ROUNDED нет), остаётся 17. Картинка 9(3) хранит три разряда с ведущим нулём, поэтому DISPLAY покажет 017. С ROUNDED получилось бы 018.',
        solution: 0
      },
      hints: [
        'Сначала посчитай выражение целиком: деление, умножение, потом сложение.',
        'ROUNDED в COMPUTE нет — дробная часть результата усекается.',
        'PIC 9(3) хранит три цифры: недостающие разряды дополняются нулями.'
      ],
      solution: 0
    },

    /* ---------- 6. Проект: Расчёт зарплаты ---------- */
    {
      id: 'cobol-6',
      title: '🚀 Проект: Расчёт зарплаты',
      goal: 'Собрать проект: WORKING-STORAGE с PIC-полями, COMPUTE с умножением и DISPLAY итога',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальный проект — задача, ради которой COBOL и создавали: расчёт зарплаты. Отработанные часы умножаем на ставку с копейками — и выводим итог. Программа соберёт всё из курса: раздел данных с PIC-картинками, глаголы MOVE и COMPUTE, DISPLAY и корректное завершение.' },
        { t: 'h', html: 'Что строим' },
        { t: 'list', items: [
          'поля в <code>WORKING-STORAGE SECTION</code>: <code>WS-HOURS PIC 9(3)</code>, <code>WS-RATE PIC 9(3)V99</code>, <code>WS-SALARY PIC 9(6)V99</code>;',
          'задание часов и ставки — через <code>VALUE</code> или <code>MOVE</code>;',
          'расчёт: <code>COMPUTE WS-SALARY = WS-HOURS * WS-RATE</code>;',
          'вывод итога через <code>DISPLAY</code> и завершение <code>STOP RUN.</code>'
        ] },
        { t: 'code', code: `DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-HOURS  PIC 9(3)    VALUE 160.
01 WS-RATE   PIC 9(3)V99 VALUE 350.5.
01 WS-SALARY PIC 9(6)V99 VALUE 0.
PROCEDURE DIVISION.
    MOVE 350.5 TO WS-RATE
    COMPUTE WS-SALARY = WS-HOURS * WS-RATE
    DISPLAY "Зарплата: ", WS-SALARY
    STOP RUN.` },
        { t: 'p', html: 'Почему COMPUTE, а не MULTIPLY? Вариант <code>MULTIPLY WS-HOURS BY WS-RATE GIVING WS-SALARY</code> тоже верен и принимается заданием. Копейки держит V99: ставка 350.5 хранится как 350.50, и умножение даёт точную сумму с двумя знаками. В примере выше MOVE повторяет VALUE — в реальном коде выбирают что-то одно.' },
        { t: 'warn', html: 'Следи за размером картинки: <code>9(6)V99</code> вмещает до 999999.99 — зарплата влезает, а вот миллионная премия уже нет. Если не задать VALUE и не сделать MOVE, в поле останутся нули, и зарплата честно окажется нулевой. Точку после последнего предложения не потеряй — на ней держится весь язык.' },
        { t: 'note', html: 'После зачёта добавь логику кадровика: <code>IF WS-HOURS &gt; 160</code> — премия <code>ADD 10000 TO WS-SALARY</code>; налог — <code>COMPUTE WS-TAX = WS-SALARY * 0.13</code>; а красивый вывод — через редактирующую картинку <code>PIC Z(5)9.99</code>. Именно так выглядят реальные payroll-системы, которым полвека.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Расчёт зарплаты».</b> В <code>WORKING-STORAGE SECTION</code> объяви поля <code>WS-HOURS</code> (PIC с цифрами), <code>WS-RATE</code> (PIC с копейками, например <code>9(3)V99</code>) и <code>WS-SALARY</code>. Задай часы и ставку (<code>VALUE</code> или <code>MOVE</code>), посчитай зарплату через <code>COMPUTE</code> с умножением (или <code>MULTIPLY ... GIVING</code>) и выведи её через <code>DISPLAY</code>. Заверши <code>STOP RUN.</code> без заглушек.</p>',
        starter: `IDENTIFICATION DIVISION.
PROGRAM-ID. SALARY.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-HOURS  PIC 9(3)    VALUE 0.
01 WS-RATE   PIC 9(3)V99 VALUE 0.
01 WS-SALARY PIC 9(6)V99 VALUE 0.
PROCEDURE DIVISION.
    *> TODO: задай часы и ставку, посчитай и выведи зарплату
    STOP RUN.`,
        rules: [
          { desc: 'Поля объявлены в WORKING-STORAGE SECTION', all: ['WORKING-STORAGE\\s+SECTION'] },
          { desc: 'Есть числовые картинки PIC 9', all: ['PIC\\s+9'] },
          { desc: 'Зарплата считается через COMPUTE с умножением (или MULTIPLY ... GIVING/BY)', any: ['COMPUTE\\s+[A-Z0-9-]+\\s*=[^\\n]*\\*', 'MULTIPLY\\s+[A-Z0-9-]+\\s+(BY|GIVING)'] },
          { desc: 'Итог выводится через DISPLAY со строкой', all: ['DISPLAY\\s+"'] },
          { desc: 'STOP RUN. на месте, пометок TODO нет', all: ['STOP\\s+RUN\\s*\\.', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Задай значения: MOVE 160 TO WS-HOURS и MOVE 350.5 TO WS-RATE (или поменяй VALUE в описаниях).',
        'Расчёт: COMPUTE WS-SALARY = WS-HOURS * WS-RATE — звёздочка обязательна.',
        'Выведи итог строкой: DISPLAY "Зарплата: ", WS-SALARY, затем STOP RUN.'
      ],
      solution: `IDENTIFICATION DIVISION.
PROGRAM-ID. SALARY.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-HOURS  PIC 9(3)    VALUE 160.
01 WS-RATE   PIC 9(3)V99 VALUE 350.5.
01 WS-SALARY PIC 9(6)V99 VALUE 0.
PROCEDURE DIVISION.
    COMPUTE WS-SALARY = WS-HOURS * WS-RATE
    DISPLAY "Зарплата: ", WS-SALARY
    STOP RUN.`
    },

    /* ---------- 7. COMPUTE и точность ---------- */
    {
      id: 'cobol-7',
      title: 'COMPUTE и точность: ROUNDED, SIZE ERROR',
      goal: 'Считать точно: ROUNDED вместо молчаливого усечения и ON SIZE ERROR против переполнения картинки',
      xp: 45,
      theory: [
        { t: 'p', html: 'Уровень про идиомы показал: COMPUTE записывает результат в картинку получателя, и всё, что не влезло в разряды, пропадает. Для дробей это усечение: 17.5 в целое поле превращается в 17 — дробная часть отбрасывается без предупреждения. В финансовых расчётах так теряются копейки, а в больших ведомостях — уже рубли. Ключевое слово <code>ROUNDED</code> меняет правило: результат округляется по законам математики, и 17.5 становится 18.' },
        { t: 'code', code: `COMPUTE WS-TAX ROUNDED = WS-GROSS * 0.13
COMPUTE WS-AVG ROUNDED = WS-SUM / WS-N` },
        { t: 'p', html: 'ROUNDED ставится сразу после имени поля-получателя, до знака равенства. Округление происходит в момент записи в картинку — само выражение считается с полной точностью. Половинки округляются от нуля (режим по умолчанию): 0.5 даст 1. Для денег это то, что нужно — иначе постоянное усечение разведёт твои итоги с бухгалтерией.' },
        { t: 'h', html: 'ON SIZE ERROR: переполнение под контролем' },
        { t: 'code', code: `COMPUTE WS-TAX ROUNDED = WS-GROSS * 0.13
  ON SIZE ERROR
    DISPLAY "налог не влез в поле!"
END-COMPUTE` },
        { t: 'p', html: 'Вторая защита — <code>ON SIZE ERROR</code>. Если результат не помещается в картинку получателя, COBOL по умолчанию молча отрезает СТАРШИЕ разряды: 123456 в поле 9(3) превратится в 456. Это худший вид ошибки — числа становятся меньше, и никто не заметит. Фраза ON SIZE ERROR перехватывает переполнение: вместо порчи данных выполняется блок обработки, а получатель остаётся нетронутым.' },
        { t: 'p', html: 'Многострочный COMPUTE с ON SIZE ERROR закрывается словом <code>END-COMPUTE</code> — как END-IF и END-PERFORM. Есть и обратная ветка NOT ON SIZE ERROR — выполнится, когда всё влезло. Так арифметический глагол превращается в маленькую программу с обработкой ошибок.' },
        { t: 'warn', html: 'Не путай два механизма: ROUNDED работает с ДРОБНОЙ частью (округляет копейки), а ON SIZE ERROR — с переполнением целой части (результат больше, чем разрядов в картинке). Поле 9(3)V99 вмещает до 999.99: налог 16050.00 в него не влезет, и без ON SIZE ERROR усечение оставит в поле 050. Банковские системы обязаны обрабатывать SIZE ERROR — иначе однажды «съедят» миллион.' },
        { t: 'note', html: 'Исторический факт: знаменитая проблема 2000 года (Y2K) отчасти родилась из таких картинок — поля дат описывали всего два разряда года. Явные картинки, ROUNDED и SIZE ERROR — три коболовских инструмента честного счёта, которые работают в банках уже полвека.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни расчёт налога: картинка с тремя цифрами и копейками, слово округления после имени получателя, ключевое слово обработки переполнения и закрывающее слово многострочного COMPUTE. Ключевые слова — прописными.</p>',
        code: `IDENTIFICATION DIVISION.
PROGRAM-ID. TAX.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-GROSS PIC 9(5)V99 VALUE 5000.00.
01 WS-TAX   PIC {{0}}V99 VALUE 0.
PROCEDURE DIVISION.
    COMPUTE WS-TAX {{1}} = WS-GROSS * 0.13
      {{2}} SIZE ERROR
        DISPLAY "налог не влез в поле!"
    END-{{3}}
    DISPLAY "налог: ", WS-TAX
    STOP RUN.`,
        blanks: [
          { answer: '9(3)', alt: ['999'] },
          { answer: 'ROUNDED', ci: true },
          { answer: 'ON', ci: true },
          { answer: 'COMPUTE', ci: true }
        ],
        ci: false
      },
      hints: [
        'Картинка 9(3) — символ 9 с повторителем в скобках: три цифры.',
        'Округление — ROUNDED сразу после имени поля, до знака равенства.',
        'Переполнение ловит пара ON SIZE ERROR ... END-COMPUTE.'
      ],
      solution: ['9(3)', 'ROUNDED', 'ON', 'COMPUTE']
    },

    /* ---------- 8. Таблицы: OCCURS и PERFORM VARYING ---------- */
    {
      id: 'cobol-8',
      title: 'Таблицы: OCCURS и PERFORM VARYING',
      goal: 'Хранить наборы значений в таблицах OCCURS и обходить их циклом PERFORM VARYING с индексом',
      xp: 50,
      theory: [
        { t: 'p', html: 'До сих пор каждое поле хранило одно значение. А что делать с тремя сотрудниками, десятью счетами, месяцами года? Для наборов однотипных значений в COBOL есть таблицы: за описанием поля добавляется фраза <code>OCCURS n TIMES</code> — и поле превращается в n ячеек. Обращение к ячейке — имя и индекс в скобках: <code>WS-HOURS (1)</code>, <code>WS-HOURS (2)</code>.' },
        { t: 'code', code: `DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-HOURS PIC 9(3) OCCURS 3 TIMES.
PROCEDURE DIVISION.
    MOVE 160 TO WS-HOURS (1)
    DISPLAY WS-HOURS (2)` },
        { t: 'p', html: 'Индексы в COBOL считаются с ЕДИНИЦЫ — не с нуля, как в большинстве языков. <code>WS-HOURS (0)</code> — ошибка: ячейки с нулевым индексом не существует. В скобках может стоять не только число, но и поле-счётчик: <code>WS-HOURS (WS-I)</code> — так таблицы обходят циклом.' },
        { t: 'h', html: 'PERFORM VARYING: цикл со счётчиком' },
        { t: 'code', code: `PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > 3
  DISPLAY "часы: ", WS-HOURS (WS-I)
END-PERFORM.` },
        { t: 'p', html: 'PERFORM VARYING — это for из мира COBOL. Читается дословно: «выполняй, изменяя WS-I от 1 с шагом 1, пока WS-I не станет больше 3». Счётчик инициализируется значением FROM, после каждой итерации увеличивается на BY, условие UNTIL проверяется перед каждым витком. Внутри тела к ячейкам таблицы обращаются по этому счётчику — классический обход.' },
        { t: 'table', head: ['Конструкция COBOL', 'Знакомый аналог'], rows: [
          ['OCCURS 3 TIMES', 'массив из 3 элементов'],
          ['WS-HOURS (WS-I)', 'hours[i]'],
          ['PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > 3', 'for (i = 1; i <= 3; i++)']
        ] },
        { t: 'warn', html: 'Следи за размером счётчика: PIC 9 вмещает 0–9 — для таблицы из трёх строк хватает, но для ста ячеек нужен PIC 9(3). И не меняй счётчик руками внутри PERFORM VARYING: он увеличивается сам, ручной ADD сломает логику. Точка после END-PERFORM обязательна.' },
        { t: 'note', html: 'Таблицы бывают и из групп: запись сотрудника с полями имени и ставки повторяется OCCURS 5 TIMES целиком. Есть и INDEXED BY — специальные индексы для быстрого доступа. Это следующий виток: сегодня достаточно простых таблиц и VARYING.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Заполни таблицу часов: три ячейки через <code>MOVE</code> (например, 160, 120 и 140), затем обойди её циклом <code>PERFORM VARYING</code> от 1 до 3, выводя каждую ячейку через <code>DISPLAY</code> по индексу <code>(WS-I)</code>. Закрой цикл <code>END-PERFORM.</code> и заверши программу.</p>',
        starter: `IDENTIFICATION DIVISION.
PROGRAM-ID. TABLES.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-HOURS PIC 9(3) OCCURS 3 TIMES.
01 WS-I     PIC 9 VALUE 1.
PROCEDURE DIVISION.
    *> TODO: заполни таблицу и обойди её циклом PERFORM VARYING
    STOP RUN.`,
        rules: [
          { desc: 'Таблица объявлена с OCCURS и PIC-картинкой', all: ['OCCURS\\s+\\d+\\s+TIMES', 'PIC\\s+9'] },
          { desc: 'Ячейка таблицы адресуется индексом WS-I', all: ['[A-Z][A-Z0-9-]*\\s*\\(\\s*WS-I\\s*\\)'] },
          { desc: 'Цикл PERFORM VARYING ... FROM ... BY ... UNTIL', all: ['PERFORM\\s+VARYING\\s+[A-Z0-9-]+\\s+FROM\\s+\\S+\\s+BY\\s+\\S+\\s+UNTIL\\s+\\S+'] },
          { desc: 'Цикл закрыт через END-PERFORM.', all: ['END-PERFORM\\s*\\.'] },
          { desc: 'Вывод через DISPLAY, программа завершена, TODO нет', all: ['DISPLAY\\s+"', 'STOP\\s+RUN\\s*\\.', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Заполнение: MOVE 160 TO WS-HOURS (1), MOVE 120 TO WS-HOURS (2), MOVE 140 TO WS-HOURS (3).',
        'Цикл: PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > 3, внутри — DISPLAY "часы: ", WS-HOURS (WS-I).',
        'Индекс с единицы, счётчик растёт сам: END-PERFORM закроет цикл, дальше STOP RUN.'
      ],
      solution: `IDENTIFICATION DIVISION.
PROGRAM-ID. TABLES.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-HOURS PIC 9(3) OCCURS 3 TIMES.
01 WS-I     PIC 9 VALUE 1.
PROCEDURE DIVISION.
    MOVE 160 TO WS-HOURS (1)
    MOVE 120 TO WS-HOURS (2)
    MOVE 140 TO WS-HOURS (3)
    PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > 3
      DISPLAY "часы: ", WS-HOURS (WS-I)
    END-PERFORM.
    STOP RUN.`
    },

    /* ---------- 9. Файлы: SELECT, FD, READ ---------- */
    {
      id: 'cobol-9',
      title: 'Файлы: SELECT, FD, READ',
      goal: 'Понять файловый триптих COBOL: SELECT в ENVIRONMENT DIVISION, FD-запись в FILE SECTION и глагол READ с AT END',
      xp: 45,
      theory: [
        { t: 'p', html: 'WORKING-STORAGE живёт только пока программа работает: выключили — данные исчезли. Настоящий учёт требует файлов. Объявление файла начинается не в DATA DIVISION, а раньше: в <code>ENVIRONMENT DIVISION</code>, секции <code>INPUT-OUTPUT SECTION</code>, абзаце <code>FILE-CONTROL</code>.' },
        { t: 'code', code: `ENVIRONMENT DIVISION.
INPUT-OUTPUT SECTION.
FILE-CONTROL.
    SELECT EMP-FILE ASSIGN TO "staff.txt"
        ORGANIZATION IS LINE SEQUENTIAL.` },
        { t: 'p', html: 'SELECT даёт файлу внутреннее имя (EMP-FILE), ASSIGN связывает его с реальным файлом на диске, а <code>ORGANIZATION IS LINE SEQUENTIAL</code> описывает организацию: обычный текстовый файл, где записи разделены переводом строки и читаются строго по порядку. Это самая простая и самая частая организация — логи, выгрузки, отчёты. Для старта с файлами в COBOL ничего удобнее не придумано: одна фраза SELECT — и файл готов к открытию.' },
        { t: 'p', html: 'Описание записи файла живёт в DATA DIVISION, секции <code>FILE SECTION</code>: строка FD с внутренним именем и запись 01 с картинкой — буфер, куда READ кладёт очередную строку файла. Поля записи видны в программе как обычные поля: DISPLAY EMP-REC напечатает всю строку целиком. А разобрать её на части можно MOVE-ами в поля поменьше — картинка подскажет, где кончается одно поле и начинается другое.' },
        { t: 'code', code: `DATA DIVISION.
FILE SECTION.
FD EMP-FILE.
01 EMP-REC PIC X(50).

PROCEDURE DIVISION.
    OPEN INPUT EMP-FILE
    PERFORM UNTIL WS-EOF = "Y"
      READ EMP-FILE
        AT END MOVE "Y" TO WS-EOF
        NOT AT END DISPLAY EMP-REC
      END-READ
    END-PERFORM.
    CLOSE EMP-FILE
    STOP RUN.` },
        { t: 'p', html: 'READ читает следующую запись в буфер FD-записи. Кончился файл — срабатывает ветка <code>AT END</code> (туда обычно ставят флаг конца), иначе — <code>NOT AT END</code> с обработкой строки. Файл открывается OPEN INPUT (чтение) и закрывается CLOSE: файловые глаголы парные, как скобки.' },
        { t: 'table', head: ['Организация', 'Что это'], rows: [
          ['LINE SEQUENTIAL', 'текстовые строки с переводом строки — как обычный .txt'],
          ['SEQUENTIAL', 'записи фиксированной длины без разделителей'],
          ['INDEXED', 'записи с ключом, доступ по ключу'],
          ['RELATIVE', 'записи с номером позиции']
        ] },
        { t: 'warn', html: 'Не перепутай: SELECT живёт в ENVIRONMENT DIVISION, FD — в DATA DIVISION. Имя после ASSIGN — реальное имя файла в кавычках, а FD-запись — картинка ОДНОЙ строки. Забудешь CLOSE — файл останется занят до конца работы программы.' },
        { t: 'note', html: 'GnuCOBOL отлично дружит с LINE SEQUENTIAL: такой файл открывается любым текстовым редактором. Более тяжёлые организации (INDEXED с ключами) — фирменная территория мейнфреймов, где они обслуживают расчёты десятилетиями.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Файл объявлен так:</p><pre>SELECT EMP-FILE ASSIGN TO "staff.txt"
    ORGANIZATION IS LINE SEQUENTIAL.</pre><p>Что означает ORGANIZATION IS LINE SEQUENTIAL?</p>`,
        options: [
          'Файл открывается только для записи, READ по нему запрещён',
          'Записи фиксированной длины без разделителей, доступ по ключу',
          'Файл текстовый: записи разделены переводом строки и читаются строго по порядку',
          'Файл сортируется по возрастанию при каждом открытии'
        ],
        correct: 2,
        explain: 'LINE SEQUENTIAL — организация текстового файла: каждая запись — строка с переводом строки в конце, чтение идёт строго последовательно, от первой записи к последней. Записи фиксированной длины — это SEQUENTIAL, доступ по ключу — INDEXED, а сортировкой организация не занимается.',
        solution: 2
      },
      hints: [
        'Подсказка в самом названии: LINE — строка, SEQUENTIAL — последовательно.',
        'Подумай, чем такой файл отличается от записей фиксированной длины (SEQUENTIAL) и от доступа по ключу (INDEXED).',
        'Именно такой файл открывается обычным текстовым редактором — строки и переводы строк.'
      ],
      solution: 2
    },

    /* ---------- 10. Проект: зарплатная ведомость ---------- */
    {
      id: 'cobol-10',
      title: '🚀 Проект: зарплатная ведомость',
      goal: 'Рассчитать зарплату для таблицы сотрудников: OCCURS, PERFORM VARYING, COMPUTE с ROUNDED и итог через DISPLAY',
      xp: 110,
      theory: [
        { t: 'p', html: 'Итоговый проект — платёжная ведомость: трое сотрудников, у каждого отработанные часы и ставка с копейками. Часы и ставки лежат в двух таблицах OCCURS, цикл PERFORM VARYING обходит сотрудников по одному, COMPUTE с ROUNDED считает зарплату каждого, а итог ведомости копится в отдельном поле и печатается в конце. Так выглядит задача, ради которой COBOL и создавали — только в промышленном масштабе.' },
        { t: 'list', items: [
          '<b>WORKING-STORAGE SECTION</b> — таблицы <code>WS-HOURS</code> и <code>WS-RATE</code> с <code>OCCURS 3 TIMES</code>, поля <code>WS-PAY</code> и <code>WS-TOTAL</code>, счётчик <code>WS-I</code>;',
          '<b>заполнение</b> — <code>MOVE</code> значений в ячейки <code>WS-HOURS (1)</code>…<code>WS-HOURS (3)</code>;',
          '<b>обход</b> — <code>PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I &gt; 3</code>;',
          '<b>расчёт</b> — <code>COMPUTE WS-PAY ROUNDED = WS-HOURS (WS-I) * WS-RATE (WS-I)</code>;',
          '<b>итог</b> — <code>ADD WS-PAY TO WS-TOTAL</code> и <code>DISPLAY</code>.'
        ] },
        { t: 'code', code: `DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-HOURS PIC 9(3)    OCCURS 3 TIMES.
01 WS-RATE  PIC 9(3)V99 OCCURS 3 TIMES.
01 WS-PAY   PIC 9(6)V99 VALUE 0.
01 WS-TOTAL PIC 9(7)V99 VALUE 0.
01 WS-I     PIC 9       VALUE 1.
PROCEDURE DIVISION.
    MOVE 160 TO WS-HOURS (1)
    MOVE 350.50 TO WS-RATE (1)
    PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > 3
      COMPUTE WS-PAY ROUNDED = WS-HOURS (WS-I) * WS-RATE (WS-I)
      ADD WS-PAY TO WS-TOTAL
      DISPLAY "Сотрудник ", WS-I, ": ", WS-PAY
    END-PERFORM.
    DISPLAY "Итого по ведомости: ", WS-TOTAL
    STOP RUN.` },
        { t: 'p', html: 'Обрати внимание на связку: индекс WS-I один на всё — и для чтения ячеек обеих таблиц, и для DISPLAY номера сотрудника. Зарплата каждого попадает в WS-PAY, откуда её подхватывают ADD и DISPLAY. Ставки с копейками дают дробный результат — ROUNDED округляет его честно, без потери копеек.' },
        { t: 'warn', html: 'Размер картинок проверь заранее: WS-PAY 9(6)V99 вмещает до 999999.99 — месячная зарплата влезает, итог 9(7)V99 — до 9999999.99, для ведомости из трёх строк хватает с запасом. Счётчику WS-I хватит PIC 9. И не оставляй пометок-заглушек: проект должен выглядеть как программа, которую завтра запустит бухгалтерия.' },
        { t: 'note', html: 'Куда расти дальше: редактирующие картинки Z(5)9.99 для красивой печати, абзац PRINT-HEADER для шапки ведомости, сортировка SORT и настоящие файлы из уровня 9 вместо MOVE. Настоящие payroll-системы на COBOL устроены ровно так же — только полей больше.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Зарплатная ведомость».</b> В <code>WORKING-STORAGE SECTION</code> объяви две таблицы с <code>OCCURS 3 TIMES</code> (часы и ставки с копейками) и поля для зарплаты, итога и счётчика. Заполни ячейки через <code>MOVE</code>, обойди сотрудников циклом <code>PERFORM VARYING ... UNTIL</code>, посчитай зарплату каждого через <code>COMPUTE ... ROUNDED = ... * ...</code>, добавь её к итогу и выведи строку с номером сотрудника. В конце выведи итог ведомости и заверши <code>STOP RUN.</code></p>',
        starter: `IDENTIFICATION DIVISION.
PROGRAM-ID. PAYROLL.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-I PIC 9 VALUE 1.
PROCEDURE DIVISION.
    *> TODO: объяви таблицы часов и ставок, обойди сотрудников, посчитай зарплаты и итог
    STOP RUN.`,
        rules: [
          { desc: 'Данные объявлены в WORKING-STORAGE SECTION', all: ['WORKING-STORAGE\\s+SECTION'] },
          { desc: 'Таблица с OCCURS n TIMES и PIC-картинкой', all: ['OCCURS\\s+\\d+\\s+TIMES', 'PIC\\s+9'] },
          { desc: 'Обход таблицы PERFORM VARYING ... FROM ... BY ... UNTIL', all: ['PERFORM\\s+VARYING\\s+[A-Z0-9-]+\\s+FROM\\s+\\S+\\s+BY\\s+\\S+\\s+UNTIL\\s+\\S+'] },
          { desc: 'Ячейки таблицы адресуются индексом', all: ['[A-Z][A-Z0-9-]*\\s*\\(\\s*[A-Z0-9-]+\\s*\\)'] },
          { desc: 'Зарплата считается через COMPUTE с ROUNDED и умножением', all: ['COMPUTE\\s+[A-Z0-9-]+\\s+ROUNDED\\s*=[^\\n]*\\*'] },
          { desc: 'Итог выводится через DISPLAY со строкой', all: ['DISPLAY\\s+"'] },
          { desc: 'STOP RUN. на месте, пометок TODO нет', all: ['STOP\\s+RUN\\s*\\.', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Таблицы: 01 WS-HOURS PIC 9(3) OCCURS 3 TIMES. и 01 WS-RATE PIC 9(3)V99 OCCURS 3 TIMES.',
        'Цикл: PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > 3 — внутри COMPUTE WS-PAY ROUNDED = WS-HOURS (WS-I) * WS-RATE (WS-I) и ADD WS-PAY TO WS-TOTAL.',
        'Выведи каждого: DISPLAY "Сотрудник ", WS-I, ": ", WS-PAY; после цикла — итог и STOP RUN.'
      ],
      solution: `IDENTIFICATION DIVISION.
PROGRAM-ID. PAYROLL.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-HOURS PIC 9(3)    OCCURS 3 TIMES.
01 WS-RATE  PIC 9(3)V99 OCCURS 3 TIMES.
01 WS-PAY   PIC 9(6)V99 VALUE 0.
01 WS-TOTAL PIC 9(7)V99 VALUE 0.
01 WS-I     PIC 9       VALUE 1.
PROCEDURE DIVISION.
    MOVE 160 TO WS-HOURS (1)
    MOVE 120 TO WS-HOURS (2)
    MOVE 140 TO WS-HOURS (3)
    MOVE 350.50 TO WS-RATE (1)
    MOVE 420.75 TO WS-RATE (2)
    MOVE 310.25 TO WS-RATE (3)
    PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > 3
      COMPUTE WS-PAY ROUNDED = WS-HOURS (WS-I) * WS-RATE (WS-I)
      ADD WS-PAY TO WS-TOTAL
      DISPLAY "Сотрудник ", WS-I, ": ", WS-PAY
    END-PERFORM.
    DISPLAY "Итого по ведомости: ", WS-TOTAL
    STOP RUN.`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас программы',
      code: `IDENTIFICATION DIVISION.
PROGRAM-ID. HELLO.
PROCEDURE DIVISION.
    DISPLAY "Hello".
    STOP RUN.
*>
*> cobc -x hello.cob -o hello`
    },
    {
      title: 'Разделы программы',
      list: [
        'IDENTIFICATION DIVISION. — паспорт (PROGRAM-ID)',
        'DATA DIVISION. — данные программы',
        'WORKING-STORAGE SECTION. — переменные',
        'PROCEDURE DIVISION. — исполняемый код',
        'каждое предложение заканчивается точкой'
      ]
    },
    {
      title: 'PIC-картинки',
      code: `01 WS-COUNT PIC 9(3)    VALUE 120.
01 WS-NAME  PIC X(10)   VALUE "АНЯ".
01 WS-PRICE PIC 9(3)V99 VALUE 12.5.
*>
*> 9 — цифра, X — любой символ, A — буква
*> V — мнимая десятичная точка
*> 9(3) хранит ведущие нули: 25 → 025`
    },
    {
      title: 'Данные и арифметика',
      code: `MOVE 30 TO WS-COUNT
MOVE "АНЯ" TO WS-NAME
ADD WS-I TO WS-SUM          *> WS-SUM = WS-SUM + WS-I
SUBTRACT 5 FROM WS-COUNT
COMPUTE WS-R = WS-A * WS-B + 1
COMPUTE WS-R ROUNDED = WS-A / WS-B`
    },
    {
      title: 'Условия и циклы',
      code: `IF WS-SUM > 10
  DISPLAY "много"
ELSE
  DISPLAY "мало"
END-IF.

PERFORM UNTIL WS-I > 5
  ADD 1 TO WS-I
END-PERFORM.

EVALUATE WS-GRADE
  WHEN 5 DISPLAY "отлично"
  WHEN OTHER DISPLAY "учись"
END-EVALUATE.`
    },
    {
      title: 'Абзацы и PERFORM',
      code: `PROCEDURE DIVISION.
MAIN-PARA.
    PERFORM SHOW-HELLO
    STOP RUN.
SHOW-HELLO.
    DISPLAY "Привет!".
*>
*> PERFORM имя — выполнить абзац и вернуться
*> имя абзаца закрывается точкой`
    },
    {
      title: 'Таблицы и PERFORM VARYING',
      code: `01 WS-HOURS PIC 9(3) OCCURS 3 TIMES.
01 WS-I     PIC 9 VALUE 1.
*>
PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > 3
  DISPLAY WS-HOURS (WS-I)
END-PERFORM.
*>
*> индексы с единицы, счётчик меняется сам`
    },
    {
      title: 'Точность и файлы',
      code: `COMPUTE WS-TAX ROUNDED = WS-GROSS * 0.13
  ON SIZE ERROR
    DISPLAY "не влезло"
END-COMPUTE
*>
ENVIRONMENT DIVISION.
INPUT-OUTPUT SECTION.
FILE-CONTROL.
    SELECT EMP-FILE ASSIGN TO "staff.txt"
        ORGANIZATION IS LINE SEQUENTIAL.
*>
OPEN INPUT EMP-FILE
READ EMP-FILE
  AT END MOVE "Y" TO WS-EOF
  NOT AT END DISPLAY EMP-REC
END-READ
CLOSE EMP-FILE`
    }
  ]
};
