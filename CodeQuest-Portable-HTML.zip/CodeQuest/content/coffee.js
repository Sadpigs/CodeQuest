'use strict';
/* ============ CodeQuest — курс CoffeeScript ============
   Язык, компилирующийся в JavaScript. Код в приложении не
   запускается: задания проверяются структурным анализом
   (regex по сырому коду), квизами, «предскажи вывод» и fill.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.coffee = {
  id: 'coffee',
  title: 'CoffeeScript',
  emoji: '🍪',
  color: '#7a5ea8',
  lang: 'coffee',
  tagline: 'Легенда 2010-х: от скрипта до классов — 10 уровней',
  description: 'Язык Джереми Ашкенаса (Jeremy Ashkenas), представленный в 2009 году: пишешь лаконичный код, компилятор превращает его в честный JavaScript. Стрелки, классы и деструктуризация из CoffeeScript позже вошли в ES6. За 10 уровней — от первого скрипта до классов с наследованием, splat-ов и деструктуризации, comprehension с фильтром when и проекта «Инвентарь магазина».',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'coffee-1',
      title: 'Первая программа',
      goal: 'Сделать первый скрипт на CoffeeScript: console.log без скобок и компиляция через coffee -c',
      xp: 30,
      theory: [
        { t: 'p', html: 'CoffeeScript — язык, который Джереми Ашкенас (Jeremy Ashkenas, автор Underscore и Backbone) представил в 2009 году. Идея: писать на красивом лаконичном языке, который компилируется один-в-один в обычный JavaScript. В начале 2010-х на нём писали Rails-проекты и целые стартапы, а идеи языка — стрелки, классы, деструктуризация — позже вошли в стандарт ES6. Говорят: учишь CoffeeScript — понимаешь, откуда взялся современный JS.' },
        { t: 'h', html: 'Первый скрипт' },
        { t: 'code', code: `# script.coffee
console.log "Привет, CoffeeScript!"` },
        { t: 'p', html: 'Сохрани файл как <code>script.coffee</code> и скомпилируй: <code>coffee -c script.coffee</code> — рядом появится <code>script.js</code>, обычный JavaScript, который выполняют браузер и node. Команда <code>coffee script.coffee</code> компилирует и сразу запускает, а <code>coffee --watch -c script.coffee</code> пересобирает файл при каждом сохранении.' },
        { t: 'list', items: [
          '<b>без точек с запятыми</b> — конец строки сам завершает выражение;',
          '<b>без фигурных скобок</b> — блоки задаются отступом (2 пробела);',
          '<b>без var/let/const</b> — переменная создаётся присваиванием;',
          '<b>скобки вызова необязательны</b> — console.log "текст";',
          '<b>комментарии</b> — как в JS: от # до конца строки.'
        ] },
        { t: 'note', html: 'Скобки у вызова можно ставить — <code>console.log("текст")</code> тоже корректно. CoffeeScript-программисты их опускают ради выразительности и возвращают там, где без них неоднозначно — например, при вложенных вызовах с несколькими аргументами.' },
        { t: 'warn', html: 'Не переноси привычки из JS: в .coffee-файле нет <code>function</code> — вместо неё стрелка <code>-&gt;</code>, нет <code>var</code>, а фигурные скобки нужны только для объектных литералов. И помни: файл с расширением .js компилятор CoffeeScript не трогает — язык живёт в .coffee.' },
        { t: 'p', html: 'Зачем учить язык-легенду? Во-первых, он до сих пор работает: Ruby on Rails собирал с ним фронтенд, а проекты вроде Atom-плагинов живут на нём и сегодня. Во-вторых, CoffeeScript — лучший «переводчик»: каждый его приём показывает, как устроен соответствующий приём в современном JavaScript.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Сделай первый скрипт: выведи через <code>console.log</code> фразу <code>Привет, CoffeeScript!</code>. Скобки у вызова не обязательны — попробуй настоящий coffee-стиль. И убери пометку-заглушку.</p>',
        starter: `# script.coffee
# TODO: выведи приветствие через console.log
console.log ""`,
        rules: [
          { desc: 'Вывод через console.log (скобки не обязательны)', any: ['console\\.log\\s+["\']', 'console\\.log\\s*\\(\\s*["\']'] },
          { desc: 'Выведена фраза "Привет, CoffeeScript!"', all: ['Привет, CoffeeScript!'] },
          { desc: 'Без точек с запятой в конце строк — стиль CoffeeScript', all: ['\\S'], none: [';\\s*$'] },
          { desc: 'Код готов: заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Достаточно одной строки: console.log "Привет, CoffeeScript!" — без скобок, без точки с запятой.',
        'Фразу пиши точно: Привет, CoffeeScript! — с запятой и восклицательным знаком.',
        'Точки с запятой в конце строк не ставь — за этим следит проверка.'
      ],
      solution: `console.log "Привет, CoffeeScript!"
console.log "Ни точек с запятыми, ни var — красота."`
    },

    /* ---------- 2. Переменные и строки ---------- */
    {
      id: 'coffee-2',
      title: 'Переменные и строки',
      goal: 'Создавать переменные присваиванием без var и подставлять значения через интерполяцию #{}',
      xp: 35,
      theory: [
        { t: 'p', html: 'Переменная в CoffeeScript — это просто присваивание: <code>name = "Аня"</code>. Ни <code>var</code>, ни <code>let</code>, ни <code>const</code> — компилятор сам объявит переменную в нужном месте сгенерированного JavaScript. Область видимости считается по функциям и файлу: объявленное внутри функции наружу не «утечёт».' },
        { t: 'code', code: `name = "Аня"
age = 25
likesCoffee = true

console.log name, age, likesCoffee` },
        { t: 'p', html: 'Типы — те же, что в JavaScript: числа, строки, логические <code>true</code>/<code>false</code>, массивы <code>[1, 2, 3]</code>, объекты. CoffeeScript — это JS под капотом, поэтому и поведение чисел то же: <code>0.1 + 0.2</code> даст знаменитое <code>0.30000000000000004</code>.' },
        { t: 'h', html: 'Интерполяция строк' },
        { t: 'p', html: 'Внутрь двойных кавычек можно вставить любое выражение через <code>#{...}</code>: <code>"Привет, #{name}! Через год тебе #{age + 1}"</code>. Компилятор превратит это в конкатенацию. Это предок JS-шаблонных строк — но в CoffeeScript такой синтаксис появился на несколько лет раньше.' },
        { t: 'warn', html: 'Интерполяция работает <b>только в двойных кавычках</b>. В одинарных <code>\'#{name}\'</code> останется текстом с решёткой. И не перепутай с JS-синтаксисом: в CoffeeScript это <code>#{}</code>, а не <code>${}</code>.' },
        { t: 'note', html: 'Отступ — часть языка: два пробела (конвенция сообщества) задают блок вместо фигурных скобок. Смешивать табы и пробелы нельзя — компилятор ругнётся сразу и покажет точную строку.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни скрипт: имя — строка в двойных кавычках, логическое «истина» — как в JS, а в интерполяцию подставь имена переменных, чтобы фраза собралась сама.</p>',
        code: `# Переменные: просто имя = значение. Никаких var!
name = {{0}}
age = 25
likesCoffee = {{1}}

# Интерполяция #{...} — только в двойных кавычках
greeting = "Привет, #{{{2}}}! Возраст: #{{{3}}}"

console.log greeting`,
        blanks: [
          { answer: '"Аня"' },
          { answer: 'true' },
          { answer: 'name' },
          { answer: 'age' }
        ],
        ci: false
      },
      hints: [
        'Строка — в двойных кавычках, булево значение — маленькими буквами: true.',
        'Внутри #{} пишется имя переменной — без кавычек и без решётки внутри.',
        'Переменные объявлены выше: name и age.'
      ],
      solution: ['"Аня"', 'true', 'name', 'age']
    },

    /* ---------- 3. Условия и циклы ---------- */
    {
      id: 'coffee-3',
      title: 'Условия и циклы',
      goal: 'Ветвить через if и постфиксный if/unless и перебирать списки через for x in',
      xp: 40,
      theory: [
        { t: 'p', html: 'Условие выглядит как в Python: <code>if</code>, условие, перенос строки, тело с отступом. <code>else</code> и <code>else if</code> — на своих строках. Фигурных скобок нет — отступ решает всё. После <code>if</code> и <code>else</code> двоеточия, в отличие от Python, не ставятся.' },
        { t: 'code', code: `n = 12

if n > 10
  console.log "большое"
else if n > 5
  console.log "среднее"
else
  console.log "маленькое"` },
        { t: 'h', html: 'Постфиксная форма' },
        { t: 'p', html: 'Когда действие одно, его пишут в конце строки — «постфиксно»: <code>console.log "большое" if n &gt; 10</code>. Читается как английское предложение. Есть и <code>unless</code> — «если не»: <code>console.log "пусто" unless items.length</code>. Перебор списка — <code>for x in список</code> с телом в отступе: переменная x на каждом шаге получает следующий элемент. Это цикл и comprehension одновременно: с круглыми скобками он собирает массив результатов — об этом подробнее на уровне идиом.' },
        { t: 'code', code: `total = 0
for x in [1, 2, 3, 4, 5]
  total += x

console.log "сумма:", total` },
        { t: 'list', items: [
          '<b>if / else if / else</b> — блоки с отступом;',
          '<b>действие if условие</b> — постфиксная форма;',
          '<b>unless</b> — «если не»;',
          '<b>for x in список</b> — перебор элементов;',
          '<b>console.log a, b</b> — печатает аргументы через пробел.'
        ] },
        { t: 'warn', html: 'Постфиксный if — только для одного действия; для нескольких строк нужен полный блок. И не забывай: сравнение — <code>==</code>, присваивание — <code>=</code>. Правда, CoffeeScript компилирует == в строгий === — об этом на уровне идиом.' },
        { t: 'note', html: 'Есть и <code>while</code>, и <code>until</code> («пока не»), и даже постфиксные циклы: <code>console.log x for x in list</code> — одна строка вместо трёх. Отступы при этом всё равно обязательны.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай скрипт и напиши, что он выведет в консоль — по одной строке на каждый console.log, в порядке появления.</p>',
        code: `# script.coffee
items = [1, 2, 3, 4, 5]
total = 0

for x in items
  total += x

console.log "сумма:", total

n = 12
console.log "большое" if n > 10
console.log "маленькое" unless n > 10`,
        answer: `сумма: 15
большое`
      },
      hints: [
        'Проследи цикл: total копит 1 + 2 + 3 + 4 + 5.',
        'console.log "сумма:", total печатает аргументы через пробел.',
        'n = 12: условие n > 10 истинно — постфиксный if сработает, а unless («если не») — нет.'
      ],
      solution: `сумма: 15
большое`
    },

    /* ---------- 4. Функции и стрелки ---------- */
    {
      id: 'coffee-4',
      title: 'Функции и стрелки',
      goal: 'Объявлять функции стрелкой ->, возвращать последнее выражение и вызывать без скобок',
      xp: 45,
      theory: [
        { t: 'p', html: 'Функция — это значение, которое присваивают переменной: <code>double = (x) -&gt; x * 2</code>. Стрелка <code>-&gt;</code> заменяет JS-овское <code>function</code>, параметры — в скобках перед стрелкой. Вызов без скобок: <code>double 21</code> даст 42. Скобки не запрещены: <code>double(21)</code> — то же самое.' },
        { t: 'code', code: `double = (x) -> x * 2
console.log double 21    # 42` },
        { t: 'p', html: 'Тело на одной строке — справа от стрелки. Многострочное — ниже, с отступом. <code>return</code> не нужен: функция возвращает последнее вычисленное выражение, как в Ruby. <code>return</code> существует и работает, но его пишут только ради раннего выхода из функции.' },
        { t: 'code', code: `greet = (name) ->
  "Привет, #{name}! Приятного кода."

console.log greet "Аня"` },
        { t: 'list', items: [
          '<b>(x) -&gt; x * 2</b> — короткая функция в одну строку;',
          '<b>имя = (параметры) -&gt;</b> — многострочная функция;',
          '<b>последнее выражение</b> — возвращается автоматически;',
          '<b>f 21</b> — вызов без скобок;',
          '<b>(x = 10) -&gt;</b> — параметр со значением по умолчанию.'
        ] },
        { t: 'warn', html: 'Не путай с ES6-стрелками: в JS <code>x =&gt; x * 2</code>, в CoffeeScript — <code>(x) -&gt; x * 2</code>. И помни: когда вызов неоднозначен, ставь скобки — <code>console.log double 21</code> ок, но <code>console.log(double 21, 5)</code> надёжнее для нескольких аргументов.' },
        { t: 'note', html: 'Сравни с тем, во что это компилируется: <code>var double = function(x) { return x * 2; }</code> — компилятор сам добавит и var, и function, и точки с запятой. CoffeeScript — это сахар поверх честного JavaScript.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви две функции стрелкой: <code>add = (a, b) -&gt; a + b</code> и многострочную <code>greet = (name) -&gt;</code>, возвращающую приветствие. Вызови обе и выведи результаты через <code>console.log</code>.</p>',
        starter: `# TODO: объяви add = (a, b) через стрелку
# TODO: объяви многострочную greet

console.log ""`,
        rules: [
          { desc: 'Функция add объявлена стрелкой с двумя параметрами', all: ['add\\s*=\\s*\\([^)]*,[^)]*\\)\\s*->'] },
          { desc: 'Функция greet объявлена стрелкой', all: ['greet\\s*=\\s*\\([^)]*\\)\\s*->'] },
          { desc: 'Обе функции вызываются', any: ['add\\s*\\(\\s*\\d', 'add\\s+\\d', 'greet\\s*\\(\\s*["\']', 'greet\\s+["\']'] },
          { desc: 'Результаты выводятся через console.log', all: ['console\\.log'] },
          { desc: 'Заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Короткая форма: add = (a, b) -> a + b.',
        'Многострочная: greet = (name) ->, с новой строки с отступом — строка приветствия; return не нужен.',
        'Вызовы: console.log "сумма:", add(2, 3) и console.log greet "Аня".'
      ],
      solution: `add = (a, b) -> a + b

greet = (name) ->
  "Привет, #{name}! Кофе готов."

console.log "сумма:", add(2, 3)
console.log greet "Аня"`
    },

    /* ---------- 5. Идиомы ---------- */
    {
      id: 'coffee-5',
      title: 'Идиомы: ?, splat и comprehensions',
      goal: 'Применять оператор существования ?, splat-параметры ... и comprehension-выражения',
      xp: 40,
      theory: [
        { t: 'p', html: 'Оператор существования <code>?</code> — ответ CoffeeScript на JS-овские null и undefined: <code>x?</code> даёт <code>true</code>, если x — не null и не undefined. Форма <code>y = x ? 10</code> берёт x, если тот существует, иначе 10. Это короче и безопаснее JS-трюка с <code>||</code>: ноль и пустая строка не потеряются.' },
        { t: 'code', code: `user = { name: "Аня" }

console.log user.age?             # false
bonus = user.bonus ? 100          # 100
console.log user?.address?.city   # undefined, без ошибки` },
        { t: 'p', html: 'Splat — три точки в параметрах: <code>sum = (nums...) -&gt; ...</code> собирает все аргументы в массив. Работает и на вызове: <code>sum(list...)</code> разворачивает массив в аргументы. JavaScript получил rest/spread только в ES6 — CoffeeScript умел это с 2009 года.' },
        { t: 'code', code: `sum = (nums...) ->
  total = 0
  total += n for n in nums
  total

console.log sum 1, 2, 3        # 6
console.log sum [10, 20]...    # 30` },
        { t: 'p', html: 'Comprehension — цикл-выражение: <code>(x * 2 for x in list)</code> возвращает массив результатов. Для объектов — <code>for k, v of obj</code>: ключевое слово <code>of</code> перебирает ключи и значения, <code>in</code> остаётся для массивов. Почти всё в CoffeeScript — выражение, у любого цикла есть результат.' },
        { t: 'list', items: [
          '<b>x?</b> — существует ли значение;',
          '<b>a = x ? 10</b> — значение по умолчанию;',
          '<b>(nums...) -&gt;</b> — собрать аргументы в массив;',
          '<b>fn(arr...)</b> — развернуть массив в аргументы;',
          '<b>(x * 2 for x in list)</b> — comprehension-массив;',
          '<b>for k, v of obj</b> — перебор объекта.'
        ] },
        { t: 'warn', html: 'Важное отличие от JS: <code>==</code> в CoffeeScript компилируется в строгий <code>===</code>, а <code>is</code> и <code>isnt</code> — читаемые псевдонимы для == и !=. Знаменитая ловушка JS «1 == "1" даёт true» в CoffeeScript не воспроизводится: сравнение всегда строгое.' },
        { t: 'note', html: 'Ещё пара мелодий из Ruby: <code>result = if x then "a" else "b"</code> — if тоже выражение, а строки можно писать в тройных кавычках """ для многострочного текста. Идиомы складываются друг с другом, как кубики.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет этот код?</p><pre>greet = (names...) -> names.length
greet "Аня", "Борис"</pre>`,
        options: [
          '"Аня, Борис"',
          '2',
          '["Аня", "Борис"]',
          'Ошибка: у greet нет параметра names'
        ],
        correct: 1,
        explain: 'Splat names... собрал два аргумента в массив ["Аня", "Борис"], а names.length — это 2. Тело функции — последнее выражение, оно и вернулось. Если бы greet возвращал сам массив, ответом был бы вариант C.',
        solution: 1
      },
      hints: [
        'Splat ... собирает все переданные аргументы в один массив.',
        'names.length — длина получившегося массива, а не сам массив.',
        'Функция без явного return возвращает последнее выражение.'
      ],
      solution: 1
    },

    /* ---------- 6. Проект: обработка заказов ---------- */
    {
      id: 'coffee-6',
      title: '🚀 Проект: обработка заказов',
      goal: 'Обработать список цен: функция скидки через comprehension, сумма через splat и вывод итога',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальный проект — мини-обработка заказа: список цен, функция скидки, применённая comprehension-выражением, и функция суммы со splat, которая принимает развёрнутый массив. Всё в coffee-стиле: без var, без точек с запятыми, вызовы без скобок там, где можно.' },
        { t: 'list', items: [
          '<b>orderPrices</b> — массив с ценами (минимум два числа);',
          '<b>applyDiscount = (price) -&gt; ...</b> — функция скидки;',
          '<b>discounted = (applyDiscount p for p in orderPrices)</b> — comprehension;',
          '<b>sumAll = (nums...) -&gt;</b> — многострочная функция со splat и суммой;',
          '<b>console.log</b> — вывод скидок и итога.'
        ] },
        { t: 'code', code: `orderPrices = [250, 120, 1500]

applyDiscount = (price) -> price * 0.9

discounted = (applyDiscount p for p in orderPrices)

sumAll = (nums...) ->
  total = 0
  for n in nums
    total += n
  total

console.log "Цены со скидкой:", discounted
console.log "Итог заказа:", sumAll discounted...` },
        { t: 'p', html: 'Comprehension в круглых скобках собирает массив: каждый элемент orderPrices пропускается через applyDiscount. Строка <code>sumAll discounted...</code> — разворот массива в аргументы: splat-параметр nums... соберёт их обратно в массив внутри функции. Два приёма работают в паре.' },
        { t: 'note', html: 'Внутри sumAll сумма считается обычным циклом for с отступом; <code>total</code> — последнее выражение, поэтому возвращается без return. После зачёта попробуй: скидку, зависящую от суммы (if внутри функции), или печать по одному: <code>console.log p for p in discounted</code>.' },
        { t: 'warn', html: 'Splat в объявлении — <code>(nums...)</code>, разворот при вызове — <code>discounted...</code> (три точки после массива): проверка ищет оба приёма. Не забудь comprehension с applyDiscount и убери все пометки-заглушки из финального кода.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Обработка списка заказов».</b> Объяви массив <code>orderPrices</code> минимум с двумя числами, функцию скидки <code>applyDiscount = (price) -&gt; ...</code>, собери <code>discounted</code> через comprehension (применение applyDiscount к каждому элементу), напиши <code>sumAll = (nums...) -&gt;</code> со суммой и выведи итог через <code>console.log</code>, развернув массив: <code>sumAll discounted...</code>.</p>',
        starter: `# TODO: объяви массив orderPrices с ценами
# TODO: напиши applyDiscount и сумму sumAll со splat

console.log "TODO"`,
        rules: [
          { desc: 'Массив orderPrices с минимум двумя числами', all: ['orderPrices\\s*=\\s*\\[[^\\]\\n]*\\d[^\\]\\n]*\\d[^\\]\\n]*\\]'] },
          { desc: 'Функция applyDiscount объявлена стрелкой', all: ['applyDiscount\\s*=\\s*\\([^)]*\\)\\s*->'] },
          { desc: 'Comprehension применяет applyDiscount к списку', any: ['applyDiscount\\s+\\w+\\s+for\\s+\\w+\\s+in\\s+\\w+', 'applyDiscount\\s*\\(\\s*\\w+\\s*\\)\\s+for\\s+\\w+\\s+in\\s+\\w+'] },
          { desc: 'Функция суммы со splat: sumAll = (nums...) ->', all: ['sumAll\\s*=\\s*\\(\\s*\\w+\\.\\.\\.\\s*\\)\\s*->'] },
          { desc: 'Итог выведен через console.log с вызовом sumAll, TODO нет', all: ['console\\.log'], any: ['sumAll\\s*\\(', 'sumAll\\s+\\w', "sumAll\\s+[\"']"], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Список: orderPrices = [250, 120, 1500].',
        'Comprehension: discounted = (applyDiscount p for p in orderPrices).',
        'Splat-функция: sumAll = (nums...) -> с отступом, внутри сумма циклом; вызов — sumAll discounted...'
      ],
      solution: `orderPrices = [250, 120, 1500]

applyDiscount = (price) -> price * 0.9

discounted = (applyDiscount p for p in orderPrices)

sumAll = (nums...) ->
  total = 0
  for n in nums
    total += n
  total

console.log "Цены со скидкой:", discounted
console.log "Итог заказа:", sumAll discounted...`
    },

    /* ---------- 7. Классы и наследование ---------- */
    {
      id: 'coffee-7',
      title: 'Классы и наследование',
      goal: 'Объявлять классы с constructor и @-полями, наследовать через extends и вызывать super',
      xp: 50,
      theory: [
        { t: 'p', html: 'Класс в CoffeeScript — аккуратная обёртка над прототипами JavaScript: слово <code>class</code>, имя, отступ — и внутри методы в виде свойств со стрелками. Конструктор называется <code>constructor</code> и вызывается автоматически при создании объекта через <code>new</code>. Каждый фронтенд Rails-проектов десятых годов был полон таких классов.' },
        { t: 'code', code: `class Animal
  constructor: (@name) ->

  speak: ->
    "#{@name} издаёт звук"

a = new Animal("Кот")
console.log a.speak()` },
        { t: 'p', html: 'Сокращение <code>@name</code> прямо в параметрах конструктора объявляет и поле, и присваивание одним махом — тот же трюк, что ты видел в функциях. Методы пишутся как свойства-функции: <code>speak: -&gt;</code>. Внутри методов <code>@</code> — это сам объект: <code>@name</code> читает поле. Классы CoffeeScript выглядят почти как будущие ES6-классы — не случайно: сама идея вошла в стандарт.' },
        { t: 'h', html: 'Наследование: extends и super' },
        { t: 'code', code: `class Dog extends Animal
  speak: ->
    super() + " — гав-гав!"

dog = new Dog("Рекс")
console.log dog.speak()
# → Рекс издаёт звук — гав-гав!` },
        { t: 'p', html: '<code>extends</code> строит прототипную цепочку: Dog получает все методы Animal, а свои методы могут дополнять или перекрывать их. Ключевое слово <code>super</code> внутри метода вызывает родительский метод с тем же именем: перекрытый speak сначала обращается к родительскому, потом добавляет лай. <code>super()</code> со скобками вызывает родителя без аргументов, голое <code>super</code> передаёт те же аргументы, что получил текущий метод.' },
        { t: 'list', items: [
          '<b>class Имя</b> — объявление класса;',
          '<b>constructor: (@поле) -&gt;</b> — конструктор с автоматическими полями;',
          '<b>метод: -&gt;</b> — метод класса (свойство-функция);',
          '<b>class Сын extends Родитель</b> — наследование;',
          '<b>super</b> — вызов родительского метода.'
        ] },
        { t: 'warn', html: 'Не забывай отступ: тело класса и каждого метода задаётся пробелами, фигурных скобок нет. И аккуратнее с super: голое super перенаправит ВСЕ аргументы текущего метода — если у родителя другой набор параметров, вызывай super() явно.' },
        { t: 'note', html: 'Приятно знать: транслируй это в JavaScript (<code>coffee -c</code>) — и увидишь prototype, __proto__ и .call(this) в сгенерированном коде. CoffeeScript-классы — лучший учебник прототипного наследования: читая скомпилированный JS, ты видишь, как классы устроены под капотом.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери пару классов: родительский <code>Animal</code> с конструктором (имя через <code>@name</code>) и методом <code>speak</code>, и класс-наследник через <code>extends</code>, который вызывает <code>super</code> и добавляет своё. Создай объект наследника через <code>new</code> и выведи результат вызова метода через <code>console.log</code>.</p>',
        starter: `# TODO: объяви родительский класс с конструктором и методом speak
# TODO: объяви наследника через extends и вызови родительский метод
# TODO: создай объект и выведи результат`,
        rules: [
          { desc: 'Класс Animal объявлен', all: ['\\bclass\\s+Animal\\b'] },
          { desc: 'Конструктор constructor: объявлен', all: ['constructor\\s*:'] },
          { desc: 'Класс-наследник объявлен через extends Animal', all: ['\\bclass\\s+\\w+\\s+extends\\s+Animal\\b'] },
          { desc: 'super вызывает родительский метод', all: ['\\bsuper\\b'] },
          { desc: 'Объект создан через new и выведен через console.log', all: ['\\bnew\\s+\\w+', 'console\\.log'] },
          { desc: 'Поля через @имя, пометок TODO нет', all: ['@\\w+'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Родитель: class Animal — constructor: (@name) -> и метод speak: -> "#{@name} издаёт звук".',
        'Наследник: class Dog extends Animal, внутри speak: -> super() + " — гав-гав!".',
        'Проверка: dog = new Dog("Рекс"), затем console.log dog.speak().'
      ],
      solution: `class Animal
  constructor: (@name) ->

  speak: ->
    "#{@name} издаёт звук"

class Dog extends Animal
  speak: ->
    super() + " — гав-гав!"

dog = new Dog("Рекс")
console.log dog.speak()`
    },

    /* ---------- 8. Splats и деструктуризация ---------- */
    {
      id: 'coffee-8',
      title: 'Splats и деструктуризация',
      goal: 'Собирать аргументы splat-ом (...), разбирать объекты и массивы деструктуризацией и обменивать значения',
      xp: 45,
      theory: [
        { t: 'p', html: 'Splat ты уже применял в проекте с заказами: <code>(nums...)</code> собирает все аргументы функции в массив. Теперь закрепим его формально и добавим зеркальный приём — <b>деструктуризацию</b>: разбор структуры данных на части прямо при присваивании. Оба приёма делают код короче без потери ясности — поэтому они повсюду в идиоматичном coffee.' },
        { t: 'code', code: `sumAll = (nums...) ->
  total = 0
  total += n for n in nums
  total

console.log sumAll 1, 2, 3, 4    # 10
console.log sumAll [1, 2, 3]...  # 6 — разворот массива` },
        { t: 'p', html: 'Деструктуризация объекта — короткая запись <code>{name, age} = user</code>: переменные name и age получают значения одноимённых полей. Это не потеря данных — объект user цел, просто его поля скопированы в удобные имена. В ES6 этот синтаксис пришёл именно из CoffeeScript.' },
        { t: 'code', code: `user = { name: "Борис", age: 30 }
{name, age} = user

console.log "#{name}, #{age} лет"` },
        { t: 'p', html: 'С массивами работает то же: <code>[first, second] = [10, 20]</code> разложит значения по переменным, а splat-остаток соберёт хвост: <code>[first, rest...] = [10, 20, 30, 40]</code> даст first = 10 и rest = [20, 30, 40]. Знаменитый трюк — обмен значений без временной переменной: <code>[a, b] = [b, a]</code>. Разбор работает и во вложенных структурах: [name, [x, y]] = ["Аня", [1, 2]].' },
        { t: 'warn', html: 'Ловушка компилятора: строка, начинающаяся со скобки, может быть понята как вызов функции из предыдущей строки. Деструктуризацию в начале строки либо предваряй объявлением, либо ставь точку с запятой в конце предыдущей строки — редкий случай, когда CoffeeScript её всё-таки ждёт.' },
        { t: 'note', html: 'Деструктуризация работает и прямо в параметрах: <code>draw = ({x, y}) -&gt; ...</code> принимает объект и сразу достаёт из него координаты. Удобно для опций: код функции читается без единого обращения к obj.поле.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни скрипт: splat-параметр, который собирает аргументы в массив <code>nums</code>, короткая деструктуризация полей объекта и имя переменной-остатка при разборе массива.</p>',
        code: `# Splat: собирает все аргументы функции в массив
sumAll = ({{0}}) ->
  total = 0
  for n in nums
    total += n
  total

console.log "сумма:", sumAll 1, 2, 3, 4

# Деструктуризация объекта — короткая запись
user = { name: "Борис", age: 30 }
{{1}} = user
console.log "#{name}, #{age} лет"

# Разбор массива: первый элемент и остаток
[first, {{2}}...] = [10, 20, 30, 40]
console.log "первый и второй:", first + rest[0]`,
        blanks: [
          { answer: 'nums...', alt: ['nums ...'] },
          { answer: '{name, age}', alt: ['{ name, age }', '{age, name}'] },
          { answer: 'rest' }
        ],
        ci: false
      },
      hints: [
        'Splat — три точки после имени параметра: nums... (аргументы соберутся в массив nums).',
        'Деструктуризация объекта: {name, age} = user — имена как у полей.',
        'Остаток массива собирает splat: [first, rest...] — дальше rest[0] даст 20.'
      ],
      solution: ['nums...', '{name, age}', 'rest']
    },

    /* ---------- 9. Comprehensions и фильтры ---------- */
    {
      id: 'coffee-9',
      title: 'Comprehensions и фильтры',
      goal: 'Фильтровать списки прямо в заголовке цикла: for x in arr when условие — в comprehension и в блочном for',
      xp: 50,
      theory: [
        { t: 'p', html: 'Comprehension — цикл-выражение: в скобках он собирает массив результатов. Ты уже писал <code>(applyDiscount p for p in orderPrices)</code>. Новый ингредиент — фильтр <code>when</code> прямо в заголовке цикла: элемент попадает в результат, только если условие истинно.' },
        { t: 'code', code: `prices = [120, 450, 80, 990, 150]

expensive = (p for p in prices when p > 100)
# [120, 450, 990, 150]` },
        { t: 'p', html: 'Читается как английская фраза: «p для каждого p в prices, когда p больше 100». Это filter и map в одной строке — задолго до того, как JS обзавёлся Array.prototype.filter. Фильтровать можно и обычный блочный цикл: <code>for p in prices when p &lt;= 100</code> с телом в отступе.' },
        { t: 'code', code: `for p in prices when p <= 100
  console.log "бюджетно: #{p}"` },
        { t: 'table', head: ['CoffeeScript', 'Эквивалент JavaScript'], rows: [
          ['(x for x in list)', 'list.map(...)'],
          ['(x for x in list when c)', 'list.filter(...).map(...)'],
          ['for x in list ... (блок)', 'for (const x of list) { ... }'],
          ['for k, v of obj', 'перебор ключей и значений объекта']
        ] },
        { t: 'p', html: 'Комбинируй свободно: <code>(p.total() for p in items when p.qty &gt; 0)</code> — стоимости только непустых позиций. В заголовок можно добавить и шаг: <code>for i in [0..10] by 2</code>. Фильтр when работает в любой форме цикла — и в comprehension, и в блочном for.' },
        { t: 'warn', html: 'Не забывай скобки: comprehension без скобок — просто инструкция-цикл, её результат обычно выбрасывается. И помни про отступ в блочной форме — он заменяет фигурные скобки JS.' },
        { t: 'note', html: 'Постфиксная форма тоже дружит с фильтрами: <code>console.log p for p in list when p.ok</code> — одна строка вместо четырёх. В меру — читаемость важнее краткости, но для коротких тел это идиоматичный coffee.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Отфильтруй список двумя способами: собери comprehension в скобках с фильтром <code>when</code> (например, числа больше ста) в переменную, затем обойди список блочным <code>for x in ... when ...</code> с выводом каждого подходящего элемента через <code>console.log</code>. Список объяви переменной.</p>',
        starter: `# TODO: объяви список чисел
# TODO: собери comprehension с when — отфильтруй значения
# TODO: обойди список блочным for с when и выведи элементы`,
        rules: [
          { desc: 'Comprehension-выражение в скобках собирает массив', any: ['=\\s*\\([^)\\n]*for\\s+\\w+\\s+in[^)\\n]*\\)'] },
          { desc: 'Фильтр when в заголовке цикла', all: ['\\bfor\\s+\\w+\\s+in\\s+[^\\n]*\\bwhen\\s+\\S+'] },
          { desc: 'Элементы выводятся через console.log', all: ['console\\.log'] },
          { desc: 'Список объявлен переменной', all: ['\\w+\\s*=\\s*\\['] },
          { desc: 'Пометок TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Comprehension: expensive = (p for p in prices when p > 100).',
        'Блочный цикл: for p in prices when p <= 100, с новой строки с отступом — console.log.',
        'Скобки у comprehension обязательны — они собирают массив результатов.'
      ],
      solution: `prices = [120, 450, 80, 990, 150]

expensive = (p for p in prices when p > 100)

console.log "дорогие:", expensive

for p in prices when p <= 100
  console.log "бюджетно: #{p}"`
    },

    /* ---------- 10. Проект: инвентарь магазина ---------- */
    {
      id: 'coffee-10',
      title: '🚀 Проект: инвентарь магазина',
      goal: 'Собрать инвентарь: класс Product, класс Inventory с add/total, comprehension с when и вывод итога',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — инвентарь магазина: товары как объекты класса Product, магазин как Inventory с методами add и total, плюс comprehension с when для отбора живых позиций. Весь курс в одной программе: классы и наследование ур. 7, splats и деструктуризация ур. 8, comprehensions ур. 9. К концу уровня у тебя будет работающий склад: добавляешь товар — итог пересчитывается сам.' },
        { t: 'list', items: [
          '<b>class Product</b> — товар: имя, цена, количество; метод <code>total: -&gt; @price * @qty</code>;',
          '<b>class Inventory</b> — склад: массив <code>@items</code>, методы <code>add</code> и <code>total</code>;',
          '<b>add: (product) -&gt; @items.push product</b> — пополнение склада;',
          '<b>comprehension с when</b> — сумма и печать только позиций с количеством больше нуля;',
          '<b>console.log</b> — чек и итог.'
        ] },
        { t: 'code', code: `class Product
  constructor: (@name, @price, @qty) ->

  total: ->
    @price * @qty

class Inventory
  constructor: ->
    @items = []

  add: (product) ->
    @items.push product

  total: ->
    sum = 0
    for p in @items when p.qty > 0
      sum += p.total()
    sum

  show: ->
    for p in @items when p.qty > 0
      console.log "#{p.name}: #{p.total()} руб."

inv = new Inventory()
inv.add new Product("Кружка", 250, 2)
inv.add new Product("Блокнот", 120, 5)
inv.add new Product("Ручка", 40, 0)

inv.show()
console.log "Итог магазина: #{inv.total()} руб."` },
        { t: 'p', html: 'Метод total внутри Inventory — цикл с фильтром: сумма набегает только по позициям, где qty больше нуля, — нулевые позиции не учитываются. Заметь связку обращений: <code>@items</code> — поле объекта, <code>p.total()</code> — вызов метода у элемента, <code>@price</code> — поле товара внутри его собственного класса. Три вида обращений, каждое на своём месте.' },
        { t: 'warn', html: 'Не перепутай @items (поле конкретного инвентаря) и p (элемент цикла). И вызов метода без скобок — inv.add new Product(...) — работает, пока аргумент у add один; для двух и больше ставь скобки.' },
        { t: 'note', html: 'После зачёта: добавь метод remove, найди самый ходовой товар — <code>inv.items.sort((a, b) -&gt; b.qty - a.qty)[0]</code>, или посчитай товары дороже сотни comprehension-ом с when. Инвентарь — классическая модель ООП: сущность + коллекция + агрегаты.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Инвентарь магазина».</b> Объяви класс <code>Product</code> с конструктором (@name, @price, @qty) и методом стоимости позиции. Объяви класс <code>Inventory</code> с массивом товаров в конструкторе, методом <code>add</code> (push) и методом <code>total</code>, где сумма считается циклом с фильтром <code>when</code>. Создай инвентарь, добавь минимум три товара через <code>new Product(...)</code> и выведи позиции и итог через <code>console.log</code>.</p>',
        starter: `# TODO: объяви класс товара (имя, цена, количество)
# TODO: объяви класс склада с методами add и total
# TODO: добавь товары, выведи позиции и итог магазина`,
        rules: [
          { desc: 'Класс Product объявлен', all: ['\\bclass\\s+Product\\b'] },
          { desc: 'Класс Inventory объявлен', all: ['\\bclass\\s+Inventory\\b'] },
          { desc: 'Конструкторы объявлены (constructor:)', all: ['constructor\\s*:'] },
          { desc: 'Метод add добавляет товар через push', all: ['\\badd\\s*:', '\\.push\\b'] },
          { desc: 'Метод total считает сумму', all: ['\\btotal\\s*:'] },
          { desc: 'Comprehension с фильтром when по коллекции', all: ['\\bfor\\s+\\w+\\s+in\\s+[^\\n]*\\bwhen\\s+\\S+'] },
          { desc: 'Товары созданы через new Product и выведены, TODO нет', all: ['\\bnew\\s+Product', 'console\\.log'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Товар: class Product — constructor: (@name, @price, @qty) -> и total: -> @price * @qty.',
        'Склад: class Inventory — constructor с @items = [], add через push, total — цикл for p in @items when p.qty > 0.',
        'Сценарий: inv = new Inventory(), inv.add new Product(...), затем вывод позиций и console.log "Итог магазина: #{inv.total()} руб.".'
      ],
      solution: `class Product
  constructor: (@name, @price, @qty) ->

  total: ->
    @price * @qty

class Inventory
  constructor: ->
    @items = []

  add: (product) ->
    @items.push product

  total: ->
    sum = 0
    for p in @items when p.qty > 0
      sum += p.total()
    sum

  show: ->
    for p in @items when p.qty > 0
      console.log "#{p.name}: #{p.total()} руб."

inv = new Inventory()
inv.add new Product("Кружка", 250, 2)
inv.add new Product("Блокнот", 120, 5)
inv.add new Product("Ручка", 40, 0)

inv.show()
console.log "Итог магазина: #{inv.total()} руб."`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Компиляция',
      code: `coffee -c script.coffee   # → script.js
coffee script.coffee      # скомпилить и запустить
coffee --watch -c s.coffee # пересборка на лету
coffee -i                 # интерактивный REPL`
    },
    {
      title: 'Переменные и строки',
      code: `name = "Аня"        # без var!
age = 25
ok = true
"Привет, #{name}!"   # интерполяция (двойные кавычки)
'#{name}'            # без интерполяции — как есть
# имена: snake_case, отступ — 2 пробела`
    },
    {
      title: 'Условия и циклы',
      code: `if n > 10
  console.log "большое"
else if n > 5
  console.log "среднее"
else
  console.log "маленькое"

console.log "да" if n > 10    # постфиксно
console.log "нет" unless ok   # «если не»

for x in [1, 2, 3]
  console.log x`
    },
    {
      title: 'Функции',
      code: `double = (x) -> x * 2      # короткая
greet = (name) ->
  "Привет, #{name}!"       # return не нужен

double 21                  # вызов без скобок
double(21)                 # со скобками тоже ок
(x = 10) -> x              # параметр по умолчанию`
    },
    {
      title: 'Идиомы',
      code: `x?                     # существует ли
y = x ? 10             # значение по умолчанию
user?.address?.city    # безопасный доступ

sum = (nums...) ->     # splat: собрать в массив
  total += n for n in nums
  total
sum [10, 20]...        # разворот массива

(x * 2 for x in list)  # comprehension
for k, v of obj        # перебор объекта`
    },
    {
      title: 'Отличия от JS',
      list: [
        'нет var/let/const — просто имя = значение',
        'нет function — стрелка ->',
        'отступы вместо фигурных скобок',
        'нет точек с запятой',
        'скобки вызова необязательны: f 2, 3',
        '== компилируется в === (строгое сравнение)',
        'is / isnt — алиасы для == / !=',
        'интерполяция #{} вместо ${}',
        'циклы можно постфиксно: действие for x in list'
      ]
    },
    {
      title: 'Классы и наследование',
      code: `class Animal
  constructor: (@name) ->
  speak: -> "#{@name} молчит"

class Dog extends Animal
  speak: -> super() + " — гав!"

dog = new Dog("Рекс")
console.log dog.speak()
# super без скобок передаёт те же аргументы
# super() — вызвать родителя без аргументов`
    },
    {
      title: 'Splat, деструктуризация и when',
      code: `sumAll = (nums...) -> ...      # splat-параметр
sumAll [10, 20]...             # разворот массива
{name, age} = user             # объект
[first, rest...] = [10, 20]    # массив + хвост
[a, b] = [b, a]                # обмен значений

(p for p in prices when p > 100)  # filter+map
for p in items when p.qty > 0     # блочный for с when
  console.log p.name`
    }
  ]
};
