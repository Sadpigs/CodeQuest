'use strict';
/* ============ CodeQuest — курс Crystal ============
   Crystal не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.crystal = {
  id: 'crystal',
  title: 'Crystal',
  emoji: '💠',
  color: '#8e5bc8',
  lang: 'crystal',
  tagline: 'Ruby-синтаксис и скорость C: 10 уровней',
  description: 'Компилируемый язык 2014 года с Ruby-синтаксисом: типы выводит сам компилятор, а на выходе — скорость C. Союз удобства и скорости. За 10 уровней дойдём от puts "Hello" до типизированных полей классов, Union-типов и nil-проверок, модулей с generics и проекта «Реестр книг».',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'crystal-1',
      title: 'Первая программа',
      goal: 'Понять устройство программы на Crystal: файл main.cr, puts для вывода и запуск через crystal run',
      xp: 30,
      theory: [
        { t: 'p', html: 'Crystal — компилируемый язык, впервые опубликованный в 2014 году разработчиками Ари Бореншвейгом и Хуаном Вахнерманом. Идея проекта дерзкая: взять восхитительно удобный синтаксис Ruby и добавить то, чего у Ruby нет, — статическую компиляцию. Ты пишешь почти как на Ruby, а компилятор сам выводит типы, ловит ошибки ещё до запуска и выдаёт быстрый машинный код через LLVM. Получается союз удобства и скорости.' },
        { t: 'h', html: 'Минимальная программа' },
        { t: 'code', code: `puts "Привет, CodeQuest!"` },
        { t: 'p', html: 'Да, это вся программа — никакого main и каркаса. Команды исполняются сверху вниз, одна за другой. <code>puts</code> печатает значение и переводит строку — точь-в-точь как в Ruby. Комментарии начинаются с <code>#</code> и идут до конца строки.' },
        { t: 'p', html: 'Запуск: сохрани код в файл <code>main.cr</code> и выполни <code>crystal run main.cr</code> — компилятор соберёт программу и тут же её запустит. Есть короткая форма <code>crystal main.cr</code>, а <code>crystal build main.cr</code> создаст отдельный исполняемый файл, который работает уже без установленного Crystal.' },
        { t: 'list', items: [
          '<b>puts "текст"</b> — печать строки с переносом;',
          '<b># комментарий</b> — заметки для человека, код не трогает;',
          '<b>двойные кавычки</b> — единственный способ записать строку;',
          '<b>crystal run main.cr</b> — компиляция и запуск одной командой.'
        ] },
        { t: 'warn', html: 'Одинарные кавычки в Crystal — для одиночного символа: <code>\'A\'</code> — это Char, а не строка. Привычка из Python писать строки в одинарных кавычках здесь сломает компиляцию. Строки — только в двойных.' },
        { t: 'note', html: 'Отступы в Crystal не значимы, как в Ruby: блоки кода открываются и закрываются словами, а не пробелами. Пока у нас одна строка — но скоро появятся циклы и методы, а вместе с ними закрывающее <code>end</code>.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши свою первую строку на Crystal: выведи фразу <code>Привет, CodeQuest!</code> с помощью <code>puts</code>. Заметь: ни каркаса, ни main — программа начинается прямо с команды. Заглушку замени настоящим кодом.</p>',
        starter: `# TODO: напиши первую строку программы — вывод приветствия`,
        rules: [
          { desc: 'Используется вывод puts со строкой', all: ['\\bputs\\s+"[^"]+"'] },
          { desc: 'Выводится фраза «Привет, CodeQuest!»', all: ['"Привет, CodeQuest!"'] },
          { desc: 'Нет одинарных кавычек (в Crystal это Char, не строка)', all: ['\\S'], none: ["'"] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Вся программа — одна строка: puts "Привет, CodeQuest!"',
        'Кавычки двойные; точка с запятой в конце не нужна.',
        'Захотел второй вывод — просто допиши ещё одну строку puts ниже.'
      ],
      solution: `puts "Привет, CodeQuest!"
puts "Это моя первая программа на Crystal."`
    },

    /* ---------- 2. Переменные и типы ---------- */
    {
      id: 'crystal-2',
      title: 'Переменные и типы',
      goal: 'Объявлять переменные присваиванием, явно указывать Int32, Float64, String, Bool и понимать выведение типов',
      xp: 30,
      theory: [
        { t: 'p', html: 'Переменная в Crystal — просто имя и значение через <code>=</code>: никаких var, let или Dim. Пишешь <code>name = "Аня"</code> — и переменная существует, а её тип компилятор вывел сам из значения. Это называется выведение типов, и это главная магия Crystal: типы всегда есть, просто их не обязательно писать руками.' },
        { t: 'code', code: `name = "Аня"      # String — выведется сам
age = 25          # Int32
price = 9.99      # Float64
in_stock = true   # Bool` },
        { t: 'table', head: ['Значение', 'Тип выведется'], rows: [
          ['<code>25</code>', '<code>Int32</code> — целое по умолчанию'],
          ['<code>3.14</code>', '<code>Float64</code> — дробное по умолчанию'],
          ['<code>"текст"</code>', '<code>String</code>'],
          ['<code>true</code>', '<code>Bool</code>'],
          ["<code>'A'</code>", '<code>Char</code> — одиночный символ']
        ] },
        { t: 'p', html: 'Целые числа по умолчанию живут в <code>Int32</code>, дробные — в <code>Float64</code>. Хочешь другой размер — явное суффикс или тип: <code>age : Int64 = 25</code> фиксирует тип через двоеточие. Явная аннотация полезна, когда значение «пустое» или когда хочешь подстраховаться: <code>count : Int32 = 0</code>.' },
        { t: 'p', html: 'Имена переменных пишутся в стиле snake_case: <code>user_name</code>, <code>max_score</code> — так принято в Ruby-мире, и Crystal не исключение. Изменение переменной — новое присваивание, а для короткой записи есть составные операторы: <code>age += 1</code> прибавит единицу, есть и <code>-=</code>, <code>*=</code>.' },
        { t: 'warn', html: 'Переменная не может сменить тип: <code>name = "Аня"</code>, а затем <code>name = 5</code> — ошибка компиляции. Тип привязан к имени раз и навсегда. Зато ошибку ты увидишь до запуска, а не в продакшене — в этом весь смысл статического Crystal.' },
        { t: 'note', html: 'Отсутствие значения — отдельный тип <code>Nil</code> и значение <code>nil</code>. С ним познакомимся ближе на уровне про идиомы: Union-типы вида String | Nil — фирменная фишка Crystal, и компилятор следит, чтобы ты не забыл про «ничего».' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни карточку товара: подставь явные типы — название строковое, возраст целое 32-битное, цена дробная, флаг логический, — а в конце прибавь единицу к возрасту составным оператором.</p>',
        code: `name : {{0}} = "Аня"      # явный тип: текст
age : {{1}} = 25          # явный тип: целое 32-битное
price : {{2}} = 9.99      # явный тип: дробное
in_stock : {{3}} = true   # явный тип: логическое

age {{4}} 1               # прибавь единицу
puts name, age, price, in_stock`,
        blanks: [
          { answer: 'String' },
          { answer: 'Int32' },
          { answer: 'Float64' },
          { answer: 'Bool' },
          { answer: '+=' }
        ],
        ci: false
      },
      hints: [
        'Текст — String, дробное — Float64, логическое — Bool.',
        'Целое 32-битное по умолчанию — Int32: тридцать два в имени.',
        'Прибавить к переменной — составной оператор из плюса и равно.'
      ],
      solution: ['String', 'Int32', 'Float64', 'Bool', '+=']
    },

    /* ---------- 3. Условия и циклы ---------- */
    {
      id: 'crystal-3',
      title: 'Условия и циклы',
      goal: 'Разобрать ветвления if / else / unless, циклы times, while и по диапазону — и предсказать вывод',
      xp: 35,
      theory: [
        { t: 'p', html: 'Ветвление — <code>if</code>, <code>elsif</code> (именно так, слитно, как в Ruby), <code>else</code>. Условие можно писать в скобках или без; тело блока — строки с отступом, а закрывается всё словом <code>end</code>. Ветки проверяются сверху вниз, срабатывает первая истинная.' },
        { t: 'code', code: `n = 12
if n > 10
  puts "большое"
elsif n > 5
  puts "среднее"
else
  puts "маленькое"
end` },
        { t: 'p', html: 'Есть и инверсия — <code>unless</code> («если не»): тело выполняется, когда условие <b>ложно</b>. Читается как английский: unless n &gt; 10 — «если только не n больше 10». У unless нет elsif, зато есть else. А <code>while условие ... end</code> крутится, пока условие истинно.' },
        { t: 'code', code: `count = 3
while count > 0
  puts count
  count -= 1
end` },
        { t: 'p', html: 'Ruby-стиль циклов — через блоки. <code>3.times do |i|</code> повторит тело трижды, а <code>i</code> на каждом шаге получит 0, 1, 2 — <b>счёт с нуля</b>. Диапазон <code>(1..10)</code> включает оба конца, <code>(1...10)</code> с тремя точками — исключает верхнюю границу. <code>(1..10).each do |i|</code> пробежит все числа диапазона.' },
        { t: 'p', html: 'Внутри двойных кавычек работает интерполяция: <code>"total = #{total}"</code> — выражение в фигурных скобках после решётки вычисляется и вставляется в строку. Так печатают числа рядом с текстом без склейки.' },
        { t: 'note', html: 'Однострочные модификаторы — Ruby-идиома: <code>puts "готово" if ok</code> выполняет команду, только если условие истинно; <code>puts "пусто" unless list.any?</code> — если ложно. В реальном коде Crystal это встречается постоянно.' },
        { t: 'warn', html: 'Не забывай: <code>times</code> идёт с нуля — <code>5.times</code> даёт 0, 1, 2, 3, 4, а не 1..5. И закрывающий <code>end</code> обязателен для каждого блока. Код задания не запускается в приложении — циклы придётся честно прокрутить в голове.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай код и напиши, что он выведет в консоль — по одной строке на каждый вывод, в порядке появления.</p>',
        code: `total = 0
(1..10).each do |i|
  total += i
end
puts "total = #{total}"

n = 7
unless n > 10
  puts "n небольшое"
end

3.times do |i|
  puts "тик #{i}"
end`,
        answer: `total = 55
n небольшое
тик 0
тик 1
тик 2`
      },
      hints: [
        'Диапазон 1..10 включает оба конца: цикл копит 1 + 2 + ... + 10.',
        'unless выполняет тело, когда условие ложно: 7 > 10 — правда ли это?',
        'times считает с нуля: три шага — это 0, 1 и 2.'
      ],
      solution: `total = 55
n небольшое
тик 0
тик 1
тик 2`
    },

    /* ---------- 4. Методы и классы ---------- */
    {
      id: 'crystal-4',
      title: 'Методы и классы',
      goal: 'Объявлять методы def с типами параметров и результата, создавать классы с полями, конструктором и методами',
      xp: 40,
      theory: [
        { t: 'p', html: 'Метод объявляется словом <code>def</code>: имя, параметры с типами в скобках, затем двоеточие и тип результата (если он есть). Возврат — через <code>return</code>, закрывается метод словом <code>end</code>. Типы параметров и результата можно указывать явно — и тогда компилятор проверит каждый вызов.' },
        { t: 'code', code: `def double(x : Int32) : Int32
  return x * 2
end

puts double(21)   # 42` },
        { t: 'p', html: 'Скобки при вызове необязательны — Ruby-стиль позволяет и <code>double 21</code>. Тип параметра можно опустить, и он выведется, но в публичном коде типы пишут: они документация и защита одновременно. Метод без результата просто не объявляет тип после скобок.' },
        { t: 'h', html: 'Классы' },
        { t: 'code', code: `class Product
  property name : String
  property price : Int32

  def initialize(@name : String, @price : Int32)
  end
end

item = Product.new(name: "Кружка", price: 250)
puts item.name     # Кружка` },
        { t: 'p', html: '<code>class Имя ... end</code> — свой тип. Переменные экземпляра начинаются с собачки: <code>@name</code> — у каждого объекта свои. Слово <code>property</code> — макрос, который создаёт и поле, и читателя, и писателя: можно и читать <code>item.name</code>, и присваивать <code>item.name = "Чашка"</code>. Конструктор — метод <code>initialize</code>; сокращение <code>@name</code> прямо в параметрах объявляет поле и присваивает его одним махом. Объект создаётся через <code>Класс.new(...)</code>, причём аргументы удобно передавать по именам: <code>Product.new(name: "Кружка", price: 250)</code> — порядок не важен, читаемость выше. Добавим классу метод описания — и он соберёт строку из полей через интерполяцию, как обычный код:' },
        { t: 'code', code: `class Product
  property name : String
  property price : Int32

  def initialize(@name : String, @price : Int32)
  end

  def describe : String
    return "#{@name} — #{@price} руб."
  end
end` },
        { t: 'warn', html: 'Методы класса объявляются только внутри <code>class ... end</code>, и каждое вложенное определение закрывается своим <code>end</code>: свой — для initialize, свой — для describe, свой — для класса. Пропустил end — каскад непонятных ошибок компиляции.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери мини-программу: метод <code>double</code>, принимающий <code>x : Int32</code> и возвращающий <code>Int32</code> (внутри — <code>return x * 2</code>). Затем класс (например, <code>Product</code>) со свойством-строкой и методом, использующим поле <code>@имя</code>. Создай объект через <code>Product.new(...)</code> и выведи результаты вызовов <code>double</code> и метода класса через <code>puts</code>.</p>',
        starter: `# TODO: объяви метод удвоения,
# затем класс товара со свойством и методом описания`,
        rules: [
          { desc: 'Метод double объявлен через def и возвращает значение', all: ['\\bdef\\s+double\\b', '\\breturn\\s+\\S'] },
          { desc: 'Есть класс (class Имя ... end)', all: ['\\bclass\\s+[A-Z]\\w*\\b'] },
          { desc: 'В классе есть метод и поле @... или property', all: ['\\bdef\\s+\\w+', '(?:@\\w+|\\bproperty\\s+\\w+)'] },
          { desc: 'Объект создаётся через .new, результат выводится', all: ['\\.new\\b'], any: ['\\bputs\\b', '\\bp\\s+\\w+'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Метод: def double(x : Int32) : Int32 ... return x * 2 ... end.',
        'Класс: class Product ... property name : String ... def describe ... end ... end.',
        'Создание и вызовы: item = Product.new(name: "Кружка", price: 250), затем puts double(21) и puts item.describe.'
      ],
      solution: `def double(x : Int32) : Int32
  return x * 2
end

class Product
  property name : String
  property price : Int32

  def initialize(@name : String, @price : Int32)
  end

  def describe : String
    return "#{@name} — #{@price} руб."
  end
end

item = Product.new(name: "Кружка", price: 250)
puts double(21)
puts item.describe`
    },

    /* ---------- 5. Идиомы Crystal ---------- */
    {
      id: 'crystal-5',
      title: 'Идиомы Crystal',
      goal: 'Познакомиться с Union-типами String | Nil, блоками each / map / select и именованными аргументами',
      xp: 40,
      theory: [
        { t: 'p', html: 'Фирменная черта Crystal — <b>Union-типы</b>: значение может быть «то или это». Записывается через вертикальную черту: <code>String | Nil</code> — «строка или ничего». Короткое имя для «тип или nil» — знак вопроса: <code>String?</code> означает ровно <code>String | Nil</code>. Так компилятор честно говорит: значения может не быть.' },
        { t: 'code', code: `nums = [3, 8, 15]
found = nums.find { |n| n > 10 }  # тип: Int32 | Nil
puts found                        # 15

words = ["яблоко", "слива"]
w = words.find { |s| s.size > 10 } # nil — такого нет` },
        { t: 'p', html: '<code>find</code> возвращает первый подходящий элемент или nil — и тип результата честно <code>Int32 | Nil</code>. Главная выгода: компилятор <b>не даст</b> вызвать строковый метод у <code>String | Nil</code>, пока ты не проверишь значение. Ошибки «nil во время выполнения» в Crystal ловятся ещё на компиляции.' },
        { t: 'p', html: '<b>Блоки</b> — способ передать методу кусок кода: <code>each</code> перебирает, <code>map</code> преобразует каждый элемент, <code>select</code> фильтрует. Блок пишется как <code>do |x| ... end</code> или коротко <code>{ |x| ... }</code>. Параметр блока — между вертикальными чертами.' },
        { t: 'code', code: `words = ["яблоко", "слива", "груша"]
words.each { |w| puts w }          # печать каждого
lens = words.map { |w| w.size }    # [6, 5, 5]
long = words.select { |w| w.size > 5 } # ["яблоко"]` },
        { t: 'p', html: '<b>Именованные аргументы</b> — вызов с именами: <code>move(from: 1, to: 5)</code>. Порядок не важен, смысл очевиден. Агрегаты есть прямо на коллекциях и диапазонах: <code>(1..100).sum</code> даст 5050, есть и <code>max</code>, <code>min</code>, <code>count</code>.' },
        { t: 'note', html: 'Проверка типа — <code>value.is_a?(String)</code> возвращает true/false, а <code>.not_nil!</code> «достаёт» значение из Union или аварийно останавливает программу, если там nil. Но лучше не выстрел в ногу, а честный if: компилятор за него благодарит.' },
        { t: 'warn', html: 'Union-типы — не украшение: <code>s = words.find { ... }</code>, а затем <code>s.size</code> без проверки — <b>ошибка компиляции</b>, а не падение в рантайме. Сначала <code>if s</code> или <code>if s.is_a?(String)</code> — и только потом вызывай методы строки.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Какой тип у результата выражения <code>words.find { |w| w.size > 5 }</code>, где <code>words</code> — массив строк?</p>',
        options: [
          'String | Nil — строка или ничего',
          'String — найденная строка',
          'Nil — только пустота',
          'Bool — нашлось или нет'
        ],
        correct: 0,
        explain: 'find возвращает первый подходящий элемент или nil — их и объединяет тип: String | Nil (кратко String?). Именно поэтому компилятор заставит проверить значение на nil, прежде чем вызывать строковые методы.',
        solution: 0
      },
      hints: [
        'А вдруг подходящей строки в массиве нет? find обязан сообщить об этом в типе.',
        'Вертикальная черта читается как «или».'
      ],
      solution: 0
    },

    /* ---------- 6. 🚀 Проект: каталог товаров ---------- */
    {
      id: 'crystal-6',
      title: '🚀 Проект: каталог товаров',
      goal: 'Собрать класс Product, массив товаров и подсчёт итоговой суммы — весь курс в одной программе',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальная практика — каталог товаров: класс с полями из уровня про классы, массив объектов, цикл с блоком из уровня про идиомы и интерполяция строк из уровня про условия. Такая программа — типовой скелет любого учёта: товары, сотрудники, задачи.' },
        { t: 'h', html: 'Что строим' },
        { t: 'list', items: [
          'класс <code>Product</code> со свойствами <code>name : String</code> и <code>price : Int32</code>;',
          'конструктор <code>initialize</code> с сокращением <code>@поле</code>;',
          'метод описания товара, возвращающий строку;',
          'массив из 2–3 товаров, созданных через <code>Product.new(name: ..., price: ...)</code>;',
          'цикл <code>products.each do |p| ... end</code> с печатью и накоплением суммы.'
        ] },
        { t: 'code', code: `class Product
  property name : String
  property price : Int32

  def initialize(@name : String, @price : Int32)
  end
end

products = [
  Product.new(name: "Кружка", price: 250),
  Product.new(name: "Блокнот", price: 120)
]` },
        { t: 'p', html: 'Сумма копится в переменной <code>total</code>: начинается с нуля и растёт на каждой итерации цикла — <code>total += p.price</code>. Итог печатаю в конце через интерполяцию: <code>puts "Итого: #{total}"</code>. Это тот же аккумулятор, что ты прокручивал в голове на уровне про циклы — только теперь он в настоящем проекте.' },
        { t: 'warn', html: 'Не путай <code>@name</code> (поле внутри класса) и <code>p.name</code> (чтение свойства у объекта снаружи). Собачка живёт только внутри методов класса. И не оставляй в финальном коде пометок-заглушек: проект должен компилироваться целиком.' },
        { t: 'note', html: 'После зачёта развивай проект: добавь поле количества и считай стоимость позиций, найди самый дорогой товар через <code>products.max_by { |p| p.price }</code>, отсортируй каталог <code>products.sort_by</code>. Направление верное: класс описывает сущность, массив хранит коллекцию, блоки обрабатывают её в одну строку.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Каталог товаров».</b> Объяви класс <code>Product</code> со свойствами <code>name : String</code> и <code>price : Int32</code> (и конструктором, если хочешь явный). Создай массив из 2–3 товаров через <code>Product.new(name: ..., price: ...)</code>. Пройди по массиву циклом <code>each</code> с блоком: выведи каждый товар через <code>puts</code> и накопи сумму цен в <code>total</code>. В конце выведи итог.</p>',
        starter: `# TODO: объяви класс товара с полями и конструктором,
# собери массив товаров, выведи каждый и посчитай сумму`,
        rules: [
          { desc: 'Класс Product объявлен', all: ['\\bclass\\s+Product\\b'] },
          { desc: 'Свойства name : String и price : Int32 объявлены', all: ['(property\\s+name\\s*:\\s*String|@name\\s*:\\s*String)', '(property\\s+price\\s*:\\s*Int32|@price\\s*:\\s*Int32)'] },
          { desc: 'Есть конструктор initialize или свойство со значением по умолчанию', any: ['\\bdef\\s+initialize\\b', '\\bproperty\\s+\\w+\\s*:\\s*\\w+\\s*='] },
          { desc: 'В классе есть метод (def ... end)', all: ['\\bdef\\s+\\w+'] },
          { desc: 'Массив товаров создаётся литералом, объекты — через .new', all: ['\\w+\\s*=\\s*\\[', '\\.new\\b'] },
          { desc: 'Итог выводится через puts, пометок TODO нет', all: ['\\bputs\\b', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Класс: class Product ... property name : String ... property price : Int32 ... def initialize(@name : String, @price : Int32) ... end ... end.',
        'Массив: products = [Product.new(name: "Кружка", price: 250), Product.new(name: "Блокнот", price: 120)].',
        'Цикл и сумма: total = 0, затем products.each do |p| puts p.name; total += p.price end, и puts "Итого: #{total}".'
      ],
      solution: `class Product
  property name : String
  property price : Int32

  def initialize(@name : String, @price : Int32)
  end

  def describe : String
    return "#{@name} — #{@price} руб."
  end
end

products = [
  Product.new(name: "Кружка", price: 250),
  Product.new(name: "Блокнот", price: 120),
  Product.new(name: "Рюкзак", price: 1500)
]

total = 0
products.each do |p|
  puts p.describe
  total += p.price
end
puts "Итого: #{total}"`
    },

    /* ---------- 7. Классы и типизация переменных ---------- */
    {
      id: 'crystal-7',
      title: 'Классы и типизация переменных',
      goal: 'Объявлять типы переменных экземпляра (@поле : Тип) в теле класса, property/getter и initialize с параметрами-типами',
      xp: 50,
      theory: [
        { t: 'p', html: 'На уровне про классы поля появлялись через сокращение <code>@name</code> в параметрах initialize. Теперь — полная форма: переменную экземпляра можно объявить прямо в теле класса с явным типом: <code>@balance : Int32</code>. Это контракт класса: любое присваивание чужого типа не скомпилируется.' },
        { t: 'code', code: `class Account
  @owner : String
  @balance : Int32

  property balance : Int32

  def initialize(@owner : String, @balance : Int32 = 0)
  end
end` },
        { t: 'p', html: '<code>property</code> — макрос, создающий и поле, и пару методов: читатель balance и писатель balance=. Если запись извне не нужна — есть <code>getter</code> (только чтение) и <code>setter</code> (только запись). Дефолтное значение в параметре initialize делает аргумент необязательным: <code>Account.new(owner: "Аня")</code> создаст счёт с нулевым балансом.' },
        { t: 'table', head: ['Объявление', 'Что даёт'], rows: [
          ['@balance : Int32', 'тип поля, проверяется компилятором'],
          ['property balance : Int32', 'поле + читатель + писатель'],
          ['getter status : Symbol', 'только чтение снаружи'],
          ['def initialize(@x : T)', 'сокращение: поле и присваивание одним махом']
        ] },
        { t: 'p', html: 'Типы в сигнатуре — документация и защита одновременно: <code>acc.deposit("много")</code> не скомпилируется, компилятор покажет строку и несовместимые типы. А внутри метода типы уже известны, поэтому <code>@balance += amount</code> безопасен: Int32 плюс Int32. Сигнатуры ещё и документируют: через полгода ты прочитаешь <code>def deposit(amount : Int32) : Int32</code> и сразу поймёшь, что метод принимает и что вернёт.' },
        { t: 'warn', html: 'Собачка @поле видна только внутри методов класса: снаружи — только через property-методы. Забыл property — acc.balance упадёт при компиляции, а не в рантайме: Crystal ловит такие вещи до запуска. И помни: переменная экземпляра обязана получить значение в initialize до использования.' },
        { t: 'note', html: 'Для маленьких структур данных у Crystal есть и struct — значение вместо ссылки, копируется при присваивании. В финальном проекте сделаем реестр книг именно на struct. А наследование классов пишется через знак меньше: class Savings &lt; Account.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери класс счёта: объяви <code>Account</code> с типизированными переменными экземпляра (<code>@owner : String</code>, <code>@balance : Int32</code>), добавь <code>property</code> и <code>initialize</code> с типизированными параметрами (можно с дефолтом). Добавь классу метод, использующий поля-собачки. Создай счёт через <code>Account.new(...)</code> и выведи что-нибудь через <code>puts</code>.</p>',
        starter: `# TODO: объяви класс счёта с типизированными переменными экземпляра
# TODO: добавь property, initialize и метод пополнения
# TODO: создай счёт и выведи описание`,
        rules: [
          { desc: 'Класс Account объявлен', all: ['\\bclass\\s+Account\\b'] },
          { desc: 'Типизированные переменные экземпляра (@поле : Тип)', all: ['@\\w+\\s*:\\s*[A-Z]\\w*'] },
          { desc: 'Свойство property (или getter) с типом', all: ['\\b(property|getter)\\s+\\w+\\s*:'] },
          { desc: 'Конструктор initialize с типизированными параметрами', all: ['\\bdef\\s+initialize\\s*\\(', ':\\s*[A-Z]\\w*'] },
          { desc: 'Метод класса с использованием поля @', all: ['\\bdef\\s+\\w+', '@\\w+'] },
          { desc: 'Объект через .new и вывод puts, пометок TODO нет', all: ['\\.new\\b', '\\bputs\\b'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Объявления в теле класса: @owner : String и @balance : Int32 — до initialize.',
        'property balance : Int32 создаст читателя и писателя; в initialize можно задать дефолт: @balance : Int32 = 0.',
        'Метод: def deposit(amount : Int32) : Int32 — внутри @balance += amount; создание: Account.new(owner: "Аня", balance: 500).'
      ],
      solution: `class Account
  @owner : String
  @balance : Int32

  property balance : Int32
  property owner : String

  def initialize(@owner : String, @balance : Int32 = 0)
  end

  def deposit(amount : Int32) : Int32
    @balance += amount
    @balance
  end

  def describe : String
    "#{@owner}: #{@balance} руб."
  end
end

acc = Account.new(owner: "Аня", balance: 500)
acc.deposit(250)
puts acc.describe`
    },

    /* ---------- 8. Union-типы и nil-проверки ---------- */
    {
      id: 'crystal-8',
      title: 'Union-типы и nil-проверки',
      goal: 'Разобраться с (T | Nil): почему методы не вызываются без проверки и чем not_nil! отличается от if',
      xp: 45,
      theory: [
        { t: 'p', html: 'Вернёмся к Union-типам — и доведём до автоматизма. <code>String | Nil</code> означает «строка или ничего», краткая запись <code>String?</code> — то же самое. Компилятор обращается с таким значением строго: пока ты не доказал, что там не nil, вызывать методы строки запрещено.' },
        { t: 'code', code: `nums = [4, 8, 15]
found = nums.find { |n| n > 100 }   # Int32 | Nil
# found.size  ← ошибка компиляции!` },
        { t: 'p', html: 'Эта ошибка компиляции — не занудство, а защита: в динамических языках тот же код упал бы в рантайме с NoMethodError у nil — в продакшене, ночью. Crystal переносит падение на этап компиляции: сначала проверка — потом вызов. Одна строка на проверку спасает от целого класса ночных инцидентов.' },
        { t: 'code', code: `if found
  puts "нашёл: #{found}"   # здесь тип уже Int32
else
  puts "нет такого"
end` },
        { t: 'p', html: 'Внутри ветки if компилятор сужает тип: found уже Int32, и любые числовые методы легальны. Это называется сужением типа по ходу исполнения. Проверять можно и явно: <code>found.is_a?(Int32)</code>, <code>found.nil?</code> — вернёт Bool.' },
        { t: 'table', head: ['Приём', 'Что делает'], rows: [
          ['if value', 'nil — ложь, значение — истина; тип сужается в ветке'],
          ['value.is_a?(T)', 'проверка типа, true/false'],
          ['value.nil?', 'true, если значение — nil'],
          ['value.not_nil!', 'вернуть значение типа T или выбросить исключение']
        ] },
        { t: 'warn', html: 'not_nil! — осознанный выстрел себе в ногу: он компилируется, но если под типом лежит nil, программа падает с NilAssertionError при запуске. Оставь его для мест, где невозможность nil доказана логикой, а обычный код пиши через if — компилятор за это благодарит.' },
        { t: 'note', html: 'Сравни с Ruby: там обращение к методу у nil тоже падает, но только при выполнении. Crystal — это Ruby, который заранее всё проверил: та же красота синтаксиса, плюс компилятор-контролёр на входе.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Прочитай программу:</p><pre>nums = [4, 8, 15]
found = nums.find { |n| n > 100 }
puts found.not_nil!</pre><p>Что произойдёт при её выполнении?</p>`,
        options: [
          'Напечатает 15 — find вернул наибольшее число',
          'Скомпилируется, но упадёт при запуске: find вернул nil, а not_nil! на nil выбрасывает NilAssertionError',
          'Не скомпилируется: у типа Int32 | Nil нельзя вызывать методы',
          'Напечатает nil'
        ],
        correct: 1,
        explain: 'find ищет число больше 100, но максимум в списке — 15, поэтому вернёт nil. not_nil! компилируется — это метод самого Union-типа, — но при выполнении под типом лежит nil, и программа падает с NilAssertionError. Безопасная альтернатива — if found: в ветке тип сужается до Int32.',
        solution: 1
      },
      hints: [
        'Есть ли в списке число больше 100? Посмотри внимательно.',
        'not_nil! проходит компиляцию — это метод самого Union-типа.',
        'Что делает not_nil!, если под типом лежит именно nil?'
      ],
      solution: 1
    },

    /* ---------- 9. Модули, generics и ограничения ---------- */
    {
      id: 'crystal-9',
      title: 'Модули, generics и ограничения',
      goal: 'Объявлять модули-пространства имён, обобщённые классы Box(T) и методы с ограничениями типов',
      xp: 55,
      theory: [
        { t: 'p', html: '<code>module</code> — контейнер, объединяющий классы и методы под общим именем. Это пространство имён: класс Box внутри модуля Registry зовётся <code>Registry::Box</code>, метод — <code>Registry.first_of</code>. В больших проектах модули группируют код по смыслу: DB, Models, Services.' },
        { t: 'code', code: `module Registry
  class Box(T)
    property value : T

    def initialize(@value : T)
    end

    def describe : String
      "Box(#{T}): #{@value}"
    end
  end

  def self.first_of(boxes : Array(Box(Int32))) : Int32
    boxes.first.value
  end
end` },
        { t: 'p', html: '<code>class Box(T)</code> — обобщённый класс: T — параметр типа, который определяется при создании объекта. <code>Registry::Box.new(42)</code> даёт Box(Int32), <code>Registry::Box.new("текст")</code> — Box(String). Один исходник — сколько угодно типизированных версий. Точно так же устроены коллекции языка: Array(T), Hash(K, V).' },
        { t: 'p', html: 'Ограничения в Crystal задаются не extends-границами, как в Java, а типами в сигнатурах методов: first_of принимает строго <code>Array(Box(Int32))</code> — передашь массив Box(String), и компиляция упадёт. Метод <code>def self.first_of</code> — метод самого модуля: вызывается без создания объектов. Так компилятор проверяет ограничения при каждом вызове: ошибка видна на месте, а не в тестах.' },
        { t: 'warn', html: 'T в скобках после имени класса — обязательная часть синтаксиса: class Box(T), не class Box T. Поле обобщённого типа — property value : T; в интерполяции #{T} напечатается имя конкретного типа. И не забывай закрывать end-ами модуль, класс и методы.' },
        { t: 'note', html: 'Модули в Crystal умеют больше: include в классе подмешивает методы (миксины, как в Ruby), abstract def объявляет контракт без реализации, а обобщённые модули тоже пишутся с параметром (T). Сегодня — пространства имён и дженерики; остальное подождёт.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери модуль-реестр: объяви <code>module Registry</code> с обобщённым классом <code>Box(T)</code> (поле <code>value : T</code>, конструктор, любой метод) и методом модуля <code>def self....</code> с ограничением типа (например, аргумент <code>: Array(Box(Int32))</code>). Создай коробку через <code>Registry::Box.new(...)</code> и выведи значения через <code>puts</code>.</p>',
        starter: `# TODO: объяви модуль с обобщённым классом Box(T)
# TODO: добавь метод с ограничением типа
# TODO: создай коробку и выведи значение`,
        rules: [
          { desc: 'Модуль объявлен (module Имя)', all: ['\\bmodule\\s+[A-Z]\\w*\\b'] },
          { desc: 'Обобщённый класс Box(T) объявлен', all: ['\\bclass\\s+Box\\s*\\(\\s*T\\s*\\)'] },
          { desc: 'Поле обобщённого типа (: T)', all: [':\\s*T\\b'] },
          { desc: 'Конструктор initialize объявлен', all: ['\\bdef\\s+initialize\\b'] },
          { desc: 'Метод с ограничением типа (def self. или аргумент Array/Box)', any: ['\\bdef\\s+self\\.\\w+', ':\\s*(Array\\s*\\(\\s*)?Box\\s*\\('] },
          { desc: 'Обращение через Модуль::Класс и создание через .new', all: ['\\w+::\\w+', '\\.new\\b'] },
          { desc: 'Вывод через puts, пометок TODO нет', all: ['\\bputs\\b', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас: module Registry ... class Box(T) ... property value : T ... def initialize(@value : T) ... end ... end.',
        'Метод модуля: def self.first_of(boxes : Array(Box(Int32))) : Int32 — ограничение прямо в сигнатуре.',
        'Использование: box = Registry::Box.new(42), затем puts box.value и puts Registry.first_of([box]).'
      ],
      solution: `module Registry
  class Box(T)
    property value : T

    def initialize(@value : T)
    end

    def describe : String
      "Box(#{T}): #{@value}"
    end
  end

  def self.first_of(boxes : Array(Box(Int32))) : Int32
    boxes.first.value
  end
end

box = Registry::Box.new(42)
puts box.describe
puts Registry.first_of([box])`
    },

    /* ---------- 10. Проект: реестр книг ---------- */
    {
      id: 'crystal-10',
      title: '🚀 Проект: реестр книг',
      goal: 'Собрать реестр: struct Book с типизированными полями, массив, фильтр select и поиск find, вывод через puts',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — реестр книг: маленький struct Book с типизированными полями, массив книг, фильтр select и поиск find. Такая программа — типовой скелет любого каталога: товары, сотрудники, задачи, библиотеки. За уровень реестр обрастёт поиском и фильтрами — как настоящий каталог.' },
        { t: 'list', items: [
          '<b>struct Book</b> — книга: <code>title : String</code>, <code>author : String</code>, <code>year : Int32</code>, метод <code>info</code>;',
          '<b>массив</b> — книги создаются <code>Book.new(...)</code> прямо в литерале;',
          '<b>select</b> — фильтр по условию, возвращает массив;',
          '<b>find</b> — первая книга по условию или nil;',
          '<b>puts</b> — печать каталога и итогов.'
        ] },
        { t: 'code', code: `struct Book
  property title : String
  property author : String
  property year : Int32

  def initialize(@title : String, @author : String, @year : Int32)
  end

  def info : String
    "#{@title} — #{@author} (#{@year})"
  end
end

books = [
  Book.new("Мы", "Замятин", 1921),
  Book.new("Мастер и Маргарита", "Булгаков", 1967),
  Book.new("Кристина", "Кинг", 1983)
]

old = books.select { |b| b.year < 1950 }
found = books.find { |b| b.author == "Замятин" }

books.each do |b|
  puts b.info
end

puts "Книг до 1950 года: #{old.size}"
if found
  puts "Найдена: #{found.info}"
end` },
        { t: 'p', html: 'struct отличается от class семантикой значения: при присваивании книга копируется, а не передаётся по ссылке. Для маленьких сущностей — точек, дат, книг — это идеальный выбор: дешёво и без сюрпризов общего состояния. Всё остальное — property, initialize, методы — работает как у класса.' },
        { t: 'p', html: 'find возвращает Book | Nil — поэтому перед вызовом found.info стоит проверка <code>if found</code>: компилятор сужает тип, и внутри ветки методы книги легальны. select возвращает просто массив — его размер считаем через <code>size</code>. Правило простое: пришёл Union — сначала if, потом методы.' },
        { t: 'warn', html: 'У каждого блока свой end: struct, метод, цикл each, if. Забытый end — каскад ошибок компиляции. И не вызывай методы у find-результата без проверки — компилятор не пропустит, а обходной not_nil! падает на nil.' },
        { t: 'note', html: 'Куда развивать: отсортируй реестр <code>books.sort_by { |b| b.year }</code>, сгруппируй по автору <code>books.group_by { |b| b.author }</code>, найди самую новую <code>books.max_by { |b| b.year }</code>. Коллекции Crystal решают эти задачи в одну строку с блоком.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Реестр книг».</b> Объяви <code>struct Book</code> (или класс) с типизированными полями (строки и число) и методом-описанием, возвращающим строку. Собери массив минимум из трёх книг через <code>Book.new(...)</code>. Отфильтруй его через <code>select</code> с блоком и найди книгу через <code>find</code> с блоком. Выведи каталог и итоги через <code>puts</code> (для find-результата — с проверкой на nil).</p>',
        starter: `# TODO: объяви книгу — структура или класс с типизированными полями и методом описания
# TODO: собери массив книг, отфильтруй и найди нужную
# TODO: выведи каталог и итоги`,
        rules: [
          { desc: 'Book объявлен как struct или class', any: ['\\bstruct\\s+Book\\b', '\\bclass\\s+Book\\b'] },
          { desc: 'Типизированные поля String и Int32 (@поле : Тип)', all: ['@\\w+\\s*:\\s*String', '@\\w+\\s*:\\s*Int32'] },
          { desc: 'Конструктор initialize объявлен', all: ['\\bdef\\s+initialize\\b'] },
          { desc: 'Метод-описание возвращает строку (: String)', all: ['\\bdef\\s+\\w+\\s*:\\s*String'] },
          { desc: 'Массив книг создаётся литералом с .new', all: ['\\w+\\s*=\\s*\\[', '\\.new\\b'] },
          { desc: 'select фильтрует книги', any: ['\\.select\\s*\\{', '\\.select\\s+do\\b'] },
          { desc: 'find ищет книгу', any: ['\\.find\\s*\\{', '\\.find\\s+do\\b'] },
          { desc: 'Вывод через puts, пометок TODO нет', all: ['\\bputs\\b', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас: struct Book ... property title : String ... def initialize(@title : String, @author : String, @year : Int32) ... def info : String ... end.',
        'Массив: books = [Book.new("Мы", "Замятин", 1921), Book.new("Мастер и Маргарита", "Булгаков", 1967)].',
        'Обработка: old = books.select { |b| b.year < 1950 }, found = books.find { |b| b.author == "Замятин" }, печать через each и puts, итог — if found ... end.'
      ],
      solution: `struct Book
  property title : String
  property author : String
  property year : Int32

  def initialize(@title : String, @author : String, @year : Int32)
  end

  def info : String
    "#{@title} — #{@author} (#{@year})"
  end
end

books = [
  Book.new("Мы", "Замятин", 1921),
  Book.new("Мастер и Маргарита", "Булгаков", 1967),
  Book.new("Кристина", "Кинг", 1983)
]

old = books.select { |b| b.year < 1950 }
found = books.find { |b| b.author == "Замятин" }

books.each do |b|
  puts b.info
end

puts "Книг до 1950 года: #{old.size}"
if found
  puts "Найдена: #{found.info}"
end`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Первая программа',
      code: `puts "Привет, CodeQuest!"
# файл main.cr
# запуск:  crystal run main.cr
# сборка:  crystal build main.cr`
    },
    {
      title: 'Переменные и типы',
      code: `name = "Аня"       # String — тип выведется
age = 25           # Int32 (целое по умолчанию)
price = 9.99       # Float64
in_stock = true    # Bool
age : Int64 = 25   # явный тип
age += 1           # составные: -= *=
# тип сменить нельзя: name = 5 — ошибка компиляции`
    },
    {
      title: 'Условия и циклы',
      code: `if n > 10
  puts "большое"
elsif n > 5
  puts "среднее"
else
  puts "маленькое"
end

unless ok            # «если не»
  puts "провал"
end

3.times do |i|       # i: 0, 1, 2
  puts i
end
(1..10).each do |i|  # 1..10 — оба конца включены
  total += i
end
while count > 0
  count -= 1
end
puts "готово" if ok  # модификатор if`
    },
    {
      title: 'Методы и классы',
      code: `def double(x : Int32) : Int32
  return x * 2
end
puts double(21)

class Product
  property name : String   # поле + читатель + писатель
  property price : Int32

  def initialize(@name : String, @price : Int32)
  end

  def describe : String
    return "#{@name} — #{@price}"
  end
end

item = Product.new(name: "Кружка", price: 250)
puts item.describe`
    },
    {
      title: 'Union-типы и блоки',
      code: `found = nums.find { |n| n > 10 }  # Int32 | Nil
if found               # проверка перед методом!
  puts found
end

words.map { |w| w.size }       # преобразовать
words.select { |w| w.size > 5 } # отфильтровать
(1..100).sum                   # 5050
move(from: 1, to: 5)           # именованные аргументы
value.is_a?(String)            # проверка типа
String?                        # = String | Nil`
    },
    {
      title: 'Частые ошибки',
      list: [
        'одинарные кавычки — это Char, строкам нужны двойные',
        'забытый end — каскад ошибок компиляции',
        'times считает с нуля: 5.times → 0..4',
        'переменная не может сменить тип',
        'метод на nil не скомпилируется — проверь Union-значение',
        'собачка @поле — внутри класса, p.поле — снаружи',
        'интерполяция только в двойных кавычках: "#{x}"'
      ]
    },
    {
      title: 'Классы: типизация полей',
      code: `class Account
  @balance : Int32        # тип переменной экземпляра
  property owner : String # поле + читатель + писатель
  getter status : Symbol  # только чтение

  def initialize(@owner : String, @balance : Int32 = 0)
  end
end

acc = Account.new(owner: "Аня")
acc.balance += 100   # property даёт и запись`
    },
    {
      title: 'Модули, generics и nil',
      code: `module Registry
  class Box(T)
    property value : T
    def initialize(@value : T); end
  end

  def self.first_of(boxes : Array(Box(Int32))) : Int32
    boxes.first.value
  end
end

b = Registry::Box.new(42)

found = nums.find { |x| x > 100 }  # T | Nil
if found                            # тип сужается в ветке
  puts found
end
found.not_nil!  # T или NilAssertionError на nil`
    }
  ]
};
