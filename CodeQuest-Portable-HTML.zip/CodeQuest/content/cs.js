'use strict';
/* ============ CodeQuest: контент курса C# ============ */

window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.cs = {
  id: 'cs',
  title: 'C#',
  emoji: '🎯',
  color: '#178600',
  lang: 'c',
  tagline: 'C#: от WriteLine до LINQ, async и своих классов',
  description: 'C# — язык платформы .NET: на нём делают игры на Unity, приложения и веб-сервисы. За 20 уровней пройдём путь от Console.WriteLine до проекта «Учёт сотрудников» с интерфейсами, коллекциями, LINQ и async/await.',

  levels: [
    /* ============ 1. Первая программа ============ */
    {
      id: 'cs-1',
      title: 'Первая программа',
      goal: 'Собрать и понять каркас C#-программы: using, class, Main и Console.WriteLine.',
      xp: 30,
      theory: [
        { t: 'h', html: 'Твоя первая программа на C#' },
        { t: 'p', html: 'C# (произносится «си шарп») — язык от Microsoft, работающий на платформе .NET. На нём написаны игры на Unity, десктопные программы, сайты и облачные сервисы. C# — компилируемый и строго типизированный: компилятор проверяет код до запуска и не пропустит опечатки. Из-за этой строгости C# кажется новичку многословным, но именно она делает большие проекты управляемыми: ошибка ловится сразу, а не в бою.' },
        { t: 'p', html: 'Разберём каркас по строкам. <code>using System;</code> подключает базовую библиотеку .NET — именно там живёт Console. <code>class Program</code> объявляет класс-контейнер: в C# весь код живёт внутри классов. <code>static void Main()</code> — точка входа: выполнение программы всегда начинается с неё. Внутри фигурных скобок — инструкции, каждая заканчивается точкой с запятой.' },
        { t: 'code', code: `using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Привет, CodeQuest!");
    }
}` },
        { t: 'table', head: ['Часть', 'Зачем нужна'], rows: [
          ['using System;', 'Подключает базовую библиотеку (там живёт Console)'],
          ['class Program', 'Контейнер для кода — в C# всё внутри классов'],
          ['static void Main()', 'Точка входа: старт программы'],
          ['Console.WriteLine("...")', 'Выводит строку в консоль']
        ] },
        { t: 'h', html: 'Как запустить самому: dotnet' },
        { t: 'p', html: 'Установи .NET SDK (он бесплатный, с официального сайта Microsoft). В терминале создай проект командой <code>dotnet new console</code> — появится файл Program.cs с каркасом. Главная команда — <code>dotnet run</code>: она компилирует и сразу запускает программу. Если в коде опечатка, dotnet честно покажет номер строки и подскажет, что не так, — читай его сообщения, это быстрее, чем гадать.' },
        { t: 'note', html: '<code>Console.WriteLine</code> выводит текст и переносит строку. <code>Console.Write</code> не переносит: следующий вывод окажется на той же строке. Пустая строка — <code>Console.WriteLine();</code> без аргументов.' },
        { t: 'warn', html: 'C# чувствителен к регистру: <code>console.writeline</code> не существует — нужен <code>Console.WriteLine</code>. И не забывай точку с запятой ; в конце каждой инструкции.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери свою первую программу: замени заглушку <code>TODO</code> так, чтобы программа поприветствовала мир.</p><ul><li>каркас <code>using System;</code>, класс <code>Program</code> и метод <code>Main</code> уже есть — не удаляй их;</li><li>выведи строку <code>"Привет, CodeQuest!"</code> через <code>Console.WriteLine</code>;</li><li>убери все комментарии с <code>TODO</code>.</li></ul>',
        starter: `using System;

class Program
{
    static void Main()
    {
        // TODO: выведи приветствие "Привет, CodeQuest!"
    }
}`,
        rules: [
          { desc: 'Подключено пространство имён System', all: ['using\\s+System\\s*;'] },
          { desc: 'Есть класс Program', all: ['\\bclass\\s+Program\\b'] },
          { desc: 'Есть точка входа Main', any: ['static\\s+void\\s+Main\\s*\\(', 'static\\s+int\\s+Main\\s*\\(', 'internal\\s+static\\s+void\\s+Main\\s*\\('] },
          { desc: 'Текст выводится через Console.WriteLine / Write', any: ['Console\\.WriteLine', 'Console\\.Write'] },
          { desc: 'Выведена строка «Привет, CodeQuest!»', all: ['"[^"]*Привет\\s*,\\s*CodeQuest[^"]*"'] },
          { desc: 'Код непуст и все заглушки TODO заменены', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Каркас уже собран — твоя работа идёт внутри метода Main, между фигурными скобками.',
        'Вывод делается одним вызовом: Console.WriteLine("..."); — кавычки двойные, в конце точка с запятой.',
        'Проверь, что ни в одной строке не осталось слова TODO.'
      ],
      solution: `using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Привет, CodeQuest!");
    }
}`
    },

    /* ============ 2. Переменные ============ */
    {
      id: 'cs-2',
      title: 'Переменные и типы',
      goal: 'Хранить данные в переменных правильных типов: int, double, string, bool и var.',
      xp: 30,
      theory: [
        { t: 'h', html: 'Переменные: коробки с ярлыком типа' },
        { t: 'p', html: 'Переменная — именованная ячейка памяти для данных. В C# у каждой переменной <b>строгий тип</b>: он указывается при объявлении и больше не меняется. Компилятор по типу понимает, сколько памяти выделить и какие операции разрешены. Объявление выглядит так: <code>тип имя = значение;</code>. Попытка положить строку в числовую переменную — ошибка ещё до запуска: это раздражает поначалу, но спасает от тихих багов потом.' },
        { t: 'table', head: ['Тип', 'Что хранит', 'Примеры'], rows: [
          ['int', 'Целые числа', '42, -7, 0'],
          ['double', 'Дробные числа', '3.14, -0.5'],
          ['string', 'Текст в двойных кавычках', '"Привет"'],
          ['bool', 'Истина или ложь', 'true, false'],
          ['var', 'Тип выводит компилятор сам', 'var count = 10;']
        ] },
        { t: 'code', code: `using System;

class Program
{
    static void Main()
    {
        int score = 95;
        double speed = 7.5;
        string name = "Аня";
        bool isAlive = true;
        var clicks = 120;       // компилятор выводит тип int

        score = score + 5;      // теперь 100
        Console.WriteLine($"{name}: {score} очков");
    }
}` },
        { t: 'p', html: 'Имя переменной придумываешь ты: латинские буквы, цифры и подчёркивания, но не с цифры и не совпадающее с ключевыми словами (int, if, class). Хорошие имена объясняют смысл: <code>playerScore</code> лучше, чем <code>x2</code>. Значение можно менять сколько угодно раз — тип при этом остаётся прежним: в int-коробку дробь просто не влезет.' },
        { t: 'list', items: [
          'Объявил — сразу присвой значение: int hp = 100;',
          'Для констант пиши const: const int MaxLevel = 99; — изменить нельзя',
          'var экономит место: var price = 9.99; — это double, тип выведен из значения',
          'var работает только при объявлении с присваиванием: просто var x; — ошибка'
        ] },
        { t: 'note', html: 'Дробная часть отделяется <b>точкой</b>, а не запятой: <code>3.14</code> — правильно, <code>3,14</code> — ошибка. Литерал вроде 3.14 в C# имеет тип double.' },
        { t: 'warn', html: 'Деление двух int отбрасывает дробную часть: <code>10 / 3</code> даст 3, а не 3.33. Нужна точность — сделай один операнд дробным: <code>10 / 3.0</code>.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Заполни пропуски <b>типами</b> так, чтобы код соответствовал комментариям: очки — целое, температура — дробное, имя — текст, флаг — истина/ложь, а у последней переменной тип пусть выведет сам компилятор. Каждое из пяти слов используется один раз.</p>',
        code: `using System;

class Program
{
    static void Main()
    {
        {{0}} score = 95;          // целое число очков
        {{1}} temperature = 36.6;  // дробная температура
        {{2}} player = "Аня";      // имя игрока — текст
        {{3}} isAlive = true;      // жив ли игрок
        {{4}} clicks = 120;        // тип выведет сам компилятор

        Console.WriteLine($"{player}: {score} очков, жив — {isAlive}");
        Console.WriteLine($"Температура: {temperature}, кликов: {clicks}");
    }
}`,
        blanks: [
          { answer: 'int' },
          { answer: 'double' },
          { answer: 'string' },
          { answer: 'bool' },
          { answer: 'var', alt: ['int'] }
        ]
      },
      hints: [
        'Пять ответов на пять пропусков: int, double, string, bool, var.',
        'Целые числа — int, дробные — double, текст — string, истина/ложь — bool.',
        'Комментарий «тип выведет сам компилятор» — прямая подсказка: там живёт var.'
      ],
      solution: ['int', 'double', 'string', 'bool', 'var']
    },

    /* ============ 3. Конвертация типов ============ */
    {
      id: 'cs-3',
      title: 'Конвертация типов',
      goal: 'Превращать строки в числа и обратно: int.Parse, ToString, Convert и безопасный TryParse.',
      xp: 35,
      theory: [
        { t: 'h', html: 'Строка или число? Научись переводить' },
        { t: 'p', html: 'Данные из внешнего мира почти всегда приходят строками: ввод пользователя, аргументы программы, текстовые поля интерфейса — всё это string. Но считать на строках нельзя: <code>"2" + "3"</code> даст <code>"23"</code>, а не 5. Поэтому строки превращают в числа перед вычислениями — и обратно, когда результат нужно вставить в сообщение.' },
        { t: 'table', head: ['Способ', 'Что делает', 'Пример'], rows: [
          ['int.Parse(s)', 'строка → целое число', 'int n = int.Parse("42");'],
          ['double.Parse(s)', 'строка → дробное число', 'double d = double.Parse("3.14");'],
          ['x.ToString()', 'число → строка', 'string s = 42.ToString();'],
          ['Convert.ToInt32(s)', 'строка → целое число', 'int c = Convert.ToInt32("100");'],
          ['int.TryParse(s, out r)', 'безопасная попытка', 'bool ok = int.TryParse("abc", out int r);']
        ] },
        { t: 'code', code: `using System;

class Program
{
    static void Main()
    {
        string raw = "150";
        int n = int.Parse(raw);        // строка → число
        n = n + 50;

        string message = "Итог: " + n.ToString();
        Console.WriteLine(message);    // Итог: 200
    }
}` },
        { t: 'p', html: 'Кстати, склейка со строкой и так превращает число в текст: <code>"Итог: " + n</code> работает без явного ToString() — компилятор сам вызовет его для числа. Но в самостоятельных выражениях вроде <code>n.ToString().Length</code> явный вызов обязателен: у int нет свойства Length, а у строки — есть.' },
        { t: 'note', html: '<code>int.Parse("abc")</code> бросит исключение FormatException и уронит программу. Если данные могут быть «грязными» (а ввод пользователя — всегда!), используй <code>int.TryParse</code>: он вернёт false вместо падения, а результат положит в переменную из <code>out</code>.' },
        { t: 'warn', html: '<code>int.Parse("3.14")</code> тоже упадёт: int не умеет дроби — для дробных строк есть <code>double.Parse</code>. И помни: <code>"5" + 2</code> — это строка <code>"52"</code>. Если в склейке участвует хотя бы одна строка, все операнды становятся текстом.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Внимательно прочитай код и выбери, что он выведет в консоль:</p><pre>string raw = "17";
int n = int.Parse(raw);
n = n * 2;
string res = n.ToString() + "!";
Console.WriteLine(res);</pre>`,
        options: ['1717!', '34!', 'Ошибка: строку "17" нельзя умножить на 2', '17 2!'],
        correct: 1,
        explain: 'int.Parse("17") даёт число 17. Затем 17 * 2 = 34. n.ToString() возвращает строку "34", плюс склейка с "!" — получается 34!.',
        solution: 1
      },
      hints: [
        'Иди по строкам по порядку: сначала строка превращается в число, потом арифметика.',
        '"17" становится числом 17, потом 34, потом снова строкой — и склеивается с "!" от отдельной строки.'
      ],
      solution: 1
    },

    /* ============ 4. Условия ============ */
    {
      id: 'cs-4',
      title: 'Условия: if, else и switch',
      goal: 'Управлять ходом программы: if/else, цепочки else if и переключатель switch.',
      xp: 35,
      theory: [
        { t: 'h', html: 'Развилки: if и else' },
        { t: 'p', html: 'Программы редко идут по прямой: поведение зависит от данных. Развилку задаёт <code>if</code>: в скобках — условие типа bool, в фигурных скобках — код, который выполнится только при истинном условии. Пара <code>else</code> — «иначе»: ветка для всех остальных случаев. Цепочка <code>else if</code> проверяет варианты по очереди, пока один не сработает, — остальные пропускаются.' },
        { t: 'code', code: `using System;

class Program
{
    static void Main()
    {
        int temperature = 14;

        if (temperature > 25)
        {
            Console.WriteLine("Жарко!");
        }
        else if (temperature >= 10)
        {
            Console.WriteLine("Нормально");
        }
        else
        {
            Console.WriteLine("Холодно");
        }
    }
}` },
        { t: 'table', head: ['Оператор', 'Смысл', 'Пример'], rows: [
          ['==', 'равно', 'score == 100'],
          ['!=', 'не равно', 'name != ""'],
          ['> , <', 'больше, меньше', 'age > 17'],
          ['>= , <=', 'больше или равно, меньше или равно', 'hp <= 0'],
          ['&&', 'и — истинны оба условия', 'age > 12 && age < 18'],
          ['||', 'или — истинно хотя бы одно', 'day == 6 || day == 7'],
          ['!', 'отрицание', '!isReady']
        ] },
        { t: 'h', html: 'Переключатель switch' },
        { t: 'p', html: 'Когда одна переменная сравнивается с набором конкретных значений, читаемее <code>switch</code>: он сравнивает значение с вариантами <code>case</code> и выполняет подходящую ветку. Каждый case заканчивается <code>break</code> — выходом из switch; без него выполнение «провалится» в следующий case. Ветка <code>default</code> срабатывает, если ни один вариант не подошёл, — как else на все оставшиеся случаи.' },
        { t: 'code', code: `using System;

class Program
{
    static void Main()
    {
        int score = 85;

        switch (score / 10)
        {
            case 10:
            case 9:
                Console.WriteLine("Отлично");
                break;
            case 8:
                Console.WriteLine("Хорошо");
                break;
            default:
                Console.WriteLine("Есть куда расти");
                break;
        }
    }
}` },
        { t: 'note', html: 'Два case подряд (<code>case 10:</code> и <code>case 9:</code>) — это «или»: одна ветка на оба значения. Фигурные скобки после if формально необязательны для одной инструкции, но со скобками { } безопаснее — меньше шансов ошибиться при дописывании кода.' },
        { t: 'warn', html: 'Главная ловушка: одиночное <code>=</code> присваивает, двойное <code>==</code> сравнивает. Условие <code>if (x = 5)</code> в C# не скомпилируется (if требует bool), но привычка писать одно «=» в сравнении опасна — в других языках она тихо портит данные. Сравнение — всегда ==' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Доведи программу до ума. Переменная <code>score = 85</code> уже объявлена.</p><ul><li>ветвление <code>if (score &gt;= 60)</code> выводит «Зачёт», ветка <code>else</code> — «Не зачёт»;</li><li>добавь <code>switch (score / 10)</code>: в <code>case 9</code> (вместе с 10) — «Отлично», в <code>case 8</code> — «Хорошо», в <code>case 7</code> — «Удовлетворительно», в <code>default</code> — «Есть куда расти»;</li><li>каждый <code>case</code> заканчивай <code>break;</code>;</li><li>убери все <code>TODO</code>.</li></ul>',
        starter: `using System;

class Program
{
    static void Main()
    {
        int score = 85;

        // TODO: ветвление — если score >= 60, выведи "Зачёт",
        // в противном случае — "Не зачёт"

        // TODO: переключатель по score / 10 — варианты 9 (и 10), 8, 7 и default
    }
}`,
        rules: [
          { desc: 'Объявлена переменная int score = 85', all: ['\\bint\\s+score\\s*=\\s*85\\s*;'] },
          { desc: 'Есть if с условием score >= 60', all: ['if\\s*\\(\\s*score\\s*>=\\s*60\\s*\\)'] },
          { desc: 'Есть ветка else', all: ['\\belse\\b'] },
          { desc: 'Результаты выводятся через Console.WriteLine', any: ['Console\\.WriteLine', 'Console\\.Write'] },
          { desc: 'Есть switch (score / 10) с case, break и default', all: ['switch\\s*\\(\\s*score\\s*/\\s*10', '\\bcase\\s+\\d', '\\bbreak\\s*;', '\\bdefault\\s*:'] },
          { desc: 'Код непуст и все заглушки TODO заменены', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Схема ветвления: if (score >= 60) { ... } else { ... } — внутри каждой ветки Console.WriteLine со своей строкой.',
        'В switch: switch (score / 10) { case 9: case 10: ... break; ... default: ... break; } — деление 85 нацело даст 8.',
        'После каждого варианта нужен break; — иначе компилятор напомнит о нём ошибкой.'
      ],
      solution: `using System;

class Program
{
    static void Main()
    {
        int score = 85;

        if (score >= 60)
        {
            Console.WriteLine("Зачёт");
        }
        else
        {
            Console.WriteLine("Не зачёт");
        }

        switch (score / 10)
        {
            case 10:
            case 9:
                Console.WriteLine("Отлично");
                break;
            case 8:
                Console.WriteLine("Хорошо");
                break;
            case 7:
                Console.WriteLine("Удовлетворительно");
                break;
            default:
                Console.WriteLine("Есть куда расти");
                break;
        }
    }
}`
    },

    /* ============ 5. Циклы ============ */
    {
      id: 'cs-5',
      title: 'Циклы: for, while, do-while',
      goal: 'Повторять действия без копипаста: for со счётчиком, while и do-while, который срабатывает хотя бы раз.',
      xp: 40,
      theory: [
        { t: 'h', html: 'Заставь компьютер повторять' },
        { t: 'p', html: 'Циклы выполняют блок кода многократно — печатать числа от 1 до 100 вручную не придётся. В C# три классических цикла. <code>for</code> — когда известно число повторений. <code>while</code> — повторяем, пока условие истинно; проверка идёт <b>до</b> тела. <code>do-while</code> — тело гарантированно выполняется <b>хотя бы раз</b>, потому что условие проверяется после.' },
        { t: 'code', code: `using System;

class Program
{
    static void Main()
    {
        for (int i = 1; i <= 5; i++)
        {
            Console.WriteLine(i);
        }
    }
}` },
        { t: 'p', html: 'Разбор for: <code>int i = 1</code> — счётчик создаётся один раз; <code>i &lt;= 5</code> — перед каждым повтором проверяется условие; <code>i++</code> — шаг после каждого повтора, сокращение для <code>i = i + 1</code>. Пока условие истинно, тело повторяется; как только i стало 6, цикл завершается и программа идёт дальше.' },
        { t: 'code', code: `using System;

class Program
{
    static void Main()
    {
        int count = 3;
        while (count > 0)
        {
            Console.WriteLine(count);
            count--;
        }

        int attempts = 0;
        do
        {
            Console.WriteLine("Попытка!");
        } while (attempts > 0);   // тело выполнится один раз
    }
}` },
        { t: 'list', items: [
          'for — число повторений известно: отсчёты, таблицы, обход массива по индексам',
          'while — заранее не знаешь, сколько раз: «пока жизнь > 0», «пока не введён стоп»',
          'do-while — действие нужно хотя бы раз: меню, запрос пароля',
          'break досрочно выходит из цикла, continue пропускает остаток витка'
        ] },
        { t: 'h', html: 'Проверь себя: мини-предсказание' },
        { t: 'p', html: 'Прогони в голове этот код — что он выведет? Ответ спрятан в заметке ниже, не подглядывай сразу.' },
        { t: 'code', code: `int sum = 0;
for (int i = 1; i <= 4; i++)
{
    sum += i;
}
Console.WriteLine(sum);` },
        { t: 'note', html: 'Ответ: <b>10</b>. Переменная-накопитель sum собирает 1 + 2 + 3 + 4. Оператор <code>+=</code> прибавляет и сохраняет: <code>sum += i</code> то же, что <code>sum = sum + i</code>. Этот приём тебе ещё много раз пригодится.' },
        { t: 'warn', html: 'Забудешь изменить счётчик внутри while (не напишешь count--) — условие никогда не станет ложным, цикл будет бесконечным, а программа зависнет. Компилятор такое не ловит: это ошибка логики, следи за счётчиком сам.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Тренировка «Разминка» — все три цикла внутри <code>Main</code>:</p><ul><li><code>for</code>: выведи числа от 1 до 5, каждое на своей строке;</li><li><code>while</code>: обратный отсчёт 3, 2, 1;</li><li><code>do-while</code>: объяви <code>attempts = 0</code> и выведи «Поехали!» — условие <code>attempts &gt; 0</code> сразу ложно, но тело обязано выполниться один раз;</li><li>убери все <code>TODO</code>.</li></ul>',
        starter: `using System;

class Program
{
    static void Main()
    {
        // TODO: 1) цикл со счётчиком — числа от 1 до 5, каждое на своей строке

        // TODO: 2) цикл с условием до тела — обратный отсчёт 3, 2, 1

        // TODO: 3) цикл, который выполняется хотя бы раз — выведи "Поехали!"
    }
}`,
        rules: [
          { desc: 'Есть цикл for со счётчиком от 1 до 5', all: ['for\\s*\\(\\s*int\\s+\\w+\\s*=\\s*1\\s*;\\s*\\w+\\s*(<=\\s*5|<\\s*6)'] },
          { desc: 'Есть цикл while с условием (while (...) на отдельной строке)', any: ['^\\s*while\\s*\\('] },
          { desc: 'Есть цикл do-while: do { ... } while (...);', all: ['\\bdo\\s*\\{', '\\}\\s*while\\s*\\([^)]*\\)\\s*;'] },
          { desc: 'Вывод через Console.WriteLine', any: ['Console\\.WriteLine', 'Console\\.Write'] },
          { desc: 'Код непуст и все заглушки TODO заменены', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Начни с for: счётчик от 1, условие «пока счётчик не больше 5», шаг i++. Внутри — Console.WriteLine со счётчиком.',
        'В while сначала объяви счётчик (int count = 3;), затем while (count > 0) { ... count--; } — уменьшай счётчик внутри, иначе цикл станет бесконечным.',
        'do-while: do { ... } while (attempts > 0); — обрати внимание на точку с запятой после скобки while.'
      ],
      solution: `using System;

class Program
{
    static void Main()
    {
        for (int i = 1; i <= 5; i++)
        {
            Console.WriteLine(i);
        }

        int count = 3;
        while (count > 0)
        {
            Console.WriteLine(count);
            count--;
        }

        int attempts = 0;
        do
        {
            Console.WriteLine("Поехали!");
        } while (attempts > 0);
    }
}`
    },

    /* ============ 6. Массивы ============ */
    {
      id: 'cs-6',
      title: 'Массивы',
      goal: 'Хранить набор значений в int[], ходить по индексам и не выходить за границы Length.',
      xp: 40,
      theory: [
        { t: 'h', html: 'Много значений в одной переменной' },
        { t: 'p', html: 'Массив — набор значений одного типа под одним именем. Вместо score1, score2, score3… заведи <code>int[] scores</code>. Создаётся массив двумя способами: сразу со значениями в фигурных скобках или через <code>new</code> с указанием длины — тогда ячейки заполняются нулями. Длина фиксируется навсегда: добавить элемент в готовый массив нельзя (для растущих наборов есть List — уровень 9).' },
        { t: 'code', code: `using System;

class Program
{
    static void Main()
    {
        int[] scores = { 10, 20, 30, 40 };  // сразу со значениями
        int[] zeros = new int[3];           // {0, 0, 0}

        Console.WriteLine(scores[0]);       // 10 — первый элемент
        scores[1] = 25;                     // заменили второй элемент
        Console.WriteLine(scores.Length);   // 4 — размер массива
    }
}` },
        { t: 'p', html: 'Индексация начинается с нуля: <code>scores[0]</code> — первый элемент, <code>scores[3]</code> — последний при длине 4. То есть последний индекс всегда <code>Length - 1</code>. Свойство <code>Length</code> хранит размер массива — используй его в циклах вместо магических чисел, тогда код не сломается при изменении данных.' },
        { t: 'table', head: ['Выражение', 'Результат', 'Почему'], rows: [
          ['scores.Length', '4', 'в массиве четыре элемента'],
          ['scores[0]', '10', 'первый элемент — индекс 0'],
          ['scores[3]', '40', 'последний элемент — индекс Length - 1'],
          ['scores[4]', 'ошибка!', 'индекса 4 нет: границы 0–3']
        ] },
        { t: 'p', html: 'Классический обход массива — цикл for от нуля до Length: <code>for (int i = 0; i &lt; scores.Length; i++)</code> с печатью <code>scores[i]</code>. Условие строго меньше: на последнем витке i равно Length - 1 — как раз последний элемент.' },
        { t: 'note', html: 'Массив может хранить любой тип: <code>string[] names</code>, <code>double[] prices</code>, <code>bool[] flags</code>. Но все элементы строго одного типа — смешать int и string в одном массиве не выйдет.' },
        { t: 'warn', html: 'Обращение за границы (<code>scores[4]</code> при длине 4) роняет программу с IndexOutOfRangeException. Проверяй условия циклов: должно быть <code>i &lt; Length</code>, а не <code>i &lt;= Length</code> — это ошибка номер один в темах про массивы.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Проследи за программой построчно и запиши, что она выведет в консоль: по одному значению на строку, в порядке вывода.</p>',
        code: `using System;

class Program
{
    static void Main()
    {
        int[] scores = { 10, 20, 30, 40 };
        Console.WriteLine(scores.Length);
        Console.WriteLine(scores[0] + scores[scores.Length - 1]);
        Console.WriteLine(scores[2]);
        scores[1] = scores[1] + 5;
        Console.WriteLine(scores[1]);
    }
}`,
        answer: '4\n50\n30\n25',
        solution: '4\n50\n30\n25'
      },
      hints: [
        'Вспомни: индексация с нуля, а Length — это количество элементов.',
        'scores.Length - 1 при длине 4 — это индекс 3, то есть последний элемент.',
        'Последний вывод печатает уже изменённый элемент: перед этим второй элемент увеличили на 5.'
      ],
      solution: '4\n50\n30\n25'
    },

    /* ============ 7. Методы ============ */
    {
      id: 'cs-7',
      title: 'Методы',
      goal: 'Писать собственные методы с параметрами и return, вызывать их из Main.',
      xp: 45,
      theory: [
        { t: 'h', html: 'Свои команды для программы' },
        { t: 'p', html: 'Метод — блок кода с именем, который можно вызывать сколько угодно раз. Ты уже пользовался готовыми методами (WriteLine, ToUpper) — пора писать свои. Методы убирают дублирование, разбивают задачу на понятные части и делают код читаемым: имя метода объясняет, что происходит, без чтения внутренностей.' },
        { t: 'code', code: `using System;

class Program
{
    static int Add(int a, int b)
    {
        return a + b;
    }

    static void Main()
    {
        int result = Add(2, 3);
        Console.WriteLine(result);       // 5
        Console.WriteLine(Add(10, 90));  // 100
    }
}` },
        { t: 'table', head: ['Часть', 'Что означает'], rows: [
          ['static', 'Метод принадлежит классу, а не объекту — так его можно вызвать из Main'],
          ['int перед именем', 'Тип возвращаемого значения'],
          ['Add', 'Имя метода — обычно глагол или действие'],
          ['(int a, int b)', 'Параметры — входные данные метода'],
          ['return', 'Вернуть результат и немедленно выйти из метода'],
          ['void', '«Ничего не возвращает» — просто выполняет действия']
        ] },
        { t: 'p', html: 'Параметры работают как переменные метода: при вызове <code>Add(2, 3)</code> значение 2 попадёт в a, 3 — в b. <code>return</code> завершает метод и отдаёт значение туда, откуда вызвали. Метод с типом int обязан вернуть int на всех путях выполнения. Методы <code>void</code> ничего не возвращают — в них return можно не писать вовсе или использовать голый <code>return;</code> для досрочного выхода.' },
        { t: 'note', html: 'Переменные внутри метода (параметры и объявленные в теле) видны только внутри него — это называется областью видимости. Поэтому два метода могут спокойно иметь переменные с одинаковыми именами и не мешать друг другу.' },
        { t: 'warn', html: 'Вызов должен совпадать по имени и типам аргументов: <code>Add("2", 3)</code> не скомпилируется — строку вместо числа компилятор не пропустит. И помни: return — это не вывод. return кладёт результат в место вызова, а чтобы напечатать, нужен Console.WriteLine.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши два метода и проверь их из <code>Main</code>:</p><ul><li><code>static int Sum(int a, int b)</code> — возвращает сумму двух чисел;</li><li><code>static string Greet(string name)</code> — возвращает приветствие вида «Привет, Аня!» (удобно через интерполяцию <code>$"..."</code>);</li><li>в <code>Main</code> вызови оба метода и выведи результаты через <code>Console.WriteLine</code>;</li><li>убери все <code>TODO</code>.</li></ul>',
        starter: `using System;

class Program
{
    // TODO: метод, который складывает два целых числа и возвращает сумму

    // TODO: метод, который принимает имя и возвращает приветствие

    static void Main()
    {
        // TODO: вызови оба метода и выведи результаты
    }
}`,
        rules: [
          { desc: 'Есть метод static int Sum с двумя int-параметрами', all: ['static\\s+int\\s+Sum\\s*\\(\\s*int\\s+\\w+\\s*,\\s*int\\s+\\w+\\s*\\)'] },
          { desc: 'Sum возвращает сумму через return', any: ['return\\s+\\w+\\s*\\+\\s*\\w+\\s*;', 'return\\s*\\(\\s*\\w+\\s*\\+\\s*\\w+\\s*\\)\\s*;'] },
          { desc: 'Есть метод static string Greet со строковым параметром', all: ['static\\s+string\\s+Greet\\s*\\(\\s*string\\s+\\w+\\s*\\)'] },
          { desc: 'Greet возвращает строку-приветствие', any: ['return\\s+\\$"', 'return\\s+"'] },
          { desc: 'Оба метода вызваны из Main', all: ['\\bSum\\s*\\([^)]*\\)\\s*[);]', '\\bGreet\\s*\\([^)]*\\)\\s*[);]'] },
          { desc: 'Результаты выводятся через Console.WriteLine', any: ['Console\\.WriteLine', 'Console\\.Write'] },
          { desc: 'Код непуст и все заглушки TODO заменены', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Шаблон метода: static int Sum(int a, int b) { return a + b; } — объявляй методы рядом с Main, в том же классе.',
        'В Greet собери строку интерполяцией: $"Привет, {name}!" — и верни её через return.',
        'Вызов с печатью: Console.WriteLine(Sum(2, 3)); — результат метода сразу уходит на экран.'
      ],
      solution: `using System;

class Program
{
    static int Sum(int a, int b)
    {
        return a + b;
    }

    static string Greet(string name)
    {
        return $"Привет, {name}!";
    }

    static void Main()
    {
        Console.WriteLine(Sum(2, 3));
        Console.WriteLine(Greet("Аня"));
    }
}`
    },

    /* ============ 8. Строки ============ */
    {
      id: 'cs-8',
      title: 'Строки и интерполяция',
      goal: 'Работать со строками как с объектами: Length, ToUpper, Substring — и красиво форматировать через $"...".',
      xp: 45,
      theory: [
        { t: 'h', html: 'Строки: объекты с суперспособностями' },
        { t: 'p', html: 'В C# строка — не просто текст, а объект типа string с кучей готовых методов. Длину даёт свойство <code>Length</code>. Регистр меняют <code>ToUpper()</code> и <code>ToLower()</code>. Кусочек строки вырезает <code>Substring(начало, длина)</code>: <code>"CodeQuest".Substring(0, 4)</code> даст <code>"Code"</code> — четыре символа, начиная с индекса 0.' },
        { t: 'table', head: ['Метод / свойство', 'Что делает', 'Пример результата'], rows: [
          ['s.Length', 'Количество символов', '"CodeQuest".Length → 9'],
          ['s.ToUpper()', 'Верхний регистр', '"код".ToUpper() → "КОД"'],
          ['s.ToLower()', 'Нижний регистр', '"КОД".ToLower() → "код"'],
          ['s.Substring(0, 4)', 'Кусок с индекса 0 длиной 4', '"Code"'],
          ['s.Contains("Quest")', 'Содержит ли подстроку', 'true'],
          ['s.Replace("e", "E")', 'Заменяет все вхождения', '"CodEQuEst"'],
          ['s.Trim()', 'Убирает пробелы по краям', '" hi " → "hi"']
        ] },
        { t: 'h', html: 'Интерполяция: $ перед строкой' },
        { t: 'p', html: 'Склеивать текст оператором + быстро надоедает. Интерполяция делает это красиво: поставь <code>$</code> перед кавычками — и внутри строки можно писать выражения в фигурных скобках. <code>$"Привет, {name}!"</code> подставит значение переменной name, а <code>$"Итог: {a + b}"</code> — вычислит выражение прямо внутри строки. Это главный способ форматирования в современном C#.' },
        { t: 'code', code: `using System;

class Program
{
    static void Main()
    {
        string s = "CodeQuest";
        Console.WriteLine(s.Length);                         // 9
        Console.WriteLine(s.Substring(0, 4).ToUpper());      // CODE
        Console.WriteLine($"Я играю в {s.Substring(0, 4)}"); // Я играю в Code
    }
}` },
        { t: 'note', html: 'Строки неизменяемы: ToUpper, Replace и даже Trim не меняют исходную строку, а возвращают новую. Написать <code>s.ToUpper();</code> и не сохранить результат — значит выбросить его. Сохраняй: <code>s = s.ToUpper();</code>' },
        { t: 'warn', html: 'Забудешь $ перед кавычками — фигурные скобки останутся обычным текстом: <code>"{name}"</code> напечатается буквально. А <code>Substring</code> с индексом за границами строки бросит исключение — сверяйся с Length.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет эта программа? Один вызов — одна строка вывода.</p><pre>string s = "CodeQuest";
Console.WriteLine($"Длина: {s.Length}, старт: {s.Substring(0, 4).ToUpper()}");</pre>`,
        options: ['Длина: {s.Length}, старт: CODE', 'Ошибка: внутри {} нельзя вызывать методы', 'Длина: 9, старт: CODE', 'Длина: 9, старт: code'],
        correct: 2,
        explain: 's.Length = 9 — в CodeQuest девять символов. Substring(0, 4) вырезает "Code", ToUpper() даёт "CODE". Внутри $-строки всё в фигурных скобках вычисляется и подставляется в текст.',
        solution: 2
      },
      hints: [
        'В $-строках выражения в фигурных скобках вычисляются: Length — свойство, а не текст.',
        'Substring(0, 4) — четыре символа с самого начала; ToUpper() поднимает регистр полученного куска.'
      ],
      solution: 2
    },

    /* ============ 9. List и foreach ============ */
    {
      id: 'cs-9',
      title: 'List и foreach',
      goal: 'Использовать растущий список List<string> и перебирать его элегантным foreach.',
      xp: 50,
      theory: [
        { t: 'h', html: 'List: массив, который растёт' },
        { t: 'p', html: 'Массив хорош, но его размер фиксирован навсегда. <code>List&lt;T&gt;</code> — список, который растёт и сжимается по мере надобности. В угловых скобках указывается тип элементов: <code>List&lt;string&gt;</code> хранит строки, <code>List&lt;int&gt;</code> — числа. Список живёт в пространстве имён <code>System.Collections.Generic</code> — не забудь соответствующий <code>using</code> в начале файла.' },
        { t: 'code', code: `using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<string> games = new List<string>();

        games.Add("Квест");
        games.Add("Гонки");
        games.Add("Шахматы");

        games.Remove("Гонки");           // удалили по значению
        Console.WriteLine(games.Count);  // 2
        Console.WriteLine(games[0]);     // Квест — индексы как у массива
    }
}` },
        { t: 'table', head: ['Операция', 'Что делает'], rows: [
          ['list.Add(x)', 'Добавляет элемент в конец'],
          ['list.Remove(x)', 'Удаляет первое вхождение значения x'],
          ['list.RemoveAt(i)', 'Удаляет элемент по индексу i'],
          ['list.Count', 'Сколько сейчас элементов'],
          ['list.Contains(x)', 'Есть ли такой элемент'],
          ['list.Clear()', 'Удаляет всё содержимое']
        ] },
        { t: 'h', html: 'foreach: перебор без счётчика' },
        { t: 'p', html: 'Когда нужно просто пройтись по всем элементам, <code>foreach</code> короче и безопаснее for: не нужны индексы, невозможно выйти за границы. В скобках — тип переменной, её имя, слово <code>in</code> и коллекция. На каждом витке цикла переменная автоматически получает следующий элемент списка.' },
        { t: 'code', code: `// продолжение программы выше
foreach (string game in games)
{
    Console.WriteLine($"• {game}");
}` },
        { t: 'note', html: 'У списка размер — это <code>Count</code> (у массива — Length, у строки — тоже Length). Путаница Count и Length — классическая ошибка новичка. И ещё: переменная foreach доступна только для чтения — переопределять её внутри цикла нельзя.' },
        { t: 'warn', html: 'Не удаляй элементы из списка прямо во время foreach: изменение коллекции в момент перебора бросит исключение. Сначала собери то, что нужно удалить, в отдельный список — а удаляй уже после цикла.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери «Список дел»:</p><ul><li>объяви список <code>List&lt;string&gt;</code> и создай его через <code>new</code>;</li><li>добавь три дела через <code>Add</code>;</li><li>перебери список через <code>foreach</code> и выведи каждое дело строкой вида «• Сделать зарядку» (точка-буллит и текст);</li><li><code>using System.Collections.Generic;</code> уже в стартере — не удаляй;</li><li>убери все <code>TODO</code>.</li></ul>',
        starter: `using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // TODO: создай список дел и добавь три записи

        // TODO: перебери список в цикле и выведи каждое дело
    }
}`,
        rules: [
          { desc: 'Подключено System.Collections.Generic', all: ['using\\s+System\\.Collections\\.Generic\\s*;'] },
          { desc: 'Объявлен List<string> и создан через new', all: ['List\\s*<\\s*string\\s*>\\s+\\w+\\s*='], any: ['new\\s+List\\s*<\\s*string\\s*>', '=\\s*new\\s*\\(\\s*\\)'] },
          { desc: 'Дела добавляются через .Add(...)', all: ['\\.Add\\s*\\('] },
          { desc: 'Список перебирается через foreach (тип переменная in список)', all: ['\\bforeach\\s*\\(\\s*\\w+\\s+\\w+\\s+in\\s+\\w+\\s*\\)'] },
          { desc: 'Каждое дело выводится через Console.WriteLine', any: ['Console\\.WriteLine', 'Console\\.Write'] },
          { desc: 'Код непуст и все заглушки TODO заменены', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Шаблон объявления: List<string> tasks = new List<string>(); — тип в угловых скобках одинаков у переменной и у new.',
        'Add принимает строку: tasks.Add("Сделать зарядку"); — повтори три раза с разными делами.',
        'Перебор: foreach (string task in tasks) { Console.WriteLine($"• {task}"); } — переменная цикла получает по одному делу за виток.'
      ],
      solution: `using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<string> tasks = new List<string>();

        tasks.Add("Сделать зарядку");
        tasks.Add("Пройти уровень");
        tasks.Add("Заварить чай");

        foreach (string task in tasks)
        {
            Console.WriteLine($"• {task}");
        }
    }
}`
    },

    /* ============ 10. Проект: Учётная книга ============ */
    {
      id: 'cs-10',
      title: 'Проект: «Учётная книга»',
      goal: 'Собрать всё изученное: класс Transaction, список операций, метод с циклом и итоговый отчёт о балансе.',
      xp: 100,
      theory: [
        { t: 'h', html: 'Финальный проект' },
        { t: 'p', html: 'Последний уровень — настоящий мини-проект, где работает всё, что ты выучил: классы, списки, методы, циклы и интерполяция. Учётная книга хранит операции: каждая операция имеет описание и сумму — доход положительный, расход отрицательный. Программа печатает отчёт: сколько операций и какой итоговый баланс получился.' },
        { t: 'h', html: 'Класс как чертёж' },
        { t: 'p', html: 'Класс — чертёж, по которому создаются объекты. Определим класс <code>Transaction</code> с двумя полями: текстовое описание и сумма. Поля объявляются внутри класса; слово <code>public</code> делает их доступными снаружи. Объект создаётся через <code>new</code>, а значения удобно задавать инициализатором: <code>new Transaction { Description = "Кофе", Amount = -150 }</code>.' },
        { t: 'code', code: `// класс объявляют рядом с Program, в том же файле
class Transaction
{
    public string Description;   // что за операция
    public int Amount;           // сумма: + доход, - расход
}` },
        { t: 'h', html: 'Метод с циклом-накопителем' },
        { t: 'p', html: 'Баланс считает метод <code>ShowBalance</code>: он принимает список транзакций, обходит его циклом <code>foreach</code> и накапливает сумму в локальной переменной <code>total</code>. Приём «накопитель» — один из главных в программировании: заведи переменную с нулём и прибавляй к ней по кусочку за каждый виток цикла.' },
        { t: 'code', code: `// метод внутри класса Program
static void ShowBalance(List<Transaction> ledger)
{
    int total = 0;
    foreach (Transaction t in ledger)
    {
        total += t.Amount;
    }
    Console.WriteLine($"Операций: {ledger.Count}");
    Console.WriteLine($"Баланс: {total} руб.");
}` },
        { t: 'list', items: [
          '1. Объяви класс Transaction с полями Description и Amount — над классом Program',
          '2. В Main создай List&lt;Transaction&gt; и добавь три операции через .Add(new Transaction { ... })',
          '3. Напиши метод ShowBalance: foreach по списку + накопитель total',
          '4. Вызови ShowBalance из Main — отчёт должен появиться на экране'
        ] },
        { t: 'note', html: 'Для настоящих денег в C# используют тип decimal — он считает без дробных погрешностей, а суммы часто хранят в копейках. Мы взяли int: для учебного проекта этого достаточно, зато балансы легко проверить в уме.' },
        { t: 'warn', html: 'Поле объекта читается через точку: <code>t.Amount</code>. Напишешь внутри метода просто <code>Amount</code> — компилятор не найдёт такую переменную: она живёт внутри каждого объекта, а не в методе. То же с Description.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери «Учётную книгу» целиком:</p><ul><li>класс <code>Transaction</code> с полями <code>Description</code> (string) и <code>Amount</code> (int);</li><li>в <code>Main</code> — список <code>List&lt;Transaction&gt;</code> и три операции через <code>.Add(new Transaction { ... })</code> (сделай хотя бы один расход — сумма с минусом);</li><li>метод <code>static void ShowBalance(List&lt;Transaction&gt;)</code>: циклом обходит список, накапливает сумму полей <code>Amount</code> и выводит итог;</li><li>вызови <code>ShowBalance</code> из <code>Main</code>;</li><li>убери все <code>TODO</code>. Это проект — после зачёта расширяй его как хочешь: категории, даты, поиск!</li></ul>',
        starter: `using System;
using System.Collections.Generic;

// TODO: опиши класс операции — текстовое описание и сумма (int)

class Program
{
    // TODO: метод, который принимает список операций,
    // циклом считает общую сумму и выводит итоговый отчёт

    static void Main()
    {
        // TODO: создай список и добавь три операции

        // TODO: вызови метод с отчётом
    }
}`,
        rules: [
          { desc: 'Объявлен класс Transaction с полями Description и Amount', all: ['\\bclass\\s+Transaction\\b', '\\bDescription\\b', '\\bAmount\\b'] },
          { desc: 'Создан List<Transaction>, операции добавлены через .Add(new Transaction ...)', all: ['List\\s*<\\s*Transaction\\s*>', '\\.Add\\s*\\(\\s*new\\s+Transaction\\b'] },
          { desc: 'Метод ShowBalance обходит список циклом и накапливает сумму', all: ['\\bShowBalance\\b', '\\b(?:foreach|for)\\s*\\('], any: ['\\+=', '=\\s*\\w+\\s*\\+'] },
          { desc: 'ShowBalance вызывается из Main, отчёт выводится через Console.WriteLine', all: ['ShowBalance\\s*\\([^)]*\\)\\s*;'], any: ['Console\\.WriteLine', 'Console\\.Write'] },
          { desc: 'Код непуст и все заглушки TODO заменены', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Класс объявляют вне класса Program: class Transaction { public string Description; public int Amount; }',
        'Инициализатор объекта: ledger.Add(new Transaction { Description = "Кофе", Amount = -150 }); — три раза, сделай один Amount отрицательным.',
        'В ShowBalance: int total = 0; затем foreach (Transaction t in ledger) { total += t.Amount; } — в конце два Console.WriteLine с интерполяцией.',
        'Вызов из Main: ShowBalance(ledger); — передай список как аргумент.'
      ],
      solution: `using System;
using System.Collections.Generic;

class Transaction
{
    public string Description;
    public int Amount;
}

class Program
{
    static void ShowBalance(List<Transaction> ledger)
    {
        int total = 0;
        foreach (Transaction t in ledger)
        {
            total += t.Amount;
        }
        Console.WriteLine($"Операций: {ledger.Count}");
        Console.WriteLine($"Баланс: {total} руб.");
    }

    static void Main()
    {
        List<Transaction> ledger = new List<Transaction>();

        ledger.Add(new Transaction { Description = "Кофе", Amount = -150 });
        ledger.Add(new Transaction { Description = "Зарплата", Amount = 40000 });
        ledger.Add(new Transaction { Description = "Книга по C#", Amount = -800 });

        ShowBalance(ledger);
    }
}`
    },

    /* ============ 11. Классы, свойства, конструкторы ============ */
    {
      id: 'cs-11',
      title: 'Классы, свойства, конструкторы',
      goal: 'Объявлять классы по-взрослому: автосвойства { get; set; }, конструктор с параметрами и ключевое слово this.',
      xp: 50,
      theory: [
        { t: 'h', html: 'Свойства вместо открытых полей' },
        { t: 'p', html: 'В проекте «Учётная книга» ты объявлял поля напрямую: <code>public string Description;</code> — работает, но так делают редко. В настоящем C# данные прячут, а наружу выставляют <b>свойства</b>: снаружи это выглядит как переменная (<code>hero.Name</code>), внутри — методы доступа get и set, куда позже можно добавить проверки. Запись <code>public string Name { get; set; }</code> называется <b>автосвойством</b>: компилятор сам создаёт скрытое поле и простые методы чтения-записи.' },
        { t: 'code', code: `class Player
{
    public string Name { get; set; }   // автосвойство
    public int Score { get; set; } = 0; // можно задать значение сразу
}` },
        { t: 'table', head: ['Член класса', 'Что это', 'Пример'], rows: [
          ['Поле', 'Переменная внутри объекта', 'public int hp;'],
          ['Автосвойство', 'Поле с доступом get/set', 'public string Name { get; set; }'],
          ['Метод', 'Действие над объектом', 'public void Print() { }'],
          ['Конструктор', 'Настройка при создании', 'public Player(string name) { }']
        ] },
        { t: 'h', html: 'Конструктор: код, который срабатывает при new' },
        { t: 'p', html: 'Конструктор — метод, названный именем класса и не имеющий возвращаемого типа. Он выполняется в момент <code>new</code>, поэтому удобно требовать имя игрока сразу, а не надеяться, что его заполнят потом. Пока в классе нет ни одного конструктора, C# выдаёт пустой конструктор по умолчанию; как только ты объявил свой — дефолтный исчезает.' },
        { t: 'code', code: `class Player
{
    public string Name { get; set; }
    public int Score { get; set; }

    public Player(string name, int score)
    {
        this.Name = name;    // this — ссылка на сам объект
        this.Score = score;
    }
}` },
        { t: 'p', html: '<code>this</code> — ссылка на текущий объект. Здесь она различает свойство <code>Name</code> объекта и параметр <code>name</code> конструктора: <code>this.Name = name;</code> читается как «имя этого объекта — из параметра». Позже this пригодится и для передачи самого объекта в другие методы.' },
        { t: 'note', html: 'Свойство только для чтения — <code>{ get; }</code>: присвоить значение можно лишь внутри конструктора. А инициализатор <code>public int Score { get; set; } = 100;</code> сработает ещё до тела конструктора — удобно для значений по умолчанию.' },
        { t: 'warn', html: 'Объявил конструктор с параметрами — вызов <code>new Player()</code> без аргументов перестанет компилироваться: конструктор по умолчанию исчез. Добавь перегрузку <code>public Player() { }</code>, если пустое создание всё же нужно.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери класс героя по канону:</p><ul><li>класс <code>Player</code> с автосвойствами <code>Name</code> (string) и <code>Score</code> (int) в форме <code>{ get; set; }</code>;</li><li>конструктор <code>public Player(string name, int score)</code>, который через <code>this</code> записывает параметры в свойства;</li><li>в <code>Main</code> создай объект через <code>new Player(...)</code> и выведи его свойства через <code>Console.WriteLine</code> (интерполяция приветствуется);</li><li>убери все <code>TODO</code>.</li></ul>',
        starter: `using System;

// TODO: объяви класс Player с автосвойствами Name (string) и Score (int)

class Program
{
    static void Main()
    {
        // TODO: создай объект через конструктор и выведи свойства в консоль
    }
}`,
        rules: [
          { desc: 'Объявлен класс Player', all: ['\\bclass\\s+Player\\b'] },
          { desc: 'Свойства Name и Score объявлены автосвойствами { get; set; }', all: ['\\bName\\s*\\{\\s*get\\s*;\\s*set\\s*;', '\\bScore\\s*\\{\\s*get\\s*;\\s*set\\s*;'] },
          { desc: 'Есть конструктор public Player(...) с параметрами', all: ['public\\s+Player\\s*\\([^)]*\\)\\s*\\{'] },
          { desc: 'Конструктор записывает значения через this.', all: ['\\bthis\\s*\\.'] },
          { desc: 'Объект создан через new Player(...)', all: ['new\\s+Player\\s*\\('] },
          { desc: 'Свойства читаются через точку и выводятся в консоль', all: ['\\.Name\\b', '\\.Score\\b'], any: ['Console\\.WriteLine', 'Console\\.Write'] },
          { desc: 'Код непуст и все заглушки TODO заменены', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Каркас свойства: public string Name { get; set; } — не забудь точку с запятой в конце.',
        'В конструкторе: this.Name = name; this.Score = score; — this различает свойство и параметр.',
        'Создание: Player hero = new Player("Аня", 90); вывод: Console.WriteLine($"{hero.Name}: {hero.Score}");'
      ],
      solution: `using System;

class Player
{
    public string Name { get; set; }
    public int Score { get; set; }

    public Player(string name, int score)
    {
        this.Name = name;
        this.Score = score;
    }
}

class Program
{
    static void Main()
    {
        Player hero = new Player("Аня", 90);
        Console.WriteLine($"{hero.Name}: {hero.Score} очков");
    }
}`
    },

    /* ============ 12. Наследование и virtual/override ============ */
    {
      id: 'cs-12',
      title: 'Наследование и virtual/override',
      goal: 'Строить иерархии классов: наследование через двоеточие, переопределение virtual/override и обращение к базовому классу через base.',
      xp: 55,
      theory: [
        { t: 'h', html: 'Наследование: общий базовый класс' },
        { t: 'p', html: 'У собак, кошек и мышей есть общее: имя и способность издавать звук. Общее выносим в базовый класс <code>Animal</code>, а частное — в наследников. Запись <code>class Dog : Animal</code> означает «Dog наследуется от Animal»: он получает все члены базового класса и добавляет своё. В C# у класса может быть только один базовый класс, но цепочки наследования любые: Dog : Animal, Puppy : Dog.' },
        { t: 'code', code: `class Animal
{
    public string Name { get; set; }

    public virtual string Speak()
    {
        return $"{Name} издаёт звук";
    }
}

class Dog : Animal { }   // пока просто наследует всё` },
        { t: 'h', html: 'virtual и override: полиморфизм' },
        { t: 'p', html: 'По умолчанию методы переопределить нельзя — так безопаснее. Помечаешь метод в базовом классе словом <code>virtual</code> («можно переопределять»), а в наследнике пишешь <code>override</code> с той же сигнатурой. Теперь вызов через переменную типа <code>Animal</code> дойдёт до версии настоящего объекта: для Dog выполнится Dog.Speak — это и есть <b>полиморфизм</b>, «много форм» одного вызова.' },
        { t: 'code', code: `class Dog : Animal
{
    public override string Speak()
    {
        return base.Speak() + " — гав!";
    }
}` },
        { t: 'p', html: '<code>base</code> — обращение к базовому классу: <code>base.Speak()</code> вызывает родительскую версию метода, чтобы дополнить, а не заменить её. В конструкторе наследника <code>base(...)</code> в заголовке вызывает конструктор базового класса — пригодится, когда базовый класс требует параметры.' },
        { t: 'table', head: ['Ключевое слово', 'Где стоит', 'Что делает'], rows: [
          ['virtual', 'В базовом классе', 'Разрешает переопределение метода'],
          ['override', 'В наследнике', 'Переопределяет виртуальный метод'],
          ['base', 'В наследнике', 'Доступ к базовому классу (base.Speak(), base(...)'],
          ['sealed', 'У класса или метода', 'Запрещает дальнейшее наследование/переопределение']
        ] },
        { t: 'note', html: '<code>sealed class Cat : Animal</code> — от Cat уже никто не унаследуется, а <code>sealed override</code> закрывает и переопределение метода дальше по цепочке. Sealed защищает критичный код от случайных наследников и чуть ускоряет вызовы.' },
        { t: 'warn', html: 'Забудешь <code>virtual</code> в базовом классе — <code>override</code> в наследнике не скомпилируется: «cannot override non-virtual method». И следи за сигнатурой: имя, параметры и тип возвращаемого значения должны совпасть точь-в-точь.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Построй зверинец:</p><ul><li>класс <code>Animal</code> со свойством <code>Name</code> и <b>виртуальным</b> методом <code>Speak()</code>, возвращающим строку вида «{Name} издаёт звук»;</li><li>классы <code>Dog : Animal</code> и <code>Cat : Animal</code>, каждый <b>переопределяет</b> <code>Speak()</code> через <code>override</code> и дополняет базовую версию: <code>base.Speak()</code> плюс « — гав!» / « — мяу!»;</li><li>в <code>Main</code> создай собаку и кошку (инициализатор <code>new Dog { Name = "Шарик" }</code>) и выведи их <code>Speak()</code>;</li><li>убери все <code>TODO</code>.</li></ul>',
        starter: `using System;

// TODO: класс Animal со свойством Name и виртуальным методом Speak()

// TODO: класс Dog : Animal — override Speak() с base.Speak() и « — гав!»
// TODO: класс Cat : Animal — override Speak() с base.Speak() и « — мяу!»

class Program
{
    static void Main()
    {
        // TODO: создай собаку и кошку, выведи, что они говорят
    }
}`,
        rules: [
          { desc: 'Объявлен класс Animal', all: ['\\bclass\\s+Animal\\b'] },
          { desc: 'Метод Speak() объявлен виртуальным (virtual)', all: ['\\bvirtual\\s+string\\s+Speak\\s*\\('] },
          { desc: 'Dog и Cat наследуются от Animal (class X : Animal)', all: ['\\bclass\\s+Dog\\s*:\\s*Animal\\b', '\\bclass\\s+Cat\\s*:\\s*Animal\\b'] },
          { desc: 'Speak() переопределён через override', all: ['\\boverride\\s+string\\s+Speak\\s*\\('] },
          { desc: 'В переопределении вызывается base.Speak()', all: ['\\bbase\\.Speak\\s*\\('] },
          { desc: 'Объекты созданы, вывод через Console.WriteLine', all: ['new\\s+Dog\\b', 'new\\s+Cat\\b'], any: ['Console\\.WriteLine', 'Console\\.Write'] },
          { desc: 'Код непуст и все заглушки TODO заменены', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'В Animal: public virtual string Speak() { return $"{Name} издаёт звук"; } — не забудь virtual.',
        'В наследнике: public override string Speak() { return base.Speak() + " — гав!"; } — двоеточие после имени класса: class Dog : Animal.',
        'Объекты: Dog dog = new Dog { Name = "Шарик" }; Cat cat = new Cat { Name = "Мурка" }; затем два Console.WriteLine.'
      ],
      solution: `using System;

class Animal
{
    public string Name { get; set; }

    public virtual string Speak()
    {
        return $"{Name} издаёт звук";
    }
}

class Dog : Animal
{
    public override string Speak()
    {
        return base.Speak() + " — гав!";
    }
}

class Cat : Animal
{
    public override string Speak()
    {
        return base.Speak() + " — мяу!";
    }
}

class Program
{
    static void Main()
    {
        Dog dog = new Dog { Name = "Шарик" };
        Cat cat = new Cat { Name = "Мурка" };
        Console.WriteLine(dog.Speak());
        Console.WriteLine(cat.Speak());
    }
}`
    },

    /* ============ 13. Интерфейсы ============ */
    {
      id: 'cs-13',
      title: 'Интерфейсы',
      goal: 'Описывать контракт через interface, реализовывать его в классах и работать с объектами через тип интерфейса.',
      xp: 50,
      theory: [
        { t: 'h', html: 'Интерфейс: контракт без кода' },
        { t: 'p', html: 'Интерфейс — список «что должен уметь класс», без реализации: <code>interface IShape { string GetInfo(); }</code>. Любой класс, подписавшийся на контракт, обязан реализовать все его члены. По конвенции .NET имена интерфейсов начинаются с большой буквы I: IShape, IPet, IEnumerable. Члены интерфейса объявляют без модификаторов — они и так публичные.' },
        { t: 'code', code: `interface IShape
{
    string GetInfo();   // без тела — только подпись
}` },
        { t: 'h', html: 'Реализация и полиморфизм через интерфейс' },
        { t: 'p', html: 'Реализация выглядит как наследование: <code>class Circle : IShape</code> — класс обязан написать <code>GetInfo</code>. Главное волшебство: переменную можно объявить типом <b>интерфейса</b>: <code>IShape a = new Circle { Radius = 5 };</code>. Через неё доступны только члены интерфейса, зато один и тот же код работает с любым классом, реализовавшим контракт. Класс наследует один класс, но реализует сколько угодно интерфейсов: <code>class Dog : Animal, IPet</code>.' },
        { t: 'code', code: `class Circle : IShape
{
    public int Radius { get; set; }

    public string GetInfo()
    {
        return $"Круг радиусом {Radius}";
    }
}

// где-то в Main:
// IShape a = new Circle { Radius = 5 };
// Console.WriteLine(a.GetInfo());` },
        { t: 'p', html: 'Кстати, <code>foreach</code>, которым ты пользуешься со времён cs-9, тоже построен на интерфейсе: он перебирает всё, что реализует <code>IEnumerable&lt;T&gt;</code>. List, массивы, Dictionary, строки — всё это IEnumerable, поэтому foreach единообразен. Запомни это имя: оно мелькнёт в LINQ, async и почти любом .NET API.' },
        { t: 'table', head: ['', 'Интерфейс', 'Класс'], rows: [
          ['Содержимое', 'Только подписи членов', 'Поля, свойства, методы с телом'],
          ['Поля', 'Нельзя', 'Можно'],
          ['Сколько на класс', 'Сколько угодно', 'Один базовый'],
          ['Назначение', 'Контракт «что умеет»', 'Реализация «как делает»']
        ] },
        { t: 'note', html: 'В реальных проектах интерфейсы — основной способ подменять зависимости: база данных и отправитель писем прячутся за интерфейсами, а в тестах на их место встают подделки. Компилятор не даст забыть член: класс обязан реализовать весь контракт или объявить себя abstract.' },
        { t: 'warn', html: 'Реализовал метод с другой сигнатурой (<code>GetInfo(int id)</code> вместо <code>GetInfo()</code>) — контракт не выполнен, и компилятор остановит сборку. Сигнатуры в реализации должны совпадать с интерфейсными вплоть до типов, а public — обязателен.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Опиши фигуры через контракт:</p><ul><li>интерфейс <code>IShape</code> с методом <code>string GetInfo();</code>;</li><li>класс <code>Circle : IShape</code> со свойством <code>Radius</code> (int) и реализацией <code>GetInfo()</code> (строка через интерполяцию);</li><li>класс <code>Square : IShape</code> со свойством <code>Side</code> (int) и своей реализацией;</li><li>в <code>Main</code> создай обе фигуры через переменные типа <code>IShape</code> и выведи <code>GetInfo()</code> каждой;</li><li>убери все <code>TODO</code>.</li></ul>',
        starter: `using System;

// TODO: объяви интерфейс IShape с методом string GetInfo();

// TODO: класс Circle : IShape — свойство Radius, реализация GetInfo()
// TODO: класс Square : IShape — свойство Side, реализация GetInfo()

class Program
{
    static void Main()
    {
        // TODO: создай фигуры через переменные типа IShape и выведи их
    }
}`,
        rules: [
          { desc: 'Интерфейс IShape объявлен', all: ['\\binterface\\s+IShape\\b'] },
          { desc: 'IShape содержит метод string GetInfo();', all: ['string\\s+GetInfo\\s*\\(\\s*\\)\\s*;'] },
          { desc: 'Circle реализует IShape (class Circle : IShape)', all: ['\\bclass\\s+Circle\\s*:\\s*IShape\\b'] },
          { desc: 'Square реализует IShape (class Square : IShape)', all: ['\\bclass\\s+Square\\s*:\\s*IShape\\b'] },
          { desc: 'Обе фигуры созданы через переменные типа интерфейса (полиморфизм)', all: ['IShape\\s+\\w+\\s*=\\s*new\\s+Circle\\b', 'IShape\\s+\\w+\\s*=\\s*new\\s+Square\\b'] },
          { desc: 'GetInfo() вызывается, вывод через Console.WriteLine', all: ['\\.GetInfo\\s*\\(\\s*\\)'], any: ['Console\\.WriteLine', 'Console\\.Write'] },
          { desc: 'Код непуст и все заглушки TODO заменены', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Интерфейс: interface IShape { string GetInfo(); } — точка с запятой вместо тела метода.',
        'Класс: class Circle : IShape { public int Radius { get; set; } public string GetInfo() { return $"Круг радиусом {Radius}"; } }.',
        'Полиморфизм: IShape a = new Circle { Radius = 5 }; IShape b = new Square { Side = 3 }; затем a.GetInfo() и b.GetInfo().'
      ],
      solution: `using System;

interface IShape
{
    string GetInfo();
}

class Circle : IShape
{
    public int Radius { get; set; }

    public string GetInfo()
    {
        return $"Круг радиусом {Radius}";
    }
}

class Square : IShape
{
    public int Side { get; set; }

    public string GetInfo()
    {
        return $"Квадрат со стороной {Side}";
    }
}

class Program
{
    static void Main()
    {
        IShape a = new Circle { Radius = 5 };
        IShape b = new Square { Side = 3 };
        Console.WriteLine(a.GetInfo());
        Console.WriteLine(b.GetInfo());
    }
}`
    },

    /* ============ 14. Коллекции: List и Dictionary ============ */
    {
      id: 'cs-14',
      title: 'Коллекции: List и Dictionary',
      goal: 'Хранить данные по ключу в Dictionary<K,V>, проверять наличие ключа и управлять списком: Add, Remove, Count, foreach.',
      xp: 50,
      theory: [
        { t: 'h', html: 'Dictionary: словарь «ключ → значение»' },
        { t: 'p', html: 'Список находит элемент по индексу, но у реальных данных есть имена: у игрока — ник, у товара — артикул. <code>Dictionary&lt;K, V&gt;</code> хранит пары «ключ → значение»: ключ уникален, поиск почти мгновенный независимо от размера. Объявление читается так: <code>Dictionary&lt;string, int&gt;</code> — «словарь из строк в числа» — ник и очки. Это вторая главная коллекция .NET после List.' },
        { t: 'code', code: `using System.Collections.Generic;

var scores = new Dictionary<string, int>();
scores.Add("Аня", 90);      // добавить пару
scores["Борис"] = 75;       // добавить или перезаписать
Console.WriteLine(scores["Аня"]); // 90 — чтение по ключу
Console.WriteLine(scores.Count);  // 2 — число пар` },
        { t: 'table', head: ['Операция', 'Что делает'], rows: [
          ['scores.Add(key, v)', 'Добавляет пару (упадёт, если ключ уже есть)'],
          ['scores[key] = v', 'Добавляет или перезаписывает по ключу'],
          ['scores[key]', 'Читает значение (упадёт, если ключа нет)'],
          ['scores.ContainsKey(key)', 'Проверяет, есть ли такой ключ'],
          ['scores.Remove(key)', 'Удаляет пару по ключу'],
          ['scores.Count', 'Количество пар']
        ] },
        { t: 'h', html: 'Безопасное чтение и foreach по словарю' },
        { t: 'p', html: 'Чтение по отсутствующему ключу бросает <code>KeyNotFoundException</code>, поэтому перед чтением проверяют <code>ContainsKey</code> (или используют TryGetValue). В цикле <code>foreach</code> по словарю приходят пары <code>KeyValuePair&lt;string, int&gt;</code>: у пары есть <code>Key</code> и <code>Value</code>. Список List ты уже знаешь со времён cs-9 — здесь работаем с ним в паре: имена в списке, очки в словаре.' },
        { t: 'code', code: `foreach (KeyValuePair<string, int> pair in scores)
{
    Console.WriteLine($"{pair.Key} — {pair.Value}");
}` },
        { t: 'note', html: 'Ключом может быть любой «неизменяемый» тип: string, int, enum или перечисление. Свой класс тоже годится, если корректно определить Equals и GetHashCode — но это уже история для продвинутых уровней. Значением может быть что угодно — хоть другой словарь.' },
        { t: 'warn', html: '<code>Add</code> по существующему ключу бросит исключение «элемент с тем же ключом уже добавлен», а <code>scores[key] = x</code> молча перезапишет. Выбирай осознанно: Add — когда дубль недопустим, индексатор — когда перезапись нормальна.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Заполни пропуски <b>одним словом</b> так, чтобы код стал рабочим: добавление пары в словарь, проверка ключа, удаление по значению из списка, тип в foreach и размер списка. Подсказки — в комментариях.</p>',
        code: `using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Словарь: имя игрока -> очки
        Dictionary<string, int> scores = new Dictionary<string, int>();
        scores.{{0}}("Аня", 90);
        scores["Борис"] = 75;

        // проверяем, есть ли ключ, прежде чем читать
        if (scores.{{1}}("Аня"))
        {
            Console.WriteLine($"У Ани {scores["Аня"]} очков");
        }

        // Список участников
        List<string> names = new List<string>();
        names.Add("Аня");
        names.Add("Борис");
        names.Add("Вера");
        names.{{2}}("Борис");            // удалить по значению

        foreach ({{3}} name in names)
        {
            Console.WriteLine(name);
        }

        Console.WriteLine(names.{{4}});   // сколько осталось
    }
}`,
        blanks: [
          { answer: 'Add' },
          { answer: 'ContainsKey' },
          { answer: 'Remove' },
          { answer: 'string' },
          { answer: 'Count' }
        ]
      },
      hints: [
        'Пять ответов: Add, ContainsKey, Remove, string, Count.',
        'Пара добавляется методом scores.Add("Аня", 90); наличие ключа проверяет ContainsKey.',
        'В foreach тип переменной совпадает с типом элементов списка — string; размер списка — свойство Count.'
      ],
      solution: ['Add', 'ContainsKey', 'Remove', 'string', 'Count']
    },

    /* ============ 15. LINQ: основы ============ */
    {
      id: 'cs-15',
      title: 'LINQ: основы',
      goal: 'Фильтровать, сортировать и преобразовывать коллекции цепочкой LINQ: Where, OrderBy, Select, FirstOrDefault — и понимать отложенное выполнение.',
      xp: 55,
      theory: [
        { t: 'h', html: 'LINQ: запросы к коллекциям' },
        { t: 'p', html: 'LINQ (Language Integrated Query) — встроенный язык запросов: фильтруй, сортируй и преобразуй коллекции одной цепочкой вместо вложенных циклов. Подключи <code>using System.Linq;</code> — и у List, массива или словаря появятся методы Where, OrderBy, Select. Каждый метод принимает <b>лямбду</b> — короткую безымянную функцию вида <code>n =&gt; n &gt; 6</code>: «для каждого n верни истину, если n больше шести».' },
        { t: 'table', head: ['Метод', 'Что делает', 'Пример'], rows: [
          ['Where', 'Отфильтровывает по условию', 'numbers.Where(n => n > 6)'],
          ['OrderBy / OrderByDescending', 'Сортирует по ключу', 'list.OrderBy(n => n)'],
          ['Select', 'Преобразует каждый элемент', 'list.Select(n => n * 10)'],
          ['FirstOrDefault', 'Первый по условию или default', 'list.FirstOrDefault(n => n > 100)'],
          ['Count / Sum / Average', 'Считает по коллекции', 'list.Sum(n => n)']
        ] },
        { t: 'h', html: 'Два синтаксиса: методы и from-запросы' },
        { t: 'p', html: 'LINQ умеет записываться двояко. Метод-синтаксис — цепочка вызовов: <code>numbers.Where(n =&gt; n &gt; 6).OrderBy(n =&gt; n)</code>. From-синтаксис читается как SQL: <code>var q = from n in numbers where n &gt; 6 orderby n select n;</code>. Компилятор превращает оба в один и тот же код, но метод-синтаксис умеет больше (FirstOrDefault в from-виде не выразить), поэтому в реальном коде чаще встречаются методы, а from — для сложных соединений и группировок.' },
        { t: 'code', code: `using System.Linq;

List<int> numbers = new List<int> { 5, 12, 3, 18, 9, 7 };

var big = numbers
    .Where(n => n > 6)        // 12, 18, 9, 7
    .OrderBy(n => n)          // 7, 9, 12, 18
    .Select(n => $"№ {n}");   // "№ 7", "№ 9", ...

foreach (string s in big)
    Console.WriteLine(s);` },
        { t: 'h', html: 'Отложенное выполнение' },
        { t: 'p', html: 'Запрос — не результат, а <b>рецепт</b>: строка с Where не пробегает по списку в момент объявления. Выполнение стартует, когда данные понадобились — на <code>foreach</code>, <code>ToList()</code>, <code>FirstOrDefault</code>. Из-за этого изменение списка между созданием запроса и его перебором отразится на результате; нужен мгновенный снимок — вызови <code>.ToList()</code>. Это называется <b>отложенным выполнением</b>, и это самая неожиданная ловушка LINQ для новичков.' },
        { t: 'note', html: '<code>FirstOrDefault</code> при отсутствии подходящего элемента возвращает <code>default(T)</code>: для int — 0, для ссылочных типов — null. Это не ошибка, а «пустой ответ»; результат стоит проверить перед использованием. Есть и <code>Single</code>, требующий ровно одного элемента, — он бросит исключение, если их два.' },
        { t: 'warn', html: 'Забудешь <code>using System.Linq;</code> — у List «не будет» метода Where, и компилятор выдаст загадочное «List&lt;int&gt; не содержит определения Where». Вторая ловушка: перебрать один и тот же запрос дважды можно, но каждое прохождение заново пересчитывает цепочку — для дорогих вычислений сначала ToList().' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери LINQ-конвейер над списком чисел (список <code>numbers</code> с шестью значениями объяви сам, например <code>{ 5, 12, 3, 18, 9, 7 }</code>):</p><ul><li><code>using System.Linq;</code> — не удаляй;</li><li>запрос: <code>.Where(...)</code> — числа больше 6, <code>.OrderBy(...)</code> — по возрастанию, <code>.Select(...)</code> — строка вида «№ 7» (лямбды со стрелкой <code>=&gt;</code>);</li><li>перебери результат в <code>foreach</code> и выведи каждый элемент;</li><li>отдельно выведи <code>FirstOrDefault</code> по условию, которому ничто не удовлетворяет (например, «больше 100») — увидишь default;</li><li>убери все <code>TODO</code>.</li></ul>',
        starter: `using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        // TODO: объяви List<int> numbers с 5-6 значениями

        // TODO: цепочка Where + OrderBy + Select и вывод через foreach

        // TODO: FirstOrDefault по условию, которому ничто не удовлетворяет
    }
}`,
        rules: [
          { desc: 'Подключено System.Linq', all: ['using\\s+System\\.Linq\\s*;'] },
          { desc: 'Есть List<int> с литералом значений', all: ['List\\s*<\\s*int\\s*>\\s+\\w+\\s*=\\s*new\\s+List\\s*<\\s*int\\s*>\\s*\\{'] },
          { desc: 'Where фильтрует через лямбду (n => условие)', all: ['\\.Where\\s*\\(\\s*\\w+\\s*=>'] },
          { desc: 'OrderBy сортирует по ключу', all: ['\\.OrderBy\\s*\\(\\s*\\w+\\s*=>'] },
          { desc: 'Select проецирует элементы', all: ['\\.Select\\s*\\(\\s*\\w+\\s*=>'] },
          { desc: 'FirstOrDefault ищет с запасным значением', all: ['\\.FirstOrDefault\\s*\\('] },
          { desc: 'Результат перебирается foreach и выводится в консоль', all: ['\\bforeach\\s*\\('], any: ['Console\\.WriteLine', 'Console\\.Write'] },
          { desc: 'Код непуст и все заглушки TODO заменены', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Список: List<int> numbers = new List<int> { 5, 12, 3, 18, 9, 7 };',
        'Цепочка: var big = numbers.Where(n => n > 6).OrderBy(n => n).Select(n => $"№ {n}"); — foreach (string s in big) выведет по строке.',
        'Запасное значение: int miss = numbers.FirstOrDefault(n => n > 100); — для int default это 0.'
      ],
      solution: `using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        List<int> numbers = new List<int> { 5, 12, 3, 18, 9, 7 };

        var big = numbers
            .Where(n => n > 6)
            .OrderBy(n => n)
            .Select(n => $"№ {n}");

        foreach (string s in big)
        {
            Console.WriteLine(s);
        }

        int miss = numbers.FirstOrDefault(n => n > 100);
        Console.WriteLine($"Первый больше сотни: {miss}");
    }
}`
    },

    /* ============ 16. Исключения ============ */
    {
      id: 'cs-16',
      title: 'Исключения: try/catch/finally',
      goal: 'Перехватывать ошибки через try/catch/finally, знать основные Exception-типы и понимать using как try-with-resources.',
      xp: 50,
      theory: [
        { t: 'h', html: 'Исключения: когда всё пошло не так' },
        { t: 'p', html: 'Деление на ноль, попытка разобрать «abc» как число, выход за границы массива — во всех этих случаях .NET бросает <b>исключение</b> (exception): объект, описывающий ошибку. Без обработки программа падает с красным текстом. Ловушка ставится так: рискованный код — в <code>try</code>, реакция на ошибку — в <code>catch</code>, а <code>finally</code> выполнится в любом случае, была ошибка или нет.' },
        { t: 'code', code: `try
{
    int n = int.Parse("abc");   // бросит FormatException
    Console.WriteLine(n);
}
catch (FormatException)
{
    Console.WriteLine("Это не число");
}
finally
{
    Console.WriteLine("Продолжаем работу");
}` },
        { t: 'table', head: ['Исключение', 'Когда возникает'], rows: [
          ['FormatException', 'int.Parse("abc") — строка не число'],
          ['DivideByZeroException', '10 / 0 для целых чисел'],
          ['IndexOutOfRangeException', 'a[10] в массиве длины 3'],
          ['NullReferenceException', 'обращение к члену null-объекта'],
          ['KeyNotFoundException', 'чтение словаря по отсутствующему ключу']
        ] },
        { t: 'h', html: 'throw и порядок catch' },
        { t: 'p', html: 'Своё исключение бросают так: <code>throw new Exception("Счёт пуст");</code> — вместо обычного return управление улетает вверх по стеку до ближайшего catch. Блоки <code>catch</code> проверяются сверху вниз, поэтому частные типы ставят выше общих: сначала <code>catch (FormatException)</code>, потом <code>catch (Exception ex)</code> как «все остальные». У пойманного объекта полезны <code>ex.Message</code> (текст) и <code>ex.StackTrace</code> (где случилось).' },
        { t: 'h', html: 'using: ресурсы сами себя закрывают' },
        { t: 'p', html: 'Файлы, сетевые соединения и прочие ресурсы нужно освобождать даже при ошибке — для этого и придуман <code>finally</code>. Но для типов с интерфейсом <code>IDisposable</code> есть короче: <code>using (var reader = File.OpenText("data.txt")) { ... }</code> — компилятор разворачивает это в try/finally с вызовом <code>Dispose()</code> на выходе. Ты уже встречал using в роли подключения пространств имён — здесь то же слово в другой роли, аналог try-with-resources из Java.' },
        { t: 'note', html: 'Ловить <code>Exception</code> целиком — крайняя мера: так прячут и чужие баги. Лучше ловить конкретные типы, а ещё лучше — не доводить до исключения: <code>int.TryParse</code> вместо Parse, проверка длины перед индексом, <code>ContainsKey</code> перед чтением словаря.' },
        { t: 'warn', html: 'Поставишь <code>catch (Exception)</code> первым блоком — до частных catch дело никогда не дойдёт: он проглотит всё. И помни: finally выполняется даже после сработавшего catch, поэтому код «закрыть ресурс» не дублируют в каждом блоке.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прогони код в голове построчно: int.Parse бросит FormatException на строке «abc». Какой порядок строк выведет консоль? Напиши каждую строку вывода на своей строке.</p>',
        code: `string raw = "abc";
try
{
    int n = int.Parse(raw);
    Console.WriteLine("Число: " + n);
}
catch (FormatException)
{
    Console.WriteLine("Не число");
}
catch (Exception ex)
{
    Console.WriteLine("Другое: " + ex.Message);
}
finally
{
    Console.WriteLine("Конец");
}`,
        answer: 'Не число\nКонец',
        solution: 'Не число\nКонец'
      },
      hints: [
        'int.Parse("abc") бросает FormatException — и выполнение немедленно прыгает в подходящий catch.',
        'catch проверяются сверху вниз: первый подходящий блок — FormatException, до общего Exception дело не доходит.',
        'finally выполняется всегда — даже после перехваченного исключения.'
      ],
      solution: 'Не число\nКонец'
    },

    /* ============ 17. Делегаты и события ============ */
    {
      id: 'cs-17',
      title: 'Делегаты и события',
      goal: 'Хранить методы в переменных через delegate, Action и Func, понимать механизм событий publish/subscribe.',
      xp: 50,
      theory: [
        { t: 'h', html: 'Делегат: тип для методов' },
        { t: 'p', html: 'Переменные хранят данные, а <b>делегаты</b> — методы. Объявление <code>delegate int Calc(int a, int b);</code> вводит тип: «функция, принимающая два int и возвращающая int». В переменную такого типа можно положить любой подходящий метод или лямбду и вызвать как обычную функцию. Так методы становятся данными, которые можно передавать.' },
        { t: 'code', code: `delegate int Calc(int a, int b);

static int Add(int a, int b) => a + b;

Calc op = Add;          // метод в переменной
op = (a, b) => a * b;   // или лямбда
Console.WriteLine(op(2, 3)); // 6` },
        { t: 'h', html: 'Action и Func: делегаты из коробки' },
        { t: 'p', html: 'Объявлять свой тип для каждого случая не нужно: в .NET есть готовые обобщённые делегаты. <code>Action&lt;T&gt;</code> — метод, который ничего не возвращает; <code>Func&lt;T1, T2, TResult&gt;</code> — который возвращает результат, причём последний параметр — всегда тип возвращаемого значения. Именно Func ты передавал в LINQ-методы на прошлом уровне: <code>Where</code> принимает <code>Func&lt;T, bool&gt;</code>.' },
        { t: 'table', head: ['Тип', 'Сигнатура', 'Пример'], rows: [
          ['Action', '() → void', 'Action beep = () => Console.WriteLine("Бип");'],
          ['Action<string>', 'string → void', 'Action<string> log = s => Console.WriteLine(s);'],
          ['Func<int>', '() → int', 'Func<int> roll = () => 6;'],
          ['Func<int, int>', 'int → int', 'Func<int, int> square = x => x * x;'],
          ['Func<int, int, int>', '(int, int) → int', 'Func<int, int, int> sum = (a, b) => a + b;']
        ] },
        { t: 'h', html: 'События: издатель и подписчики' },
        { t: 'p', html: 'Событие — делегат с ограничениями доступа: снаружи класса можно только <b>подписаться</b> (<code>+=</code>) и <b>отписаться</b> (<code>-=</code>), а вызвать — только изнутри класса-издателя. Издатель не знает, кто подписан: он просто «выстреливает» событие, и все обработчики срабатывают. Классика — интерфейс: <code>button.Click += (s, e) =&gt; Save();</code>. Паттерн называется publish/subscribe: один публикует, многие реагируют.' },
        { t: 'code', code: `class Thermometer
{
    public event Action<int> Overheated;

    public void Measure(int t)
    {
        if (t > 100 && Overheated != null)
            Overheated(t);   // стреляем событием
    }
}

// подписчики:
var th = new Thermometer();
th.Overheated += t => Console.WriteLine($"Жарко: {t}");
th.Overheated += t => Console.WriteLine("Выключаю плиту!");` },
        { t: 'note', html: '<code>+=</code> накапливает подписчиков в списке вызова, <code>-=&gt;</code> снимает конкретного. Если подписчиков нет, событие равно null — издатель обязан проверить это перед вызовом (или использовать безопасный синтаксис <code>Overheated?.Invoke(t)</code>).' },
        { t: 'warn', html: 'Лямбда в <code>+=</code> держит ссылки на объекты, которые захватила: забудешь отписаться в долгоживущем приложении — получишь утечку памяти. В обработчиках событий принято отсоединяться, когда объект-слушатель больше не нужен.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет этот код? Лямбды лежат в переменных-делегатах.</p><pre>Func<int, int> square = x => x * x;
Func<int, int, int> add = (a, b) => a + b;

Console.WriteLine(square(add(2, 3)));</pre>`,
        options: ['25', '10', 'Ошибка: лямбду нельзя присвоить Func', '5'],
        correct: 0,
        explain: 'Сначала выполняется add(2, 3) — лямбда складывает, получается 5. Затем square(5) — умножает на себя, получается 25. Func<int, int, int> означает «два аргумента int, результат int»: последний тип-параметр всегда возвращаемое значение, поэтому хранить лямбды в Func — норма.',
        solution: 0
      },
      hints: [
        'Читай изнутри наружу: сначала add(2, 3), затем результат уходит в square.',
        'Func<int, int, int>: первые два типа — типы аргументов, последний — возвращаемое значение.'
      ],
      solution: 0
    },

    /* ============ 18. async/await ============ */
    {
      id: 'cs-18',
      title: 'async/await',
      goal: 'Понимать Task и асинхронные методы: что делает async, как работает await и почему нельзя блокировать UI-поток.',
      xp: 55,
      theory: [
        { t: 'h', html: 'Task: обещание результата' },
        { t: 'p', html: 'Долгие операции — загрузка файла, ответ сервера, чтение диска — не должны замораживать программу. <code>Task&lt;T&gt;</code> — «обещание» выдать значение T когда-нибудь позже; <code>Task</code> без угловых скобок — обещание просто закончить работу. Метод с модификатором <code>async</code> разрешает внутри <code>await</code>; его возвращаемый тип — Task или Task&lt;T&gt;, а результат вызывающий получает через <code>await</code>.' },
        { t: 'code', code: `async Task<int> LoadScoreAsync()
{
    await Task.Delay(500);   // имитация долгой работы
    return 42;
}

// в другом async-методе:
int score = await LoadScoreAsync();
Console.WriteLine(score);    // 42 — когда придёт` },
        { t: 'h', html: 'Как работает await' },
        { t: 'p', html: 'До первого <code>await</code> асинхронный метод выполняется как обычный, синхронно. На <code>await</code> управление возвращается вызывающему: поток не стоит и не ждёт, а занимается другими делами. Когда операция завершится, выполнение продолжится со строки после await. Поэтому <code>Console.WriteLine("Старт");</code> перед ожиданием появится раньше, чем результат — вызов вернулся сразу, а значение дозрело позже.' },
        { t: 'p', html: 'Особенно важен UI-поток: в десктопных и мобильных приложениях один-единственный поток рисует окно и обрабатывает клики. Заблокируешь его долгим вычислением или <code>Thread.Sleep</code> — интерфейс «замерзает», кнопки не нажимаются, окно становится «не отвечает». <code>await</code> отпускает поток на время ожидания, и окно продолжает жить.' },
        { t: 'table', head: ['Так нельзя', 'Так правильно'], rows: [
          ['Thread.Sleep(1000) в UI', 'await Task.Delay(1000)'],
          ['var x = task.Result;', 'var x = await task;'],
          ['new Thread(...).Start() для мелочи', 'Task.Run(() => ...)'],
          ['async void (кроме обработчиков событий)', 'async Task']
        ] },
        { t: 'note', html: 'Имя асинхронного метода по конвенции оканчивают на Async: LoadScoreAsync, SaveAsync. Метод, помеченный async, но без единого await, вызовет предупреждение компилятора — значит, асинхронность там не нужна.' },
        { t: 'warn', html: '<code>.Result</code> и <code>.Wait()</code> блокируют поток до завершения задачи — в UI-приложении это и есть замерзание интерфейса, а иногда и взаимная блокировка (deadlock): задача ждёт освобождения потока, а поток ждёт задачу. В асинхронном коде дожидайся только await-ом.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>В каком порядке консоль получит строки? Метод LoadAsync — асинхронный.</p><pre>static async Task<int> LoadAsync()
{
    await Task.Delay(100);
    return 42;
}

static void Main()
{
    Task<int> t = LoadAsync();
    Console.WriteLine("Жду...");
    Console.WriteLine(t.Result);
}</pre>`,
        options: ['42, затем Жду...', 'Жду..., затем 42', 'Только 42: «Жду...» не выведется', 'Программа зависнет навсегда'],
        correct: 1,
        explain: 'До первого await LoadAsync выполняется синхронно, на await Task.Delay управление мгновенно возвращается в Main — печатается «Жду...». Затем t.Result дожидается завершения задачи и даёт 42. Порядок: Жду..., потом 42. (В настоящем UI-коде вместо .Result используют await — иначе поток блокируется.)',
        solution: 1
      },
      hints: [
        'На await метод сразу возвращает управление вызывающему — Main продолжает печатать, не дожидаясь значения.',
        't.Result «дожидается» обещания: строка с ним появится после Жду..., но значение будет готово.'
      ],
      solution: 1
    },

    /* ============ 19. Строки и интерполяция: углубление ============ */
    {
      id: 'cs-19',
      title: 'Строки и интерполяция: углубление',
      goal: 'Форматировать значения в $-строках, склеивать текст без потерь через StringBuilder и писать дословные строки с @.',
      xp: 50,
      theory: [
        { t: 'h', html: 'Интерполяция: продвинутый уровень' },
        { t: 'p', html: 'В $-строках внутри фигурных скобок может стоять любое выражение, а после двоеточия — <b>формат</b>. <code>{price:F2}</code> — два знака после точки, <code>{n:D5}</code> — целое с ведущими нулями, <code>{count,8}</code> — выравнивание на восемь символов вправо. Чтобы напечатать саму фигурную скобку (а не начать выражение), её удваивают: <code>{{</code> и <code>}}</code>.' },
        { t: 'code', code: `double price = 1234.5;
int level = 7;
Console.WriteLine($"Цена: {price:F2}");  // Цена: 1234.50
Console.WriteLine($"Уровень: {level:D3}"); // Уровень: 007
Console.WriteLine($"Скобки: {{литерал}}"); // Скобки: {литерал}` },
        { t: 'h', html: 'StringBuilder: склейка без мусора' },
        { t: 'p', html: 'Строки в .NET неизменяемы: каждая правка создаёт <b>новую</b> строку, а старая выбрасывается. <code>text += "ещё";</code> в цикле на десять тысяч витков породит десять тысяч временных строк — мусор для сборщика и тормоза. <code>StringBuilder</code> из <code>System.Text</code> накапливает текст в изменяемом буфере: <code>Append</code> добавляет в конец, <code>ToString()</code> собирает итоговую строку.' },
        { t: 'code', code: `using System.Text;

var sb = new StringBuilder();
for (int i = 1; i <= 3; i++)
{
    sb.Append($"Строка {i}, ");
}
Console.WriteLine(sb.ToString());
// Строка 1, Строка 2, Строка 3,` },
        { t: 'h', html: 'Verbatim-строки: @ перед кавычками' },
        { t: 'p', html: 'Префикс <code>@</code> делает строку <b>дословной</b>: обратные слэши не нужно удваивать, а текст можно переносить на несколько строк. Идеально для путей Windows, регулярок и SQL: <code>@"C:\\Users\\Аня"</code> выглядит ровно так, как будет напечатано. Кавычка внутри дословной строки удваивается: <code>@"он сказал ""привет"""</code>.' },
        { t: 'code', code: `string path = @"C:\\Users\\Аня\\отчёт.txt";
string sql = @"
    SELECT Name, Salary
    FROM Employee
    WHERE Dept = 'IT'";
Console.WriteLine(path);` },
        { t: 'note', html: 'Полезные форматы: <code>F</code> — дробное число (F2 — два знака), <code>N</code> — с разделителями тысяч, <code>P</code> — проценты, <code>D</code> — целое с нулями (D5), <code>X</code> — шестнадцатеричное. Форматы работают и в классической записи <code>Console.WriteLine("{0:F2}", x)</code>.' },
        { t: 'warn', html: 'Путаешь StringBuilder и строку: <code>sb += "текст";</code> не скомпилируется — у StringBuilder метод <code>Append</code>. А совместный префикс <code>$@"..."</code> даёт одновременно интерполяцию и дословность — удобно для путей с подстановками.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Заполни пропуски: префикс дословной строки, формат с двумя знаками после точки, имя класса-конструктора, метод добавления и метод сборки итоговой строки. Подсказки — в комментариях.</p>',
        code: `using System;
using System.Text;

class Program
{
    static void Main()
    {
        string path = {{0}}"C:\\Users\\Аня\\отчёт.txt";  // дословная строка без удвоенных \\

        double price = 1234.5;
        Console.WriteLine($"Цена: {price:{{1}}}");   // формат: два знака после точки

        var sb = new {{2}}();                         // класс из System.Text
        for (int i = 1; i <= 3; i++)
        {
            sb.{{3}}($"Строка {i}, ");                // добавить к тексту
        }
        Console.WriteLine(sb.{{4}}());                // собрать итоговую строку
    }
}`,
        blanks: [
          { answer: '@' },
          { answer: 'F2' },
          { answer: 'StringBuilder' },
          { answer: 'Append' },
          { answer: 'ToString' }
        ]
      },
      hints: [
        'Пять ответов: @, F2, StringBuilder, Append, ToString.',
        'Дословная строка начинается с @ перед кавычками; формат F2 — два знака после точки.',
        'StringBuilder копит текст методом Append, а итог отдаёт ToString().'
      ],
      solution: ['@', 'F2', 'StringBuilder', 'Append', 'ToString']
    },

    /* ============ 20. Проект: учёт сотрудников ============ */
    {
      id: 'cs-20',
      title: '🚀 Проект: учёт сотрудников',
      goal: 'Собрать финальную программу: интерфейс IReportable, класс Employee со свойствами и конструктором, список сотрудников и LINQ-отчёт с агрегатами.',
      xp: 110,
      theory: [
        { t: 'h', html: 'Проект: учёт сотрудников' },
        { t: 'p', html: 'Финальный уровень собирает всё, что ты выучил на второй половине курса: <b>интерфейс</b> из cs-13, <b>класс с автосвойствами и конструктором</b> из cs-11, <b>коллекции</b> из cs-14 и <b>LINQ-отчёт</b> из cs-15. Программа хранит сотрудников, выбирает отдел, сортирует по зарплате и печатает отчёт — причём печать идёт через метод интерфейса, а не напрямую. Такие мини-системы учёта — основа любого бизнес-приложения.' },
        { t: 'list', items: [
          '1. Интерфейс IReportable с методом string Report();',
          '2. Класс Employee : IReportable — автосвойства Name, Dept, Salary + конструктор + Report() с интерполяцией',
          '3. В Main: List&lt;Employee&gt; и три сотрудника через .Add(new Employee(...))',
          '4. LINQ: Where по отделу + OrderByDescending по зарплате',
          '5. foreach: вывести каждого через .Report()',
          '6. Итог: количество сотрудников и средняя зарплата через .Average(...)'
        ] },
        { t: 'code', code: `interface IReportable
{
    string Report();
}

class Employee : IReportable
{
    public string Name { get; set; }
    public string Dept { get; set; }
    public int Salary { get; set; }

    public Employee(string name, string dept, int salary)
    {
        Name = name;
        Dept = dept;
        Salary = salary;
    }

    public string Report()
    {
        return $"{Name} ({Dept}): {Salary} руб.";
    }
}` },
        { t: 'p', html: 'Обрати внимание на полиморфизм: список типизирован <code>List&lt;Employee&gt;</code>, но Report() объявлен в интерфейсе — завтра добавишь классы Contractor или Manager с той же кнопкой Report, и код печати не изменится. Агрегаты LINQ считают одним вызовом то, что в cs-10 требовало цикла-накопителя: <code>staff.Average(e =&gt; e.Salary)</code> — средняя зарплата без ручного foreach.' },
        { t: 'code', code: `// в Main:
var it = staff
    .Where(e => e.Dept == "IT")
    .OrderByDescending(e => e.Salary);

foreach (Employee e in it)
    Console.WriteLine(e.Report());

Console.WriteLine($"Сотрудников: {staff.Count}, средняя: {staff.Average(e => e.Salary):F0}");` },
        { t: 'note', html: 'Формат <code>{avg:F0}</code> округляет среднюю до целого — отчёт читается лучше. В настоящих программах для денег используют decimal, а печать отчётов выносят в отдельный класс — но архитектурная идея «данные + отчёт через интерфейс» уже именно такая.' },
        { t: 'warn', html: 'Класс Employee подписался на IReportable — значит, обязан иметь <code>public string Report()</code> с точной сигнатурой: забудешь — компилятор остановит сборку. И не оставляй в финальном коде пометки TODO: проверка их не пропустит.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Учёт сотрудников».</b> Собери программу целиком:</p><ul><li>интерфейс <code>IReportable</code> с методом <code>string Report();</code>;</li><li>класс <code>Employee : IReportable</code>: автосвойства <code>Name</code>, <code>Dept</code> (string), <code>Salary</code> (int), конструктор с тремя параметрами, метод <code>Report()</code> возвращает строку вида «Аня (IT): 90000 руб.»;</li><li>в <code>Main</code> — <code>List&lt;Employee&gt;</code> и три сотрудника через <code>.Add(new Employee(...))</code> (сделай два отдела, например IT и HR);</li><li>LINQ-отчёт: <code>.Where(...)</code> по одному отделу + <code>.OrderBy...</code> по зарплате, вывод каждого через <code>.Report()</code>;</li><li>итоговая строка: количество сотрудников (<code>Count</code>) и средняя зарплата (<code>Average</code>);</li><li>убери все <code>TODO</code>. После зачёта расширяй: премии, поиск по имени, экспорт отчёта!</li></ul>',
        starter: `using System;
using System.Collections.Generic;
using System.Linq;

// TODO: объяви интерфейс IReportable с методом string Report();

// TODO: объяви класс Employee : IReportable —
// свойства Name, Dept, Salary + конструктор + метод Report()

class Program
{
    static void Main()
    {
        // TODO: создай List<Employee> и добавь 3 сотрудников

        // TODO: LINQ-отчёт: Where по отделу + OrderBy по зарплате,
        // выведи каждого через .Report()

        // TODO: выведи количество и среднюю зарплату (Average)
    }
}`,
        rules: [
          { desc: 'Интерфейс IReportable объявлен с методом Report', all: ['\\binterface\\s+IReportable\\b', 'string\\s+Report\\s*\\(\\s*\\)\\s*;'] },
          { desc: 'Класс Employee реализует IReportable', all: ['\\bclass\\s+Employee\\s*:\\s*IReportable\\b'] },
          { desc: 'Employee имеет автосвойства Name, Dept и Salary', all: ['\\bName\\s*\\{\\s*get\\s*;\\s*set\\s*;', '\\bDept\\s*\\{\\s*get\\s*;\\s*set\\s*;', '\\bSalary\\s*\\{\\s*get\\s*;\\s*set\\s*;'] },
          { desc: 'Есть конструктор Employee с параметрами', any: ['public\\s+Employee\\s*\\([^)]*\\)\\s*\\{', 'Employee\\s*\\([^)]*string[^)]*\\)\\s*\\{'] },
          { desc: 'Создан List<Employee>, сотрудники добавлены через .Add(new Employee(...))', all: ['List\\s*<\\s*Employee\\s*>', '\\.Add\\s*\\(\\s*new\\s+Employee\\s*\\('] },
          { desc: 'LINQ-отчёт: Where + OrderBy по зарплате', all: ['\\.Where\\s*\\(\\s*\\w+\\s*=>'], any: ['\\.OrderByDescending\\s*\\(', '\\.OrderBy\\s*\\('] },
          { desc: 'Report() вызывается, вывод через Console.WriteLine', all: ['\\.Report\\s*\\(\\s*\\)'], any: ['Console\\.WriteLine', 'Console\\.Write'] },
          { desc: 'Подключён System.Linq, код непуст и все TODO заменены', all: ['using\\s+System\\.Linq\\s*;', '\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Интерфейс и класс: interface IReportable { string Report(); } затем class Employee : IReportable { ... }.',
        'В Main: staff.Add(new Employee("Аня", "IT", 90000)); — три раза, повтори отдел хотя бы у двоих.',
        'Отчёт: var it = staff.Where(e => e.Dept == "IT").OrderByDescending(e => e.Salary); foreach (Employee e in it) Console.WriteLine(e.Report());',
        'Итог: Console.WriteLine($"Сотрудников: {staff.Count}, средняя: {staff.Average(e => e.Salary):F0}");'
      ],
      solution: `using System;
using System.Collections.Generic;
using System.Linq;

interface IReportable
{
    string Report();
}

class Employee : IReportable
{
    public string Name { get; set; }
    public string Dept { get; set; }
    public int Salary { get; set; }

    public Employee(string name, string dept, int salary)
    {
        Name = name;
        Dept = dept;
        Salary = salary;
    }

    public string Report()
    {
        return $"{Name} ({Dept}): {Salary} руб.";
    }
}

class Program
{
    static void Main()
    {
        List<Employee> staff = new List<Employee>();
        staff.Add(new Employee("Аня", "IT", 90000));
        staff.Add(new Employee("Борис", "HR", 60000));
        staff.Add(new Employee("Вера", "IT", 95000));

        var it = staff
            .Where(e => e.Dept == "IT")
            .OrderByDescending(e => e.Salary);

        foreach (Employee e in it)
        {
            Console.WriteLine(e.Report());
        }

        Console.WriteLine($"Сотрудников: {staff.Count}, средняя зарплата: {staff.Average(e => e.Salary):F0}");
    }
}`
    }
  ],

  /* ============ Шпаргалки ============ */
  cheats: [
    {
      title: 'Каркас программы',
      code: `using System;

class Program
{
    static void Main()
    {
        // точка входа — старт программы
    }
}`
    },
    {
      title: 'Вывод в консоль',
      code: `Console.WriteLine("Привет!"); // с переводом строки
Console.Write("Без перевода"); // строка не прервётся
Console.WriteLine();           // пустая строка`
    },
    {
      title: 'Переменные и типы',
      list: [
        'int age = 25; — целые числа',
        'double price = 9.99; — дробные (точка, не запятая!)',
        'string name = "Аня"; — текст в двойных кавычках',
        'bool isReady = true; — истина / ложь',
        'var count = 10; — тип выведет компилятор (здесь int)',
        'const int Max = 99; — константа, изменить нельзя'
      ]
    },
    {
      title: 'Конвертация типов',
      code: `int n = int.Parse("42");            // строка → число
double d = double.Parse("3.14");
string s = 42.ToString();           // число → строка
string t = "Итог: " + n;            // число само станет текстом
int c = Convert.ToInt32("100");
bool ok = int.TryParse("abc", out int r); // false — без падения`
    },
    {
      title: 'Условия: if / else / switch',
      code: `if (score >= 90)
{
    Console.WriteLine("Отлично");
}
else if (score >= 60)
{
    Console.WriteLine("Неплохо");
}
else
{
    Console.WriteLine("Учись");
}

switch (day)
{
    case 6:
    case 7:
        Console.WriteLine("Выходной");
        break;
    default:
        Console.WriteLine("Будни");
        break;
}`
    },
    {
      title: 'Циклы',
      code: `for (int i = 0; i < 5; i++) { /* счётчик */ }

while (условие) { /* проверка ДО тела */ }

do { /* тело хотя бы раз */ } while (условие);

break;    // досрочный выход из цикла
continue; // переход к следующему витку`
    },
    {
      title: 'Массивы',
      code: `int[] a = { 10, 20, 30 };     // сразу со значениями
int[] b = new int[3];          // три нуля
a[0] = 5;                      // первый элемент
int last = a[a.Length - 1];    // последний элемент

for (int i = 0; i < a.Length; i++)
    Console.WriteLine(a[i]);`
    },
    {
      title: 'Методы',
      code: `static int Square(int x)
{
    return x * x;
}

static void SayHi()            // void — ничего не возвращает
{
    Console.WriteLine("Привет!");
}

int s = Square(5);             // вызов: s = 25
SayHi();`
    },
    {
      title: 'Строки',
      list: [
        's.Length — количество символов',
        's.ToUpper() / s.ToLower() — регистр',
        's.Substring(0, 4) — кусок с индекса 0 длиной 4',
        's.Contains("Code") — содержит ли подстроку',
        's.Replace("a", "b") — замена всех вхождений',
        's.Trim() — убрать пробелы по краям',
        'string.IsNullOrEmpty(s) — пустая или null'
      ]
    },
    {
      title: 'Интерполяция строк',
      code: `string name = "Аня";
int age = 20;
Console.WriteLine($"Меня зовут {name}, мне {age}");
Console.WriteLine($"Через год: {age + 1}");  // выражения работают
Console.WriteLine("Без $: {name}");          // скобки останутся текстом`
    },
    {
      title: 'List<T>',
      code: `using System.Collections.Generic;

List<string> list = new List<string>();
list.Add("первый");            // добавить в конец
list.Remove("первый");         // удалить по значению
list.RemoveAt(0);              // удалить по индексу
Console.WriteLine(list.Count); // количество элементов

foreach (string item in list)
    Console.WriteLine(item);`
    },
    {
      title: 'Частые ошибки',
      list: [
        'console.writeline — C# чувствителен к регистру: Console.WriteLine',
        'Забытая точка с запятой ; в конце инструкции',
        '= присваивает, == сравнивает — не перепутай',
        'int.Parse("abc") падает с FormatException — бери TryParse',
        'Массив длины 4: индексы 0–3, обращение к [4] — ошибка',
        'Забыл $ перед строкой со скобками — {} выведутся как текст',
        'У списка Count, у массива Length — не путай'
      ]
    },
    {
      title: 'Классы и интерфейсы',
      code: `class Dog : Animal, IPet          // наследование + интерфейсы
{
    public string Name { get; set; }   // автосвойство
    public int Age { get; } = 1;       // только чтение

    public Dog(string name) { this.Name = name; }

    public override string Speak()     // переопределение
    {
        return base.Speak() + " — гав!";
    }
}

interface IPet { string Speak(); }     // контракт без кода

sealed class Cat : Animal { }          // дальше не наследуется`
    },
    {
      title: 'Dictionary и LINQ',
      code: `var scores = new Dictionary<string, int>();
scores.Add("Аня", 90);            // добавить пару
scores["Борис"] = 75;             // добавить или перезаписать
if (scores.ContainsKey("Аня"))    // есть ли ключ
    Console.WriteLine(scores["Аня"]);

var big = numbers                  // цепочка LINQ
    .Where(n => n > 6)             // фильтр
    .OrderBy(n => n)               // сортировка
    .Select(n => n * 10);          // преобразование
int miss = numbers.FirstOrDefault(n => n > 100); // или default
Console.WriteLine(list.Average(x => x)); // среднее без цикла`
    }
  ]
};
