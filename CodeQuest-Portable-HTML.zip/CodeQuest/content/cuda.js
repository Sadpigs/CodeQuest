'use strict';
/* ============ CodeQuest — курс CUDA ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.cuda = {
  id: 'cuda',
  title: 'CUDA',
  emoji: '🟩',
  color: '#76b900',
  lang: 'cuda',
  tagline: 'Параллелизм на GPU: 10 уровней',
  description: 'Платформа NVIDIA для общего программирования GPU: тысячи потоков вместо циклов. Отсюда вырос весь современный ИИ — PyTorch и CUDA-ядра. За 10 уровней: ядра и потоки, блоки и гриды, память device/host, индексация, синхронизация, shared memory и финальный vector add.',

  levels: [

    {
      id: 'cuda-1',
      title: 'Хост и устройство',
      goal: 'Понять разделение CPU (host) и GPU (device)',
      xp: 30,
      theory: [
        { t: 'p', html: 'CUDA-программа — смесь кода для CPU (<b>host</b>) и GPU (<b>device</b>). Ключевые слова: <code>__global__</code> — функция-ядро, запускаемая НА GPU (вызывается с CPU), <code>__device__</code> — функция, работающая только на GPU, без префикса — обычный CPU-код.' },
        { t: 'code', code: `__global__ void hello() {
    printf("Привет с GPU!\\n");
}

int main() {
    hello<<<1, 1>>>();   // запуск ядра: 1 блок, 1 поток
    cudaDeviceSynchronize();
    return 0;
}` },
        { t: 'p', html: 'Запуск ядра — тройные угловые скобки <code>&lt;&lt;&lt;блоки, потоки&gt;&gt;&gt;</code> — конфигурация запуска. GPU асинхронен: <code>cudaDeviceSynchronize()</code> ждёт завершения ядра, иначе main закончится раньше.' },
        { t: 'list', items: [
          '<b>__global__</b> — ядро: CPU запускает, GPU исполняет;',
          '<b>__device__</b> — GPU-only функция;',
          '<b>&lt;&lt;&lt;…&gt;&gt;&gt;</b> — конфигурация запуска;',
          '<b>cudaDeviceSynchronize()</b> — барьер ожидания.'
        ] },
        { t: 'note', html: 'Файлы CUDA — .cu, компилятор — nvcc: он разбирает файл на CPU-часть (gcc) и GPU-часть. printf внутри ядра работает (буферизованный) — удобная отладка.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви ядро kernel с __global__ и запусти его конфигурацией 1 блок, 1 поток, затем синхронизируй устройство.</p>',
        starter: `TODO`,
        rules: [
          { desc: '__global__ ядро объявлено', all: ['__global__\\s+void\\s+kernel\\s*\\(\\s*\\)'] },
          { desc: 'Запуск <<<1, 1>>>', all: ['kernel\\s*<<<\\s*1\\s*,\\s*1\\s*>>>\\s*\\(\\s*\\)'] },
          { desc: 'Синхронизация', all: ['cudaDeviceSynchronize\\s*\\(\\s*\\)'] }
        ],
        note: '__global__ void kernel() {} / kernel<<<1, 1>>>(); / cudaDeviceSynchronize();'
      },
      hints: [
        'Ядро: __global__ void kernel() { … }',
        'Запуск: kernel<<<1, 1>>>();'
      ],
      solution: `__global__ void kernel() {
    printf("gpu\\n");
}

int main() {
    kernel<<<1, 1>>>();
    cudaDeviceSynchronize();
    return 0;
}`
    },

    {
      id: 'cuda-2',
      title: 'Память: cudaMemcpy',
      goal: 'Выделять память GPU и копировать данные',
      xp: 35,
      theory: [
        { t: 'p', html: 'GPU имеет собственную память. <code>cudaMalloc((void**)&amp;d_ptr, size)</code> — выделить на устройстве, <code>cudaMemcpy(d, h, size, cudaMemcpyHostToDevice)</code> — скопировать туда, <code>cudaMemcpy(h, d, size, cudaMemcpyDeviceToHost)</code> — обратно, <code>cudaFree(d)</code> — освободить.' },
        { t: 'code', code: `float *h_a, *d_a;             // h_ — host, d_ — device
int n = 1024;
size_t bytes = n * sizeof(float);

h_a = (float*)malloc(bytes);          // память CPU
cudaMalloc(&d_a, bytes);              // память GPU

cudaMemcpy(d_a, h_a, bytes, cudaMemcpyHostToDevice);
// ... вычисления на GPU ...
cudaMemcpy(h_a, d_a, bytes, cudaMemcpyDeviceToHost);

free(h_a);
cudaFree(d_a);` },
        { t: 'p', html: 'Соглашение имён h_ / d_ — спасение от путаницы: забыл скопировать — данные «пустые», забыл обратно — «результат не меняется». memcpy НАПРАВЛЕНИЕ указывается явно — это третий аргумент, перепутать HostToDevice и DeviceToHost — классика.' },
        { t: 'note', html: 'Каждый вызов cudaMemcpy — поездка по шине PCIe (~16-32 ГБ/с). Профессиональный CUDA минимизирует копирования: то, что можно посчитать на GPU — оставайся на GPU.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь вызовы: выделение GPU-памяти и копирование host→device.</p>',
        code: `float *d_x;
cuda{{0}}(&d_x, bytes);
cudaMemcpy({{1}}, h_x, bytes, cudaMemcpy{{2}});`,
        blanks: [
          { answer: 'Malloc' },
          { answer: 'd_x' },
          { answer: 'HostToDevice' }
        ],
        ci: false
      },
      hints: [
        'Выделение на GPU — cudaMalloc.',
        'Направление в CPU→GPU — HostToDevice.'
      ],
      solution: ['Malloc', 'd_x', 'HostToDevice']
    },

    {
      id: 'cuda-3',
      title: 'Потоки и threadIdx',
      goal: 'Индексация потоков: кто я в гrvine?',
      xp: 40,
      theory: [
        { t: 'p', html: 'Внутри ядра каждый поток узнаёт себя: <code>threadIdx.x</code> — номер в блоке, <code>blockIdx.x</code> — номер блока, <code>blockDim.x</code> — размер блока. Глобальный индекс: <code>i = blockIdx.x * blockDim.x + threadIdx.x</code> — ДНК всего CUDA-кода.' },
        { t: 'code', code: `__global__ void mark(int *d_out, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        d_out[i] = i * 10;
    }
}

int main() {
    int n = 1000;
    // 1000 потоков = 4 блока по 256
    mark<<<4, 256>>>(d_out, n);
}` },
        { t: 'p', html: 'Проверка <code>if (i &lt; n)</code> обязательна: блоки запускаются целыми (256), а элементов может быть 1000 — последние 24 потока 4-го блока вышли бы за границу. GPU-код — «каждый поток решает свою маленькую задачу по индексу».' },
        { t: 'list', items: [
          '<b>threadIdx</b> — я внутри блока;',
          '<b>blockIdx</b> — мой блок в гриде;',
          '<b>blockDim</b> — сколько нас в блоке;',
          '<b>i = blockIdx * blockDim + threadIdx</b> — глобальный номер.'
        ] },
        { t: 'note', html: '1000 потоков через 4×256 = 1024 слота: лишние 24 потока простаивают с if-защитой. Это нормальная практика — неделимость блоков важнее идеального распределения.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери формулу глобального индекса.</p>',
        code: `int i = {{0}}.x * {{1}}.x + {{2}}.x;`,
        blanks: [
          { answer: 'blockIdx' },
          { answer: 'blockDim' },
          { answer: 'threadIdx' }
        ],
        ci: false
      },
      hints: [
        'Номер блока × размер блока + номер потока.',
        'Три структуры: blockIdx, blockDim, threadIdx.'
      ],
      solution: ['blockIdx', 'blockDim', 'threadIdx']
    },

    {
      id: 'cuda-4',
      title: 'Vector Add',
      goal: 'Написать классическое ядро сложения векторов',
      xp: 45,
      theory: [
        { t: 'p', html: '«Hello World» параллелизма — сложение векторов: c[i] = a[i] + b[i]. На CPU — цикл; на GPU — цикл исчезает: каждый поток делает ОДНО сложение. Тысячи потоков выполняются одновременно на тысячах ядер.' },
        { t: 'code', code: `__global__ void vecAdd(const float *a, const float *b,
                       float *c, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        c[i] = a[i] + b[i];
    }
}

// запуск на 1 млн элементов:
int blocks = (n + 255) / 256;   // округление вверх!
vecAdd<<<blocks, 256>>>(d_a, d_b, d_c, n);` },
        { t: 'p', html: 'Формула <code>blocks = (n + 255) / 256</code> — целочисленное округление вверх: 1 млн элементов → 3907 блоков по 256 потоков. Каждый поток читает a[i], b[i], пишет c[i] — глобальная память GPU, случайный доступ к любому индексу одинаково быстр.' },
        { t: 'list', items: [
          'цикл → заменился на индекс потока;',
          'if (i &lt; n) — защита границ;',
          'const в параметрах — ядро не изменяет вход;',
          'округление блоков вверх — (n + blockDim − 1) / blockDim.'
        ] },
        { t: 'note', html: 'Это ядро — дедлайн всех туториалов CUDA и первый вопрос на GPU-собеседованиях. Оно же — физическая модель ИИ: сложение тензоров в PyTorch выглядит ровно так (с оптимизациями).' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши ядро vecAdd: глобальный индекс, защита i < n, запись c[i] = a[i] + b[i].</p>',
        starter: `__global__ void vecAdd(const float *a, const float *b, float *c, int n) {
    TODO
}`,
        rules: [
          { desc: 'Глобальный индекс', all: ['blockIdx\\.x\\s*\\*\\s*blockDim\\.x\\s*\\+\\s*threadIdx\\.x'] },
          { desc: 'Проверка границы', all: ['if\\s*\\(\\s*i\\s*<\\s*n\\s*\\)'] },
          { desc: 'Запись суммы', all: ['c\\[\\s*i\\s*\\]\\s*=\\s*a\\[\\s*i\\s*\\]\\s*\\+\\s*b\\[\\s*i\\s*\\]'] }
        ],
        note: 'int i = blockIdx.x * blockDim.x + threadIdx.x; if (i < n) c[i] = a[i] + b[i];'
      },
      hints: [
        'Сначала индекс, потом проверка.',
        'Тело — одна строка сложения.'
      ],
      solution: `__global__ void vecAdd(const float *a, const float *b, float *c, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        c[i] = a[i] + b[i];
    }
}`
    },

    {
      id: 'cuda-5',
      title: 'Ошибки CUDA',
      goal: 'Проверять коды ошибок всех вызовов',
      xp: 45,
      theory: [
        { t: 'p', html: 'Каждый CUDA-вызов возвращает <code>cudaError_t</code>. Профессиональный код проверяет ВСЁ: макрос <code>CUDA_CHECK(err)</code> с выходом при ошибке. Ошибки GPU коварны: ядро падает молча, а слом обнаруживается на следующем cudaMemcpy.' },
        { t: 'code', code: `#define CUDA_CHECK(err) \\
    do { \\
        if (err != cudaSuccess) { \\
            printf("CUDA error %s: %s\\n", \\
                   #err, cudaGetErrorString(err)); \\
            exit(1); \\
        } \\
    } while (0)

CUDA_CHECK(cudaMalloc(&d_a, bytes));
CUDA_CHECK(cudaMemcpy(d_a, h_a, bytes, cudaMemcpyHostToDevice));
vecAdd<<<blocks, 256>>>(d_a, d_b, d_c, n);
CUDA_CHECK(cudaGetLastError());        // ошибка ЗАПУСКА ядра
CUDA_CHECK(cudaDeviceSynchronize());   // ошибка ВНУТРИ ядра` },
        { t: 'p', html: 'Два места проверки ядра: <code>cudaGetLastError()</code> — конфигурация запуска (например, слишком много потоков в блоке), <code>cudaDeviceSynchronize()</code> — ошибки исполнения внутри ядра. Обе нужны — это единственный способ услышать крик GPU.' },
        { t: 'note', html: 'В реальных проектах макрос пишут с std::runtime_error или assert. Скрытая классика: ядро «работает» на маленьком n и молча падает на большом — потому что проверок не было.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь проверки после запуска ядра.</p>',
        code: `vecAdd<<<blocks, 256>>>(d_a, d_b, d_c, n);
CUDA_CHECK(cuda{{0}}());
CUDA_CHECK(cuda{{1}}());`,
        blanks: [
          { answer: 'GetLastError' },
          { answer: 'DeviceSynchronize' }
        ],
        ci: false
      },
      hints: [
        'Ошибка запуска — cudaGetLastError().',
        'Ошибка исполнения — cudaDeviceSynchronize().'
      ],
      solution: ['GetLastError', 'DeviceSynchronize']
    },

    {
      id: 'cuda-6',
      title: 'Гриды 2D',
      goal: 'Индексация двумерных данных: изображения и матрицы',
      xp: 50,
      theory: [
        { t: 'p', html: 'Для 2D-данных (изображения!) гриды тоже 2D: <code>dim3 threads(16, 16)</code> — блок 16×16 = 256 потоков, <code>dim3 blocks((w+15)/16, (h+15)/16)</code>. Индекс: <code>x = blockIdx.x * blockDim.x + threadIdx.x</code>, аналогично y. Линейный индекс в памяти: <code>y * width + x</code>.' },
        { t: 'code', code: `__global__ void grayscale(const unsigned char *rgb,
                          unsigned char *gray, int w, int h) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;
    if (x < w && y < h) {
        int idx = y * w + x;         // пиксель (x, y)
        float r = rgb[3 * idx], g = rgb[3*idx + 1], b = rgb[3*idx + 2];
        gray[idx] = 0.299f * r + 0.587f * g + 0.114f * b;
    }
}

dim3 threads(16, 16);
dim3 blocks((w + 15) / 16, (h + 15) / 16);
grayscale<<<blocks, threads>>>(d_rgb, d_gray, w, h);` },
        { t: 'p', html: 'Формула серого 0.299R + 0.587G + 0.114B — человеческое восприятие яркости. Каждый пиксель — независимый поток: идеальный параллелизм. 4K-изображение = 8.3 млн потоков, GPU прожуёт за доли секунды.' },
        { t: 'note', html: 'Порядок обхода влияет на скорость: соседние потоки должны читать соседнюю память (coalescing). idx = y*w + x даёт соседям по x соседние адреса — память читается широкой шиной, а не по одному байту.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери 2D-индексацию и линейный адрес пикселя.</p>',
        code: `int x = blockIdx.x * blockDim.x + threadIdx.x;
int y = blockIdx.{{0}} * blockDim.{{1}} + threadIdx.{{2}};
int idx = y * w + {{3}};`,
        blanks: [
          { answer: 'y' },
          { answer: 'y' },
          { answer: 'y' },
          { answer: 'x' }
        ],
        ci: false
      },
      hints: [
        'Вторая ось — .y у всех трёх структур.',
        'Строка за строкой: y * width + x.'
      ],
      solution: ['y', 'y', 'y', 'x']
    },

    {
      id: 'cuda-7',
      title: 'Shared memory',
      goal: 'Использовать быструю память блока',
      xp: 50,
      theory: [
        { t: 'p', html: 'Внутри блока живёт <b>shared memory</b> — SRAM в кристалле, в ~100 раз быстрее глобальной. Объявление: <code>__shared__ float cache[256];</code> — общая для всего блока. Синхронизация потоков блока — <code>__syncthreads();</code>.' },
        { t: 'code', code: `__global__ void sumReduce(const float *in, float *out, int n) {
    __shared__ float cache[256];

    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int tid = threadIdx.x;

    cache[tid] = (i < n) ? in[i] : 0.0f;
    __syncthreads();               // кэш заполнен!

    // древовидное суммирование
    for (int s = blockDim.x / 2; s > 0; s >>= 1) {
        if (tid < s) cache[tid] += cache[tid + s];
        __syncthreads();
    }

    if (tid == 0) out[blockIdx.x] = cache[0];
}` },
        { t: 'p', html: 'Классическая <b>редукция</b>: блок суммирует свои 256 элементов в cache, древовидно сжимает (128+128, 64+64…) и поток 0 пишет результат блока. Затем CPU (или второе ядро) суммирует результаты блоков —两级 редукция.' },
        { t: 'note', html: '__syncthreads() — барьер: без него половина потоков читает недозаполненный кэш. Пропущенный барьер — ошибка №1 shared-кода; гонки данных в GPU не ловятся отладчиком легко.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что произойдёт, если убрать __syncthreads() перед древовидным суммированием?</p>',
        options: [
          `Ничего, код работает`,
          `Потоки прочитают незаполненный кэш — гонка`,
          `Ядро не скомпилируется`,
          `Кэш очистится`
        ],
        correct: 1,
        explain: 'Без барьера быстрые потоки начнут свёртку, пока медленные ещё пишут в cache — гонка данных и неверный результат. __syncthreads() гарантирует: все записи завершены до чтения.'
      },
      hints: [
        'Потоки блока асинхронны.',
        'Кто-то ещё пишет, кто-то уже читает.'
      ],
      solution: `Потоки прочитают незаполненный кэш — гонка`
    },

    {
      id: 'cuda-8',
      title: 'Unified и pinned память',
      goal: 'Разбираться в типах памяти: pinned, unified, streams',
      xp: 55,
      theory: [
        { t: 'p', html: 'Обычный malloc + копии медленные. <code>cudaMallocHost</code> (pinned — странично-закреплённая) ускоряет копирование в разы. <code>cudaMallocManaged</code> — unified memory: указатель виден и CPU, и GPU, миграция страниц автоматична. <code>cudaStream_t</code> — потоки исполнения для перекрытия копирования и вычислений.' },
        { t: 'code', code: `// pinned: быстрые копии
float *h_a;
cudaMallocHost(&h_a, bytes);   // вместо malloc

// unified: одна память для всех
float *u_x;
cudaMallocManaged(&u_x, bytes);
u_x[0] = 1.0f;                 // пишет CPU
kernel<<<...>>>(u_x);          // читает GPU — миграция сама

// stream: перекрытие
cudaStream_t s1, s2;
cudaStreamCreate(&s1);
cudaMemcpyAsync(d_a, h_a, bytes, cudaMemcpyHostToDevice, s1);
kernel<<<blocks, threads, 0, s1>>>(d_a);` },
        { t: 'p', html: 'Асинхронные вызовы с суффиксом Async работают со stream: копирование данных для следующего ядра перекрывается вычислением текущего — конвейер. Профиль производительности: pinned + streams — стандарт высоконагруженных пайплайнов.' },
        { t: 'note', html: 'Unified memory чудо-удобна для прототипов, но скрытые миграции страниц замедляют горячие циклы. Правило: прототип на unified, продакшн — на явных копиях pinned-памяти.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Создай stream, выполни асинхронную копию в нём и запусти ядро в том же stream.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Stream создан', all: ['cudaStreamCreate\\s*\\(\\s*&\\s*\\w+\\s*\\)'] },
          { desc: 'Асинхронная копия со stream', all: ['cudaMemcpyAsync\\s*\\([^)]*,\\s*\\w+\\s*\\)'] },
          { desc: 'Ядро со stream-конфигурацией', all: ['<<<\\s*\\w+\\s*,\\s*\\w+\\s*,\\s*0\\s*,\\s*\\w+\\s*>>>'] }
        ],
        note: 'cudaStreamCreate(&s); / cudaMemcpyAsync(d, h, bytes, cudaMemcpyHostToDevice, s); / k<<<b, t, 0, s>>>(d);'
      },
      hints: [
        'Async-копия принимает stream последним аргументом.',
        'Ядро: <<<блоки, потоки, shm, stream>>>'
      ],
      solution: `cudaStream_t s;
cudaStreamCreate(&s);
cudaMemcpyAsync(d_a, h_a, bytes, cudaMemcpyHostToDevice, s);
kernel<<<blocks, threads, 0, s>>>(d_a);`
    },

    {
      id: 'cuda-9',
      title: 'Иерархия потоков и occupancy',
      goal: 'Выбирать размеры блоков и понимать warp',
      xp: 55,
      theory: [
        { t: 'p', html: 'Минимальная единица исполнения — <b>warp</b>: 32 потока, шагающие синхронно. Размер блока кратен 32 (обычно 128/256/512). <code>cudaGetDeviceProperties</code> даёт лимиты: максимум потоков в блоке (обычно 1024), количество SM. <b>Occupancy</b> — доля занятых слотов warp-ов.' },
        { t: 'code', code: `cudaDeviceProp prop;
cudaGetDeviceProperties(&prop, 0);
printf("SM: %d, max threads/block: %d\\n",
       prop.multiProcessorCount, prop.maxThreadsPerBlock);

// выбор размера:
int threads = 256;                       // 8 warps
int blocks = (n + threads - 1) / threads;
kernel<<<blocks, threads>>>(...);

// 1D-грид на весь диапазон (современный тренд):
kernel<<<(n + 255) / 256, 256>>>(...);` },
        { t: 'p', html: 'Почему 256? Баланс: больше потоков в блоке — больше shared-памяти на блок и выше occupancy, но меньше блоков на SM. Ветвления внутри warp замедляют: if, разделяющий warp пополам, сериализует обе ветки — <b>warp divergence</b>.' },
        { t: 'list', items: [
          '<b>warp = 32 потока</b> — атомарная единица SIMT;',
          'блоки кратно 32;',
          '&lt;= 1024 потоков на блок;',
          'divergence: одинаковые ветви внутри warp.'
        ] },
        { t: 'note', html: 'Рецепт оптимизации: nsys/ncu (профайлеры NVIDIA) → смотреть occupancy, memory throughput, divergence. GPU-инженер differ от случайного человека именно этим: код на CUDA пишется за час, ускоряется — за месяц.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Сколько потоков в одном warp?</p>',
        options: [
          `8`,
          `32`,
          `256`,
          `1024`
        ],
        correct: 1,
        explain: 'Warp — 32 потока, минимальная синхронно исполняемая единица на всех архитектурах NVIDIA. Поэтому размеры блоков кратны 32.'
      },
      hints: [
        'Атомарность исполнения GPU.',
        'Половина от 64.'
      ],
      solution: `32`
    },

    {
      id: 'cuda-10',
      title: 'Проект: параллельная стата',
      goal: 'Собрать конвейер: память, ядро, редукция, проверка',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финальный проект — параллельная статистика массива: копируем данные, ядро редукции считает сумму блоков, CPU агрегирует. Полный цикл CUDA-разработки: alloc → H2D → kernel → D2H → check → free. Так выглядят первые шаги каждой GPU-библиотеки.' },
        { t: 'code', code: `int main() {
    int n = 1 << 20;                     // 1M элементов
    size_t bytes = n * sizeof(float);

    float *h_x = (float*)malloc(bytes);
    for (int i = 0; i < n; i++) h_x[i] = 1.0f;

    float *d_x, *d_part;
    CUDA_CHECK(cudaMalloc(&d_x, bytes));
    CUDA_CHECK(cudaMalloc(&d_part, 4096 * sizeof(float)));
    CUDA_CHECK(cudaMemcpy(d_x, h_x, bytes, cudaMemcpyHostToDevice));

    int threads = 256;
    int blocks = (n + threads - 1) / threads;
    sumReduce<<<blocks, threads>>>(d_x, d_part, n);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());

    float parts[4096];
    CUDA_CHECK(cudaMemcpy(parts, d_part, blocks * sizeof(float),
               cudaMemcpyDeviceToHost));

    double total = 0;
    for (int i = 0; i < blocks; i++) total += parts[i];
    printf("Сумма: %f\\n", total);

    cudaFree(d_x); cudaFree(d_part); free(h_x);
    return 0;
}` },
        { t: 'list', items: [
          '<b>alloc + H2D</b> — данные на GPU;',
          '<b>ядро-редукция</b> — суммы блоков;',
          '<b>синхронизация + D2H</b> — забрать результат;',
          '<b>финальный шаг CPU</b> — сложить части;',
          '<b>free всего</b> — дисциплина памяти.'
        ] },
        { t: 'note', html: 'Ускорь проект: замени два уровня на один через atomicAdd, затем сравни время с cub::Reduce или thrust::reduce — готовыми библиотеками NVIDIA. Путь от «vector add на 30 строк» до понимания, почему cuBLAS в сто раз быстрее твоего кода, — и есть путь GPU-инженера: он начинается именно с этого проекта.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь этапы конвейера в main.</p>',
        code: `CUDA_CHECK(cuda{{0}}(&d_x, bytes));          // выделить
CUDA_CHECK(cudaMemcpy(d_x, h_x, bytes, cudaMemcpy{{1}}));
sumReduce<<<blocks, threads>>>(d_x, d_part, n);
CUDA_CHECK(cuda{{2}}());                      // ждать
CUDA_CHECK(cudaMemcpy(parts, d_part, bytes2, cudaMemcpy{{3}}));`,
        blanks: [
          { answer: 'Malloc' },
          { answer: 'HostToDevice' },
          { answer: 'DeviceSynchronize' },
          { answer: 'DeviceToHost' }
        ],
        ci: false
      },
      hints: [
        'Выделение — cudaMalloc.',
        'Туда — HostToDevice, ждать — DeviceSynchronize, обратно — DeviceToHost.'
      ],
      solution: ['Malloc', 'HostToDevice', 'DeviceSynchronize', 'DeviceToHost']
    }
  ]
};
