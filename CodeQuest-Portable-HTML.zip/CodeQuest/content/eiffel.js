'use strict';
/* ============ CodeQuest — курс Eiffel ============
   Eiffel не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами
   и заполнением пропусков.
=================================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.eiffel = {
  id: 'eiffel',
  title: 'Eiffel',
  emoji: '🗼',
  color: '#e0a832',
  lang: 'eiffel',
  tagline: 'Design by Contract за 6 уровней',
  description: 'Язык Бертрана Мейера (1985), колыбель Design by Contract: каждый класс несёт контракт из предусловий, постусловий и инвариантов. За 6 уровней дойдём от каркаса HELLO до проекта «Банковский счёт»: фичи, Result, create, наследование с redefine и Precursor.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'eiffel-1',
      title: 'Первая программа',
      goal: 'Собрать каркас класса HELLO: create-процедуру make, feature-секцию и вывод через print',
      xp: 30,
      theory: [
        { t: 'p', html: 'Eiffel создал Бертран Мейер в 1985 году, а его компания Interactive Software Engineering (ныне Eiffel Software) развила язык в целую экосистему с IDE EiffelStudio. Книга Мейера Object-Oriented Software Construction стала одним из главных текстов про объектно-ориентированное проектирование. Именно из Eiffel мир получил Design by Contract — программирование по контракту, а также популяризированный Мейером открыто-закрытый принцип. Язык стандартизован как ECMA-366 и до сих пор работает в критичных системах: финансовые, медицинские, оборонные.' },
        { t: 'h', html: 'Каркас класса' },
        { t: 'code', code: `class
    HELLO

create
    make

feature
    make
        do
            print ("Привет, CodeQuest!%N")
        end

end` },
        { t: 'p', html: 'В Eiffel всё — классы, и их имена принято писать заглавными буквами: <code>HELLO</code>. Секция <code>create</code> называет процедуру создания — что-то вроде конструктора. Все возможности класса объявляются внутри <code>feature</code>: процедуры с телом <code>do ... end</code> и функции с результатом. Печать делает <code>print</code>, унаследованный от всеобщего предка ANY, а <code>%N</code> — перенос строки внутри строковых литералов.' },
        { t: 'list', items: [
          '<b>class ИМЯ ... end</b> — класс;',
          '<b>create make</b> — назначение процедуры создания;',
          '<b>feature</b> — секция возможностей класса;',
          '<b>do ... end</b> — тело процедуры;',
          '<b>print ("текст%N")</b> — вывод, %N — перенос строки.'
        ] },
        { t: 'p', html: 'Структура класса вертикальная и очень ровная: имя, создание, фичи, конец. Каждое слово конструкции пишется на своей строке с отступом — так код Eiffel узнаётся с первого взгляда. Форма <code>do ... end</code> закрывает тело процедуры так же, как <code>end</code> закрывает весь класс.' },
        { t: 'warn', html: 'Комментарии начинаются с двух дефисов: <code>-- пояснение</code>. Ключевые слова нечувствительны к регистру, но классы капсом — это традиция, без которой код выглядит чужим. Точка с запятой между инструкциями необязательна: перенос строки сам их разделяет.' },
        { t: 'note', html: 'Класс обычно живёт в файле с тем же именем: <code>hello.e</code> содержит <code>HELLO</code>. Система собирается по описанию проекта <code>.ecf</code>, а точку входа назначают в его настройках.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Каркас почти готов — в теле процедуры <code>make</code> выведи строку «Привет, CodeQuest!» с переносом <code>%N</code> в конце и убери заглушку.</p>',
        starter: `class
    HELLO

create
    make

feature
    make
        do
            -- TODO: выведи приветствие
        end

end`,
        rules: [
          { desc: 'Объявлен класс HELLO', all: ['\\bclass\\s+HELLO\\b'] },
          { desc: 'Процедура создания назначена: create make', all: ['\\bcreate\\s+make\\b'] },
          { desc: 'Есть feature-секция с процедурой make', all: ['\\bfeature\\b[\\s\\S]*\\bmake\\b'] },
          { desc: 'Тело процедуры заключено в do ... end', all: ['\\bdo\\b[\\s\\S]*\\bend\\b'] },
          { desc: 'Вывод через print со строкой', all: ['print\\s*\\(\\s*"[^"]+"\\s*\\)'] },
          { desc: 'Строка заканчивается переносом %N', all: ['%N'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Форма вызова: print ("текст") — со скобками и кавычками.',
        'Перенос строки в Eiffel — это %N внутри строки.',
        'Заголовок класса и create уже на месте — работай только в теле make.'
      ],
      solution: `class
    HELLO

create
    make

feature
    make
        do
            print ("Привет, CodeQuest!%N")
            print ("Это первая программа на Eiffel.%N")
        end

end`
    },

    /* ---------- 2. Фичи и locals ---------- */
    {
      id: 'eiffel-2',
      title: 'Фичи и locals',
      goal: 'Писать функции с Result и процедуры с локальными переменными в блоке local',
      xp: 35,
      theory: [
        { t: 'p', html: 'Возможности класса в Eiffel называются фичами (features). Процедура меняет состояние и не возвращает значения, функция — вычисляет результат. Присваивание пишется через <code>:=</code>, а объявление локальных переменных живёт в блоке <code>local</code> перед телом <code>do</code>. Всё это выглядит суше, чем в большинстве языков, зато читается однозначно.' },
        { t: 'code', code: `    double (n: INTEGER): INTEGER
        do
            Result := n * 2
        end` },
        { t: 'p', html: 'Функция возвращает результат через специальную сущность <code>Result</code>: её можно читать и присваивать, отдельного <code>return</code> в языке нет. До первого присваивания Result равен нулевому значению типа: ноль для чисел, <code>Void</code> для ссылок. Тип результата указывается после двоеточия в сигнатуре.' },
        { t: 'code', code: `    sum_to (n: INTEGER): INTEGER
        local
            i: INTEGER
        do
            from i := 1 until i > n loop
                Result := Result + i
                i := i + 1
            end
        end` },
        { t: 'p', html: 'Локалы объявляются по одному на строку: имя, двоеточие, тип. Цикл здесь в фирменном стиле: слово <code>from</code> задаёт инициализацию, <code>until</code> — условие выхода, <code>loop</code> — тело. Из этого кода видно и правило Eiffel: параметры менять нельзя, они read-only, поэтому счётчик живёт в local.' },
        { t: 'list', items: [
          '<b>local ... do ... end</b> — локалы и тело процедуры;',
          '<b>x := 5</b> — присваивание;',
          '<b>Result</b> — возвращаемое значение функции;',
          '<b>from ... until ... loop ... end</b> — классический цикл;',
          '<b>-- комментарий</b> — пояснение до конца строки.'
        ] },
        { t: 'warn', html: 'Привычка искать <code>return</code> здесь не работает: функция возвращает только через Result. Забыл присвоить — вернётся ноль или Void, и компилятор не спасёт от логической ошибки. Проверяй результат постусловием — об этом следующий уровень.' },
        { t: 'note', html: 'Фичи со словом <code>once</code> выполняются один раз за жизнь программы — встроенный синглтон: <code>once config: STRING do Result := "настройки" end</code>. Пригодится, когда дойдёшь до общих ресурсов.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Восстанови фичи: блок локалов, начало тела, возврат через специальную переменную и тип результата функции.</p>',
        code: `class
    COUNTER

create
    make

feature
    make
        {{1}}
            i: INTEGER
        {{2}}
            from i := 1 until i > 3 loop
                i := i + 1
            end
            print (i)
        end

    double (n: INTEGER): {{3}}
        do
            {{4}} := n * 2
        end

end`,
        blanks: [
          { answer: 'local' },
          { answer: 'do' },
          { answer: 'Result' },
          { answer: 'INTEGER' }
        ]
      },
      hints: [
        'Локалы объявляются в блоке перед телом процедуры.',
        'Тело начинается словом do и кончается end.',
        'Функция возвращает через Result, а её тип — INTEGER.'
      ],
      solution: ['local', 'do', 'Result', 'INTEGER']
    },

    /* ---------- 3. Контракты: require/ensure ---------- */
    {
      id: 'eiffel-3',
      title: 'Контракты: require/ensure',
      goal: 'Добавить фиче контракт: предусловие require, постусловие ensure и сравнение через old',
      xp: 40,
      theory: [
        { t: 'p', html: 'Design by Contract — главная идея Eiffel, и звучит она как юридическая метафора. Клиент, вызывающий фичу, обязан выполнить предусловия <code>require</code>; поставщик — сама фича — гарантирует постусловия <code>ensure</code>. Если контракт нарушен, возникает исключение, и виновника видно сразу: предусловие — ошибка клиента, постусловие — баг поставщика. Это превращает отладку в разбор чётких соглашений.' },
        { t: 'code', code: `class
    HEATER

feature
    temperature: REAL

    warm_up (delta: REAL)
        require
            positive: delta > 0
        do
            temperature := temperature + delta
        ensure
            increased: temperature > old temperature
        end

end` },
        { t: 'p', html: 'Условия снабжаются метками: <code>positive: delta > 0</code> — метка попадёт в сообщение об ошибке и объяснит, что именно нарушили. Условий может быть сколько угодно — они перечисляются строка за строкой. Выражение <code>old temperature</code> в постусловии обозначает значение на входе, что позволяет сравнить «до» и «после».' },
        { t: 'list', items: [
          '<b>require</b> — предусловия, обязательства клиента;',
          '<b>ensure</b> — постусловия, гарантии поставщика;',
          '<b>old x</b> — значение x до выполнения фичи;',
          '<b>метка: условие</b> — имя для сообщения об ошибке;',
          '<b>invariant</b> — инвариант класса (появится в проекте).'
        ] },
        { t: 'p', html: 'Контракты проверяются во время выполнения, и EiffelStudio позволяет включать их по отдельности: только предусловия или всё сразу. В релизной сборке проверки отключают ради скорости, но при разработке они работают как непрерывный тест-драйв каждого вызова. Хороший контракт короче, чем комментарий «не вызывай с отрицательным числом», и куда строже.' },
        { t: 'warn', html: 'Предусловие не обязывает тебя проверять аргументы внутри тела — проверку берёт на себя контракт. Но не путай: require не «чинит» плохие данные, он честно падает и указывает на нарушителя. Падение в правильном месте — это фича, а не баг.' },
        { t: 'note', html: 'Наследование и контракты связаны железно: потомок может ослабить предусловие и усилить постусловие, но не наоборот. Так система защищает всех, кто полагался на поведение родителя.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Добавь процедуре <code>warm_up</code> контракт: предусловие с меткой о положительности шага и постусловие, которое сравнивает температуру с прежней через <code>old</code>.</p>',
        starter: `class
    HEATER

feature
    temperature: REAL

    warm_up (delta: REAL)
        -- TODO: добавь предусловие и постусловие
        do
            temperature := temperature + delta
        end

end`,
        rules: [
          { desc: 'Поле temperature: REAL объявлено', all: ['temperature\\s*:\\s*REAL'] },
          { desc: 'Процедура warm_up принимает аргумент REAL', all: ['\\bwarm_up\\s*\\(\\s*\\w+\\s*:\\s*REAL\\s*\\)'] },
          { desc: 'Есть блок require с меткой positive', all: ['\\brequire\\b', '\\bpositive\\s*:'] },
          { desc: 'Предусловие проверяет положительность аргумента', all: ['\\w+\\s*>\\s*0'] },
          { desc: 'Есть блок ensure с меткой', all: ['\\bensure\\b', '\\b\\w+\\s*:'] },
          { desc: 'Постусловие сравнивает с old temperature', all: ['\\bold\\s+temperature\\b'] },
          { desc: 'Тело меняет поле через :=', all: ['temperature\\s*:=\\s*temperature\\s*\\+\\s*\\w+'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Между сигнатурой и do вставь require с меткой: positive: delta > 0',
        'После тела, перед end, добавь ensure: increased: temperature > old temperature',
        'Метки — произвольные имена, но они попадут в сообщение об ошибке.'
      ],
      solution: `class
    HEATER

feature
    temperature: REAL

    warm_up (delta: REAL)
        require
            positive: delta > 0
        do
            temperature := temperature + delta
        ensure
            increased: temperature > old temperature
        end

end`
    },

    /* ---------- 4. Классы и create ---------- */
    {
      id: 'eiffel-4',
      title: 'Классы и create',
      goal: 'Создать класс с конструктором-аргументами и использовать create p.make (...) в другом классе',
      xp: 45,
      theory: [
        { t: 'p', html: 'Создание объекта в Eiffel двухшаговое: сначала объявляется переменная-ссылка, затем выполняется инструкция создания <code>create p.make (3, 4)</code>. Процедуры, перечисленные в секции <code>create</code>, — это конструкторы; их может быть несколько с разными наборами аргументов. До создания ссылка равна <code>Void</code>, и система Void-safety следит, чтобы ты не разыменовал пустую ссылку.' },
        { t: 'code', code: `class
    POINT

create
    make

feature
    x: INTEGER
    y: INTEGER

    make (a_x: INTEGER; a_y: INTEGER)
        do
            x := a_x
            y := a_y
        end

end` },
        { t: 'p', html: 'Поля объявляются прямо в feature — без слова var. Аргументы конструктора по традиции называют с префиксом <code>a_</code> (от argument), чтобы не спорить с именами полей. Точка с запятой разделяет аргументы; она необязательна, но делает сигнатуру нагляднее.' },
        { t: 'code', code: `class
    APPLICATION

create
    make

feature
    make
        local
            p: POINT
        do
            create p.make (3, 4)
            print (p.x)
        end

end` },
        { t: 'p', html: 'В процедуре <code>make</code> другого класса объявлена локальная переменная <code>p: POINT</code>, и только потом создан объект. Вызов <code>create p.make (3, 4)</code> — единая инструкция: выдели память, назначь процедуру, передай аргументы. После этого к полям и фичам обращаются через точку.' },
        { t: 'list', items: [
          '<b>create p.make (3, 4)</b> — создание с конструктором;',
          '<b>feature {NONE}</b> — секция, скрытая от клиентов класса;',
          'несколько конструкторов: <b>create make, create default</b>;',
          '<b>Void</b> — «ссылки нет» до создания.'
        ] },
        { t: 'warn', html: 'Не пытайся вызвать make как обычную процедуру на пустой ссылке — без <code>create</code> это не создание. И не забудь перечислить все аргументы: <code>create p.make (3, 4)</code> с одним числом не скомпилируется.' },
        { t: 'note', html: 'Хитрость: make может лежать в <code>feature {NONE}</code> и всё равно использоваться клиентами — секция create переоткрывает её для создания. Так сделано в стандартной библиотеке Eiffel.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Класс <code>POINT</code> готов — допиши второй класс: создание точки инструкцией <code>create p.make (...)</code> с двумя координатами и печать поля созданного объекта.</p>',
        starter: `class
    POINT

create
    make

feature
    x: INTEGER
    y: INTEGER

    make (a_x: INTEGER; a_y: INTEGER)
        do
            x := a_x
            y := a_y
        end

end

class
    APPLICATION

create
    make

feature
    make
        local
            p: POINT
        do
            -- TODO: создай точку и напечатай её координату
        end

end`,
        rules: [
          { desc: 'Класс POINT с полями x и y типа INTEGER', all: ['\\bclass\\s+POINT\\b', '\\bx\\s*:\\s*INTEGER', '\\by\\s*:\\s*INTEGER'] },
          { desc: 'create назначает make', all: ['\\bcreate\\s+make\\b'] },
          { desc: 'make принимает два аргумента INTEGER через точку с запятой', all: ['\\bmake\\s*\\(\\s*\\w+\\s*:\\s*INTEGER\\s*;\\s*\\w+\\s*:\\s*INTEGER\\s*\\)'] },
          { desc: 'Второй класс APPLICATION объявлен', all: ['\\bclass\\s+APPLICATION\\b'] },
          { desc: 'Локальная переменная типа POINT объявлена', all: ['\\w+\\s*:\\s*POINT\\b'] },
          { desc: 'Объект создан инструкцией create p.make (...) с двумя аргументами', all: ['\\bcreate\\s+\\w+\\.make\\s*\\([^)]*,[^)]*\\)'] },
          { desc: 'Поле созданного объекта напечатано', all: ['print\\s*\\(\\s*\\w+\\.'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Внутри do: create p.make (3, 4)',
        'Печать поля: print (p.x)',
        'Локал уже объявлен — переменная p ждёт создания.'
      ],
      solution: `class
    POINT

create
    make

feature
    x: INTEGER
    y: INTEGER

    make (a_x: INTEGER; a_y: INTEGER)
        do
            x := a_x
            y := a_y
        end

end

class
    APPLICATION

create
    make

feature
    make
        local
            p: POINT
        do
            create p.make (3, 4)
            print (p.x)
        end

end`
    },

    /* ---------- 5. Наследование и redefine ---------- */
    {
      id: 'eiffel-5',
      title: 'Наследование и redefine',
      goal: 'Понять наследование: секция inherit, обязательный redefine и вызов родителя через Precursor',
      xp: 50,
      theory: [
        { t: 'p', html: 'Наследование объявляется секцией <code>inherit</code>: класс получает все фичи родителя. Если потомок переопределяет фичу, это фиксируется явно: <code>redefine имя end</code> внутри inherit. Молчаливое переопределение запрещено — компилятор поймает коллизию и потребует честного объявления. Вызов родительской версии из переопределённой — через <code>Precursor</code>.' },
        { t: 'code', code: `class
    SHAPE

feature
    area: REAL
        do
            Result := 0
        end

end

class
    SQUARE

inherit
    SHAPE
        redefine area end

feature
    side: REAL

    area: REAL
        do
            Result := side * side
        end

end` },
        { t: 'p', html: 'В примере <code>SQUARE</code> переопределяет <code>area</code>: строка <code>redefine area end</code> — обязательная страховка. Если бы квадрат решил использовать формулу родителя и добавить надбавку, тело выглядело бы как <code>Result := Precursor + side</code>. Precursor вызывает версию именно того родителя, из чьей ветки пришла фича.' },
        { t: 'list', items: [
          '<b>inherit РОДИТЕЛЬ</b> — наследование;',
          '<b>redefine имя end</b> — объявление переопределения;',
          '<b>Precursor</b> — вызов родительской версии;',
          '<b>rename</b> — переименование унаследованной фичи;',
          'контракты: предусловие можно ослабить, постусловие — усилить.'
        ] },
        { t: 'warn', html: 'Забыл вписать фичу в redefine, но переписал её тело — компилятор сообщит о переопределении без объявления. И наоборот: вписал в redefine, но не дал новую реализацию, — тоже ошибка. Eiffel не оставляет щелей для неявного поведения.' },
        { t: 'note', html: 'Множественное наследование в Eiffel полноценное: класс может наследовать нескольких родителей, а конфликты имён решаются через rename. Это редкость среди мейнстрим-языков и одна из причин строгости контрактов.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Разработчик написал в потомке новую версию фичи <code>area</code> родительского класса SHAPE, но забыл про секцию <code>redefine</code> внутри <code>inherit</code>. Что произойдёт?</p>',
        options: [
          'Программа соберётся, но будет работать старая версия фичи',
          'Ошибка компиляции: переопределение фичи требует явного redefine',
          'Соберётся, а падение случится только при вызове фичи',
          'Компилятор молча добавит redefine и предупредит в логе'
        ],
        correct: 1,
        explain: 'В Eiffel переопределение должно быть объявлено явно: inherit SHAPE redefine area end. Без этой строки компилятор видит коллизию имён и останавливает сборку. Родительскую версию при этом вызывают через Precursor.',
        solution: 1
      },
      hints: [
        'Eiffel не любит молчаливые изменения унаследованного поведения.',
        'Секция inherit настраивает наследование: rename, redefine, export.',
        'Компилятор ловит такие вещи на этапе сборки, а не в рантайме.'
      ],
      solution: 1
    },

    /* ---------- 6. 🚀 Проект: банковский счёт ---------- */
    {
      id: 'eiffel-6',
      title: '🚀 Проект: банковский счёт',
      goal: 'Собрать класс ACCOUNT с контрактами: deposit/withdraw через require/ensure и old, инвариант баланса',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — банковский счёт с честным контрактом. Класс <code>ACCOUNT</code> хранит владельца и баланс, пополнение и снятие описаны предусловиями и постусловиями, а инвариант класса не даёт балансу уйти в минус. Это канонический пример из книг Мейера — и хорошая рабочая заготовка.' },
        { t: 'code', code: `class
    ACCOUNT

create
    make

feature {NONE}

    make (a_owner: STRING)
        do
            owner := a_owner
            balance := 0
        end

feature

    owner: STRING
    balance: INTEGER

    deposit (amount: INTEGER)
        require
            positive: amount > 0
        do
            balance := balance + amount
        ensure
            added: balance = old balance + amount
        end

    withdraw (amount: INTEGER)
        require
            positive: amount > 0
            enough: balance >= amount
        do
            balance := balance - amount
        ensure
            removed: balance = old balance - amount
        end

invariant
    non_negative: balance >= 0

end` },
        { t: 'p', html: 'Конструктор спрятан в <code>feature {NONE}</code> — секции, невидимой клиентам; секция create всё равно позволяет создавать объекты, так устроена стандартная библиотека Eiffel. У <code>withdraw</code> два предусловия: сумма положительна и средств хватает. Постусловия сверяют баланс со значением <code>old</code> — гарантия точности до копейки.' },
        { t: 'code', code: `class
    ACCOUNT_DEMO

create
    run

feature
    run
        local
            acc: ACCOUNT
        do
            create acc.make ("Ада")
            acc.deposit (500)
            acc.withdraw (150)
            print (acc.owner + ": " + acc.balance.out + "%N")
        end

end` },
        { t: 'p', html: 'Демонстрационный класс создаёт счёт, кладёт пятьсот, снимает сто пятьдесят и печатает остаток: <code>350</code>. Метод <code>out</code> превращает число в строку — он есть у любого значения. Попробуй снять больше, чем есть: исключение предусловия назовёт метку <code>enough</code> и сторону, нарушившую контракт.' },
        { t: 'list', items: [
          'шаг 1: класс ACCOUNT с create make и полями;',
          'шаг 2: deposit с require и ensure;',
          'шаг 3: withdraw с двумя предусловиями;',
          'шаг 4: инвариант non_negative для всего класса;',
          'шаг 5: демо-класс с созданием, пополнением и снятием.'
        ] },
        { t: 'warn', html: 'Инвариант проверяется после create и после каждого внешнего вызова фич: если баланс уйдёт в минус, падение произойдёт на границе класса. Это не дублирование require — инвариант защищает состояние всегда, а не один вызов.' },
        { t: 'note', html: 'Куда расти: добавь историю операций в массив, сделай <code>transfer</code> между счетами с двумя контрактами сразу и вынес ставку начисления в <code>once</code>-фичу.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери <code>ACCOUNT</code> по контракту: поля уже есть — добавь <code>deposit</code> и <code>withdraw</code> с require/ensure через <code>old</code> и инвариант неотрицательности баланса на уровне класса.</p>',
        starter: `class
    ACCOUNT

create
    make

feature {NONE}

    make (a_owner: STRING)
        do
            owner := a_owner
            balance := 0
        end

feature

    owner: STRING
    balance: INTEGER

    -- TODO: добавь deposit и withdraw с контрактами, затем инвариант класса

end`,
        rules: [
          { desc: 'Класс ACCOUNT с процедурой создания make', all: ['\\bclass\\s+ACCOUNT\\b', '\\bcreate\\s+make\\b'] },
          { desc: 'Поля owner:STRING и balance:INTEGER', all: ['owner\\s*:\\s*STRING', 'balance\\s*:\\s*INTEGER'] },
          { desc: 'deposit принимает INTEGER и имеет require с положительностью', all: ['\\bdeposit\\s*\\(\\s*\\w+\\s*:\\s*INTEGER\\s*\\)', '\\brequire\\b', '\\w+\\s*>\\s*0'] },
          { desc: 'Постусловие deposit сравнивает с old balance + amount', all: ['\\bensure\\b', '\\bold\\s+balance\\s*\\+\\s*\\w+'] },
          { desc: 'withdraw проверяет достаточность средств', all: ['\\bwithdraw\\s*\\(\\s*\\w+\\s*:\\s*INTEGER\\s*\\)', 'balance\\s*>=\\s*\\w+'] },
          { desc: 'Постусловие withdraw сравнивает с old balance минус сумма', all: ['\\bold\\s+balance\\s*-\\s*\\w+'] },
          { desc: 'Инвариант класса защищает неотрицательность баланса', all: ['\\binvariant\\b', 'balance\\s*>=\\s*0'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'deposit: require positive: amount > 0 ... ensure added: balance = old balance + amount',
        'withdraw добавляет второе предусловие: enough: balance >= amount',
        'Инвариант пишется на уровне класса: invariant non_negative: balance >= 0'
      ],
      solution: `class
    ACCOUNT

create
    make

feature {NONE}

    make (a_owner: STRING)
        do
            owner := a_owner
            balance := 0
        end

feature

    owner: STRING
    balance: INTEGER

    deposit (amount: INTEGER)
        require
            positive: amount > 0
        do
            balance := balance + amount
        ensure
            added: balance = old balance + amount
        end

    withdraw (amount: INTEGER)
        require
            positive: amount > 0
            enough: balance >= amount
        do
            balance := balance - amount
        ensure
            removed: balance = old balance - amount
        end

invariant
    non_negative: balance >= 0

end`
    }
  ],

  cheats: [
    { title: 'Каркас класса', code: `class
    HELLO
create
    make
feature
    make
        do
            print ("Привет!%N")
        end
end
-- комментарий до конца строки` },
    { title: 'Фичи и Result', code: `double (n: INTEGER): INTEGER
    do
        Result := n * 2
    end

sum_to (n: INTEGER): INTEGER
    local
        i: INTEGER
    do
        from i := 1 until i > n loop
            Result := Result + i
            i := i + 1
        end
    end` },
    { title: 'Контракты', code: `f (x: INTEGER): INTEGER
    require
        positive: x > 0
    do
        Result := x * 2
    ensure
        doubled: Result = old x * 2
    end

invariant
    balance >= 0` },
    { title: 'Классы и create', code: `create p.make (3, 4)     -- создание объекта
feature {NONE}           -- скрытая секция
Void                     -- «ссылки нет»
x.out                    -- число → строка
-- несколько create-процедур перечисляются под create` },
    { title: 'Наследование', code: `class SQUARE inherit
    SHAPE
        redefine area end
feature
    area: REAL
        do
            Result := Precursor + side
        end
end` },
    { title: 'Цикл и мелочи', code: `from i := 1 until i > 5 loop
    i := i + 1
end
-- %N перенос, %T табуляция
-- (x * x).abs, x.sqrt
-- print (s + "%N")` }
  ]
};
