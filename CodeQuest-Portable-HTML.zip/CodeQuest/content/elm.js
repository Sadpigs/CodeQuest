'use strict';
/* ============ CodeQuest — курс Elm ============
   Чистый функциональный язык для фронтенда. Код в приложении
   не запускается: задания проверяются структурным анализом
   (regex по сырому коду), квизами, «предскажи вывод» и fill.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.elm = {
  id: 'elm',
  title: 'Elm',
  emoji: '🌳',
  color: '#60b5cc',
  lang: 'elm',
  tagline: 'Elm Architecture: 10 уровней от модуля до TEA',
  description: 'Чистый функциональный язык для веб-интерфейсов, созданный Эваном Чаплицки (Evan Czaplicki) в 2012 году. Компилируется в JavaScript и обещает ни одного runtime-исключения; его архитектура Model-Update-View вдохновила Redux. За 10 уровней — от первого модуля до проекта «Список покупок» и модели счётчика TEA.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'elm-1',
      title: 'Первая программа',
      goal: 'Собрать каркас Elm-модуля: module с exposing, import Html и значение main',
      xp: 30,
      theory: [
        { t: 'p', html: 'Elm — чистый функциональный язык для веб-интерфейсов, созданный Эваном Чаплицки (Evan Czaplicki) в 2012 году как дипломная работа. Он компилируется в JavaScript, но обещает уникальное: ни одного runtime-исключения. Компилятор настолько строг, что если проект собрался — он работает. Идеи Elm легли в основу Redux и заметно повлияли на весь фронтенд.' },
        { t: 'h', html: 'Каркас модуля' },
        { t: 'code', code: `module Main exposing (main)

import Html exposing (text)

main =
    text "Hello, Elm!"` },
        { t: 'p', html: 'Первая строка объявляет модуль <code>Main</code> и в скобках <code>exposing</code> перечисляет, что видно снаружи, — здесь только значение <code>main</code>. <code>import Html exposing (text)</code> подключает библиотеку HTML и позволяет писать <code>text</code> без префикса. <code>main</code> — точка входа: то, что Elm нарисует на странице.' },
        { t: 'list', items: [
          '<b>module Main exposing (main)</b> — имя модуля и список экспорта;',
          '<b>import Html</b> — подключение библиотеки;',
          '<b>text "..."</b> — HTML-узел, отображающий текст;',
          '<b>main =</b> — точка входа: значение, которое попадёт на страницу.'
        ] },
        { t: 'note', html: 'Запуск: установи Elm (<code>npm install -g elm</code>), в папке проекта выполни <code>elm reactor</code> и открой localhost:8000 — он покажет файлы и запустит Main.elm прямо в браузере. Сборка в готовый JS — <code>elm make src/Main.elm</code>.' },
        { t: 'warn', html: 'Elm чувствителен к отступам: тело <code>main</code> пишется с отступом под знаком равенства, а ветки case — ещё правее. Строки — только в двойных кавычках, имена модулей — с большой буквы: Main, Html. Точка с запятой в Elm не нужна вовсе.' },
        { t: 'p', html: 'Почему нет runtime-ошибок? В Elm нет null, нет неявных преобразований типов, а все ветки кода компилятор обязан проверить. Ошибка, которую в JavaScript поймали бы пользователи, в Elm не даёт проекту собраться. К этому строгости нужно привыкнуть — дальше она станет твоим союзником.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первый Elm-модуль: каркас <code>module</code> и <code>import</code> уже дан — допиши значение <code>main</code> так, чтобы оно выводило <code>text "Hello, Elm!"</code>, и убери пометку-заглушку.</p>',
        starter: `module Main exposing (main)

import Html exposing (text)

main =
    -- TODO: выведи приветствие
    text ""`,
        rules: [
          { desc: 'Модуль объявлен с exposing', all: ['\\bmodule\\s+\\w+\\s+exposing\\s*\\('] },
          { desc: 'Модуль Html импортирован', all: ['\\bimport\\s+Html\\b'] },
          { desc: 'Есть привязка main =', all: ['\\bmain\\s*='] },
          { desc: 'main выводит text "Hello, Elm!"', all: ['text\\s+"Hello, Elm!"'] },
          { desc: 'Заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Строки module и import менять не нужно — они уже правильные.',
        'После main = с отступом напиши text "Hello, Elm!" — двойные кавычки обязательны.',
        'Фразу пиши точно: Hello, Elm! — с запятой и восклицательным знаком.'
      ],
      solution: `module Main exposing (main)

import Html exposing (text)

main =
    text "Hello, Elm!"`
    },

    /* ---------- 2. let и типы ---------- */
    {
      id: 'elm-2',
      title: 'let и типы',
      goal: 'Использовать let..in для локальных привязок и различать Int, Float, String, Bool',
      xp: 35,
      theory: [
        { t: 'p', html: 'В Elm нет переменных, которые меняются, — есть <b>привязки</b> (bindings): имя раз и навсегда указывает на значение. Локальные привязки оформляются выражением <code>let ... in</code>: между let и in объявляются имена, а после in стоит итоговое выражение, которое их использует.' },
        { t: 'code', code: `main =
    let
        price = 100
        count = 3
    in
    price * count` },
        { t: 'p', html: 'Тип можно указать явно аннотацией над определением: <code>age : Int</code>. Это не требование — Elm выводит типы сам, — но аннотации читаются как документация и ловят ошибки раньше компиляции. Аннотация пишется на строке выше определения.' },
        { t: 'table', head: ['Тип', 'Примеры', 'Запомни'], rows: [
          ['<code>Int</code>', '<code>1</code>, <code>-42</code>', 'целые; деление нацело — <code>//</code>'],
          ['<code>Float</code>', '<code>1.75</code>, <code>3.0</code>', 'дробные; деление — <code>/</code>'],
          ['<code>String</code>', '<code>"привет"</code>', 'только двойные кавычки'],
          ['<code>Bool</code>', '<code>True</code>, <code>False</code>', 'с большой буквы!']
        ] },
        { t: 'p', html: 'Ловушка для новичков: <code>1 + 1.5</code> не скомпилируется — Int и Float в Elm не смешиваются. Преобразуй явно: <code>toFloat 1</code>, <code>round 1.6</code>, <code>floor 1.9</code>. Это строгость ради надёжности: неожиданных округлений и переполнений не бывает.' },
        { t: 'warn', html: 'Логические значения — только <code>True</code> и <code>False</code>, с большой буквы: <code>true</code> компилятор не знает. И строки — только в двойных кавычках: одинарные в Elm зарезервированы для отдельных символов Char.' },
        { t: 'note', html: 'Конкатенация строк — два плюса: <code>"Привет, " ++ "мир"</code>. Числа в текст превращают <code>String.fromInt 42</code> и <code>String.fromFloat 1.75</code> — пригодится при выводе значений на страницу.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни аннотации типов в let-выражении: возраст — целое, рост — дробное, приветствие — строка, флаг — логическое. Пиши имена типов так, как их знает Elm.</p>',
        code: `module Main exposing (main)

import Html exposing (text)

main =
    let
        age : {{0}}
        age = 25

        height : {{1}}
        height = 1.75

        greeting : {{2}}
        greeting = "Привет, Elm!"

        isAdmin : {{3}}
        isAdmin = True
    in
    text greeting`,
        blanks: [
          { answer: 'Int' },
          { answer: 'Float' },
          { answer: 'String' },
          { answer: 'Bool' }
        ],
        ci: false
      },
      hints: [
        'Имена типов пишутся с большой буквы: Int, Float, String, Bool.',
        'Целые числа — Int, числа с точкой — Float.',
        'True/False живут в типе Bool, строки — String.'
      ],
      solution: ['Int', 'Float', 'String', 'Bool']
    },

    /* ---------- 3. if/then/else и case ---------- */
    {
      id: 'elm-3',
      title: 'if/then/else и case',
      goal: 'Писать выражения if/then/else с обязательным else и разбирать значения через case-of',
      xp: 40,
      theory: [
        { t: 'p', html: 'В Elm <code>if</code> — не инструкция, а <b>выражение</b>: оно возвращает значение. Поэтому у него всегда есть <code>else</code> — компилятор не позволит ветке «остаться пустой». Результат if можно сразу присвоить имени или передать в функцию.' },
        { t: 'code', code: `sign n =
    if n > 0 then
        "плюс"

    else
        "минус"` },
        { t: 'p', html: 'Для разбора вариантов есть <code>case ... of</code>: перечисляешь образцы, у каждого — стрелка и результат. Первый совпавший образец побеждает. Образец <code>_</code> (подчёркивание) — «всё остальное», его ставят последним, чтобы покрыть оставшиеся значения.' },
        { t: 'code', code: `word n =
    case n of
        0 ->
            "ноль"

        5 ->
            "пять"

        _ ->
            "много"` },
        { t: 'list', items: [
          '<b>if условие then A else B</b> — всегда возвращает значение;',
          '<b>case x of</b> — разбор по образцам, у каждого — стрелка -&gt;;',
          '<b>_</b> — образец-универсал, ставится последним;',
          '<b>++</b> — склейка строк;',
          '<b>/=</b> — «не равно» (да, именно так).'
        ] },
        { t: 'warn', html: 'Без <code>else</code> if не скомпилируется — Elm обязан знать результат в любом случае. И следи за отступами: тело ветки сдвигается правее, а <code>then</code> и <code>else</code> выравниваются по началу if.' },
        { t: 'note', html: 'Деление: <code>/</code> — дробное (Float), <code>//</code> — целочисленное (Int): <code>7 // 2</code> даст 3, а <code>7 / 2</code> — 3.5. Если компилятор спорит о типах — он всегда прав, просто подсказывает, где смешались Int и Float.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай программу и напиши, какой текст она выведет на страницу (без кавычек).</p>',
        code: `module Main exposing (main)

import Html exposing (text)

sign n =
    if n > 0 then
        "плюс"

    else
        "минус"


word n =
    case n of
        0 ->
            "ноль"

        5 ->
            "пять"

        _ ->
            "много"


main =
    text (sign 5 ++ " " ++ word 5)`,
        answer: `плюс пять`
      },
      hints: [
        'sign 5: проверка 5 > 0 истинна — какая строка вернётся?',
        'case 5: образец 0 не подходит, образец 5 — подходит.',
        '++ склеивает строки; между словами вставлен пробел " ".'
      ],
      solution: `плюс пять`
    },

    /* ---------- 4. Функции и Maybe ---------- */
    {
      id: 'elm-4',
      title: 'Функции и Maybe',
      goal: 'Объявлять функции с аннотациями типов и возвращать Maybe: Just или Nothing вместо null',
      xp: 45,
      theory: [
        { t: 'p', html: 'Функция — просто привязка: <code>add a b = a + b</code>. Параметры перечисляются через пробел, скобки не нужны. Вызов — тоже пробел: <code>add 2 3</code>. Здесь работает каррирование: функция от двух аргументов — это функция, возвращающая функцию; передашь один аргумент — получишь готовую частичную функцию.' },
        { t: 'p', html: 'Аннотация описывает типы через стрелки: <code>add : Int -&gt; Int -&gt; Int</code> — «от двух Int к Int». Аннотация не обязательна, но в настоящих проектах её ставят над каждой функцией верхнего уровня: она документирует код и ловит ошибки раньше всех.' },
        { t: 'code', code: `add : Int -> Int -> Int
add a b =
    a + b` },
        { t: 'p', html: 'Вместо null в Elm — тип <code>Maybe</code>. Значение «есть» — <code>Just x</code>, «нет» — <code>Nothing</code>. Компилятор заставит разобрать оба варианта, прежде чем использовать результат. Именно поэтому в Elm не бывает ошибок «у null нет свойств».' },
        { t: 'code', code: `safeDivide : Int -> Int -> Maybe Int
safeDivide a b =
    if b == 0 then
        Nothing

    else
        Just (a // b)` },
        { t: 'list', items: [
          '<b>Maybe a</b> — тип «значение или ничего»;',
          '<b>Just x</b> — значение есть;',
          '<b>Nothing</b> — значения нет;',
          '<b>case результата of Just/Nothing</b> — безопасно достать значение;',
          '<b>Maybe.withDefault 0 m</b> — запасное значение без case.'
        ] },
        { t: 'warn', html: 'Не пытайся «распаковать» Maybe силой — такой возможности просто нет. Компилятор потребует обработать Nothing: через case-of или Maybe.withDefault. Это не бюрократия, а защита от крашей в продакшене.' },
        { t: 'note', html: 'Целочисленное деление — <code>//</code>: в задании ниже <code>safeDivide 10 2</code> вернёт <code>Just 5</code>. А <code>String.fromInt</code> превратит Int в строку, чтобы показать число на странице.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви функцию <code>safeDivide</code>: аннотация с <code>Maybe Int</code>, определение с двумя параметрами, проверка деления на ноль — <code>Nothing</code>, иначе <code>Just (a // b)</code>. Разбери результат в <code>main</code> через case-of (или Maybe.withDefault) и выведи через <code>text</code>.</p>',
        starter: `module Main exposing (main)

import Html exposing (text)


-- TODO: объяви safeDivide с аннотацией и обработкой нуля


main =
    text "ждём деление"`,
        rules: [
          { desc: 'safeDivide: аннотация с Maybe и определение с двумя параметрами', all: ['safeDivide\\s*:\\s*[^\\n]*\\bMaybe\\b', '\\bsafeDivide\\s+\\w+\\s+\\w+\\s*='] },
          { desc: 'Есть проверка деления на ноль через if', all: ['\\bif\\s[^\\n]*(==\\s*0|0\\s*==)'] },
          { desc: 'Обе ветви: Just со значением и Nothing', all: ['\\bJust\\s*\\(', '\\bNothing\\b'] },
          { desc: 'Результат разбирается через case или Maybe.withDefault', any: ['\\bcase\\b', 'Maybe\\.withDefault'] },
          { desc: 'Вывод через text, заглушек TODO нет', all: ['\\btext\\b'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Аннотация: safeDivide : Int -> Int -> Maybe Int — на строке выше определения.',
        'Внутри: if b == 0 then Nothing else Just (a // b) — целочисленное деление это //.',
        'В main разбери результат: case safeDivide 10 2 of Just v -> ... / Nothing -> ...'
      ],
      solution: `module Main exposing (main)

import Html exposing (text)


safeDivide : Int -> Int -> Maybe Int
safeDivide a b =
    if b == 0 then
        Nothing

    else
        Just (a // b)


main =
    text
        (case safeDivide 10 2 of
            Just v ->
                String.fromInt v

            Nothing ->
                "делить нельзя"
        )`
    },

    /* ---------- 5. Списки и архитектура ---------- */
    {
      id: 'elm-5',
      title: 'Списки и архитектура',
      goal: 'Использовать List.map и List.filter и понять схему Model-Update-View — Elm Architecture',
      xp: 40,
      theory: [
        { t: 'p', html: 'Список — <code>[1, 2, 3]</code>: элементы через запятую, все одного типа. Главные инструменты — <code>List.map</code> и <code>List.filter</code>, и оба принимают функцию. Анонимная функция пишется как <code>\\x -&gt; x * 2</code>: обратный слэш, параметры, стрелка.' },
        { t: 'code', code: `doubled =
    List.map (\\x -> x * 2) [1, 2, 3]      -- [2, 4, 6]

adults =
    List.filter (\\p -> p.age >= 18) people` },
        { t: 'p', html: '<code>map</code> превращает каждый элемент, <code>filter</code> оставляет только те, для которых функция вернула True. Ещё полезны: <code>List.length</code>, <code>List.sum</code>, <code>List.sort</code>, <code>List.concat</code>. Списки однотипны: <code>[1, "a"]</code> — ошибка компиляции.' },
        { t: 'h', html: 'Elm Architecture' },
        { t: 'p', html: 'Приложения в Elm строятся по одной схеме — <b>Elm Architecture</b>: <b>Model</b> — всё состояние приложения (просто данные), <b>Update</b> — функция, которая по сообщению (Msg) возвращает новое состояние, <b>View</b> — функция, превращающая состояние в HTML. Всё состояние в одном месте, изменения — только через Update.' },
        { t: 'p', html: 'Схема настолько удачная, что фронтенд-мир её скопировал: Redux — прямой потомок Elm Architecture. Разница в том, что Elm реализует её силами компилятора, без библиотек и middleware, — поэтому и без runtime-ошибок.' },
        { t: 'list', items: [
          '<b>Model</b> — данные приложения;',
          '<b>Msg</b> — сообщение о событии (клик, ввод);',
          '<b>update : Msg -&gt; Model -&gt; Model</b> — новое состояние;',
          '<b>view : Model -&gt; Html Msg</b> — разметка;',
          '<b>Browser.sandbox</b> — простейший каркас для старта.'
        ] },
        { t: 'warn', html: 'В Elm нет циклов for и while — перебор всегда через map/filter/fold. Это непривычно после императивных языков, но именно так гарантируется чистота функций: одни и те же входные данные дают один и тот же результат.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что вернёт выражение <code>List.filter (\\n -&gt; n &gt; 2) [1, 2, 3, 4]</code>?</p>',
        options: [
          '[1, 2]',
          '[3, 4]',
          '[False, False, True, True]',
          '[1, 2, 3, 4]'
        ],
        correct: 1,
        explain: 'filter оставляет только элементы, для которых функция-предикат вернула True. \\n -> n > 2 истинно для 3 и 4 — результат [3, 4]. А [False, False, True, True] дал бы List.map: map превращает каждый элемент, filter отбирает.',
        solution: 1
      },
      hints: [
        'filter возвращает отфильтрованный список элементов, а не True/False.',
        'Предикат n > 2: перебери 1, 2, 3, 4 и отметь, кто проходит.',
        'map превращает элементы, filter — отбирает: не перепутай их роли.'
      ],
      solution: 1
    },

    /* ---------- 6. Проект: список покупок ---------- */
    {
      id: 'elm-6',
      title: '🚀 Проект: список покупок',
      goal: 'Создать тип записи через type alias, список товаров и функцию подсчёта количества',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальный проект — список покупок: тип записи <code>Item</code> с полями name и qty, список из нескольких товаров и функция <code>totalQty</code>, считающая суммарное количество. Запись (record) — аналог объекта: <code>{ name = "Хлеб", qty = 1 }</code>. Обрати внимание: в литерале записи — знак <b>=</b>, а в аннотации типа — двоеточие.' },
        { t: 'code', code: `type alias Item =
    { name : String, qty : Int }` },
        { t: 'p', html: '<code>type alias Item = ...</code> — псевдоним типа: теперь <code>Item</code> — синоним этой записи. Доступ к полю — через точку: <code>item.qty</code>, а сама точка с именем поля — готовая функция: <code>.qty</code> принимает запись и возвращает число.' },
        { t: 'p', html: 'Считаем количество: <code>List.map .qty items</code> превратит список записей в список чисел, <code>List.sum</code> сложит. Композиция мелких функций — фирменный стиль Elm: никаких циклов, только преобразования данных, каждое из которых легко проверить.' },
        { t: 'list', items: [
          '<b>type alias Item = { name : String, qty : Int }</b> — тип записи;',
          '<b>items = [ {...}, {...} ]</b> — список минимум из двух товаров;',
          '<b>totalQty : List Item -&gt; Int</b> — аннотация функции;',
          '<b>List.map .qty + List.sum</b> — путь к сумме;',
          '<b>text (String.fromInt ...)</b> — вывод числа на страницу.'
        ] },
        { t: 'note', html: 'После зачёта расширь модель: добавь поле price и посчитай общую стоимость, отсортируй список через <code>List.sortBy .qty</code>. Это уже почти модель настоящего приложения — оставалось бы добавить Update с сообщениями о кликах.' },
        { t: 'warn', html: 'Не путай <code>=</code> и <code>:</code>: в записи-литерале <code>{ name = "Хлеб" }</code>, в аннотации типа <code>{ name : String }</code>. Компилятор поймает перепутанные знаки, но лучше приучиться сразу. И не оставляй пометки-заглушки в финальном коде.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Список покупок».</b> Объяви тип <code>Item</code> через <code>type alias</code> с полями <code>name : String</code> и <code>qty : Int</code>. Создай список <code>items</code> минимум из двух записей. Напиши функцию <code>totalQty : List Item -&gt; Int</code> (аннотация + определение), которая через <code>List.map</code>/<code>List.sum</code> возвращает суммарное количество, и выведи результат в <code>main</code> через <code>text</code>.</p>',
        starter: `module Main exposing (main)

import Html exposing (text)


-- TODO: объяви тип Item, список items и функцию totalQty


main =
    text "TODO"`,
        rules: [
          { desc: 'Тип Item объявлен через type alias с полями name: String и qty: Int', all: ['\\btype\\s+alias\\s+Item\\s*=\\s*\\{', '\\bname\\s*:\\s*String', '\\bqty\\s*:\\s*Int'] },
          { desc: 'Список items содержит минимум две записи', all: ['\\bitems\\s*=\\s*\\[[^\\]]*\\{[^\\]]*\\{'] },
          { desc: 'Функция totalQty: аннотация с Item и определение', all: ['totalQty\\s*:\\s*[^\\n]*\\bItem\\b', '\\btotalQty\\s+\\w+\\s*='] },
          { desc: 'Подсчёт через List.map / List.sum / List.foldl', any: ['List\\.map', 'List\\.sum', 'List\\.foldl'] },
          { desc: 'totalQty вызывается, результат выводится через text', all: ['\\btext\\b'], any: ['totalQty\\s+items', 'totalQty\\s*\\(\\s*items\\s*\\)'] },
          { desc: 'Заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Тип: type alias Item = { name : String, qty : Int } — в литерале записи позже будет =, здесь двоеточия.',
        'Список: items = [ { name = "Хлеб", qty = 1 }, { name = "Молоко", qty = 2 } ].',
        'Функция: totalQty list = List.sum (List.map .qty list) — и вызови её в main.'
      ],
      solution: `module Main exposing (main)

import Html exposing (text)


type alias Item =
    { name : String, qty : Int }


items =
    [ { name = "Хлеб", qty = 1 }
    , { name = "Молоко", qty = 2 }
    , { name = "Сыр", qty = 3 }
    ]


totalQty : List Item -> Int
totalQty list =
    List.sum (List.map .qty list)


main =
    text ("Всего покупок: " ++ String.fromInt (totalQty items))`
    },

    /* ---------- 7. Records и обновление полей ---------- */
    {
      id: 'elm-7',
      title: 'Records и обновление полей',
      goal: 'Обновлять записи через { rec | field = ... } — создавать новую копию, не трогая старую',
      xp: 45,
      theory: [
        { t: 'p', html: 'Запись (record) — набор именованных полей в фигурных скобках. Тип описывается через <code>type alias</code>: в аннотации поля разделяются двоеточиями, в литерале — знаками равенства. Доступ к полю — через точку: <code>user.score</code>. Причём <code>.score</code> сама по себе — готовая функция: она принимает запись и возвращает значение поля.' },
        { t: 'code', code: `type alias User =
    { name : String, score : Int }

alice =
    { name = "Алиса", score = 10 }` },
        { t: 'p', html: 'Записи в Elm неизменяемы — как и всё остальное. Но переписывать все поля руками утомительно, поэтому есть короткий синтаксис <b>обновления записи</b>: <code>{ alice | score = 15 }</code>. Читается так: «возьми запись alice, замени в ней поле score, остальное оставь как было». На выходе — <b>новая</b> запись; старая остаётся нетронутой, и это можно проверить в коде.' },
        { t: 'code', code: `leveled =
    { alice | score = alice.score + 5 }

-- leveled: { name = "Алиса", score = 15 }
-- alice по-прежнему со score = 10` },
        { t: 'p', html: 'За вертикальной чертой можно обновить сразу несколько полей через запятую: <code>{ model | count = 0, label = "сброс" }</code>. Обновлять можно только существующие поля — добавить новое этим синтаксисом нельзя, компилятор не пропустит: набор полей записи фиксирован её типом.' },
        { t: 'list', items: [
          '<b>type alias X = { a : T }</b> — описание типа записи;',
          '<b>{ a = v }</b> — литерал: знак равенства;',
          '<b>{ rec | f = v }</b> — обновление: черта и равенство;',
          '<b>rec.f и .f</b> — доступ к полю и функция-аксессор;',
          '<b>{ rec | a = 1, b = 2 }</b> — несколько полей за раз.'
        ] },
        { t: 'warn', html: 'Не перепутай знаки: в литерале <code>{ name = "Аня" }</code> — равенство, в типе <code>{ name : String }</code> — двоеточие, в обновлении — черта <code>{ alice | score = 15 }</code>. Обновление несуществующего поля — ошибка компиляции, и это хорошо: опечатка в имени поля не пройдёт незамеченной.' },
        { t: 'note', html: 'Именно запись-обновление — сердце Elm Architecture: функция update получает старую модель и возвращает <code>{ model | count = model.count + 1 }</code>. Освоишь этот синтаксис — финальный уровень соберётся сам собой.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви тип <code>User</code> через <code>type alias</code> с полями <code>name : String</code> и <code>score : Int</code>. Создай запись <code>alice</code> с любым именем и числом очков. Построй запись <code>leveled</code> через синтаксис обновления <code>{ alice | score = ... }</code>, используя старое значение через точечный доступ. Результат выведи в <code>main</code> через <code>text</code>.</p>',
        starter: `module Main exposing (main)

import Html exposing (text)


-- TODO: объяви type alias User, запись alice и обновлённую запись leveled


main =
    text ""`,
        rules: [
          { desc: 'type alias User с полями name: String и score: Int', all: ['\\btype\\s+alias\\s+User\\s*=\\s*\\{', '\\bname\\s*:\\s*String', '\\bscore\\s*:\\s*Int'] },
          { desc: 'Создан литерал записи с name = "..." и числом очков', all: ['\\{\\s*name\\s*=\\s*"[^"]+"\\s*,\\s*score\\s*=\\s*\\d+\\s*\\}'] },
          { desc: 'Обновление записи через { ... | score = ... }', all: ['\\{\\s*\\w+\\s*\\|\\s*score\\s*='] },
          { desc: 'Новое значение строится из старого через точечный доступ', all: ['\\.score\\b'] },
          { desc: 'Результат выводится через text', all: ['\\btext\\b'] },
          { desc: 'Заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Тип: type alias User = { name : String, score : Int } — в аннотации двоеточия.',
        'Литерал: alice = { name = "Алиса", score = 10 } — в литерале знаки равенства.',
        'Обновление: leveled = { alice | score = alice.score + 5 } — черта отделяет обновляемые поля.'
      ],
      solution: `module Main exposing (main)

import Html exposing (text)


type alias User =
    { name : String, score : Int }


alice =
    { name = "Алиса", score = 10 }


leveled =
    { alice | score = alice.score + 5 }


main =
    text (leveled.name ++ " набрала: " ++ String.fromInt leveled.score)`
    },

    /* ---------- 8. Maybe и Result ---------- */
    {
      id: 'elm-8',
      title: 'Maybe и Result',
      goal: 'Различать Maybe (Just/Nothing) и Result (Ok/Err) и разбирать оба через case-of',
      xp: 50,
      theory: [
        { t: 'p', html: 'Тип <code>Maybe</code> уже встречался — «значение или ничего»: конструкторы <code>Just x</code> и <code>Nothing</code>. Его возвращают функции, которым значение может не достаться: <code>List.head []</code> вернёт <code>Nothing</code>, и <code>String.toInt "abc"</code> тоже — строка не число.' },
        { t: 'p', html: 'А как быть, когда важно <b>почему</b> не получилось? Для этого есть <code>Result</code>: успех — <code>Ok значение</code>, неудача — <code>Err сообщение</code>. Maybe отвечает «есть или нет», Result — «получилось или сломалось, и вот что именно сломалось». Ошибка в Err — полноценное значение: строка с описанием, код, что угодно.' },
        { t: 'code', code: `toScore : String -> Result String Int
toScore raw =
    case String.toInt raw of
        Nothing ->
            Err "это не число"

        Just n ->
            Ok n` },
        { t: 'p', html: 'Оба типа разбираются одним и тем же <code>case</code>: перечисляешь все конструкторы — и компилятор следит, чтобы ни один не забыть. Вложенность не страшна: значение типа <code>Result String (Maybe Int)</code> разбирается внешним case по Ok/Err, внутренним — по Just/Nothing.' },
        { t: 'list', items: [
          '<b>Maybe a</b>: <code>Just x</code> / <code>Nothing</code> — «есть или нет»;',
          '<b>Result e a</b>: <code>Ok x</code> / <code>Err e</code> — «успех или причина провала»;',
          '<b>String.toInt, List.head</b> — функции, возвращающие Maybe;',
          '<b>Maybe.withDefault 0 m</b> — запасное значение без case;',
          '<b>Result.withDefault</b> — то же для Result.'
        ] },
        { t: 'warn', html: 'Не путай уровни: <code>Nothing</code> — «значения нет вообще», а <code>Err "msg"</code> — «не вышло, вот причина». Функция, объявленная как Maybe, не может вернуть Err, и наоборот: типы разные, компилятор не даст смешать.' },
        { t: 'note', html: 'В настоящих Elm-приложениях Result приходит отовсюду: ответ HTTP-запроса, чтение localStorage, декодирование JSON (Json.Decode) — всё это Result. Привычка разбирать Ok/Err через case делает ошибки видимыми ещё до запуска.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни программу конструкторами <code>Just</code>, <code>Nothing</code>, <code>Ok</code> и <code>Err</code> — по смыслу каждого пропуска. В <code>firstOrZero</code> разбирается Maybe, в <code>toScore</code> и <code>main</code> — Result.</p>',
        code: `module Main exposing (main)

import Html exposing (text)


firstOrZero : List Int -> Int
firstOrZero list =
    case List.head list of
        {{0}} x ->
            x

        {{1}} ->
            0


toScore : String -> Result String Int
toScore raw =
    case String.toInt raw of
        Nothing ->
            {{2}} "это не число"

        Just n ->
            if n < 0 then
                {{3}} "отрицательное"

            else
                {{4}} n


main =
    case toScore "35" of
        Ok n ->
            text ("Счёт: " ++ String.fromInt n)

        Err msg ->
            text ("Ошибка: " ++ msg)`,
        blanks: [
          { answer: 'Just' },
          { answer: 'Nothing' },
          { answer: 'Err' },
          { answer: 'Err' },
          { answer: 'Ok' }
        ],
        ci: false
      },
      hints: [
        'List.head возвращает Maybe: значение есть — Just x, нет — Nothing.',
        'Пропуски в toScore строят Result: успех — Ok n, неудача — Err "причина".',
        'Конструкторы пишутся с большой буквы: Just, Nothing, Ok, Err.'
      ],
      solution: ['Just', 'Nothing', 'Err', 'Err', 'Ok']
    },

    /* ---------- 9. List.map, filter и foldl ---------- */
    {
      id: 'elm-9',
      title: 'List.map, filter и foldl',
      goal: 'Связать map и filter со свёрткой List.foldl — накопить итог по списку без циклов',
      xp: 50,
      theory: [
        { t: 'p', html: '<code>List.map</code> и <code>List.filter</code> ты уже видел: первый превращает каждый элемент, второй отбирает подходящие. Третий кит — <b>свёртка</b> <code>List.foldl</code>: она пробегает список слева направо и накапливает результат в аккумуляторе — значение, к которому на каждом шаге что-то прибавляется.' },
        { t: 'code', code: `List.foldl (+) 0 [1, 2, 3, 4]
-- шаги: 0+1=1, 1+2=3, 3+3=6, 6+4=10
-- итог: 10` },
        { t: 'p', html: 'Сигнатура: <code>List.foldl : (a -&gt; b -&gt; b) -&gt; b -&gt; List a -&gt; b</code> — функция, начальное значение аккумулятора, список. Функция принимает элемент и текущий аккумулятор, возвращает новый. Запись <code>(+)</code> — «оператор как функция»: в скобках плюсу можно передать имя вместо лямбды.' },
        { t: 'code', code: `List.foldl (\\x acc -> acc + x) 0 [1, 2, 3]    -- 6
List.foldl (\\x acc -> x :: acc) [] [1, 2, 3]  -- [3, 2, 1]` },
        { t: 'p', html: 'Настоящая сила — <b>конвейер</b>: отфильтровать, преобразовать, свернуть. <code>List.filter</code> оставляет нужные элементы, <code>List.map</code> превращает их, <code>List.foldl (+) 0</code> собирает всё в одно число. Каждый шаг — маленькая чистая функция, и цепочка читается как рецепт: без циклов, счётчиков и временных переменных.' },
        { t: 'list', items: [
          '<b>List.map f list</b> — преобразовать каждый элемент;',
          '<b>List.filter p list</b> — оставить элементы с True;',
          '<b>List.foldl f init list</b> — свернуть в одно значение;',
          '<b>(+)</b> — оператор в скобках = функция от двух аргументов;',
          '<b>\\x acc -&gt; ...</b> — лямбда для своей свёртки.'
        ] },
        { t: 'warn', html: 'В операторных секциях скобки обязательны: <code>List.foldl + 0</code> без скобок не сработает — компилятор увидит не функцию, а попытку сложить. И помни: циклов в Elm нет — любой «перебор с накоплением» это foldl.' },
        { t: 'note', html: 'Есть зеркальная <code>List.foldr</code> — справа налево; для сложения разницы нет, а для вычитания или построения списка — есть. Проверь: <code>List.foldl (-) 0 [1, 2, 3]</code> и <code>List.foldr (-) 0 [1, 2, 3]</code> дают разные числа.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери конвейер без циклов: <code>nums</code> через <code>List.range 1 10</code>, предикат <code>even</code>, функция <code>double</code>. Затем один итог: <code>List.filter</code> отбирает чётные, <code>List.map</code> удваивает их, <code>List.foldl (+) 0</code> суммирует. Результат выведи в <code>main</code> через <code>text</code> со <code>String.fromInt</code>.</p>',
        starter: `module Main exposing (main)

import Html exposing (text)


-- TODO: объяви nums, even, double и собери конвейер filter, map, foldl


main =
    text ""`,
        rules: [
          { desc: 'Список nums построен через List.range', all: ['\\bnums\\s*=\\s*List\\.range'] },
          { desc: 'List.filter отбирает элементы', all: ['List\\.filter'] },
          { desc: 'List.map преобразует элементы', all: ['List\\.map'] },
          { desc: 'List.foldl сворачивает список', all: ['List\\.foldl'] },
          { desc: 'Свёртка начинается с аккумулятора 0', all: ['List\\.foldl\\s+\\S+\\s+0\\b'] },
          { desc: 'Итог выводится через text и String.fromInt', all: ['\\btext\\b', 'String\\.fromInt'] },
          { desc: 'Заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Диапазон: nums = List.range 1 10 — список от 1 до 10.',
        'Предикат: even n = remainderBy 2 n == 0, удвоение: double n = n * 2.',
        'Итог: total = List.foldl (+) 0 (List.map double (List.filter even nums)) — от внутреннего к внешнему.'
      ],
      solution: `module Main exposing (main)

import Html exposing (text)


nums =
    List.range 1 10


even n =
    remainderBy 2 n == 0


double n =
    n * 2


total =
    List.foldl (+) 0 (List.map double (List.filter even nums))


main =
    text ("Итого: " ++ String.fromInt total)`
    },

    /* ---------- 10. Проект: модель счётчика TEA ---------- */
    {
      id: 'elm-10',
      title: '🚀 Проект: модель счётчика TEA',
      goal: 'Собрать ядро Elm Architecture: type Msg, Model, init, update с case и view с text',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — ядро Elm Architecture, той самой схемы Model-Update-View, о которой говорилось на уровне 5. Ты соберёшь её вручную: сообщения, модель, чистая функция update с разбором сообщений и view. Это не учебная игрушка — ровно эта структура (плюс Browser.sandbox вместо main) стоит в каждом настоящем Elm-приложении.' },
        { t: 'h', html: 'Четыре части' },
        { t: 'list', items: [
          '<b>type Msg = Increment | Decrement</b> — union-тип сообщений-событий;',
          '<b>type alias Model = { count : Int }</b> — модель, просто данные;',
          '<b>init = { count = 0 }</b> — стартовое состояние;',
          '<b>update : Msg -&gt; Model -&gt; Model</b> — case по сообщениям;',
          '<b>view : Model -&gt; Html Msg</b> — разметка через text.'
        ] },
        { t: 'code', code: `update : Msg -> Model -> Model
update msg model =
    case msg of
        Increment ->
            { model | count = model.count + 1 }

        Decrement ->
            { model | count = model.count - 1 }` },
        { t: 'p', html: 'Разбери по косточкам. <code>Msg</code> — union-тип: каждый конструктор — событие интерфейса. <code>update</code> — чистая функция: старая модель плюс сообщение, новая модель; никакого «изменения поля», только копия через синтаксис обновления записи с уровня 7. <code>view</code> просто рисует модель — пока текстом, в настоящем приложении на месте text стояли бы кнопки с onClick, отправляющим Increment.' },
        { t: 'p', html: 'Как это живёт: <code>Browser.sandbox { init = init, update = update, view = view }</code> замыкает цикл — клик рождает Msg, update строит новую Model, view перерисовывается. Elm сам разруливает DOM-обновления: тебе остаётся описывать только чистые преобразования данных. Именно поэтому в Redux-подобных архитектурах всё выглядит знакомо — они выросли отсюда.' },
        { t: 'warn', html: 'Ветки case обязаны покрывать все конструкторы Msg — компилятор не пропустит забытый Increment. И возвращай всегда новую модель через <code>{ model | ... }</code>: попытка «просто поменять поле» в Elm невозможна в принципе, а аннотации Msg -&gt; Model -&gt; Model держат функцию честной.' },
        { t: 'note', html: 'Куда расти: <code>Browser.element</code> с командами и подписками (Http.get вернёт уже знакомый Result с уровня 8), пайплайны List.foldl из уровня 9 для обработки списков в update. Ядро у тебя уже есть — дальше только обвязка.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Модель счётчика TEA».</b> Объяви <code>type Msg</code> с конструкторами <code>Increment</code> и <code>Decrement</code>, модель <code>type alias Model = { count : Int }</code> и стартовое <code>init = { count = 0 }</code>. Напиши <code>update</code> с аннотацией <code>Msg -&gt; Model -&gt; Model</code>: внутри <code>case</code> обработай оба сообщения, возвращая новую модель через <code>{ model | count = ... }</code>. Добавь <code>view</code> с <code>text</code> и свяжи всё в <code>main</code>.</p>',
        starter: `module Main exposing (main)

import Html exposing (Html, text)


-- TODO: объяви type Msg, Model, init, update с case и view


main =
    text "0"`,
        rules: [
          { desc: 'type Msg объявлен union с конструкторами Increment и Decrement', all: ['\\btype\\s+Msg\\b', '=\\s*Increment\\b', '\\|\\s*Decrement\\b'] },
          { desc: 'Model объявлен через type alias с полем count : Int', all: ['\\btype\\s+alias\\s+Model\\b', '\\bcount\\s*:\\s*Int\\b'] },
          { desc: 'update объявлен с аннотацией Msg -> Model -> Model и определением', all: ['update\\s*:\\s*\\w+\\s*->\\s*\\w+\\s*->\\s*\\w+', '\\bupdate\\s+\\w+\\s+\\w+\\s*='] },
          { desc: 'update разбирает оба сообщения через case-of', all: ['\\bcase\\s+\\w+\\s+of\\b', 'Increment\\s*->', 'Decrement\\s*->'] },
          { desc: 'Новая модель строится record update: { model | count = ... }', all: ['\\{\\s*model\\s*\\|\\s*count\\s*='] },
          { desc: 'view с text и init со стартовой моделью', all: ['\\bview\\s+\\w+\\s*=', '\\btext\\b', '\\binit\\b'] },
          { desc: 'Заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Union: type Msg = Increment | Decrement — конструкторы с большой буквы, через |.',
        'Ветви case: Increment -> { model | count = model.count + 1 } — копия записи, не мутация.',
        'Финал: view model = text (String.fromInt model.count), а main = view init.'
      ],
      solution: `module Main exposing (main)

import Html exposing (Html, text)


type Msg
    = Increment
    | Decrement


type alias Model =
    { count : Int }


init : Model
init =
    { count = 0 }


update : Msg -> Model -> Model
update msg model =
    case msg of
        Increment ->
            { model | count = model.count + 1 }

        Decrement ->
            { model | count = model.count - 1 }


view : Model -> Html Msg
view model =
    text ("Счётчик: " ++ String.fromInt model.count)


main =
    view init`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас модуля',
      code: `module Main exposing (main)

import Html exposing (text)

main =
    text "Hello, Elm!"
-- запуск: elm reactor → localhost:8000
-- сборка: elm make src/Main.elm`
    },
    {
      title: 'Типы',
      code: `age : Int        -- 1, -42; деление нацело: 7 // 2
height : Float   -- 1.75; деление: 7 / 2
name : String    -- "Аня"; склейка: "a" ++ "b"
isAdmin : Bool   -- True / False (с большой буквы!)
-- 1 + 1.5 — ошибка: toFloat 1 + 1.5`
    },
    {
      title: 'let .. in',
      code: `main =
    let
        price = 100
        count = 3
    in
    price * count
-- имена видны только в выражении после in`
    },
    {
      title: 'if и case',
      code: `if n > 0 then "плюс" else "минус"
-- else ОБЯЗАТЕЛЕН: if — выражение

case n of
    0 -> "ноль"
    5 -> "пять"
    _ -> "много"   -- всё остальное`
    },
    {
      title: 'Функции и Maybe',
      code: `add : Int -> Int -> Int
add a b = a + b
-- вызов: add 2 3 (без скобок)

safeDivide : Int -> Int -> Maybe Int
-- Just x — значение есть, Nothing — нет
Maybe.withDefault 0 maybeValue
-- или case m of Just v -> ... / Nothing -> ...`
    },
    {
      title: 'Списки и архитектура',
      code: `List.map (\\x -> x * 2) [1,2,3]   -- [2,4,6]
List.filter (\\n -> n > 2) [1..4] -- [3,4]
List.sum [1..10]                 -- 55
List.length items

-- Elm Architecture:
-- Model → Update (Msg) → View
-- вдохновила Redux`
    },
    {
      title: 'Records и обновление',
      code: `type alias User = { name : String, score : Int }

let u = { name = "Аня", score = 10 }
u.score                 -- 10
.score                  -- функция-аксессор

{ u | score = u.score + 5 }
-- копия: изменился только score, u не тронут
-- = в литерале, : в типе, | в обновлении`
    },
    {
      title: 'TEA: Msg, Model, update, view',
      code: `type Msg = Increment | Decrement
type alias Model = { count : Int }

init = { count = 0 }

update msg model =
    case msg of
        Increment -> { model | count = model.count + 1 }
        Decrement -> { model | count = model.count - 1 }

view model = text (String.fromInt model.count)

-- Browser.sandbox { init = init, update = update, view = view }`
    }
  ]
};
