'use strict';
/* ============ CodeQuest — курс Fortran ============
   Fortran не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
   Ключевые слова в заданиях пишутся строчными буквами —
   так принято в современном идиоматичном Fortran.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.fortran = {
  id: 'fortran',
  title: 'Fortran',
  emoji: '👴',
  color: '#6a63b8',
  lang: 'fortran',
  tagline: 'Первый язык (1957): 10 уровней научных расчётов',
  description: 'Язык, с которого началась программная история: Джон Бэкус и его команда в IBM создали его в 1957 году, чтобы переводить формулы физики в машинный код. Сегодня Fortran — рабочий инструмент суперкомпьютеров: на нём считают погоду, климат, термояд и аэродинамику. За 10 уровней дойдём от program hello до срезов массивов, модулей с use и проекта «Среднее и дисперсия» на современном Fortran 2018 в свободном формате с компилятором gfortran.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'fortran-1',
      title: 'Первая программа',
      goal: 'Собрать каркас программы на Fortran: program, вывод print *, end program — и узнать, как его компилирует gfortran',
      xp: 30,
      theory: [
        { t: 'p', html: 'Fortran (FORmula TRANslation — «перевод формул») — первый в мире высокоуровневый язык программирования. Его создал Джон Бэкус с командой в IBM, первая версия вышла в 1957 году и сразу дала взрывной эффект: программы, которые раньше выбивали вручную в машинных кодах, стали записываться формулами. С тех пор прошло больше полувека, а Фортран живее всех живых: это главный язык суперкомпьютерного мира — прогнозы погоды, климатические модели, термоядерная физика, аэродинамика. Современный стандарт называется Fortran 2018, и это развивающийся язык, а не музейный экспонат.' },
        { t: 'h', html: 'Минимальная программа' },
        { t: 'code', code: `program hello
  print *, "Привет, CodeQuest!"
end program hello` },
        { t: 'p', html: 'Разберём каркас. <code>program hello</code> открывает главную программу с именем hello, <code>end program hello</code> закрывает её. <code>print *</code> — вывод «списком»: звёздочка означает «формат не задан, компилятор сделает как удобно». После звёздочки идёт запятая и список выводимого через запятую. Текст пишется в двойных кавычках (одинарные тоже легальны, но выбери один стиль и держись его).' },
        { t: 'list', items: [
          '<b>program имя</b> — начало главной программы;',
          '<b>print *, значения</b> — вывод через запятую, звёздочка = свободный формат;',
          '<b>end program имя</b> — конец программы;',
          '<b>!</b> — комментарий до конца строки.'
        ] },
        { t: 'note', html: 'Компиляция: <b>gfortran hello.f90 -o hello</b>, запуск: <b>./hello</b>. gfortran — свободный компилятор из набора GCC; есть ещё Intel ifx и LLVM flang. Расширение <b>.f90</b> означает «свободный формат»: код начинается с любой колонки, отступы на твой вкус. Старые расширения .f/.for — фиксированный формат эпохи перфокарт: там первые шесть колонок служебные, а комментарий — это буква C в первой колонке. Мы работаем только со свободным форматом.' },
        { t: 'warn', html: 'Регистр в Фортране не важен: PROGRAM и program — одно и то же. Но в этом курсе все задания пишутся <b>строчными буквами</b> — так выглядит современный идиоматичный Fortran, и проверки ожидают именно нижний регистр ключевых слов. Текст в кавычках и комментарии — исключение: там регистр сохраняется как написан.' },
        { t: 'p', html: 'print умеет несколько значений сразу: <code>print *, "sum =", 2 + 3</code> напечатает текст и сумму. Арифметика обычная: + - * / и ** для степени. Собери первую программу — и считается, что ты прикоснулся к 1957 году.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первую программу на Fortran: программа с именем <code>hello</code>, вывод фразы <code>Привет, CodeQuest!</code> через <code>print *</code> и завершение <code>end program</code>. Строку-заглушку в комментарии замени настоящим выводом. Пиши ключевые слова строчными буквами.</p>',
        starter: `program hello
  ! TODO: выведи приветствие

end program hello`,
        rules: [
          { desc: 'Программа объявлена: program hello', all: ['\\bprogram\\s+hello\\b'] },
          { desc: 'Есть вывод print *, с текстом в кавычках', all: ['print\\s*\\*\\s*,\\s*"[^"]+"'] },
          { desc: 'Выведена фраза "Привет, CodeQuest!"', all: ['"Привет, CodeQuest!"'] },
          { desc: 'Программа закрыта end program', any: ['end\\s+program', 'endprogram', '^\\s*end\\s*$'] },
          { desc: 'Без заглушек TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас program hello / end program hello уже правильный — его менять не нужно.',
        'Вывод выглядит так: print *, "Привет, CodeQuest!" — звёздочка и запятая после print обязательны.',
        'Фразу пиши точно, в двойных кавычках: Привет, CodeQuest!'
      ],
      solution: `program hello
  print *, "Привет, CodeQuest!"
  print *, "Это моя первая программа на Фортране."
end program hello`
    },

    /* ---------- 2. Переменные и типы ---------- */
    {
      id: 'fortran-2',
      title: 'Переменные и типы',
      goal: 'Объявлять переменные с implicit none: integer, real, character(len=) и logical — и инициализировать их',
      xp: 30,
      theory: [
        { t: 'p', html: 'Fortran — язык со статической типизацией: тип переменной известен при объявлении и не меняется. Объявления ставят в начале программы, до исполняемых операторов. Синтаксис: <code>тип :: имя = значение</code> — через двойное двоеточие.' },
        { t: 'code', code: `program info
  implicit none
  integer :: age = 20
  real :: height = 1.78
  character(len=12) :: city = "Москва"
  logical :: passed = .true.
  print *, age, height, city, passed
end program info` },
        { t: 'p', html: '<code>implicit none</code> — строка, которую пишут всегда. Исторически Фортран угадывал типы по первой букве имени: переменные на i..n считались целыми, остальные — вещественными. <code>implicit none</code> отключает эту телепатию: теперь необъявленная переменная — ошибка компиляции. Без неё опечатка в имени молча создаст новую переменную, и ты будешь искать баг неделю.' },
        { t: 'table', head: ['Тип', 'Хранит', 'Примеры'], rows: [
          ['integer', 'целые числа', '42, -7, 0'],
          ['real', 'дробные числа', '3.14, -0.5, 2.0'],
          ['character(len=n)', 'строка длины n', '"Аня"'],
          ['logical', 'истина / ложь', '.true., .false.']
        ] },
        { t: 'p', html: 'Строка требует длины: <code>character(len=12)</code> — ровно 12 символов, короткие значения дополняются пробелами. Логические литералы окружены точками: <code>.true.</code> и <code>.false.</code> — это не опечатка, а фирменный синтаксис Фортрана, восходящий к эпохе, когда точки было проще набивать на перфокартах.' },
        { t: 'warn', html: 'Целые и дробные не смешиваются свободно: <code>7 / 2</code> для двух integer — это 3 (дробная часть отбрасывается), а для real — 3.5. Присваивание <code>integer :: x = 2.7</code> сохранит 2 — дробная часть отрезается без округления.' },
        { t: 'note', html: 'Несколько переменных одного типа объявляют списком: <code>integer :: a, b, c</code>. Комментарий — <code>!</code> до конца строки: <code>s = 0 ! обнуляем сумму</code>. Регистр имён компилятору безразличен, но по соглашению современного кода имена и ключевые слова пишут строчными.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни программу-анкету: в первом пропуске включи явный режим объявлений, затем подставь тип для дробного роста, тип для строки города и логическое значение «истина».</p>',
        code: `program info
  {{0}}
  integer :: age = 20
  {{1}} :: height = 1.78
  {{2}}(len=12) :: city = "Москва"
  logical :: passed = {{3}}
  print *, age, height, city, passed
end program info`,
        blanks: [
          { answer: 'implicit none' },
          { answer: 'real' },
          { answer: 'character' },
          { answer: '.true.', ci: true }
        ],
        ci: false
      },
      hints: [
        'Строка, которая запрещает неявные типы, — implicit none.',
        'Дробные числа — real, а для строк нужен тип, к которому приписывается (len=12).',
        'Истина в Фортране пишется с точками по бокам: .true.'
      ],
      solution: ['implicit none', 'real', 'character', '.true.']
    },

    /* ---------- 3. Условия и циклы ---------- */
    {
      id: 'fortran-3',
      title: 'Условия и циклы',
      goal: 'Ветвить программу через if/else и повторять действия циклами do и do while — и предсказать вывод',
      xp: 35,
      theory: [
        { t: 'p', html: 'До сих пор программы шли строго сверху вниз. Настоящие программы выбирают дорогу и повторяют шаги. Ветвление — конструкция <code>if ... then ... else ... end if</code>: условие обязательно в круглых скобках, после него слово then. Цепочка проверок — через <code>else if (условие) then</code>, финальный <code>else</code> ловит всё остальное, закрывается всё <code>end if</code> (допустима краткая форма endif).' },
        { t: 'code', code: `if (s > 50) then
  print *, "много"
else
  print *, "мало"
end if` },
        { t: 'p', html: 'Операции сравнения: <code>==</code> равно, <code>/=</code> не равно (не !=!), <code>&gt;</code>, <code>&lt;</code>, <code>&gt;=</code>, <code>&lt;=</code>. Логические связки тоже обёрнуты точками: <code>.and.</code>, <code>.or.</code>, <code>.not.</code>. Счётный цикл <code>do i = 1, 10</code> — рабочий конь научных расчётов:' },
        { t: 'code', code: `do i = 1, 10
  s = s + i
end do` },
        { t: 'p', html: 'Обе границы <b>включаются</b>: do i = 1, 10 выполнится ровно 10 раз. Третий параметр — шаг: <code>do i = 10, 1, -1</code> идёт в обратную сторону. Переменную цикла (как и всякую другую) надо объявить, закрывается цикл <code>end do</code>. Цикл-пока <code>do while (условие)</code> повторяет тело, пока условие истинно, — проверка идёт перед каждой итерацией:' },
        { t: 'code', code: `do while (n > 1)
  n = n / 2
end do` },
        { t: 'warn', html: 'Целочисленное деление <code>n / 2</code> отбрасывает дробную часть — так 8 уменьшается до 4, 2, 1. В do while обязательно меняй переменную внутри тела — иначе вечный цикл. И не путай <code>/=</code> (не равно) с привычным != из других языков: компилятор такое не примет.' },
        { t: 'p', html: 'Задание уровня — «предскажи вывод»: прочитай код, прокрути циклы руками и запиши, что напечатает программа. Вывод list-directed print в реальном gfortran дополняет числа выравнивающими пробелами — их учитывать не нужно, пиши только сами значения.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай код и напиши, что он выведет, — по одной строке на каждый <code>print</code>, в порядке появления. Выравнивающие пробелы перед числами не учитывай: пиши просто <code>sum = 55</code>, если вывелось 55.</p>',
        code: `program demo
  implicit none
  integer :: i, s, n

  s = 0
  do i = 1, 10
    s = s + i
  end do
  print *, "sum =", s

  n = 8
  do while (n > 1)
    n = n / 2
  end do
  print *, "n =", n

  if (s > 50) then
    print *, "много"
  else
    print *, "мало"
  end if
end program demo`,
        answer: `sum = 55
n = 1
много`
      },
      hints: [
        'Пройди счётный цикл руками: s копит 1 + 2 + 3 + ... + 10.',
        'n уменьшается вдвое, пока n > 1: 8 → 4 → 2 → ... Остановись, когда условие станет ложным.',
        'Ветку if выбирает сравнение s > 50 — проверь сумму и запиши слово из нужной ветки.'
      ],
      solution: `sum = 55
n = 1
много`
    },

    /* ---------- 4. Функции и подпрограммы ---------- */
    {
      id: 'fortran-4',
      title: 'Функции и подпрограммы',
      goal: 'Писать функции и подпрограммы в секции contains: параметры с intent, возврат значения, вызов через call',
      xp: 40,
      theory: [
        { t: 'p', html: 'Повторяющийся код прячут в подпрограммы. В Фортране их два вида: <code>function</code> вычисляет и возвращает значение, <code>subroutine</code> — просто «делает действие» и вызывается словом <code>call</code>.' },
        { t: 'code', code: `program demo
  implicit none
  real :: r

  r = area(2.0, 3.0)
  call greet("Аня")

contains

  real function area(a, b)
    real, intent(in) :: a, b
    area = a * b
  end function area

  subroutine greet(name)
    character(len=*), intent(in) :: name
    print *, "Привет, ", name
  end subroutine greet

end program demo` },
        { t: 'p', html: 'Секция <code>contains</code> стоит между телом программы и <code>end program</code>: здесь живут внутренние процедуры, видимые только своей программе-хозяину. Функция возвращает значение, присваивая его собственному имени: <code>area = a * b</code>. Современная альтернатива — форма <code>function area(a, b) result(p)</code>: результат возвращается присваиванием <code>p = ...</code>.' },
        { t: 'p', html: '<code>intent(in)</code> — параметр только для чтения, <code>intent(out)</code> — выходной результат, <code>intent(inout)</code> — читаем и меняем. Указывать intent — правило хорошего стиля: компилятор поймает случайное изменение входных данных. Строка <code>character(len=*)</code> берёт длину из фактического аргумента — универсальный параметр-текст.' },
        { t: 'list', items: [
          '<b>function имя(...)</b> — возвращает значение через присваивание имени или result(...);',
          '<b>subroutine имя(...)</b> — вызывается только через call имя(...);',
          '<b>intent(in|out|inout)</b> — контракт параметра;',
          '<b>contains</b> — секция внутренних процедур программы.'
        ] },
        { t: 'note', html: 'Функции можно вызывать прямо в выражениях: <code>s = 2.0 * area(3.0, 4.0) + 1.0</code>. Именно так устроены научные библиотеки — BLAS и LAPACK, на которых считает линейную алгебру всего мира, — это гигантские наборы фортрановских подпрограмм.' },
        { t: 'warn', html: 'Подпрограммы объявляют в секции contains, а не внутри исполняемого кода. Не вызывай subroutine как функцию: <code>r = greet("Аня")</code> — ошибка, только <code>call greet("Аня")</code>. И не забудь объявить тип результата функции перед словом function (например, <code>integer function</code>).' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери программу с внутренней функцией <code>double(n)</code>, возвращающей удвоенное целое, и подпрограммой <code>show(text)</code>, печатающей текст. Вызови оба: результат функции сохрани в переменную и выведи, подпрограмму вызови через <code>call</code>. Функцию и подпрограмму размести после <code>contains</code>.</p>',
        starter: `program demo
  implicit none
  integer :: d

  ! TODO: вызови функцию и подпрограмму, объяви их после contains

end program demo`,
        rules: [
          { desc: 'Функция double объявлена', all: ['\\bfunction\\s+double'] },
          { desc: 'Функция возвращает значение (double = ... или result(...))', any: ['\\bdouble\\s*=\\s*\\S', 'result\\s*\\('] },
          { desc: 'Подпрограмма show объявлена', all: ['\\bsubroutine\\s+show'] },
          { desc: 'show вызывается через call', all: ['\\bcall\\s+show'] },
          { desc: 'Без заглушек TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Вызовы в теле: d = double(21), затем call show("работает!").',
        'Функция: integer function double(n) ... double = n * 2 ... end function double.',
        'Подпрограмма: subroutine show(text) с character(len=*) :: text и print внутри.'
      ],
      solution: `program demo
  implicit none
  integer :: d

  d = double(21)
  print *, "double =", d
  call show("работает!")

contains

  integer function double(n)
    integer, intent(in) :: n
    double = n * 2
  end function double

  subroutine show(text)
    character(len=*), intent(in) :: text
    print *, text
  end subroutine show

end program demo`
    },

    /* ---------- 5. Идиомы Фортрана ---------- */
    {
      id: 'fortran-5',
      title: 'Идиомы Фортрана',
      goal: 'Узнавать фирменные приёмы: массивы с индексацией с единицы, имплайд-ду, форматный вывод write и модули',
      xp: 45,
      theory: [
        { t: 'p', html: 'Массив объявляется прямо в типе: <code>real :: h(11)</code> — одиннадцать элементов. Индексация по умолчанию <b>с единицы</b>: h(1) — первый, h(11) — последний. Нижнюю границу можно задать явно: <code>real :: h(0:10)</code> — индексы от 0 до 10, удобно для моментов времени с нуля.' },
        { t: 'code', code: `real :: a(3) = [10, 20, 30]
integer :: i
do i = 1, 3
  print *, a(i)
end do` },
        { t: 'p', html: 'Фирменный приём — <b>имплайд-ду</b> («неявный цикл») внутри списка значений: <code>print *, (a(i), i = 1, 3)</code> печатает весь массив одной строкой. Тем же приёмом заполняют массивы литералами: <code>integer :: b(3) = [(i, i = 1, 3)]</code> даст 1 2 3.' },
        { t: 'h', html: 'Форматный вывод: write' },
        { t: 'p', html: 'Когда list-directed print выводит real с хвостом из нулей, берут <code>write</code> с форматной строкой: <code>write(*, "(F6.2)") x</code>. Дескриптор <b>F6.2</b> — число в 6 позициях, 2 после точки: строка <code>write(*, "(A, F6.2)") "x = ", 3.14159</code> напечатает x =   3.14. Другие дескрипторы: <b>I5</b> — целое в 5 позициях, <b>A</b> — строка, <b>ES</b> — экспоненциальная запись. Это «printf» Фортрана, только формат задаётся отдельной картинкой.' },
        { t: 'h', html: 'Модули' },
        { t: 'p', html: 'Переиспользуемый код собирают в <code>module</code>: константы, типы и процедуры упаковываются в блок, который подключается словом <code>use</code>. Константа объявляется атрибутом <code>parameter</code> — менять её нельзя. Забудешь use — компилятор не узнает про PI. И помни: неявный цикл в print — это скобки и запятые: <code>(a(i), i = 1, 3)</code>; перепутаешь порядок — ошибка компиляции.' },
        { t: 'code', code: `module mathkit
  implicit none
  real, parameter :: PI = 3.14159265
end module mathkit

program demo
  use mathkit
  print *, PI
end program demo` }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что напечатает эта программа?</p><pre>program quiz
  implicit none
  integer :: a(4) = [5, 10, 15, 20]
  integer :: i
  print *, (a(i) * 2, i = 1, 4)
end program quiz</pre>`,
        options: [
          '10 20 30 40',
          '5 10 15 20',
          '10203040',
          'Ошибка: в print нельзя поместить цикл'
        ],
        correct: 0,
        explain: 'Скобочная конструкция (a(i) * 2, i = 1, 4) — имплайд-ду: i пробегает 1, 2, 3, 4, и для каждого значения печатается a(i) * 2. List-directed print разделяет значения пробелами: 10 20 30 40. Массив индексируется с единицы, поэтому a(1) = 5.',
        solution: 0
      },
      hints: [
        'Имплайд-ду — это цикл внутри вывода: перебери i от 1 до 4.',
        'Каждый элемент печатается умноженным на 2.',
        'List-directed print не склеивает значения — ставит между ними пробелы.'
      ],
      solution: 0
    },

    /* ---------- 6. Проект: Расчёт траектории ---------- */
    {
      id: 'fortran-6',
      title: '🚀 Проект: Расчёт траектории',
      goal: 'Собрать проект: массив высот, цикл do заполнения, функция height по формуле и поиск максимума',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальный проект — классика научного Фортрана: численный расчёт по формуле. Тело бросили вверх со скоростью 20 м/с; высота меняется по закону <code>h(t) = v0·t − g·t²/2</code>, где g ≈ 9.8, то есть коэффициент 4.9. Посчитаем высоты в моменты t = 0…10 секунд, сложим их в массив и найдём максимум. Сетка моментов времени, цикл по узлам и функция с физической формулой — ровно так выглядят настоящие программы прогноза погоды, только с миллионами узлов.' },
        { t: 'h', html: 'Что строим' },
        { t: 'list', items: [
          'массив <code>h</code> на 11 значений (например, <code>real :: h(11)</code> или <code>h(0:10)</code>);',
          'функция <code>height(t)</code> — высота по формуле;',
          'цикл <code>do</code> заполнения массива и цикл поиска максимума;',
          'вывод максимума через <code>print *</code> или <code>write</code>.'
        ] },
        { t: 'code', code: `program trajectory
  implicit none
  integer :: i
  real :: h(0:10)
  real :: hmax

  do i = 0, 10
    h(i) = height(real(i))
  end do

contains

  real function height(t)
    real, intent(in) :: t
    height = 20.0 * t - 4.9 * t * t
  end function height

end program trajectory` },
        { t: 'p', html: 'Обрати внимание на два момента. Во-первых, <code>real(i)</code> — приведение целого счётчика к вещественному, чтобы передать его функции, ожидающей real. Во-вторых, максимум ищется классическим аккумулятором: берём первый элемент, проходим по остальным и обновляем рекорд, когда встретили большее.' },
        { t: 'warn', html: 'Для t больше 4 секунд высота станет отрицательной — тело уже упало, формула про землю не знает. Для учебного расчёта это нормально: задание про структуру программы, а не про физику. И не оставляй в финальном коде заглушек-комментариев.' },
        { t: 'note', html: 'После зачёта усиль программу: найди и время максимума (теория обещает t = v0/g ≈ 2 с), выведи таблицу через <code>write</code> с форматом <code>F7.2</code>, добавь функцию скорости <code>v(t) = 20.0 - 9.8 * t</code>. Каждый новый расчёт — это новая функция и ещё один цикл: конструктор научного кода.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Расчёт траектории».</b> Объяви массив высот <code>h</code> (например, <code>real :: h(11)</code> или с границами <code>h(0:10)</code>). Напиши функцию <code>height(t)</code>, вычисляющую высоту по формуле <code>20.0 * t - 4.9 * t * t</code>. В цикле <code>do</code> заполни массив значениями и найди максимальную высоту. Выведи максимум через <code>print *</code> (или <code>write</code>). Функцию размести после <code>contains</code>. Без заглушек!</p>',
        starter: `program trajectory
  implicit none
  ! TODO: массив высот, цикл заполнения, поиск максимума
  ! нужная функция объявляется после contains
end program trajectory`,
        rules: [
          { desc: 'Объявлена функция height', all: ['\\bfunction\\s+height'] },
          { desc: 'Функция возвращает высоту (height = ... или result(...))', any: ['\\bheight\\s*=\\s*\\S', 'result\\s*\\('] },
          { desc: 'Объявлен массив (например, real :: h(...) или dimension)', any: ['::\\s*\\w+\\s*\\(\\s*[\\d:]', 'dimension\\s*\\('] },
          { desc: 'Есть цикл do', all: ['\\bdo\\b'] },
          { desc: 'Есть вывод print * или write', any: ['print\\s*\\*\\s*,', 'write\\s*\\('] },
          { desc: 'Без заглушек TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Массив: real :: h(0:10) — тогда индексы совпадут с моментами времени.',
        'В цикле заполняй через функцию: h(i) = height(real(i)); функция вернёт 20.0 * t - 4.9 * t * t.',
        'Максимум: hmax = h(0), затем цикл по остальным и if (h(i) > hmax) hmax = h(i). В конце print *, "max h =", hmax.'
      ],
      solution: `program trajectory
  implicit none
  integer :: i
  real :: h(0:10)
  real :: hmax

  do i = 0, 10
    h(i) = height(real(i))
  end do

  hmax = h(0)
  do i = 1, 10
    if (h(i) > hmax) hmax = h(i)
  end do

  print *, "max h =", hmax

contains

  real function height(t)
    real, intent(in) :: t
    height = 20.0 * t - 4.9 * t * t
  end function height

end program trajectory`
    },

    /* ---------- 7. Массивы: срезы и измерения ---------- */
    {
      id: 'fortran-7',
      title: 'Массивы: срезы и измерения',
      goal: 'Работать со срезами массива a(2:5), присваивать им значения и считать sum по диапазону',
      xp: 45,
      theory: [
        { t: 'p', html: 'Массивы — сердце Фортрана, и работать с ними можно кусками. Объявление <code>real :: a(6)</code> создаёт шесть элементов с индексами 1..6; явные границы <code>real :: t(0:10)</code> удобны для сетки времени от нуля. Двумерные массивы — через запятую: <code>real :: m(3, 4)</code> — три строки и четыре столбца; именно в таких массивах живут данные климатических моделей.' },
        { t: 'code', code: `real :: a(6) = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
real :: m(2, 2) = reshape([1.0, 2.0, 3.0, 4.0], [2, 2])` },
        { t: 'p', html: '<b>Срез</b> — диапазон в скобках через двоеточие: <code>a(2:4)</code> — элементы со второго по четвёртый включительно, <code>a(2:)</code> — от второго до конца, <code>a(1:6:2)</code> — каждый второй. Срез можно присваивать целиком: <code>a(4:6) = 0.0</code> обнулит сразу три элемента, а <code>a = a * 2.0</code> удвоит весь массив — арифметика работает поэлементно, без циклов.' },
        { t: 'code', code: `a(4:6) = 0.0        ! хвост обнулён
a(1:3) = a(1:3) * 10.0   ! первые три — умножены
s = sum(a(1:3))     ! сумма по срезу` },
        { t: 'p', html: 'Встроенные функции принимают массивы и срезы целиком: <code>sum(a)</code> — сумма всех элементов, <code>sum(a(2:5))</code> — по срезу, плюс <code>maxval</code>, <code>minval</code> и <code>size(a)</code> — число элементов. Это сильная сторона Фортрана: компилятор превращает такие выражения в быстрые векторные операции — отсюда репутация языка суперкомпьютеров.' },
        { t: 'list', items: [
          '<b>a(2:5)</b> — срез: элементы 2, 3, 4, 5;',
          '<b>a(2:)</b> — от второго до конца, <b>a(1:6:2)</b> — с шагом;',
          '<b>a(4:6) = 0.0</b> — присваивание всему срезу;',
          '<b>sum / maxval / minval</b> — свёртки по массиву;',
          '<b>size(a)</b> — количество элементов.'
        ] },
        { t: 'warn', html: 'Индексация по умолчанию с единицы: <code>a(0)</code> для массива <code>a(6)</code> — ошибка выхода за границу. Срез не должен выходить за объявленные границы, и помни: границы <code>do</code>-цикла включаются с обеих сторон — <code>do i = 2, 6, 2</code> даст i = 2, 4, 6.' },
        { t: 'note', html: 'Тот же синтаксис срезов без стыда скопирован современными языками: Python-срезы <code>a[1:4]</code> и NumPy-массивы выросли из фортрановских массивных операций. Настоящие коды прогноза погоды крутят трёхмерные срезы на миллиарды значений — синтаксис при этом тот же, что здесь.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви массив <code>real :: a(6)</code> с начальными значениями. Обнули срез <code>a(4:6)</code>, в цикле <code>do</code> с шагом пройди по чётным позициям и умножь их на 10, затем посчитай сумму первых трёх элементов через <code>sum(a(1:3))</code> и выведи её и массив через <code>print *</code>.</p>',
        starter: `program slices
  implicit none
  real :: a(6) = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
  real :: part
  integer :: i

  ! TODO: срез, цикл do с шагом и сумма через встроенную функцию

  part = 0.0
  print *, "sum a(1:3) =", part
end program slices`,
        rules: [
          { desc: 'Массив объявлен через :: с числом элементов', all: ['::\\s*\\w+\\s*\\(\\s*\\d+\\s*\\)'] },
          { desc: 'Используется срез массива a(...:...)', any: ['\\w+\\s*\\(\\s*\\d+\\s*:\\s*\\d+\\s*\\)', '\\w+\\s*\\(\\s*\\d+\\s*:\\s*\\)'] },
          { desc: 'Цикл do с числовыми границами', all: ['\\bdo\\s+\\w+\\s*=\\s*\\d+\\s*,\\s*\\d+'] },
          { desc: 'Сумма по срезу через sum(a(...:...))', all: ['\\bsum\\s*\\(\\s*\\w+\\s*\\(\\s*\\d+\\s*:\\s*\\d+\\s*\\)\\s*\\)'] },
          { desc: 'Есть вывод print *', all: ['print\\s*\\*\\s*,'] },
          { desc: 'Заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Обнуление среза: a(4:6) = 0.0 — присваивание всему диапазону разом.',
        'Цикл с шагом: do i = 2, 6, 2 — даёт i = 2, 4, 6; внутри a(i) = a(i) * 10.0.',
        'Сумма: part = sum(a(1:3)) — встроенная функция по срезу.'
      ],
      solution: `program slices
  implicit none
  real :: a(6) = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
  real :: part
  integer :: i

  a(4:6) = 0.0
  do i = 2, 6, 2
    a(i) = a(i) * 10.0
  end do

  part = sum(a(1:3))
  print *, "sum a(1:3) =", part
  print *, "array:", (a(i), i = 1, 6)
end program slices`
    },

    /* ---------- 8. Функции: result() и intent ---------- */
    {
      id: 'fortran-8',
      title: 'Функции: result() и intent',
      goal: 'Писать функции в форме function ... result(...) с защищёнными intent(in) параметрами',
      xp: 50,
      theory: [
        { t: 'p', html: 'На уровне 4 функция возвращала значение через собственное имя: <code>area = a * b</code>. Современная форма — <code>result()</code>: <code>real function to_fahrenheit(c) result(f)</code>. Теперь результат накапливается в переменной <code>f</code>, а имя функции остаётся только в объявлении и вызове — удобно для длинных имён и рекурсии.' },
        { t: 'code', code: `real function to_fahrenheit(c) result(f)
  real, intent(in) :: c
  f = c * 1.8 + 32.0
end function to_fahrenheit` },
        { t: 'p', html: 'Контракт параметров задаёт <code>intent</code>: <code>intent(in)</code> — параметр только для чтения, попытка присвоить ему значение — ошибка компиляции; <code>intent(out)</code> — выходной результат, <code>intent(inout)</code> — читаем и меняем. Указывать intent у каждого параметра — правило хорошего стиля: компилятор ловит случайную порчу входных данных ещё до запуска.' },
        { t: 'p', html: 'Вызов функции — прямо в выражении: <code>fahrenheit = to_fahrenheit(celsius)</code>. Тип параметра объявляется внутри процедуры: <code>real, intent(in) :: c</code>. Для строк берут длину из фактического аргумента — <code>character(len=*)</code>, как в <code>greet</code> с уровня 4.' },
        { t: 'list', items: [
          '<b>real function f(x) result(r)</b> — форма с result;',
          '<b>intent(in)</b> — только чтение, <b>intent(out)</b> — только запись;',
          '<b>intent(inout)</b> — читаем и меняем;',
          '<b>r = ...</b> — присваивание результату;',
          '<b>end function имя</b> — закрывающая строка.'
        ] },
        { t: 'warn', html: 'Не забывай объявлять типы параметров и результата: без <code>real, intent(in) :: c</code> включится неявная типизация по первой букве (а с <code>implicit none</code> — ошибка). И не пытайся менять параметр с <code>intent(in)</code>: компилятор это пресечёт.' },
        { t: 'note', html: 'В настоящих научных кодах к функциям добавляют атрибуты <code>pure</code> (без побочных эффектов) и <code>elemental</code> (автоматически работает поэлементно с массивами): <code>elemental real function sq(x)</code> применима и к числу, и к целому массиву сразу. Это естественное продолжение intent-дисциплины.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши функцию <code>to_fahrenheit</code> в форме <code>real function to_fahrenheit(c) result(f)</code> с параметром <code>real, intent(in) :: c</code>: формула <code>f = c * 1.8 + 32.0</code>. Размести её после <code>contains</code>, вызови из программы (результат сохрани в переменную) и выведи через <code>print *</code>.</p>',
        starter: `program convert
  implicit none
  real :: celsius, fahrenheit

  celsius = 25.0
  ! TODO: объяви функцию с result() и intent(in), вызови её и выведи

  print *, "25 C = ?"
end program convert`,
        rules: [
          { desc: 'Функция объявлена в форме function ... result(...)', all: ['\\bfunction\\s+\\w+\\s*\\([^)]*\\)\\s*result\\s*\\('] },
          { desc: 'Параметр защищён intent(in)', all: ['intent\\s*\\(\\s*in\\s*\\)'] },
          { desc: 'Тип функции объявлен (real function)', all: ['\\breal\\s+function\\b'] },
          { desc: 'Функция вызывается в присваивании', all: ['=\\s*to_fahrenheit\\s*\\('] },
          { desc: 'Есть вывод print *', all: ['print\\s*\\*\\s*,'] },
          { desc: 'Функция закрыта end function имя', all: ['end\\s+function\\s+\\w+'] },
          { desc: 'Заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Заголовок: real function to_fahrenheit(c) result(f) — внутри contains.',
        'Тело: real, intent(in) :: c, затем f = c * 1.8 + 32.0.',
        'Вызов: fahrenheit = to_fahrenheit(celsius), дальше print *, "25 C =", fahrenheit.'
      ],
      solution: `program convert
  implicit none
  real :: celsius, fahrenheit

  celsius = 25.0
  fahrenheit = to_fahrenheit(celsius)
  print *, "25 C =", fahrenheit

contains

  real function to_fahrenheit(c) result(f)
    real, intent(in) :: c
    f = c * 1.8 + 32.0
  end function to_fahrenheit

end program convert`
    },

    /* ---------- 9. Модули: module/contains/use ---------- */
    {
      id: 'fortran-9',
      title: 'Модули: module и use',
      goal: 'Упаковать константы и функции в module с contains и подключить его через use',
      xp: 50,
      theory: [
        { t: 'p', html: 'Модуль — способ упаковать переиспользуемый код: константы, типы и процедуры живут в <code>module ... end module</code>, а любой другой программный блок подключает их словом <code>use</code>. На уровне 5 модуль уже мелькал с одной константой; теперь добавим внутрь полноценные функции через секцию <code>contains</code>.' },
        { t: 'code', code: `module geometry
  implicit none
  real, parameter :: PI = 3.14159265

contains

  real function circle_area(r) result(a)
    real, intent(in) :: r
    a = PI * r * r
  end function circle_area

end module geometry` },
        { t: 'p', html: 'Порядок внутри модуля: сначала объявления (<code>implicit none</code>, константы через <code>parameter ::</code>), затем <code>contains</code> и процедуры. Объявления модуля видны всем его процедурам — <code>PI</code> внутри <code>circle_area</code> доступна без всяких префиксов, и <code>implicit none</code> модуля распространяется на процедуры тоже.' },
        { t: 'p', html: 'Программа подключает модуль: <code>use geometry</code> — строка идёт сразу после <code>program</code>, до <code>implicit none</code>. После этого имена модуля (константы, функции) видны напрямую: <code>print *, circle_area(2.0)</code>. Компилятор проверяет имена на этапе компиляции — опечатка в имени функции из модуля ловится сразу.' },
        { t: 'list', items: [
          '<b>module имя ... end module имя</b> — каркас модуля;',
          '<b>implicit none</b> — всегда, и в модуле тоже;',
          '<b>parameter ::</b> — константы модуля;',
          '<b>contains</b> — секция процедур модуля;',
          '<b>use имя</b> — подключение в программе (до implicit none).'
        ] },
        { t: 'warn', html: 'Модуль в файле размещают до программы, которая его использует (или в отдельном файле — тогда он компилируется первым). Перепутаешь порядок — компилятор не найдёт модуль. Имя модуля должно совпадать с именем файла: geometry в geometry.f90.' },
        { t: 'note', html: 'Так устроены настоящие научные библиотеки: физика ядра, сетки, линейная алгебра — наборы модулей с константами и процедурами, которые подключаются use-ом. Современный стандарт добавил классы (<code>class(...)</code>) и generic-интерфейсы, но каркас module/use не менялся десятилетиями.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери модуль <code>geometry</code>: внутри <code>implicit none</code>, константа <code>real, parameter :: PI</code> и после <code>contains</code> функция <code>circle_area(r)</code> с <code>intent(in)</code>, считающая <code>PI * r * r</code>. Затем программа <code>demo</code>, которая подключает модуль через <code>use geometry</code>, вызывает функцию и печатает результат.</p>',
        starter: `module geometry
  implicit none
  real, parameter :: PI = 3.14159265

  ! TODO: добавь секцию процедур с функцией площади круга

end module geometry


program demo
  use geometry
  implicit none

  print *, "area = ?"
end program demo`,
        rules: [
          { desc: 'Модуль объявлен и закрыт end module', all: ['\\bmodule\\s+\\w+\\b', 'end\\s+module\\s+\\w+'] },
          { desc: 'В модуле implicit none', all: ['implicit\\s+none'] },
          { desc: 'Секция contains с процедурами модуля', all: ['\\bcontains\\b'] },
          { desc: 'Константа объявлена через parameter ::', all: ['parameter\\s*::'] },
          { desc: 'Программа подключает модуль через use', all: ['\\buse\\s+\\w+'] },
          { desc: 'Функция модуля вызывается и выводится через print', all: ['circle_area\\s*\\(', 'print\\s*\\*\\s*,'] },
          { desc: 'Заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'В модуле: contains, затем real function circle_area(r) result(a) с real, intent(in) :: r.',
        'Тело функции: a = PI * r * r — константа видна без префиксов.',
        'В программе use geometry уже стоит — осталось вызвать circle_area(2.0) в print.'
      ],
      solution: `module geometry
  implicit none
  real, parameter :: PI = 3.14159265

contains

  real function circle_area(r) result(a)
    real, intent(in) :: r
    a = PI * r * r
  end function circle_area

end module geometry


program demo
  use geometry
  implicit none

  print *, "area =", circle_area(2.0)
end program demo`
    },

    /* ---------- 10. Проект: среднее и дисперсия ---------- */
    {
      id: 'fortran-10',
      title: '🚀 Проект: среднее и дисперсия',
      goal: 'Посчитать статистику набора данных: функция mean с intent(in), циклы сумм и вывод print',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — численный расчёт статистики набора данных: среднее значение и дисперсия. Формулы простые, но мы соберём их по-настоящему, в фортрановском стиле: массив данных, две функции после <code>contains</code>, каждая со своим циклом суммирования, и вывод результатов. Ровно так пишутся обработчики измерений — от лабораторных датчиков до климатических рядов.' },
        { t: 'h', html: 'Формулы и план' },
        { t: 'list', items: [
          '<b>mean = (x₁ + x₂ + ... + xₙ) / n</b> — среднее арифметическое;',
          '<b>var = Σ (xᵢ − mean)² / n</b> — дисперсия;',
          '<b>real :: data(8) = [ ... ]</b> — массив данных;',
          '<b>function mean(x) result(m)</b> с <code>real, intent(in) :: x(:)</code>;',
          '<b>do i = 1, size(x)</b> — циклы суммирования, вывод через <code>print *</code>.'
        ] },
        { t: 'code', code: `real function mean(x) result(m)
  real, intent(in) :: x(:)
  integer :: i
  m = 0.0
  do i = 1, size(x)
    m = m + x(i)
  end do
  m = m / size(x)
end function mean` },
        { t: 'p', html: 'Разбор. <code>x(:)</code> — массив «любой длины» (assumed-shape): функция примет массив любого размера, а <code>size(x)</code> узнает его длину — никаких магических констант. Первый цикл копит сумму, затем делим на <code>size(x)</code>. Дисперсия устроена так же, только в цикле накапливаются квадраты отклонений: <code>v = v + (x(i) - xmean) ** 2</code> — поэтому mean считается первым и передаётся в variance.' },
        { t: 'p', html: 'Для наших данных [2, 4, 4, 4, 5, 5, 7, 9] среднее ровно 5.0, а дисперсия — 4.0: суммы квадратов отклонений 32, делённые на 8. Проверь руками — это лучший способ убедиться, что циклы написаны верно. Вывод — два <code>print *</code> с подписями.' },
        { t: 'warn', html: 'Не забудь <code>intent(in)</code> у массивов: без него легко случайно испортить данные. И дели на <code>size(x)</code>, а не на размер минус один — здесь считается смещённая (генеральная) дисперсия, для учебного расчёта этого достаточно. Циклы должны идти после обнуления аккумулятора.' },
        { t: 'note', html: 'Куда расти: добавь функцию <code>std</code> — корень дисперсии через <code>sqrt</code>, найди <code>maxval</code> и <code>minval</code> данных, выведи результаты в колонку через <code>write</code> с форматом <code>(A, F8.3)</code>. Это уже готовый каркас лабораторного отчёта.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Среднее и дисперсия».</b> Объяви массив <code>data(8)</code> с числами. После <code>contains</code> напиши функции <code>mean(x)</code> и <code>variance(x, xmean)</code> в форме <code>result()</code> с параметрами <code>real, intent(in) :: x(:)</code>: внутри циклы <code>do i = 1, size(x)</code> накапливают сумму и сумму квадратов отклонений (<code>** 2</code>). Вызови обе, выведи среднее и дисперсию через <code>print *</code>.</p>',
        starter: `program statistics
  implicit none
  real :: data(8) = [2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0]
  real :: m, v

  ! TODO: объяви функции mean и variance после contains, вызови и выведи

  print *, "mean = ?"
  print *, "variance = ?"

end program statistics`,
        rules: [
          { desc: 'Массив данных объявлен', any: ['::\\s*\\w+\\s*\\(\\s*[\\d:]', 'dimension\\s*\\('] },
          { desc: 'Функция mean объявлена', all: ['\\bfunction\\s+mean\\b'] },
          { desc: 'Параметры защищены intent(in)', all: ['intent\\s*\\(\\s*in\\s*\\)'] },
          { desc: 'Циклы суммирования do i = 1, size(...)', all: ['\\bdo\\s+\\w+\\s*=\\s*1\\s*,\\s*size\\s*\\('] },
          { desc: 'Накопление суммы: m = m + x(i) или sum(...)', any: ['\\w+\\s*=\\s*\\w+\\s*\\+\\s*x\\s*\\(', '\\bsum\\s*\\('] },
          { desc: 'Дисперсия через квадраты отклонений ** 2', all: ['\\*\\*\\s*2'] },
          { desc: 'Есть вывод print *', all: ['print\\s*\\*\\s*,'] },
          { desc: 'Заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'mean: m = 0.0, цикл do i = 1, size(x) копит m = m + x(i), потом m = m / size(x).',
        'variance(x, xmean): второй параметр — среднее; в цикле v = v + (x(i) - xmean) ** 2.',
        'Вызовы: m = mean(data), v = variance(data, m), затем два print *.'
      ],
      solution: `program statistics
  implicit none
  real :: data(8) = [2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0]
  real :: m, v

  m = mean(data)
  v = variance(data, m)

  print *, "mean =", m
  print *, "variance =", v

contains

  real function mean(x) result(m)
    real, intent(in) :: x(:)
    integer :: i
    m = 0.0
    do i = 1, size(x)
      m = m + x(i)
    end do
    m = m / size(x)
  end function mean

  real function variance(x, xmean) result(v)
    real, intent(in) :: x(:), xmean
    integer :: i
    v = 0.0
    do i = 1, size(x)
      v = v + (x(i) - xmean) ** 2
    end do
    v = v / size(x)
  end function variance

end program statistics`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас программы',
      code: `program hello
  implicit none
  print *, "Привет!"
end program hello

! gfortran hello.f90 -o hello
! ./hello`
    },
    {
      title: 'Переменные и типы',
      code: `integer :: i = 42
real :: x = 3.14
character(len=12) :: s = "Аня"
logical :: ok = .true.
integer :: a, b, c      ! несколько сразу
! implicit none — писать всегда!
! .true. / .false. — с точками`
    },
    {
      title: 'Условия и циклы',
      code: `if (s > 50) then
  print *, "много"
else
  print *, "мало"
end if
! сравнения: ==  /=  >  <  >=  <=
! логика: .and. .or. .not.

do i = 1, 10     ! обе границы включены
  s = s + i
end do

do while (n > 1)
  n = n / 2
end do`
    },
    {
      title: 'Функции и подпрограммы',
      code: `program demo
  ...
contains
  integer function double(n)
    integer, intent(in) :: n
    double = n * 2
  end function double

  subroutine show(text)
    character(len=*), intent(in) :: text
    print *, text
  end subroutine show
end program demo

! вызов: d = double(21)
! вызов: call show("привет")`
    },
    {
      title: 'Массивы и implied do',
      code: `real :: a(3) = [10, 20, 30]
real :: h(0:10)            ! границы 0..10
print *, a(1)              ! индексация с 1!
print *, (a(i), i = 1, 3)  ! весь массив в строку
integer :: b(3) = [(i, i = 1, 3)]`
    },
    {
      title: 'Форматный вывод и модули',
      code: `write(*, "(A, F6.2)") "x = ", 3.14159
! → x =   3.14
! I5 — целое, A — строка, ES — экспонента

module mathkit
  implicit none
  real, parameter :: PI = 3.14159265
end module mathkit
! use mathkit`
    },
    {
      title: 'Срезы массивов и sum()',
      code: `real :: a(6) = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
a(4:6) = 0.0          ! срез целиком
a(2:)                 ! от 2 до конца
sum(a(1:3))           ! сумма по срезу
maxval(a), minval(a), size(a)
do i = 2, 6, 2        ! шаг 2: i = 2, 4, 6
end do
! индексация по умолчанию с 1!`
    },
    {
      title: 'Модули и result()',
      code: `module geometry
  implicit none
  real, parameter :: PI = 3.14159265
contains
  real function circle_area(r) result(a)
    real, intent(in) :: r
    a = PI * r * r
  end function circle_area
end module geometry

program demo
  use geometry
  print *, circle_area(2.0)
end program demo`
    }
  ]
};
