'use strict';
/* ============ CodeQuest — курс F# ============
   F# не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.fsharp = {
  id: 'fsharp',
  title: 'F#',
  emoji: '🎼',
  color: '#b845fc',
  lang: 'fsharp',
  tagline: 'Функциональный .NET: 10 уровней до счёта в банке',
  description: 'Функциональный язык платформы .NET из Microsoft Research (первый релиз 2005): лаконичный, строго типизированный, с выведением типов. На нём пишут банковский софт и анализ данных. За 10 уровней — от первого printfn до discriminated unions, immutable update и проекта «Банковский счёт».',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'fsharp-1',
      title: 'Первая программа',
      goal: 'Написать скрипт на F#: два вызова printfn и запуск через dotnet fsi',
      xp: 30,
      theory: [
        { t: 'p', html: 'F# — функциональный язык платформы .NET, выросший из Microsoft Research (первый официальный релиз — 2005 год, автор идеи Дон Сайм). Формула языка: строгость и лаконичность семейства ML плюс вся библиотека .NET. На F# пишут банковский софт, финансовую аналитику, инструменты для data science — там, где цена ошибки высока, а код должен читаться как описание задачи.' },
        { t: 'p', html: 'Для первых шагов у F# есть скриптовый формат — файл <code>.fsx</code>. Не нужно ни объявлять классы, ни искать функцию Main: интерпретатор выполняет строки сверху вниз, как будто это список команд. Это делает F# отличным «вторым языком»: минимум обвязки, максимум смысла.' },
        { t: 'h', html: 'Первая программа' },
        { t: 'code', code: `printfn "Привет, CodeQuest!"
printfn "Это моя первая программа на F#."` },
        { t: 'p', html: '<code>printfn</code> печатает текст и переводит строку. Это не просто печать, а форматный вывод: в строку вписываются маркеры <code>%d</code> (целое число), <code>%s</code> (строка), <code>%f</code> (дробное), а сами значения перечисляются после строки через пробел.' },
        { t: 'code', code: `printfn "Сумма: %d" (2 + 2)` },
        { t: 'note', html: 'Запуск в терминале: <b>dotnet fsi main.fsx</b> — F# Interactive выполнит скрипт. Есть и компилируемый путь (проект <code>.fsproj</code> и команда <code>dotnet run</code>), но для обучения скрипт проще всего. В этом приложении F#-код не запускается, а проверяется по структуре — пиши настоящий код, как для fsi.' },
        { t: 'warn', html: 'Текст — только в двойных кавычках. Одинарные кавычки в F# зарезервированы для одиночных символов: <code>\'a\'</code> — это символ, а не строка, и для текста они не подойдут.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первую программу на F# в файле <code>main.fsx</code>: два вызова <code>printfn</code>, первый — с фразой <code>Привет, CodeQuest!</code>. Скрипт не требует каркаса — просто пиши строки сверху вниз.</p>',
        starter: `// TODO: выведи приветствие через printfn`,
        rules: [
          { desc: 'Есть вызов printfn со строкой в двойных кавычках', all: ['printfn\\s+"'] },
          { desc: 'Выводится фраза "Привет, CodeQuest!"', all: ['"Привет, CodeQuest!'] },
          { desc: 'Минимум два вызова printfn', any: ['printfn[\\s\\S]*printfn'] },
          { desc: 'Пометок TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'printfn — это вся программа: printfn "Привет, CodeQuest!".',
        'Добавь второй printfn с любой строкой — скрипт выполнит их по порядку.',
        'Кавычки двойные; точек с запятой в конце строк F# не требует.'
      ],
      solution: `printfn "Привет, CodeQuest!"
printfn "Это моя первая программа на F#."`
    },

    /* ---------- 2. let и типы ---------- */
    {
      id: 'fsharp-2',
      title: 'let и типы',
      goal: 'Связывать значения через let, понимать выведение типов и форматный вывод',
      xp: 30,
      theory: [
        { t: 'p', html: '<code>let</code> — главное слово F#: связывает имя со значением. <code>let age = 25</code> — и всё: тип компилятор вывел сам. Явные аннотации нужны редко, но возможны: <code>let age: int = 25</code> — если хочется подчеркнуть тип намеренно.' },
        { t: 'code', code: `let age = 25          // int
let city = "Москва"   // string
let pi = 3.14         // float
let happy = true      // bool` },
        { t: 'p', html: 'Выведение типов (type inference) — фирменная фишка: компилятор смотрит на значение и сам знает тип. 25 — <code>int</code>, текст в кавычках — <code>string</code>, число с точкой — <code>float</code>, <code>true</code>/<code>false</code> — <code>bool</code>. Ошибку типа он поймает ещё до запуска программы.' },
        { t: 'table', head: ['Значение', 'Тип', 'Комментарий'], rows: [
          ['<code>25</code>', '<code>int</code>', 'целое число'],
          ['<code>3.14</code>', '<code>float</code>', 'обязательно с точкой'],
          ['<code>"Москва"</code>', '<code>string</code>', 'текст в двойных кавычках'],
          ['<code>true</code>', '<code>bool</code>', 'логическое значение']
        ] },
        { t: 'p', html: 'Значения по умолчанию неизменяемы: после <code>let x = 5</code> строка <code>x = 6</code> — ошибка. Изменяемость — осознанный выбор: <code>let mutable x = 5</code> и присваивание стрелкой <code>x &lt;- 6</code>. Неизменяемость делает код предсказуемым: значение нельзя случайно испортить по дороге.' },
        { t: 'p', html: 'Арифметика: <code>+ - * /</code> для int, и <code>5 / 2</code> даст 2 — целочисленное деление. Для float те же операторы, но оба операнда должны быть float: <code>5.0 / 2.0</code> даст 2.5. Смешать <code>5 / 2.0</code> нельзя — компилятор запретит.' },
        { t: 'note', html: 'Форматный вывод: <code>%d</code> — int, <code>%s</code> — string, <code>%f</code> — float, <code>%b</code> — bool, <code>%A</code> — «любое значение как есть» (удобно для списков). Вызов: <code>printfn "Возраст: %d" age</code>.' },
        { t: 'warn', html: 'Частая ловушка: <code>3</code> и <code>3.0</code> — разные типы. Напишешь <code>pi = 3</code> — получишь int, и <code>pi / 2</code> посчитается нацело. Для дробного пиши <code>3.0</code> или <code>3.14</code>.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни программу: подставь целое 25, город «Москва» (кавычки уже стоят), дробное 3.14 и логическое <code>true</code>. Типы выводятся сами — твоя задача дать правильные литералы.</p>',
        code: `let age = {{0}}
let city = "{{1}}"
let pi = {{2}}
let happy = {{3}}

printfn "Возраст: %d" age
printfn "Город: %s" city
printfn "Pi: %f" pi
printfn "Радость: %b" happy`,
        blanks: [
          { answer: '25' },
          { answer: 'Москва' },
          { answer: '3.14' },
          { answer: 'true' }
        ]
      },
      hints: [
        'Целое — без точки, дробное — с точкой: 25 и 3.14.',
        'true в F# пишется с маленькой буквы.',
        'Город уже в кавычках — впиши только текст между ними.'
      ],
      solution: ['25', 'Москва', '3.14', 'true']
    },

    /* ---------- 3. if-выражения и рекурсия ---------- */
    {
      id: 'fsharp-3',
      title: 'if-выражения и рекурсия',
      goal: 'Использовать if..then..else как выражение и писать рекурсию через let rec',
      xp: 35,
      theory: [
        { t: 'p', html: '<code>if</code> в F# — не инструкция, а <b>выражение</b>: оно возвращает значение, как тернарный оператор в других языках. Поэтому обе ветки обязаны давать результат одного типа — иначе компиляция упадёт.' },
        { t: 'code', code: `let sign x =
    if x > 0 then 1
    else -1` },
        { t: 'p', html: '<code>else</code> обязателен, когда результат используется: без него выражение вернёт <code>unit</code> (пустое значение), и типы не сойдутся. Цепочка условий строится через <code>elif</code> — сокращение от «else if»:' },
        { t: 'code', code: `let classify x =
    if x > 0 then "плюс"
    elif x = 0 then "ноль"
    else "минус"` },
        { t: 'h', html: 'Рекурсия: let rec' },
        { t: 'p', html: 'Рекурсивная функция объявляется словом <code>let rec</code> — так компилятор понимает, что имя функции видно внутри её же тела. Классика: сумма чисел от 1 до n — база <code>sumTo 0 = 0</code>, шаг <code>n + sumTo (n - 1)</code>. Сравнения в F# одиночные: <code>=</code> означает «равно», а не присваивание.' },
        { t: 'code', code: `let rec sumTo n =
    if n = 0 then 0
    else n + sumTo (n - 1)` },
        { t: 'warn', html: 'Забыл <code>rec</code> — компилятор не найдёт функцию внутри её тела; забыл <code>else</code> — типы веток не совпадут; забыл базу — рекурсия не остановится. Все три ошибки ловятся до запуска, а сообщения компилятора в F# на удивление внятные — читай их.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай программу: if-выражения и рекурсия с <code>let rec</code>. Что она выведет? Напиши по одной строке на каждый <code>printfn</code>, в порядке появления.</p>',
        code: `let rec sumTo n =
    if n = 0 then 0
    else n + sumTo (n - 1)

let classify x =
    if x > 0 then "плюс"
    elif x = 0 then "ноль"
    else "минус"

printfn "%s" (classify -5)
printfn "%s" (classify 0)
printfn "%d" (sumTo 10)`,
        answer: `минус
ноль
55`
      },
      hints: [
        'classify(-5): оба условия (x > 0 и x = 0) ложны — сработает ветка else.',
        'sumTo 10 складывает 10 + 9 + ... + 1 + 0 — сумму чисел от 1 до 10.',
        'Порядок вывода — как строки printfn идут в программе.'
      ],
      solution: `минус
ноль
55`
    },

    /* ---------- 4. Функции и списки ---------- */
    {
      id: 'fsharp-4',
      title: 'Функции и списки',
      goal: 'Объявлять функции let с параметром, вызывать их через пробел и строить списки через точки с запятой',
      xp: 40,
      theory: [
        { t: 'p', html: 'Функции — полноправные значения. Объявление: <code>let имя параметры = тело</code>. Ни скобок вокруг параметров (можно, но не принято), ни <code>return</code>: результат — значение последнего выражения тела.' },
        { t: 'code', code: `let double x = x * 2

let quad x = double (double x)

printfn "%d" (quad 3)   // 12` },
        { t: 'p', html: 'Вызов — через пробел: <code>double 7</code>. Скобки нужны только для группировки: <code>double (3 + 4)</code> — иначе <code>double 3 + 4</code> значило бы <code>(double 3) + 4</code>. Это самая частая ошибка переходного периода.' },
        { t: 'h', html: 'Списки' },
        { t: 'p', html: 'Список — значения в квадратных скобках, разделённые <b>точками с запятой</b>: <code>[1; 2; 3]</code>. Да, именно точки с запятой: запятая в F# собирает кортеж, и <code>[1, 2, 3]</code> — это список из одного кортежа. Ловушка номер один у новичков.' },
        { t: 'code', code: `let nums = [1; 2; 3]

let more = 0 :: nums      // [0; 1; 2; 3]

printfn "%A" more         // %A печатает значение как есть` },
        { t: 'p', html: 'Оператор <code>::</code> прицепляет элемент к списку слева. Формат <code>%A</code> печатает любое значение «как есть» — список покажется как <code>[0; 1; 2; 3]</code>. Полезные функции: <code>List.length nums</code> — длина, <code>List.sum nums</code> — сумма. И помни про композицию: маленькие функции вроде <code>quad</code> из <code>double</code> складываются в большие — так строится идиоматичный F#.' },
        { t: 'warn', html: 'Не смешивай типы: <code>double 3.5</code> для функции над int не скомпилируется — компилятор вывел тип <code>int -&gt; int</code> по телу функции. Одна функция — один тип параметров; для дробей понадобится своя версия.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви функцию <code>double</code>, удваивающую аргумент (<code>let double x = x * 2</code>). Создай список <code>nums</code> из трёх чисел (через точки с запятой!). Выведи через <code>printfn</code>: результаты <code>double 7</code> и <code>double 10</code> и сам список (формат <code>%A</code>).</p>',
        starter: `// TODO: объяви функцию double, удваивающую число

// TODO: создай список nums и выведи результаты через printfn`,
        rules: [
          { desc: 'Функция double объявлена через let с параметром', any: ['let\\s+double\\s+\\w+\\s*=', 'let\\s+double\\s*\\(\\s*\\w+\\s*\\)\\s*='] },
          { desc: 'В теле аргумент умножается на 2', any: ['\\w+\\s*\\*\\s*2\\b', '2\\s*\\*\\s*\\w+'] },
          { desc: 'Список объявлен литералом [число; число; ...] через точки с запятой', all: ['\\[\\s*\\d+\\s*;\\s*\\d+(\\s*;\\s*\\d+)*\\s*\\]'] },
          { desc: 'double вызывается с числом, есть вывод через printfn', all: ['double\\s+\\d', 'printfn\\s+'] },
          { desc: 'Пометок TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Функция: let double x = x * 2 — без скобок и return.',
        'Список: let nums = [1; 2; 3] — разделитель точка с запятой, не запятая!',
        'Вывод: printfn "%d" (double 7) и printfn "%A" nums.'
      ],
      solution: `let double x = x * 2

let nums = [1; 2; 3]

printfn "%d" (double 7)
printfn "%d" (double 10)
printfn "%A" nums`
    },

    /* ---------- 5. Идиомы: пайплайн и Option ---------- */
    {
      id: 'fsharp-5',
      title: 'Идиомы: пайплайн и Option',
      goal: 'Строить цепочки через |>, применять List.map/filter и понимать Option вместо null',
      xp: 45,
      theory: [
        { t: 'p', html: 'Пайплайн <code>|&gt;</code> — визитная карточка F#: <code>x |&gt; f</code> — то же, что <code>f x</code>, но читается слева направо: «возьми данные, прогони через шаг, потом ещё через один». Цепочки преобразований превращаются в историю про данные, а не в матрёшку скобок.' },
        { t: 'code', code: `[1; 2; 3; 4]
|> List.map (fun x -> x * 10)
// [10; 20; 30; 40]` },
        { t: 'p', html: '<code>fun x -&gt; ...</code> — лямбда, анонимная функция. <code>List.map</code> применяет её к каждому элементу, <code>List.filter</code> оставляет только те, для кого функция вернула <code>true</code>, <code>List.sum</code> суммирует, <code>List.length</code> считает элементы.' },
        { t: 'code', code: `[1; 2; 3; 4; 5]
|> List.filter (fun x -> x % 2 = 0)   // [2; 4]
|> List.map (fun x -> x * 100)        // [200; 400]` },
        { t: 'h', html: 'Option — значения, которого может не быть' },
        { t: 'p', html: 'Вместо <code>null</code> в F# — <code>Option</code>: результат есть — <code>Some значение</code>, нет — <code>None</code>. Так работают <code>List.tryHead</code> и <code>List.tryFind</code>: вместо исключения или null ты честно получаешь «может быть». Достать значение из Some можно сопоставлением с образцом.' },
        { t: 'warn', html: 'Не смешивай <code>Option</code> с обычными значениями: <code>Some 5</code> — это не 5, и арифметика с ним не пройдёт. Компилятор заставит разобрать оба случая — Some и None. Это и есть защита от «ошибки на миллиард долларов».' },
        { t: 'note', html: 'Пайплайн хорошо комбинируется: <code>[1..10] |&gt; List.filter ... |&gt; List.sum</code>. Диапазон <code>[1..10]</code> — быстрый способ получить список чисел от 1 до 10 без ручного перечисления.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что вернёт эта цепочка? Пайплайн <code>|&gt;</code> гонит список через два шага.</p><pre>[1; 2; 3; 4]
|&gt; List.filter (fun x -&gt; x % 2 = 0)
|&gt; List.map (fun x -&gt; x * 10)</pre>`,
        options: [
          '[20; 40]',
          '[10; 20; 30; 40]',
          '[2; 4]',
          '[40; 20]'
        ],
        correct: 0,
        explain: 'filter оставил чётные (2 и 4), затем map умножил каждый на 10 — получилось [20; 40]. Порядок шагов важен: поменяй их местами — и ответ изменится. [2; 4] — это результат только filter, без map.',
        solution: 0
      },
      hints: [
        'Сначала filter: кого оставит условие x % 2 = 0?',
        'Потом map: каждое оставшееся число умножается на 10.',
        'Списки печатаются через точки с запятой: [20; 40].'
      ],
      solution: 0
    },

    /* ---------- 6. Проект: учёт заказов ---------- */
    {
      id: 'fsharp-6',
      title: '🚀 Проект: учёт заказов',
      goal: 'Объявить record-тип, собрать список заказов и посчитать сумму цен через List.sumBy',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальный проект — учёт заказов. <b>Record</b> — тип с именованными полями: <code>type Order = { Item: string; Price: int }</code>. Теперь у данных есть смысл: не безликие кортежи, а заказы с названием и ценой, и опечататься в поле невозможно — компилятор проверит.' },
        { t: 'code', code: `type Order = { Item: string; Price: int }

let sample = { Item = "Кружка"; Price = 250 }` },
        { t: 'p', html: 'Разница тонкая, но важная: в объявлении типа поля с двоеточием (<code>Item: string</code>), в литерале — со знаком равенства (<code>Item = "Кружка"</code>). Достаётся поле точкой: <code>sample.Price</code>.' },
        { t: 'h', html: 'План' },
        { t: 'list', items: [
          '<code>type Order</code> с полями <code>Item: string</code> и <code>Price: int</code>;',
          'список <code>orders</code> из 2–3 литералов записи;',
          'сумма цен: <code>orders |&gt; List.sumBy (fun o -&gt; o.Price)</code>;',
          'вывод итога и количества (<code>List.length orders</code>) через <code>printfn</code>.'
        ] },
        { t: 'p', html: '<code>List.sumBy</code> — сумма и map в одном флаконе: для каждого заказа достаёт <code>o.Price</code> и всё складывает. Это идиоматичный F#: одна строчка вместо цикла. Если хочется по классике — то же самое через <code>List.map</code> и <code>List.sum</code> подряд.' },
        { t: 'note', html: 'После зачёта: добавь поле <code>Qty</code> (количество) и считай <code>o.Price * o.Qty</code>, найди самый дорогой заказ через <code>List.maxBy</code>, отфильтруй дорогие заказы через <code>List.filter</code>.' },
        { t: 'warn', html: 'В литерале записи поля разделяются <code>;</code>, и все поля обязательны: забудешь Price — компилятор ругнётся. И порядок: сначала <code>type</code>, потом литералы — тип должен быть известен к моменту создания значений.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Учёт заказов».</b> Объяви record-тип <code>Order</code> с полями <code>Item: string</code> и <code>Price: int</code>. Создай список <code>orders</code> из 2–3 заказов. Посчитай сумму цен через <code>List.sumBy</code> (или <code>List.map</code> + <code>List.sum</code>) и выведи её и количество заказов через <code>printfn</code>.</p>',
        starter: `// TODO: объяви record-тип Order с полями Item (string) и Price (int)

// TODO: создай список orders и посчитай сумму цен

printfn "Сумма: %d" 0`,
        rules: [
          { desc: 'Record-тип Order объявлен с полями Item (string) и Price (int)', all: ['type\\s+Order\\s*=\\s*\\{', 'Item\\s*:\\s*string', 'Price\\s*:\\s*int'] },
          { desc: 'Список минимум из двух record-литералов', any: ['\\{\\s*Item\\s*=[\\s\\S]*\\{\\s*Item\\s*=', '\\{\\s*Price\\s*=[\\s\\S]*\\{\\s*Price\\s*='] },
          { desc: 'Сумма цен через List.sumBy или List.map + List.sum', any: ['List\\.sumBy', 'List\\.map[\\s\\S]{0,200}List\\.sum', 'List\\.sum[\\s\\S]{0,200}List\\.map'] },
          { desc: 'Цена достаётся из поля (доступ через точку, например o.Price)', all: ['\\.Price\\b'] },
          { desc: 'Итог выводится через printfn', all: ['printfn\\s+'] },
          { desc: 'Пометок TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Тип: type Order = { Item: string; Price: int } — в объявлении двоеточия.',
        'Литералы: { Item = "Кружка"; Price = 250 } — в литерале знак = и точки с запятой между полями.',
        'Сумма: orders |> List.sumBy (fun o -> o.Price), количество: List.length orders.'
      ],
      solution: `type Order = { Item: string; Price: int }

let orders = [
    { Item = "Кружка"; Price = 250 }
    { Item = "Блокнот"; Price = 120 }
    { Item = "Рюкзак"; Price = 1500 }
]

let total = orders |> List.sumBy (fun o -> o.Price)

printfn "Заказов: %d" (List.length orders)
printfn "Сумма заказов: %d" total`
    },

    /* ---------- 7. Пайплайны и композиция ---------- */
    {
      id: 'fsharp-7',
      title: 'Пайплайны |> и композиция >>',
      goal: 'Строить конвейеры List.filter → List.map → List.sum и склеивать функции оператором >>',
      xp: 50,
      theory: [
        { t: 'p', html: 'Пайплайн <code>|&gt;</code> ты уже видел: <code>x |&gt; f</code> — то же, что <code>f x</code>, но читается слева направо. Настоящая сила раскрывается в длинных цепочках: список прогоняется через шаги как через конвейер, и каждый шаг — отдельная строка. Менять шаги местами легко, добавлять новые — ещё легче.' },
        { t: 'code', code: `[1..10]
|> List.filter (fun x -> x % 2 = 0)
|> List.map (fun x -> x * 3)
|> List.sum
// [2; 4; 6; 8; 10] → [6; 12; 18; 24; 30] → 90` },
        { t: 'p', html: 'Второй оператор — <b>композиция</b> <code>&gt;&gt;</code>: <code>let f = g &gt;&gt; h</code> строит новую функцию «сначала g, потом h». Разница тонкая, но важная: пайплайн гонит <b>данные</b> через шаги, а композиция склеивает <b>функции</b> в одну. Результат композиции — обычная функция, её можно передавать, хранить и сама подставлять в пайплайны.' },
        { t: 'code', code: `let double x = x * 2
let increment x = x + 1

let transform = double >> increment
// transform 5 = 11` },
        { t: 'list', items: [
          '<b>x |&gt; f</b> — применить функцию справа к данным слева;',
          '<b>g &gt;&gt; h</b> — композиция: сначала g, потом h;',
          '<b>List.filter / List.map / List.sum</b> — типовые шаги конвейера;',
          '<b>fun x -&gt; ...</b> — лямбда для одноразовых шагов;',
          '<b>[1..10]</b> — диапазон как источник данных.'
        ] },
        { t: 'warn', html: 'Пиши пробелы вокруг <code>&gt;&gt;</code>: без них компилятор может прочитать это как сдвиг разрядов. И следи за порядком в композиции: <code>double &gt;&gt; increment</code> — это «сначала удвой», а <code>increment &gt;&gt; double</code> — совсем другая функция: сначала плюс один, потом удвоение.' },
        { t: 'note', html: 'Композиция и пайплайн — близнецы: <code>x |&gt; g |&gt; h</code> даёт тот же результат, что <code>(g &gt;&gt; h) x</code>. В библиотеках F# (Giraffe, FsToolkit) конвейеры из мелких функций — основной стиль: собираешь поведение как из кубиков, и каждый кубик легко протестировать отдельно.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери конвейер: список <code>[1..10]</code> через <code>|&gt; List.filter</code> (оставь чётные), затем <code>|&gt; List.map</code> (умножь на 3), затем <code>|&gt; List.sum</code>. Отдельно объяви функцию-композицию через <code>&gt;&gt;</code> (например, <code>let transform = triple &gt;&gt; (fun x -&gt; x + 1)</code>) и выведи оба результата через <code>printfn</code>.</p>',
        starter: `// TODO: собери конвейер filter, map, sum и объяви композицию через >>

let even n = n % 2 = 0
let triple x = x * 3

printfn "Сумма: %d" 0`,
        rules: [
          { desc: 'Есть шаг конвейера |> List.filter', all: ['\\|>\\s*List\\.filter'] },
          { desc: 'Есть шаг конвейера |> List.map', all: ['\\|>\\s*List\\.map'] },
          { desc: 'Конвейер завершается |> List.sum', all: ['\\|>\\s*List\\.sum'] },
          { desc: 'Композиция функций через >>', all: ['>>'] },
          { desc: 'Результаты выводятся через printfn', all: ['printfn\\s+'] },
          { desc: 'Пометок TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Конвейер: [1..10] |> List.filter even |> List.map triple |> List.sum.',
        'Композиция: let transform = triple >> (fun x -> x + 1) — сначала triple, потом лямбда.',
        'Вывод: printfn "Сумма: %d" total и printfn "transform 5 = %d" (transform 5).'
      ],
      solution: `let even n = n % 2 = 0
let triple x = x * 3

let total =
    [1..10]
    |> List.filter even
    |> List.map triple
    |> List.sum

let transform = triple >> (fun x -> x + 1)

printfn "Сумма: %d" total
printfn "transform 5 = %d" (transform 5)`
    },

    /* ---------- 8. Discriminated Unions и match ---------- */
    {
      id: 'fsharp-8',
      title: 'Discriminated Unions и match',
      goal: 'Объявить DU с вариантами of-данных и разобрать его исчерпывающим match',
      xp: 50,
      theory: [
        { t: 'p', html: '<b>Discriminated Union</b> (размеченное объединение, DU) — тип, у которого есть несколько вариантов, и каждый вариант несёт свои данные: <code>type Shape = Circle of float | Rect of float * float</code>. Читается: фигура — это либо круг с радиусом, либо прямоугольник с шириной и высотой. Слово <code>of</code> описывает данные варианта.' },
        { t: 'code', code: `type Shape =
    | Circle of float
    | Rect of float * float

let c = Circle 1.0
let r = Rect (2.0, 3.0)` },
        { t: 'p', html: 'Разбирают DU конструкцией <code>match</code>: для каждого варианта — своя ветка с образцом, и данные варианта распаковываются в переменные прямо в образце. Match обязан быть <b>исчерпывающим</b>: забудешь ветку — компилятор предупредит, что какие-то варианты не покрыты. Это то, за что любят F#: нельзя «случайно» не обработать случай.' },
        { t: 'code', code: `let area shape =
    match shape with
    | Circle rad -> 3.14159 * rad * rad
    | Rect (w, h) -> w * h` },
        { t: 'list', items: [
          '<b>type X = | A of t | B of t</b> — объявление DU;',
          '<b>A 5</b> — создание значения (данные без скобок);',
          '<b>match x with | A v -&gt; ... | B v -&gt; ...</b> — разбор;',
          '<b>Rect (w, h)</b> — вариант-кортеж распаковывается в образце;',
          '<b>Option и Result</b> — тоже DU: Some/None, Ok/Err.'
        ] },
        { t: 'warn', html: 'Не путай создание и разбор: при создании данные идут без скобок вокруг имени — <code>Circle 1.0</code>, но вариант-кортеж в скобках — <code>Rect (2.0, 3.0)</code>. И не пытайся разобрать DU через if: у if нет доступа к данным варианта — только match.' },
        { t: 'note', html: 'DU повсюду в идиоматичном F#: состояния экрана (<code>Loading | Loaded of Data | Error of string</code>), парсинг, платежи. Ты уже пользовался DU не зная этого: <code>Option</code> с Some/None и <code>Result</code> с Ok/Err — стандартные DU-типы языка.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви <code>type Shape</code> с вариантами <code>Circle of float</code> и <code>Rect of float * float</code>. Напиши функцию <code>area</code> через <code>match</code>: круг — <code>3.14159 * r * r</code>, прямоугольник — <code>w * h</code> (кортеж распакуй в образце). Создай по одному значению каждого варианта, прогони через <code>List.map area</code> и выведи площади через <code>printfn</code>.</p>',
        starter: `// TODO: объяви type Shape с Circle of float и Rect of float * float

// TODO: напиши area через match и выведи площади через printfn`,
        rules: [
          { desc: 'DU Shape объявлен с конструкторами Circle и Rect (данные через of)', all: ['type\\s+Shape\\s*=', '\\|\\s*Circle\\s+of\\b', '\\|\\s*Rect\\s+of\\b'] },
          { desc: 'match разбирает значение на конструкторы', all: ['\\bmatch\\s+\\w+\\s+with\\b', '\\|\\s*Circle\\s+\\w+\\s*->', '\\|\\s*Rect\\s*\\(?'] },
          { desc: 'Вариант Rect распаковывает пару (w, h)', all: ['Rect\\s*\\(\\s*\\w+\\s*,\\s*\\w+\\s*\\)'] },
          { desc: 'Функция area объявлена через let', all: ['\\blet\\s+area\\b'] },
          { desc: 'Созданы значения и есть вывод printfn', all: ['Circle\\s+\\d', 'Rect\\s*\\(\\s*\\d', 'printfn\\s+'] },
          { desc: 'Пометок TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Объявление: type Shape = | Circle of float | Rect of float * float — каждый вариант на своей строке.',
        'Match: match shape with | Circle rad -> ... | Rect (w, h) -> ... — данные распаковываются в образце.',
        'Значения: let shapes = [ Circle 1.0; Rect (2.0, 3.0) ], затем shapes |> List.map area |> List.iter (fun a -> printfn "%f" a).'
      ],
      solution: `type Shape =
    | Circle of float
    | Rect of float * float

let area shape =
    match shape with
    | Circle rad -> 3.14159 * rad * rad
    | Rect (w, h) -> w * h

let shapes = [ Circle 1.0; Rect (2.0, 3.0) ]

shapes
|> List.map area
|> List.iter (fun a -> printfn "Площадь: %f" a)`
    },

    /* ---------- 9. Records и immutable update ---------- */
    {
      id: 'fsharp-9',
      title: 'Records и immutable update',
      goal: 'Копировать record с изменениями через синтаксис { rec with Field = ... }',
      xp: 45,
      theory: [
        { t: 'p', html: 'Record — тип с именованными полями: <code>type User = { Name: string; Age: int }</code>. В объявлении типа поля отделяются двоеточиями, в литерале — знаками равенства: <code>{ Name = "Аня"; Age = 25 }</code>, поля разделяются точками с запятой. Доступ — через точку: <code>user.Age</code>.' },
        { t: 'code', code: `type User = { Name: string; Age: int }

let user = { Name = "Аня"; Age = 25 }` },
        { t: 'p', html: 'Значения неизменяемы: поменять поле напрямую нельзя. Вместо этого есть синтаксис <b>копирования с заменой</b> — <code>{ user with Age = 26 }</code>. Читается: «возьми user, создай копию, замени Age, остальное оставь». Старая запись остаётся нетронутой — у тебя две независимые величины.' },
        { t: 'code', code: `let older = { user with Age = user.Age + 1 }
// user: Age = 25, older: Age = 26

let renamed = { user with Name = "Миша" }
// можно заменить несколько полей через ;` },
        { t: 'list', items: [
          '<b>type X = { F1: t1; F2: t2 }</b> — объявление record;',
          '<b>{ F1 = v; F2 = v }</b> — литерал;',
          '<b>{ rec with F = v }</b> — копия с заменами;',
          '<b>rec.F</b> — доступ к полю;',
          '<b>две записи равны</b>, если равны все поля (сравнение по значению).'
        ] },
        { t: 'warn', html: 'Поле после <code>with</code> должно существовать в типе записи — опечатка ловится компилятором. И не забывай: литерал записи обязан указать <b>все</b> поля, а копия с <code>with</code> берёт недостающие из оригинала — поэтому для «изменить одно поле» идиоматичен именно with.' },
        { t: 'note', html: 'Copy-and-update — основа всей работы со состоянием в функциональном стиле: вместо мутации строится новая версия данных. Ты встретишь тот же синтаксис в Elm (<code>{ model | count = ... }</code>) — и в следующем финальном проекте он понадобится при проведении операций по счёту.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни программу: типы двух полей записи, слово копирования-с-заменой <code>with</code> и имя обновляемого поля в последней копии. Два вывода в конце уже написаны — проверь себя: <code>older</code> должен показать «Миша 26», <code>renamed</code> — тоже новое имя, но прежний возраст.</p>',
        code: `type User = { Name: {{0}}; Age: {{1}} }

let user = { Name = "Аня"; Age = 25 }

let older = { user {{2}} Age = user.Age + 1 }

let renamed = { user with {{3}} = "Миша" }

printfn "%s %d" older.Name older.Age
printfn "%s %d" renamed.Name renamed.Age`,
        blanks: [
          { answer: 'string' },
          { answer: 'int' },
          { answer: 'with' },
          { answer: 'Name' }
        ],
        ci: false
      },
      hints: [
        'В объявлении типа поля с двоеточиями: Name: string, Age: int — типы с маленькой буквы.',
        'Копия с заменой: { user with Age = user.Age + 1 } — оригинал не меняется.',
        'В renamed меняется только имя — поле Name.'
      ],
      solution: ['string', 'int', 'with', 'Name']
    },

    /* ---------- 10. Проект: банковский счёт ---------- */
    {
      id: 'fsharp-10',
      title: '🚀 Проект: банковский счёт',
      goal: 'Провести операции по счёту: DU Transaction, record Account, apply с match и List.fold',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — модель банковского счёта без единой мутации. Транзакции описываются DU: <code>Deposit of int</code> и <code>Withdraw of int</code>. Счёт — record с именем владельца и балансом. Функция <code>apply</code> применяет транзакцию к счёту и возвращает новый счёт, а список операций прогоняется через <code>List.fold</code> — та же свёртка, что в <code>List.sum</code>, только «накопитель» теперь счёт.' },
        { t: 'h', html: 'План' },
        { t: 'list', items: [
          '<b>type Transaction = Deposit of int | Withdraw of int</b> — операции;',
          '<b>type Account = { Owner: string; Balance: int }</b> — счёт;',
          '<b>apply : Account -&gt; Transaction -&gt; Account</b> через match;',
          '<b>{ account with Balance = ... }</b> — новая копия счёта;',
          '<b>operations |&gt; List.fold apply start</b> — итоговый баланс.'
        ] },
        { t: 'code', code: `let apply account tx =
    match tx with
    | Deposit amount -> { account with Balance = account.Balance + amount }
    | Withdraw amount ->
        if account.Balance >= amount then
            { account with Balance = account.Balance - amount }
        else
            account` },
        { t: 'p', html: 'Разбор. Match распаковывает сумму из варианта прямо в образце — <code>amount</code>. Каждая ветка возвращает новый счёт через копию с <code>with</code>: старый не портится, и историю можно хранить как список версий. Недостаток средств — просто возвращаем счёт без изменений: операция «не прошла». В настоящем банке вернули бы <code>Result</code> из уровня 8-идиом — <code>Ok account</code> или <code>Err "недостаточно средств"</code>.' },
        { t: 'p', html: 'Свёртка собирает финал: <code>operations |&gt; List.fold apply start</code> — fold берёт стартовый счёт и по очереди применяет каждую транзакцию. Для операций [пополнение 50, снятие 30, снятие 500, пополнение 20] от баланса 100 итог — 140: снятие 500 не прошло, потому что на счету было 120. Проверь руками — это лучшая проверка apply.' },
        { t: 'warn', html: 'Match обязан покрыть оба варианта — Deposit и Withdraw, иначе компилятор не пропустит. В копии счёта пиши <code>with</code>, а не попытку присвоить поле. И не забудь пайплайн: <code>|&gt; List.fold apply start</code> — apply передаётся в fold как функция без вызова.' },
        { t: 'note', html: 'Куда расти: верни из apply <code>Result Account string</code> и аккуратно обработай отказ, добавь транзакцию <code>Transfer of Account</code>, а историю операций храни в поле <code>History: Transaction list</code> — копией с with. Это уже архитектура настоящего платёжного ядра, где нельзя молча менять состояние.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Банковский счёт».</b> Объяви <code>type Transaction</code> с вариантами <code>Deposit of int</code> и <code>Withdraw of int</code> и record <code>Account</code> с полями <code>Owner: string</code> и <code>Balance: int</code>. Напиши <code>apply</code>: match по транзакции, пополнение и снятие возвращают новый счёт через <code>{ account with Balance = ... }</code>, снятие сверх баланса возвращает счёт без изменений. Создай стартовый счёт, список из 3–4 операций и прогони их через <code>|&gt; List.fold apply start</code>; итог выведи через <code>printfn</code>.</p>',
        starter: `// TODO: объяви type Transaction (Deposit/Withdraw) и record Account с Balance

// TODO: напиши apply с match и прогони операции через |> List.fold

let start = { Owner = "Аня"; Balance = 100 }

printfn "Итог: %d" 0`,
        rules: [
          { desc: 'type Transaction объявлен DU с Deposit и Withdraw (of)', all: ['type\\s+Transaction\\s*=', '\\|\\s*Deposit\\s+of\\b', '\\|\\s*Withdraw\\s+of\\b'] },
          { desc: 'Record Account с полем Balance: int', all: ['type\\s+Account\\s*=\\s*\\{', 'Balance\\s*:\\s*int'] },
          { desc: 'Функция apply объявлена через let', all: ['\\blet\\s+apply\\b'] },
          { desc: 'match разбирает оба конструктора', all: ['\\bmatch\\s+\\w+\\s+with\\b', '\\|\\s*Deposit\\s+\\w+\\s*->', '\\|\\s*Withdraw\\s+\\w+\\s*->'] },
          { desc: 'Новый счёт строится копией { ... with Balance = ... }', all: ['\\bwith\\s+Balance\\s*='] },
          { desc: 'Операции прогоняются через |> List.fold', all: ['\\|>\\s*List\\.fold'] },
          { desc: 'Вывод через printfn', all: ['printfn\\s+'] },
          { desc: 'Пометок TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'DU: type Transaction = | Deposit of int | Withdraw of int — данные после of.',
        'apply: match tx with | Deposit amount -> { account with Balance = account.Balance + amount } — снятие по тому же образцу с проверкой баланса.',
        'Финал: let final = operations |> List.fold apply start, затем printfn "%s: %d" final.Owner final.Balance.'
      ],
      solution: `type Transaction =
    | Deposit of int
    | Withdraw of int

type Account = { Owner: string; Balance: int }

let apply account tx =
    match tx with
    | Deposit amount -> { account with Balance = account.Balance + amount }
    | Withdraw amount ->
        if account.Balance >= amount then
            { account with Balance = account.Balance - amount }
        else
            account

let start = { Owner = "Аня"; Balance = 100 }

let operations = [ Deposit 50; Withdraw 30; Withdraw 500; Deposit 20 ]

let final = operations |> List.fold apply start

printfn "%s: %d" final.Owner final.Balance`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас скрипта и запуск',
      code: `// main.fsx — просто код, без каркаса
printfn "Привет, CodeQuest!"
printfn "Сумма: %d" (2 + 2)

// запуск: dotnet fsi main.fsx
// форматы: %d int, %s string, %f float, %b bool, %A как есть`
    },
    {
      title: 'let и типы',
      code: `let age = 25          // int — тип выведен сам
let name = "Аня"      // string
let pi = 3.14         // float (обязательно с точкой)
let ok = true         // bool
let x: int = 5        // аннотация — по желанию
// let x2 = 6 — новая привязка затеняет старую
// x = 6 — ошибка: значения неизменяемы
// 5 / 2 = 2 (целочисленное), 5.0 / 2.0 = 2.5`
    },
    {
      title: 'Функции',
      code: `let double x = x * 2      // объявление
double 7                  // вызов пробелом
double (3 + 4)            // скобки — для группировки
let rec sumTo n =         // рекурсия — let rec
    if n = 0 then 0
    else n + sumTo (n - 1)
fun x -> x * 2            // лямбда
// if..then..else — выражение: else обязателен`
    },
    {
      title: 'Списки',
      code: `let nums = [1; 2; 3]      // точки с запятой!
let more = 0 :: nums      // [0; 1; 2; 3]
let rng = [1..10]         // диапазон
List.length nums          // 3
List.sum nums             // 6
printfn "%A" nums         // [1; 2; 3]
// [1, 2, 3] — список из одного кортежа (ловушка!)`
    },
    {
      title: 'Пайплайн и List',
      code: `[1; 2; 3; 4]
|> List.filter (fun x -> x % 2 = 0)   // [2; 4]
|> List.map (fun x -> x * 10)         // [20; 40]

List.sumBy (fun o -> o.Price) orders  // сумма полей
List.tryHead []                       // None — option
// x |> f — то же, что f x, но читается слева направо`
    },
    {
      title: 'Record и Option',
      code: `type Order = { Item: string; Price: int }

let o = { Item = "Кружка"; Price = 250 }
o.Price                       // 250 — доступ через точку

// Option: Some значение | None
match List.tryHead nums with
| Some x -> printfn "%d" x
| None -> printfn "пусто"`
    },
    {
      title: 'Пайплайн и композиция',
      code: `[1..10]
|> List.filter (fun x -> x % 2 = 0)
|> List.map (fun x -> x * 3)
|> List.sum            // 90

let f = double >> increment   // композиция
// x |> f  — то же, что f x
// g >> h  — сначала g, потом h
// пробелы вокруг >> обязательны`
    },
    {
      title: 'DU, match и record with',
      code: `type Shape =
    | Circle of float
    | Rect of float * float

let area s =
    match s with
    | Circle r -> 3.14159 * r * r
    | Rect (w, h) -> w * h

type Account = { Owner: string; Balance: int }
{ acc with Balance = acc.Balance + 50 }
// with — копия с заменами, оригинал не тронут
// match обязан покрыть все варианты DU`
    }
  ]
};
