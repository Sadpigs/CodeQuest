'use strict';
/* ============ CodeQuest — курс GDScript ============
   Язык движка Godot. Код в приложении не запускается:
   задания проверяются структурным анализом (regex по сырому коду),
   квизами, «предскажи вывод» и заполнением пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.gdscript = {
  id: 'gdscript',
  title: 'GDScript',
  emoji: '🎮',
  color: '#5b9bd5',
  lang: 'gdscript',
  tagline: 'Godot: сигналы, классы, счёт очков — 10 уровней',
  description: 'Встроенный язык движка Godot (Хуан Линицки и команда, релиз движка — 2014): питон-подобный синтаксис, мгновенный запуск без компиляции и прямая связь с узлами, сценами и сигналами. За 10 уровней — от первого скрипта до подписок на сигналы через connect, классов с @export и @onready, массивов и словарей и проекта «Счётчик очков для игры».',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'gdscript-1',
      title: 'Первая программа',
      goal: 'Собрать первый скрипт Godot: extends Node, функцию _ready() и вывод через print()',
      xp: 30,
      theory: [
        { t: 'p', html: 'GDScript — встроенный язык движка Godot: бесплатного open-source движка, на котором сделаны Brotato, Dome Keeper и тысячи инди-игр. Его придумали создатели Godot во главе с Хуаном Линицки (Juan Linietsky), и впервые он вышел вместе с движком в 2014 году. Синтаксис почти как у Python: отступы вместо скобок и минимум формальностей, но язык заточен под игры — он знает всё про узлы, сцены, кадры и ввод игрока.' },
        { t: 'h', html: 'Сцены и узлы' },
        { t: 'p', html: 'В Godot всё построено из <b>узлов</b> (Node): спрайт — узел, звук — узел, камера — узел. Узлы собираются в дерево — <b>сцену</b>. Скрипт прикрепляется к узлу и оживляет его: узел получает сообщения движка и отвечает своим поведением. Твой первый скрипт будет прикреплён к самому простому узлу — Node.' },
        { t: 'code', code: `extends Node

func _ready():
    print("Привет, Godot!")` },
        { t: 'p', html: 'Разберём каркас. <code>extends Node</code> — «мой скрипт наследуется от класса Node», то есть ведёт себя как узел. <code>func _ready():</code> объявляет функцию <b>_ready</b>: движок сам вызовет её один раз, когда узел появится в сцене. Всё, что с отступом после двоеточия, — тело функции. <code>print(...)</code> пишет текст в панель Output внизу редактора.' },
        { t: 'list', items: [
          '<b>extends</b> — от какого класса узла наследуется скрипт;',
          '<b>func</b> — объявление функции;',
          '<b>_ready()</b> — срабатывает при появлении узла в сцене;',
          '<b>print()</b> — вывод в консоль Output;',
          '<b>отступ</b> — тело функции выделяется отступом, скобок нет.'
        ] },
        { t: 'note', html: 'Как запустить: создай в Godot проект, добавь узел Node в сцену, правой кнопкой — «Прикрепить скрипт» (Attach Script). Запуск проекта — F5, вывод появится в панели Output. Отдельно файлы .gd не запускаются: скрипт всегда живёт внутри сцены и выполняется вместе с ней.' },
        { t: 'warn', html: 'После <code>func _ready():</code> обязано стоять двоеточие, а тело — отступ (4 пробела или Tab, но не вперемешку). Фигурных скобок и точек с запятой в GDScript нет — как в Python. Забудешь отступ — движок покажет Parse Error, и проект не запустится.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первый скрипт Godot: каркас <code>extends Node</code> / <code>func _ready()</code> уже дан — допиши в теле функции вывод фразы <code>Привет, Godot!</code> через <code>print(...)</code> и убери пометку-заглушку. По желанию добавь вторую строку вывода.</p>',
        starter: `extends Node

func _ready():
    # TODO: выведи приветствие
    pass`,
        rules: [
          { desc: 'Скрипт начинается с extends — класс узла объявлен', all: ['\\bextends\\s+\\w+'] },
          { desc: 'Функция _ready объявлена, тело с отступом', all: ['func\\s+_ready\\s*\\(\\s*\\)\\s*:\\s*\\n\\s+\\S'] },
          { desc: 'Есть вывод через print(...)', all: ['\\bprint\\s*\\('] },
          { desc: 'Выведена фраза "Привет, Godot!"', all: ['"Привет, Godot!"'] },
          { desc: 'Код готов: заглушек TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас extends Node / func _ready(): уже правильный — менять его не нужно.',
        'Внутри _ready допиши print("Привет, Godot!") — с двоеточием в конце объявления функции и отступом в теле.',
        'Фразу пиши точно: Привет, Godot! — в двойных кавычках, с запятой и восклицательным знаком.'
      ],
      solution: `extends Node

func _ready():
    print("Привет, Godot!")
    print("Скрипт готов к работе.")`
    },

    /* ---------- 2. Переменные и типы ---------- */
    {
      id: 'gdscript-2',
      title: 'Переменные и типы',
      goal: 'Создавать переменные через var и указывать типы int, float, String и bool через двоеточие',
      xp: 35,
      theory: [
        { t: 'p', html: 'Переменная в GDScript создаётся словом <code>var</code>: <code>var hp = 100</code>. Язык динамический — тип можно не указывать, и он выведется из значения. Но настоящие Godot-проекты почти всегда пишут тип явно через двоеточие: <code>var hp: int = 100</code>. Так редактор подсказывает методы и ловит ошибки ещё до запуска игры.' },
        { t: 'code', code: `var hp: int = 100        # целое
var speed: float = 5.5   # дробное
var hero: String = "Аня" # текст
var alive: bool = true   # истина/ложь` },
        { t: 'table', head: ['Тип', 'Хранит', 'Примеры'], rows: [
          ['<code>int</code>', 'целые числа', '<code>42</code>, <code>-7</code>, <code>0</code>'],
          ['<code>float</code>', 'дробные числа', '<code>5.5</code>, <code>-0.1</code>, <code>2.0</code>'],
          ['<code>String</code>', 'текст', '<code>"привет"</code>, <code>"Godot 4"</code>'],
          ['<code>bool</code>', 'истина/ложь', '<code>true</code>, <code>false</code>']
        ] },
        { t: 'p', html: 'Обрати внимание на написание: <code>String</code> — с большой буквы (это класс движка), остальные типы — маленькими. Строки — в двойных кавычках. Числа с точкой — float: <code>5.5</code>, даже <code>5.0</code>. Всё без точки — int.' },
        { t: 'p', html: 'Если тип не указан, GDScript подберёт его сам: <code>var coins = 10</code> станет int, <code>var name = "Аня"</code> — String. Пока тип не зафиксирован аннотацией, переменной можно присвоить значение другого типа — динамическая типизация это разрешает.' },
        { t: 'warn', html: 'С аннотацией тип строгий: <code>var hp: int = 100</code>, а потом <code>hp = "сто"</code> — ошибка! int и float тоже не смешиваются неявно: <code>int(3.9)</code> отрежет дробную часть и даст 3 — без всякого округления.' },
        { t: 'note', html: 'Константы объявляются словом <code>const</code>: <code>const MAX_HP = 100</code> — изменить нельзя. Имена переменных пишутся в стиле snake_case: <code>max_speed</code>, <code>coin_count</code> — так принято во всём сообществе Godot.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни объявления переменных правильными типами: здоровье — целое, скорость — дробное, имя героя — строка, флаг живости — логическое. А для последней строки подставь ключевое слово, которое создаёт переменную.</p>',
        code: `extends Node

func _ready():
    var hp: {{0}} = 100
    var speed: {{1}} = 5.5
    var hero: {{2}} = "Аня"
    var alive: {{3}} = true
    {{4}} level = 3
    print(hero, hp, speed, alive, level)`,
        blanks: [
          { answer: 'int' },
          { answer: 'float' },
          { answer: 'String' },
          { answer: 'bool' },
          { answer: 'var' }
        ],
        ci: false
      },
      hints: [
        'Типы пишутся после двоеточия: String — с большой буквы, остальные — с маленькой.',
        'Целые — int, числа с точкой — float, истина/ложь — bool.',
        'Переменную создаёт ключевое слово var — его и забыли в последней строке.'
      ],
      solution: ['int', 'float', 'String', 'bool', 'var']
    },

    /* ---------- 3. Условия и циклы ---------- */
    {
      id: 'gdscript-3',
      title: 'Условия и циклы',
      goal: 'Ветвить программу через if/elif/else и повторять действия через for i in range()',
      xp: 40,
      theory: [
        { t: 'p', html: 'Программа становится интересной, когда умеет выбирать дорогу. Условие в GDScript: <code>if</code>, выражение, двоеточие — и тело с отступом. Фигурных скобок нет, отступ решает всё. Альтернатива — <code>elif</code> (сокращение от «else if»), а замыкающий <code>else</code> ловит всё, что не подошло выше.' },
        { t: 'code', code: `var hp = 30

if hp > 50:
    print("в порядке")
elif hp > 0:
    print("ранен")
else:
    print("повержен")` },
        { t: 'p', html: 'Ветки проверяются сверху вниз: сработает первая истинная, остальные пропустятся. Сравнения: <code>==</code>, <code>!=</code>, <code>&gt;</code>, <code>&lt;</code>, <code>&gt;=</code>, <code>&lt;=</code>. Логические связки — словами, как в Python: <code>and</code>, <code>or</code>, <code>not</code>.' },
        { t: 'p', html: 'Цикл <code>for</code> перебирает последовательности, и главный помощник здесь — <code>range()</code>: <code>range(5)</code> даёт числа 0, 1, 2, 3, 4; <code>range(1, 6)</code> — от 1 до 5, правая граница не включается; третий аргумент — шаг: <code>range(0, 10, 2)</code> — это 0, 2, 4, 6, 8.' },
        { t: 'code', code: `for i in range(1, 4):
    print(i)
# выведет 1, 2, 3 — каждое на новой строке` },
        { t: 'list', items: [
          '<b>range(n)</b> — числа от 0 до n-1;',
          '<b>range(a, b)</b> — от a до b-1;',
          '<b>total += i</b> — сокращение для total = total + i;',
          '<b>str(число)</b> — превращает число в строку;',
          '<b>print("total = " + str(total))</b> — собери строку сам и выведи аккуратно.'
        ] },
        { t: 'warn', html: 'Двоеточие после <code>if</code> и <code>for</code> — обязательно, как и отступ в теле. И не путай <code>=</code> (присваивание) с <code>==</code> (сравнение): <code>if n = 5</code> — синтаксическая ошибка.' },
        { t: 'note', html: 'Есть и цикл <code>while</code> — «пока условие истинно». А для разбора вариантов в Godot 4 появился <code>match</code> — дальний родственник switch; загляни в него, когда освоишь базу.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай скрипт Godot и напиши, что он выведет в панель Output — по одной строке на каждый print, в порядке появления.</p>',
        code: `extends Node

func _ready():
    var total = 0
    for i in range(1, 6):
        total += i
    print("total = " + str(total))

    var n = 7
    if n < 5:
        print("мало")
    elif n < 10:
        print("средне")
    else:
        print("много")`,
        answer: `total = 15
средне`
      },
      hints: [
        'range(1, 6) — это 1, 2, 3, 4, 5. Проследи, как total копит сумму, шаг за шагом.',
        'n = 7: проверка n < 5 ложна, проверка n < 10 истинна — какая ветка сработает?',
        'str(total) превращает число в текст, а + склеивает строки: получи точный вид первой строки вывода.'
      ],
      solution: `total = 15
средне`
    },

    /* ---------- 4. Функции и class_name ---------- */
    {
      id: 'gdscript-4',
      title: 'Функции и class_name',
      goal: 'Писать функции с параметрами, типами и возвратом значения, регистрировать класс через class_name',
      xp: 45,
      theory: [
        { t: 'p', html: 'Функции объявляются словом <code>func</code>, параметры перечисляются в скобках, а возвращаемый тип указывается после стрелки <code>-&gt;</code>. Тело — с отступом. Значение наружу отдаёт <code>return</code>: он завершает функцию и передаёт результат тому, кто вызвал.' },
        { t: 'code', code: `func add_coins(a: int, b: int) -> int:
    return a + b` },
        { t: 'p', html: 'Типизация параметров необязательна — <code>func add_coins(a, b):</code> тоже сработает. Но с типами редактор подсказывает и проверяет за тебя. <code>return</code> без значения возвращает <code>null</code> — «ничего». Вызов обычный: <code>var total = add_coins(3, 4)</code>. Функции, объявленные в скрипте узла, — это методы узла: у тебя уже есть встроенные <code>_ready()</code> и <code>_process(delta)</code>, их вызывает сам движок, а собственные функции ты зовёшь сам — из _ready или друг из друга.' },
        { t: 'h', html: 'class_name' },
        { t: 'p', html: 'Строка <code>class_name CoinBag</code> регистрирует скрипт как глобальный класс: имя <code>CoinBag</code> становится доступно из любого другого скрипта проекта, а сам класс появляется в библиотеке при создании узлов. Обычно class_name ставят в начале файла, рядом с extends.' },
        { t: 'code', code: `class_name CoinBag
extends Node

# Теперь CoinBag — полноценный класс движка` },
        { t: 'note', html: 'Параметрам можно задавать значения по умолчанию: <code>func greet(name: String = "друг"):</code> — вызов <code>greet()</code> подставит «друг». Имена функций в GDScript — snake_case: <code>take_damage</code>, <code>spawn_enemy</code>.' },
        { t: 'warn', html: 'Не путай <code>class_name</code> с внутренними классами <code>class X:</code> — те объявляются внутри файла и работают иначе. И не вызывай <code>_ready()</code> вручную: его зовёт движок в нужный момент сам.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери «кошелёк»: зарегистрируй класс <code>class_name CoinBag</code>, объяви функцию <code>add_coins(a: int, b: int) -&gt; int</code>, возвращающую сумму, и вызови её в <code>_ready</code>, а результат выведи через <code>print(...)</code>.</p>',
        starter: `extends Node

# TODO: зарегистрируй класс кошелька
# TODO: объяви функцию с двумя параметрами и возвратом суммы

func _ready():
    # TODO: вызови функцию и выведи результат
    pass`,
        rules: [
          { desc: 'Класс зарегистрирован через class_name', all: ['\\bclass_name\\s+\\w+'] },
          { desc: 'Функция add_coins объявлена с двумя параметрами', all: ['func\\s+add_coins\\s*\\([^)]*,[^)]*\\)'] },
          { desc: 'Указан возвращаемый тип -> и есть return со значением', all: ['func\\s+add_coins[^\\n]*->', '\\breturn\\s+\\S+'] },
          { desc: 'add_coins вызывается в коде', any: ['=\\s*add_coins\\s*\\(', '\\(\\s*add_coins\\s*\\(', 'print[^\\n]*add_coins'] },
          { desc: 'Результат печатается через print, заглушек TODO нет', all: ['\\bprint\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'class_name CoinBag поставь рядом с extends — на верхнем уровне файла, не внутри функции.',
        'Объявление с типами: func add_coins(a: int, b: int) -> int: и return a + b с отступом.',
        'В _ready: var total = add_coins(3, 4), затем print("монет стало:", total) или print с str().'
      ],
      solution: `extends Node

class_name CoinBag

func add_coins(a: int, b: int) -> int:
    return a + b

func _ready():
    var total = add_coins(3, 4)
    print("монет стало: " + str(total))`
    },

    /* ---------- 5. Идиомы движка ---------- */
    {
      id: 'gdscript-5',
      title: 'Идиомы движка: сигналы и векторы',
      goal: 'Разобраться с сигналами signal/emit, вектором Vector2 и аннотацией @onready',
      xp: 40,
      theory: [
        { t: 'p', html: '<b>Сигналы</b> — главный механизм событий Godot: «что-то произошло, кому надо — реагируйте». Узел объявляет сигнал словом <code>signal</code>, испускает его при событии, а другие узлы подписываются через <code>connect</code>. Это слабая связь: монета ничего не знает про счётчик интерфейса — просто кричит в эфир.' },
        { t: 'code', code: `signal coin_collected(total)

func collect(amount: int) -> void:
    coin_collected.emit(amount)` },
        { t: 'p', html: 'В Godot 4 сигнал испускается как <code>coin_collected.emit(...)</code>; старый стиль <code>emit_signal("coin_collected", amount)</code> тоже работает. Подписка: <code>coin_collected.connect(метод)</code> — и метод выполнится при каждом испускании. Так устроены кнопки интерфейса: у них есть встроенный сигнал <code>pressed</code>.' },
        { t: 'p', html: '<b>Vector2</b> — двухмерный вектор: пара чисел (x, y) с готовой математикой. Перемещение узла: <code>position += Vector2(0, -10)</code>. Важная ловушка: ось Y в Godot направлена <b>вниз</b> — начало координат в левом верхнем углу экрана. Поэтому -10 по Y — это движение вверх.' },
        { t: 'p', html: '<code>@onready</code> — аннотация «выполни присваивание прямо перед _ready». Она нужна для получения ссылок на дочерние узлы: <code>@onready var label = $Label</code>. Знак доллара — сокращение для <code>get_node("Label")</code>. Без @onready строка на уровне класса выполнится слишком рано и даст null.' },
        { t: 'list', items: [
          '<b>signal имя(аргумент)</b> — объявить собственный сигнал;',
          '<b>.emit(...)</b> — испустить сигнал;',
          '<b>.connect(метод)</b> — подписаться на сигнал;',
          '<b>@onready var x = $Имя</b> — ссылка на дочерний узел;',
          '<b>@export var speed = 300</b> — показать переменную в Инспекторе редактора.'
        ] },
        { t: 'warn', html: 'Не путай присваивание и смещение: <code>position = Vector2(0, -50)</code> телепортирует узел в точку (0, −50), а <code>position += Vector2(0, -50)</code> сдвинет его <b>относительно</b> текущего места. Разница между этими строками — источник половины багов новичка.' },
        { t: 'note', html: 'Ещё две рабочие лошадки: <code>_process(delta)</code> выполняется каждый кадр (delta — доля секунды с прошлого кадра), а <code>preload("res://файл.tscn")</code> заранее загружает ресурс. Об этом — в документации Godot, когда заведёшь свои первые сцены.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>В скрипте игрока выполняется строка <code>position += Vector2(0, -50)</code>. Что произойдёт с узлом?</p>',
        options: [
          'Узел телепортируется в точку (0, -50)',
          'Узел сдвинется вниз на 50 пикселей',
          'Узел сдвинется вверх на 50 пикселей',
          'Ошибка: Vector2 нельзя прибавлять к position'
        ],
        correct: 2,
        explain: 'Vector2(0, -50) — смещение: 0 по оси X и −50 по Y. Ось Y в Godot направлена вниз, поэтому отрицательное смещение двигает узел ВВЕРХ на 50 пикселей. Телепортом была бы строка position = Vector2(0, -50): присваивание заменяет координаты, а += прибавляет смещение к текущим.',
        solution: 2
      },
      hints: [
        'Вспомни, куда направлена ось Y в Godot — вверх или вниз?',
        '+= прибавляет смещение к текущим координатам, а = заменяет их целиком.',
        'Отрицательное смещение по Y в Godot — это движение вверх по экрану.'
      ],
      solution: 2
    },

    /* ---------- 6. Проект: скрипт счётчика монет ---------- */
    {
      id: 'gdscript-6',
      title: '🚀 Проект: скрипт счётчика монет',
      goal: 'Собрать игровой скрипт: счётчик-переменная, функция пополнения с возвратом и собственный сигнал',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальный проект — скрипт-счётчик монет, как в настоящей игре: узел хранит количество монет, метод <code>collect</code> пополняет счёт и кричит об этом сигналом, а <code>_ready</code> прогоняет сценарий и печатает итог. Здесь сходится весь курс: переменные с типами, функции с возвратом, сигнал.' },
        { t: 'list', items: [
          '<b>signal coin_collected(total)</b> — собственный сигнал;',
          '<b>var coins: int = 0</b> — счётчик монет;',
          '<b>func collect(amount: int) -&gt; int</b> — пополнить счёт, испустить сигнал, вернуть итог;',
          '<b>в _ready</b> — два вызова collect с числами и вывод результата через print.'
        ] },
        { t: 'code', code: `extends Node

signal coin_collected(total)

var coins: int = 0

func collect(amount: int) -> int:
    coins += amount
    coin_collected.emit(coins)
    return coins

func _ready():
    collect(5)
    collect(10)
    print("монет: " + str(coins))` },
        { t: 'p', html: 'Порядок в collect: сначала изменить счётчик, потом испустить сигнал (он понесёт новое значение), потом вернуть итог. В реальной игре на сигнал подписался бы UI-узел и обновил надпись «монет: 15» — без единой строчки, связывающей монеты и интерфейс напрямую. Это и есть сила сигналов.' },
        { t: 'note', html: 'Сигнал объявляют на уровне класса, не внутри функции. Вызови collect дважды с числами (например, 5 и 10) — проверка ищет именно два вызова с числами. После зачёта попробуй подписаться: coin_collected.connect(метод) и обновляй текст в $Label при каждом испускании.' },
        { t: 'warn', html: 'Не забудь стрелку возврата <code>-&gt; int</code> и <code>return</code> в collect — проверка их ищет. Сигнал испусти через <code>coin_collected.emit(...)</code> или <code>emit_signal("coin_collected", ...)</code> — оба стиля засчитываются. И убери все пометки-заглушки из финального кода.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Скрипт счётчика монет».</b> Объяви сигнал <code>coin_collected</code> и переменную <code>coins: int = 0</code>. Напиши функцию <code>collect(amount: int) -&gt; int</code>: прибавь amount к coins, испусти сигнал и верни итог. В <code>_ready</code> вызови collect дважды с числами (например, 5 и 10) и выведи итог через <code>print(...)</code>.</p>',
        starter: `extends Node

# TODO: объяви сигнал coin_collected и счётчик coins

func _ready():
    # TODO: напиши функцию collect и вызови её дважды
    pass`,
        rules: [
          { desc: 'Объявлен собственный сигнал coin_collected', all: ['\\bsignal\\s+coin_collected\\b'] },
          { desc: 'Сигнал испускается: .emit(...) или emit_signal(...)', any: ['coin_collected\\.emit\\s*\\(', 'emit_signal\\s*\\(\\s*"coin_collected"', "emit_signal\\s*\\(\\s*'coin_collected'"] },
          { desc: 'Счётчик coins объявлен через var', all: ['\\bvar\\s+coins\\b'] },
          { desc: 'Функция collect объявлена с параметром', all: ['func\\s+collect\\s*\\(\\s*\\w+'] },
          { desc: 'collect возвращает значение: тип -> и return', all: ['func\\s+collect[^\\n]*->', '\\breturn\\b'] },
          { desc: 'collect вызван дважды с числами, итог выведен, TODO нет', all: ['collect\\s*\\(\\s*\\d+[\\s\\S]*collect\\s*\\(\\s*\\d+', '\\bprint\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Сигнал объявляется на верхнем уровне: signal coin_collected(total).',
        'Внутри collect: coins += amount, затем coin_collected.emit(coins), затем return coins.',
        'В _ready — два вызова с числами (collect(5) и collect(10)) и print("монет: " + str(coins)).'
      ],
      solution: `extends Node

signal coin_collected(total)

var coins: int = 0

func collect(amount: int) -> int:
    coins += amount
    coin_collected.emit(coins)
    return coins

func _ready():
    collect(5)
    collect(10)
    print("монет: " + str(coins))`
    },

    /* ---------- 7. Сигналы: signal и connect ---------- */
    {
      id: 'gdscript-7',
      title: 'Сигналы: signal и connect',
      goal: 'Подключать обработчики к сигналам через connect, испускать сигнал emit-ом и знать встроенные сигналы узлов',
      xp: 45,
      theory: [
        { t: 'p', html: 'На прошлом уровне монеты «кричали» сигналом — но в комнате никого не было. Время второй половины механики: <b>подписка</b>. Метод <code>connect</code> приписывает сигналу функцию-обработчик: сигнал испущен — Godot сам обойдёт список подписчиков и вызовет каждого. Так игра остаётся связной без жёстких связей: счётчик не знает про интерфейс, интерфейс — про счётчик.' },
        { t: 'code', code: `signal level_up(new_level)

func _ready():
    level_up.connect(_on_level_up)   # подписка
    level_up.emit(2)                 # испускание

func _on_level_up(new_level):
    print("новый уровень: " + str(new_level))` },
        { t: 'p', html: 'В <code>connect</code> передаётся <b>ссылка на функцию</b> — просто имя без скобок. Конвенция именования: <code>_on_</code> плюс имя сигнала — по такому имени сразу видно, на что реагирует метод. При каждом <code>emit</code> движок передаёт обработчику аргументы сигнала: здесь это новый уровень. Подписок может быть сколько угодно — все сработают в порядке подключения.' },
        { t: 'h', html: 'Встроенные сигналы узлов' },
        { t: 'p', html: 'Свои сигналы объявлять необязательно — у каждого узла они уже есть: у кнопки <code>pressed</code>, у таймера <code>timeout</code>, у зоны <code>body_entered</code>. Подписка выглядит одинаково: <code>button.pressed.connect(_on_start_pressed)</code>. Это основной способ узнать о действиях игрока: код не опрашивает кнопку, а ждёт звонка. Полный список сигналов любого класса — в документации Godot, вкладка Signals.' },
        { t: 'code', code: `func _ready():
    var timer = Timer.new()
    timer.wait_time = 2.0
    timer.timeout.connect(_on_tick)
    add_child(timer)
    timer.start()

func _on_tick():
    print("тик!")` },
        { t: 'warn', html: 'Классическая ошибка — скобки: <code>connect(_on_tick())</code> вызовет функцию прямо здесь, а подключит её <b>результат</b> (то есть null). Ссылка на функцию — без скобок. И подписывайся в <code>_ready</code>: до него дочерние узлы могут ещё не существовать.' },
        { t: 'note', html: 'Снять подписку можно <code>disconnect</code>, проверить наличие — <code>is_connected</code>. Обработчик ничего не возвращает испускателю: сигнал — объявление, а не вопрос-ответ. В больших проектах сигналы соединяют и через панель Node в редакторе — там те же connect, только мышкой.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери «звонок о повышении»: объяви собственный сигнал <code>level_up</code>, подключи к нему обработчик в <code>_ready</code> через <code>connect</code>, испусти сигнал через <code>emit</code> и напиши функцию-обработчик <code>_on_...</code>, которая печатает сообщение через <code>print</code>.</p>',
        starter: `extends Node

# TODO: объяви собственный сигнал с одним аргументом
# TODO: подключи к нему обработчик и испусти сигнал
# TODO: напиши функцию-обработчик с выводом

func _ready():
    pass`,
        rules: [
          { desc: 'Объявлен собственный сигнал', all: ['\\bsignal\\s+\\w+'] },
          { desc: 'Есть обработчик _on_... с телом', all: ['func\\s+_on_\\w+\\s*\\([^)]*\\)[^\\n]*:\\s*\\n\\s+\\S'] },
          { desc: 'Обработчик подписан через connect', all: ['\\.connect\\s*\\(\\s*\\w'] },
          { desc: 'Сигнал испускается через .emit', all: ['\\.emit\\s*\\('] },
          { desc: 'Есть вывод через print, заглушек TODO нет', all: ['\\bprint\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'signal level_up(new_level) — объявление на верхнем уровне, рядом с extends.',
        'В _ready: level_up.connect(_on_level_up) — имя обработчика без скобок, это ссылка на функцию.',
        'Обработчик: func _on_level_up(new_level): с print("новый уровень: " + str(new_level)). И не забудь level_up.emit(2).'
      ],
      solution: `extends Node

signal level_up(new_level)

func _ready():
    level_up.connect(_on_level_up)
    level_up.emit(2)

func _on_level_up(new_level):
    print("новый уровень: " + str(new_level))`
    },

    /* ---------- 8. Классы: class_name, extends Node, onready ---------- */
    {
      id: 'gdscript-8',
      title: 'Классы: class_name, extends Node, onready',
      goal: 'Собрать класс игрового объекта: class_name, @export-настройка, ссылка на дочерний узел через @onready и $',
      xp: 50,
      theory: [
        { t: 'p', html: 'Каждый скрипт Godot — уже класс: <code>extends</code> объявляет, от какого узла он наследуется, а <code>class_name</code> даёт классу имя, видимое всему проекту. Поверх этого у класса есть три повседневных инструмента: <code>@export</code> выносит переменную в Инспектор редактора, <code>@onready</code> со знаком доллара даёт ссылку на дочерний узел, а обычные <code>var</code>-поля хранят состояние. Разберём их на живом примере.' },
        { t: 'code', code: `class_name Player
extends Node

@export var speed: int = 300
@onready var label = $Label

var hp: int = 100

func take_damage(amount: int) -> void:
    hp -= amount
    label.text = "HP: " + str(hp)` },
        { t: 'p', html: 'Строка <code>@export var speed: int = 300</code> появится в панели Инспектора — дизайнер уровня подкрутит скорость, не открывая код. <code>@onready var label = $Label</code> ищет дочерний узел с именем Label: знак доллара — сокращение для <code>get_node("Label")</code>, а аннотация откладывает присваивание до момента, когда дерево сцены уже собрано. Метод <code>take_damage</code> меняет поле и тут же обновляет надпись — состояние и вид связаны.' },
        { t: 'h', html: 'Наследование своих классов' },
        { t: 'p', html: 'Один класс может наследоваться от другого: <code>class_name Boss extends Player</code> — босс получает все поля и методы игрока. Переопределить унаследованную функцию можно, объявив её заново с тем же именем, — движок вызовет твою версию. Это тот же принцип, что и с <code>_ready</code>: ты переопределяешь поведение базового класса.' },
        { t: 'code', code: `class_name Boss
extends Player

func take_damage(amount: int) -> void:
    # у босса броня: урон вдвое слабее
    hp -= amount / 2` },
        { t: 'warn', html: '<code>$Label</code> ищет узел среди детей того узла, к которому прикреплён скрипт; не найдёт — ошибка «Node not found» при запуске сцены. Без <code>@onready</code> простое <code>var label = $Label</code> выполнится слишком рано — дерева ещё нет, и скрипт упадёт. Соблюдай порядок в начале файла: class_name, extends, потом поля с аннотациями.' },
        { t: 'note', html: 'Это каркас любого игрового объекта в Godot: поля — состояние, @export — настройки, @onready и знак доллара — связи со сценой, методы — поведение. Сигналы из прошлого уровня вписываются сюда же — их объявляют рядом с полями. Собранный класс появляется в диалоге добавления узлов как компонент сцены.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери класс врага: зарегистрируй <code>class_name Enemy</code>, унаследуй его от <code>Node</code>, добавь настройку через <code>@export</code> и ссылку на дочерний узел через <code>@onready</code> и <code>$</code>. Объяви метод, который меняет состояние (поле) и печатает сообщение через <code>print</code>.</p>',
        starter: `extends Node

# TODO: зарегистрируй класс врага и добавь настройку (аннотация-экспорт)
# TODO: добавь ссылку на дочерний узел Label (аннотация + знак доллара)
# TODO: объяви метод, меняющий поле и печатающий сообщение

func _ready():
    pass`,
        rules: [
          { desc: 'Класс зарегистрирован через class_name', all: ['\\bclass_name\\s+\\w+'] },
          { desc: 'Класс наследуется от узла: extends', all: ['\\bextends\\s+\\w+'] },
          { desc: 'Есть @export-переменная — настройка для Инспектора', all: ['@export\\s+var\\s+\\w+'] },
          { desc: 'Есть @onready-ссылка на дочерний узел через $', all: ['@onready\\s+var\\s+\\w+\\s*=\\s*\\$\\w+'] },
          { desc: 'Метод меняет состояние и печатает, заглушек TODO нет', all: ['func\\s+\\w+\\s*\\([^)]*\\)[^\\n]*:\\s*\\n\\s+\\S', '\\bprint\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Порядок в начале файла: class_name Enemy, extends Node, затем поля с аннотациями.',
        'Ссылка на дочерний узел: @onready var label = $Label — аннотация откладывает присваивание до _ready.',
        'Метод: func take_damage(amount: int) -> void: внутри hp -= amount и print(...).'
      ],
      solution: `class_name Enemy
extends Node

@export var speed: int = 200
@onready var label = $Label

var hp: int = 50

func take_damage(amount: int) -> void:
    hp -= amount
    print("у врага осталось hp: " + str(hp))
    if hp <= 0:
        label.text = "враг повержен"`
    },

    /* ---------- 9. Массивы и словари Godot ---------- */
    {
      id: 'gdscript-9',
      title: 'Массивы и словари Godot: TypedArray, Dictionary',
      goal: 'Хранить наборы данных: Array с append и size, типизированные массивы Array[int], Dictionary с доступом по ключу',
      xp: 50,
      theory: [
        { t: 'p', html: 'До сих пор данные жили по одному: hp, coins, speed. Но игра — это волны врагов, инвентарь и таблицы рекордов, где значений много. Для наборов в GDScript два контейнера: <b>массив</b> Array — упорядоченный список с индексами, и <b>словарь</b> Dictionary — пары «ключ—значение». У обоих богатый набор методов, и оба перебираются обычным for.' },
        { t: 'code', code: `var waves: Array[int] = [3, 5, 8]
waves.append(12)          # [3, 5, 8, 12]
print(waves.size())       # 4
print(waves[0])           # 3 — индексация с нуля

var loot = {"gold": 120, "potion": 3}
loot["gold"] += 30
print(loot["gold"])       # 150
print(loot.has("potion")) # true` },
        { t: 'p', html: 'Квадратные скобки создают массив: элементы лежат по индексам с нуля, <code>append</code> дописывает в конец, <code>size()</code> возвращает длину. Фигурные — словарь: ключи могут быть строками, числами, чем угодно; обращение по ключу — в квадратных скобках, проверка наличия — <code>has()</code>. Запись <code>Array[int]</code> — <b>типизированный массив</b>: он обещает хранить только int, и редактор сразу укажет на попытку положить внутрь строку.' },
        { t: 'list', items: [
          '<b>waves.append(x)</b> — добавить элемент в конец;',
          '<b>waves.size()</b> — количество элементов;',
          '<b>waves.remove_at(i)</b> — удалить элемент по индексу;',
          '<b>loot["gold"]</b> — прочитать или записать значение по ключу;',
          '<b>loot.has("gold")</b> — есть ли такой ключ;'
        ] },
        { t: 'p', html: 'Словари удобны для игровых сущностей без собственного класса: параметры уровня, настройки врага, таблица рекордов. У словаря есть <code>keys()</code> и <code>values()</code> — списки ключей и значений. Оба контейнера перебираются без индексов: <code>for w in waves</code> даст элементы массива, <code>for k in loot</code> — ключи словаря.' },
        { t: 'warn', html: 'Индекс за границами массива — ошибка времени выполнения: <code>waves[10]</code> на четырёх элементах остановит игру. Словарь мягче: чтение отсутствующего ключа вернёт <code>null</code> — и тихо сломает арифметику где-то дальше. Проверяй <code>size()</code> и <code>has()</code>, когда данными не управляешь.' },
        { t: 'note', html: 'Тип можно и не указывать: <code>var waves = [3, 5]</code> — обычный Array, подойдёт что угодно. TypedArray — стиль зрелых проектов: автодополнение точнее, ошибки виднее. Подробности — в описании классов Array и Dictionary официальной документации Godot.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни скрипт: укажи тип для типизированного массива, метод дописывания в конец, метод размера, проверку ключа словаря и ключ, по которому читается значение зелий. Ответ вводи так, как он будет стоять в коде — включая кавычки.</p>',
        code: `extends Node

func _ready():
    var waves: {{0}}[int] = [3, 5, 8]
    waves.{{1}}(12)             # дописать волну в конец
    print(waves.{{2}}())        # сколько волн накопилось

    var loot = {"gold": 120, "potion": 3}
    loot["gold"] += 30
    print(loot.{{3}}("gold"))   # есть ли монеты в добыче
    print(loot[{{4}}])          # сколько зелий`,
        blanks: [
          { answer: 'Array' },
          { answer: 'append' },
          { answer: 'size' },
          { answer: 'has' },
          { answer: '"potion"' }
        ]
      },
      hints: [
        'Типизированный массив: Array[int] — имя класса с большой буквы.',
        'Дописывает в конец append, длину возвращает size.',
        'Проверка ключа — has("gold"); значение по ключу читается так: loot["potion"].'
      ],
      solution: ['Array', 'append', 'size', 'has', '"potion"']
    },

    /* ---------- 10. 🚀 Проект: счётчик очков ---------- */
    {
      id: 'gdscript-10',
      title: '🚀 Проект: счётчик очков для игры',
      goal: 'Собрать класс очков: сигнал score_changed, счётчик, метод add с испусканием сигнала и подписка в _ready',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — узел-счётчик очков, сердце любой аркады. Паттерн из настоящих Godot-игр: один узел владеет счётом и объявляет сигнал <code>score_changed</code>; все, кому интересно, — интерфейс, звук «плюс один», сохранения — подписываются сами. Счётчик не знает ни про кого из них: он просто считает и объявляет.' },
        { t: 'list', items: [
          '<b>extends Node</b> — класс-узел;',
          '<b>signal score_changed(new_score)</b> — событие «очки изменились»;',
          '<b>var score: int = 0</b> — состояние счётчика;',
          '<b>func add(points: int) -&gt; int</b> — прибавить очки, испустить сигнал, вернуть итог;',
          '<b>_ready</b> — подписка через connect и сценарий из двух вызовов add;',
          '<b>_on_score_changed</b> — обработчик, который печатает новый счёт.'
        ] },
        { t: 'code', code: `extends Node

signal score_changed(new_score)

var score: int = 0

func add(points: int) -> int:
    score += points
    score_changed.emit(score)
    return score

func _ready():
    score_changed.connect(_on_score_changed)
    add(10)
    add(15)

func _on_score_changed(new_score):
    print("очки: " + str(new_score))` },
        { t: 'p', html: 'Порядок важен: подписка должна случиться <b>до</b> первого <code>add</code>, иначе первые сигналы уйдут в пустоту. Метод <code>add</code> сперва меняет счёт и только потом испускает сигнал — подписчики получают уже новое значение. Аргумент сигнала избавляет обработчики от обращения к чужим полям: данные едут внутри события.' },
        { t: 'p', html: 'Это и есть слабая связь, ради которой придумали сигналы: счётчик не знает про интерфейс ничего, интерфейс знает только имя сигнала. Поменяешь счётчик на новый — подписчики даже не заметят, пока событие остаётся прежним. В большой игре такой узел выносят в автозагрузку, и он становится доступен из любой сцены.' },
        { t: 'warn', html: 'Не вызывай <code>_on_score_changed</code> вручную — его зовёт механизм сигналов. Не путай роли: испускает владелец сигнала, подписываются слушатели; connect без emit — тихий телефон, emit без connect — крик в пустой комнате. Заглушки-комментарии из стартера убери.' },
        { t: 'note', html: 'Куда развивать: добавь сигнал <code>game_over</code> и испусти его из add, когда счёт перевалит за порог; подпиши на него перезапуск сцены. Второй шаг — автозагрузка: Project Settings → Autoload, и счётчик станет глобальным. Третий — вместо print обновляй надпись $Label: интерфейс уже готов.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Счётчик очков для игры».</b> Объяви сигнал <code>score_changed</code> и счётчик <code>score: int = 0</code>. Напиши функцию <code>add(points: int)</code>: прибавь очки, испусти сигнал с новым счётом, верни итог. В <code>_ready</code> подключи обработчик через <code>connect</code> и добавь очки дважды. Обработчик <code>_on_score_changed</code> печатает счёт через <code>print</code>.</p>',
        starter: `extends Node

# TODO: объяви сигнал изменения очков и счётчик с нулём
# TODO: напиши функцию добавления очков: прибавь, испусти сигнал, верни итог
# TODO: в _ready подключи обработчик и добавь очки дважды
# TODO: напиши обработчик сигнала с выводом

func _ready():
    pass`,
        rules: [
          { desc: 'Скрипт наследуется от Node', all: ['\\bextends\\s+Node\\b'] },
          { desc: 'Объявлен сигнал score_changed', all: ['\\bsignal\\s+score_changed\\b'] },
          { desc: 'Счётчик score объявлен через var', all: ['\\bvar\\s+score\\b'] },
          { desc: 'Функция add объявлена с параметром очков', all: ['func\\s+add\\s*\\(\\s*\\w+'] },
          { desc: 'Сигнал испускается: score_changed.emit(...)', all: ['score_changed\\.emit\\s*\\('] },
          { desc: 'В _ready есть подписка через connect', all: ['\\.connect\\s*\\('] },
          { desc: 'Обработчик _on_score_changed печатает через print, заглушек TODO нет', all: ['func\\s+_on_score_changed', '\\bprint\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Объявления на верхнем уровне: signal score_changed(new_score) и var score: int = 0 — рядом с extends.',
        'В add: score += points, затем score_changed.emit(score), затем return score.',
        'В _ready сначала score_changed.connect(_on_score_changed), потом add(10) и add(15). Обработчик печатает через print.'
      ],
      solution: `extends Node

signal score_changed(new_score)

var score: int = 0

func add(points: int) -> int:
    score += points
    score_changed.emit(score)
    return score

func _ready():
    score_changed.connect(_on_score_changed)
    add(10)
    add(15)

func _on_score_changed(new_score):
    print("очки: " + str(new_score))`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас скрипта',
      code: `extends Node

func _ready():
    print("Привет, Godot!")
# F5 — запуск проекта, вывод в панели Output
# скрипт прикрепляется к узлу сцены`
    },
    {
      title: 'Переменные и типы',
      code: `var hp: int = 100
var speed: float = 5.5
var hero: String = "Аня"   # с большой буквы!
var alive: bool = true
var coins = 10             # тип выведется сам
const MAX_HP = 100         # константа
# имена — snake_case: max_speed`
    },
    {
      title: 'Условия и циклы',
      code: `if hp > 50:
    print("в порядке")
elif hp > 0:
    print("ранен")
else:
    print("повержен")

for i in range(1, 6):   # 1..5
    total += i
# range(0, 10, 2) — с шагом 2
# while условие: — цикл «пока»`
    },
    {
      title: 'Функции и классы',
      code: `func add(a: int, b: int) -> int:
    return a + b

var total = add(3, 4)   # вызов
func greet(name: String = "друг"):
    print("Привет, ", name)

class_name CoinBag   # глобальный класс
extends Node`
    },
    {
      title: 'Сигналы',
      code: `signal coin_collected(total)

coin_collected.emit(15)            # испустить
coin_collected.connect(_on_coins)  # подписаться

func _on_coins(total):
    print("монет:", total)
# старый стиль: emit_signal("coin_collected", 15)`
    },
    {
      title: 'Движок под рукой',
      code: `@onready var label = $Label  # дочерний узел
@export var speed = 300      # видно в Инспекторе

position += Vector2(0, -50)  # вверх на 50 (Y вниз!)
rotation_degrees += 90
# _process(delta) — каждый кадр
# _input(event) — ввод игрока
# int(3.9) → 3, str(42) → "42"`
    },
    {
      title: 'Массивы и словари',
      code: `var waves: Array[int] = [3, 5, 8]
waves.append(12)          # в конец
waves.size()              # длина
waves[0]                  # первый (с нуля!)

var loot = {"gold": 120, "potion": 3}
loot["gold"] += 30
loot.has("potion")        # true
loot.keys()               # ["gold", "potion"]
# for w in waves: — перебор без индексов`
    },
    {
      title: 'Сигналы: connect и обработчики',
      code: `signal score_changed(new_score)

score_changed.connect(_on_score)   # подписаться
score_changed.emit(10)             # испустить
score_changed.disconnect(_on_score)

func _on_score(new_score):
    print("очки:", new_score)
# конвенция: _on_<имя сигнала>
# скобки у обработчика НЕ нужны — это ссылка
# встроенные: pressed, timeout, body_entered`
    }
  ]
};
