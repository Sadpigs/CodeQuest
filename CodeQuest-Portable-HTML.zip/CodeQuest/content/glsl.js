'use strict';
/* ============ CodeQuest — курс GLSL ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.glsl = {
  id: 'glsl',
  title: 'GLSL',
  emoji: '🌈',
  color: '#9a4fd0',
  lang: 'glsl',
  tagline: 'Шейдеры и графика: 10 уровней',
  description: 'Язык шейдеров OpenGL/WebGL — код, который выполняется на каждом пикселе экрана. Игры, спецэффекты, Shadertoy-шедевры и нейро-рендеры живут на нём. За 10 уровней: vec-типы, varying-переменные, built-in функции, uv-координаты, время, шум и финальный шейдер-эффект.',

  levels: [

    {
      id: 'glsl-1',
      title: 'Шейдер = программа пикселя',
      goal: 'Понять fragment shader: один вызов на пиксель',
      xp: 30,
      theory: [
        { t: 'p', html: 'Fragment shader — функция, вызываемая GPU для КАЖДОГО пикселя независимо. Главная выходная переменная — <code>gl_FragColor</code> (vec4: R, G, B, A — все от 0.0 до 1.0). Минимальный шейдер красит весь экран одним цветом.' },
        { t: 'code', code: `// GLSL ES (WebGL)
precision mediump float;

void main() {
    gl_FragColor = vec4(1.0, 0.5, 0.2, 1.0);
    //            красный зелёный синий альфа
}` },
        { t: 'p', html: 'Тип vec — вектор из float: <code>vec2</code> (2 компоненты), <code>vec3</code>, <code>vec4</code>. Конструктор собирает из чисел и других векторов: <code>vec4(v.rgb, 1.0)</code>. Компоненты доступны по-разному: <code>v.r = v.x = v[0]</code> — свиззлинг: <code>v.rgb = v.bgr;</code> переставит каналы!' },
        { t: 'list', items: [
          '<b>vec4(r, g, b, a)</b> — цвет пикселя;',
          'значения 0.0 — 1.0 (не 0-255!);',
          '<b>precision mediump float;</b> — точность (WebGL обязателен);',
          'свиззлинг: v.xyz, v.rgba, v.xx'
        ] },
        { t: 'note', html: 'В GLSL нет циклов с переменными границами (в старых версиях), нет указателей, нет printf. Зато есть массовый параллелизм: миллионы вызовов main() за кадр.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери шейдер чёрного непрозрачного цвета.</p>',
        code: `precision mediump float;

void main() {
    gl_FragColor = vec4({{0}}, 1.0);
}`,
        blanks: [
          { answer: '0.0' }
        ],
        ci: false
      },
      hints: [
        'Чёрный = RGB(0, 0, 0).',
        'vec4 сжат: vec4(0.0, 1.0) — RGB из одного числа.'
      ],
      solution: `precision mediump float;

void main() {
    gl_FragColor = vec4(0.0, 1.0);
}`
    },

    {
      id: 'glsl-2',
      title: 'varying и интерполяция',
      goal: 'Понять поток данных: attribute → varying → fragment',
      xp: 35,
      theory: [
        { t: 'p', html: 'Данные текут по конвейеру: <b>attribute</b> (вершинные данные) → <b>vertex shader</b> → <b>varying</b> (передаётся в fragment, ИНТЕРПОЛИРУЕТСЯ по треугольнику!) → fragment shader. Именно интерполяция даёт градиенты: значения вершин плавно растекаются по грани.' },
        { t: 'code', code: `// vertex shader:
attribute vec3 a_position;
varying vec3 v_color;

void main() {
    gl_Position = vec4(a_position, 1.0);
    v_color = a_position * 0.5 + 0.5;   // -1..1 → 0..1
}

// fragment shader:
varying vec3 v_color;
void main() {
    gl_FragColor = vec4(v_color, 1.0);
}` },
        { t: 'p', html: 'Трюк <code>pos * 0.5 + 0.5</code> — перевод координат из диапазона -1..1 (NDC — нормализованные координаты устройства) в 0..1 цветов. Вершина слева получит красный, справа — зелёный, а пиксели между — плавный переход. Это и есть GPU-градиент.' },
        { t: 'note', html: 'Varying = «меняющийся»: GPU сам вычисляет барицентрическую интерполяцию по треугольнику. Современные версии (GLSL 3.0+) переименовали: in/out, но механика та же — самое важное понятие графики.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Вершина A имеет v_color = красный, вершина B — зелёный. Каким будет цвет середины отрезка AB в fragment shader?</p>',
        options: [
          `Красный`,
          `Зелёный`,
          `Жёлтый`,
          `Чёрный`
        ],
        correct: 2,
        explain: 'Интерполяция даёт 50% красного + 50% зелёного = жёлтый. GPU усредняет varying-значения автоматически — так рождаются градиенты.'
      },
      hints: [
        'Значения интерполируются линейно.',
        'Смешай красный и зелёный пополам.'
      ],
      solution: `Жёлтый`
    },

    {
      id: 'glsl-3',
      title: 'uniform: данные снаружи',
      goal: 'Передавать в шейдер константы кадра: время, разрешение, мышь',
      xp: 40,
      theory: [
        { t: 'p', html: '<code>uniform</code> — глобальная константа, одинаковая для всех пикселей кадра, задаваемая с CPU: время, разрешение, позиция мыши. Стандарт Shadertoy: <code>uniform float iTime;</code>, <code>uniform vec2 iResolution;</code>, <code>uniform vec2 iMouse;</code>.' },
        { t: 'code', code: `uniform float iTime;        // секунды
uniform vec2 iResolution;   // ширина, высота

void main() {
    // мигающий красный канал:
    float blink = 0.5 + 0.5 * sin(iTime * 3.14159);
    gl_FragColor = vec4(blink, 0.0, 0.0, 1.0);
}` },
        { t: 'p', html: 'sin(iTime) колеблется от −1 до 1; формула <code>0.5 + 0.5 * sin(t)</code> переводит в 0..1 — «пульс». Любая анимация шейдера — функции времени: sin, cos, fract, mix. Uniform меняется один раз на кадр — дёшево, в отличие от attribute.' },
        { t: 'list', items: [
          '<b>uniform</b> — одинаков для всех пикселей кадра;',
          '<b>iTime</b> — время от старта (Shadertoy);',
          '<b>0.5 + 0.5*sin(t)</b> — пульс 0..1;',
          'частота = множитель t.'
        ] },
        { t: 'note', html: 'CPU-сторона: glUniform1f(location, value) каждый кадр. Шейдерные часы живут в uniform — сам шейдер состояния не хранит (функциональный стиль по определению!).' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери пульсирующую яркость: синус времени в диапазон 0..1.</p>',
        code: `uniform float iTime;

void main() {
    float pulse = 0.5 + 0.5 * {{0}}(iTime * 2.0);
    gl_FragColor = vec4({{1}}, pulse, 0.0, 1.0);
}`,
        blanks: [
          { answer: 'sin' },
          { answer: 'pulse' }
        ],
        ci: false
      },
      hints: [
        'Колебание — синус от времени.',
        'Результат кладётся в зелёный канал.'
      ],
      solution: ['sin', 'pulse']
    },

    {
      id: 'glsl-4',
      title: 'UV-координаты',
      goal: 'Вычислять позицию пикселя 0..1 и строить фигуры',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>gl_FragCoord.xy</code> — пиксели экрана. Нормализованные UV: <code>vec2 uv = gl_FragCoord.xy / iResolution;</code> — теперь uv от 0 до 1 по экрану. Канон Shadertoy: центр в середине — <code>uv = (uv - 0.5) * 2.0</code> → −1..1 с центром 0.' },
        { t: 'code', code: `void main() {
    vec2 uv = gl_FragCoord.xy / iResolution;   // 0..1
    uv = (uv - 0.5) * 2.0;                     // -1..1, центр 0

    // круг в центре: длина вектора = расстояние до центра
    float d = length(uv);
    float circle = step(0.5, d);   // 0 внутри, 1 снаружи
    // или инверт: 1 - step(...)
    gl_FragColor = vec4(vec3(1.0 - circle), 1.0);
}` },
        { t: 'p', html: 'Главные функции фигур: <code>length(v)</code> — расстояние, <code>step(edge, x)</code> — резкая ступенька (0 до edge, 1 после), <code>smoothstep(a, b, x)</code> — мягкий переход, <code>mix(a, b, t)</code> — линейная смесь. Комбинация mix+smoothstep — любой градиент по маске.' },
        { t: 'code', code: `// мягкий светящийся круг:
float glow = smoothstep(0.6, 0.0, length(uv));
vec3 col = mix(vec3(0.0), vec3(0.2, 0.6, 1.0), glow);` },
        { t: 'note', html: 'Поля расстояний (SDF) — философия Shadertoy: цвет пикселя = функция его ПОЗИЦИИ. Круг, квадрат, сердце — всё описывается уравнением расстояния. length(uv) — твой первый SDF.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Нормализуй координаты в UV 0..1 (деление на iResolution) и вычисли расстояние до центра через length.</p>',
        starter: `void main() {
    TODO
}`,
        rules: [
          { desc: 'UV нормализация', all: ['gl_FragCoord\\.xy\\s*/\\s*iResolution'] },
          { desc: 'length от uv', all: ['length\\s*\\(\\s*uv\\s*\\)'] }
        ],
        note: 'vec2 uv = gl_FragCoord.xy / iResolution; / float d = length(uv);'
      },
      hints: [
        'Делим пиксели на разрешение.',
        'Расстояние — length вектора uv.'
      ],
      solution: `void main() {
    vec2 uv = gl_FragCoord.xy / iResolution;
    float d = length(uv);
    gl_FragColor = vec4(vec3(d), 1.0);
}`
    },

    {
      id: 'glsl-5',
      title: 'mix, step, smoothstep',
      goal: 'Освоить три столпа композиции цвета',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>mix(a, b, t)</code> — a·(1−t) + b·t: линейная интерполяция всего (числа, цвета, векторы). <code>step(edge, x)</code> — резкая граница. <code>smoothstep(a, b, x)</code> — гермитов S-переход между a и b: главный инструмент мягкости — резкие края выглядят дёшево, гладкие — дорого.' },
        { t: 'code', code: `vec3 night = vec3(0.05, 0.07, 0.15);
vec3 day   = vec3(0.9, 0.75, 0.4);

// закат по вертикали: uv.y сверху 1, снизу 0
vec3 sky = mix(day, night, smoothstep(0.0, 0.6, uv.y));

// резкая земля:
float ground = step(uv.y, 0.2);
sky = mix(sky, vec3(0.1, 0.25, 0.1), ground);

gl_FragColor = vec4(sky, 1.0);` },
        { t: 'p', html: 'Слои складываются через mix: сначала небо, поверх — земля. Каждый слой — своя маска (step/smoothstep от координат). Десяток таких слоёв — и на экране пейзаж. Это как Photoshop-слои, только в математике.' },
        { t: 'note', html: 'smoothstep с edge0 > edge1 (в обратную сторону) — инвертированный переход: плавная маска «от центра». Многие glow-эффекты — просто smoothstep(0.5, 0.0, dist).' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь функции: смесь цветов и мягкая ступень.</p>',
        code: `vec3 col = {{0}}(colorA, colorB, t);
float mask = {{1}}(0.0, 0.5, d);`,
        blanks: [
          { answer: 'mix' },
          { answer: 'smoothstep' }
        ],
        ci: false
      },
      hints: [
        'Смешивание — mix.',
        'Мягкий переход — smoothstep.'
      ],
      solution: ['mix', 'smoothstep']
    },

    {
      id: 'glsl-6',
      title: 'fract и модульные паттерны',
      goal: 'Повторяющиеся узлы через fract и mod',
      xp: 50,
      theory: [
        { t: 'p', html: '<code>fract(x)</code> — дробная часть (x − floor(x)): пилá 0..1, идеальна для повторов. <code>mod(x, y)</code> — остаток. <code>floor(x)</code> — целая часть вниз. Трио превращает координаты в плитку: <code>vec2 tile = fract(uv * 5.0);</code> — экран разбит на 5×5 клеток, в каждой tile снова 0..1.' },
        { t: 'code', code: `void main() {
    vec2 uv = gl_FragCoord.xy / iResolution;

    vec2 grid = fract(uv * 8.0);      // 8x8 клеток
    vec2 cell = floor(uv * 8.0);      // номер клетки

    // шахматка: чётность суммы координат клетки
    float chess = mod(cell.x + cell.y, 2.0);

    // рамка клетки: резкие края grid
    float border = step(0.45, grid.x) + step(0.45, grid.y);

    vec3 col = mix(vec3(0.1), vec3(0.8), chess * 0.5 + border * 0.5);
    gl_FragColor = vec4(col, 1.0);
}` },
        { t: 'p', html: 'Шаблон «fract → floor → mod» покрывает бесконечные узоры: шахматы, кирпичи, соты, шестиугольники. Анимация — сдвиг координат до fract: <code>fract(uv * 8.0 + iTime)</code> — плита ползёт.' },
        { t: 'note', html: 'Функция floor даёт «номер клетки» — можно рисовать РАЗНЫЕ узоры в разных клетках: hash(cell) выбирает цвет/поворот. Псевдослучайность по клеткам — следующий уровень.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери плитку 6×6 и шахматную чётность.</p>',
        code: `vec2 grid = {{0}}(uv * 6.0);
vec2 cell = {{1}}(uv * 6.0);
float chess = {{2}}(cell.x + cell.y, 2.0);`,
        blanks: [
          { answer: 'fract' },
          { answer: 'floor' },
          { answer: 'mod' }
        ],
        ci: false
      },
      hints: [
        'Позиция в клетке — fract.',
        'Номер клетки — floor; чётность — mod 2.'
      ],
      solution: ['fract', 'floor', 'mod']
    },

    {
      id: 'glsl-7',
      title: 'Хэш и случайность',
      goal: 'Псевдослучайные значения от координат',
      xp: 50,
      theory: [
        { t: 'p', html: 'В GLSL нет random() — случайность вычисляют хэшем координат. Каноничный хэш: <code>fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453)</code> — волшебные константы, дающие равномерный хаос 0..1 из любых координат.' },
        { t: 'code', code: `float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
    vec2 uv = gl_FragCoord.xy / iResolution;

    // шум-зерно: каждый пиксель свой цвет
    float n = hash(floor(uv * 100.0));

    // случайный цвет клетки:
    vec2 cell = floor(uv * 5.0);
    vec3 col = vec3(hash(cell), hash(cell + 7.0), hash(cell + 13.0));
    gl_FragColor = vec4(col, 1.0);
}` },
        { t: 'p', html: 'Хэш детерминирован: одинаковые координаты — одинаковое значение (важно для стабильности кадра). Формула выглядит магией, но принцип прост: умножение на большие простые числа перемешивает биты, fract обрезает до 0..1.' },
        { t: 'note', html: 'Hash + floor = «шум-сетка». Hash + плавная интерполяция между узлами сетки = value noise — основа облаков, пламени и текстур. Следующий уровень — многооктавный FBM-шум.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши функцию hash(vec2 p), возвращающую fract от sin(dot(...)) с константами.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'dot с вектором констант', all: ['dot\\s*\\(\\s*p,\\s*vec2\\s*\\(\\s*12\\.9898\\s*,\\s*78\\.233\\s*\\)\\s*\\)'] },
          { desc: 'sin умножен на 43758', all: ['sin\\s*\\([^)]*\\)\\s*\\*\\s*43758\\.5453'] },
          { desc: 'fract снаружи', all: ['fract\\s*\\(\\s*sin'] }
        ],
        note: 'float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }'
      },
      hints: [
        'Схема: fract(sin(dot(p, K)) * M).',
        'Константы: (12.9898, 78.233) и 43758.5453.'
      ],
      solution: `float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}`
    },

    {
      id: 'glsl-8',
      title: 'Шум и FBM',
      goal: 'Плавный value noise и фрактальные слои',
      xp: 55,
      theory: [
        { t: 'p', html: 'Value noise: плавный шум = хэш в узлах сетки + интерполяция между ними. <code>mix(hash(i), hash(i+1), f)</code> по обеим осям — билинейная интерполяция со smoothstep — даёт мягкие «облака» без резких ступеней.' },
        { t: 'code', code: `float noise(vec2 p) {
    vec2 i = floor(p);          // узел сетки
    vec2 f = fract(p);          // внутри клетки
    f = f * f * (3.0 - 2.0 * f);   // сглаживание

    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));

    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// FBM: слои шума с удвоением частоты
float fbm(vec2 p) {
    float v = 0.0, amp = 0.5;
    for (int i = 0; i < 5; i++) {
        v += amp * noise(p);
        p *= 2.0;
        amp *= 0.5;
    }
    return v;
}` },
        { t: 'p', html: 'Формула <code>f*f*(3−2f)</code> — smoothstep руками. <b>FBM</b> (fractional Brownian motion) суммирует октавы: каждая вдвое мельче и вдвое бледнее — так рисуют облака, горы, туман, мрамор. 5 октав — киношный вид.' },
        { t: 'note', html: 'fbm(uv * 3.0 + iTime * 0.2) — плывущие облака. Анимация шума = сдвиг входа по времени. Вся классика Shadertoy (океан, космос, огонь) — это fbm с разными раскрасками.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь шаги октавы FBM.</p>',
        code: `for (int i = 0; i < 5; i++) {
    v += amp * {{0}}(p);
    p *= {{1}}.0;
    amp *= 0.5;
}`,
        blanks: [
          { answer: 'noise' },
          { answer: '2' }
        ],
        ci: false
      },
      hints: [
        'Слой — вызов noise.',
        'Частота удваивается: p *= 2.0'
      ],
      solution: ['noise', '2']
    },

    {
      id: 'glsl-9',
      title: 'Постэффекты',
      goal: 'Виньетка, хроматическая аберрация, скан-линии',
      xp: 55,
      theory: [
        { t: 'p', html: 'Постэффекты — трансформации цвета/координат whole-screen. <b>Виньетка</b>: затемнение краёв — smoothstep от length(uv − центр). <b>Скан-линии</b> CRT: mod по y. <b>Хроматика</b>: каналы сэмплируются со сдвигом.' },
        { t: 'code', code: `void main() {
    vec2 uv = gl_FragCoord.xy / iResolution;
    vec3 col = texture2D(iChannel0, uv).rgb;   // картинка

    // виньетка:
    float vig = smoothstep(1.2, 0.3, length(uv - 0.5));
    col *= vig;

    // скан-линии:
    col *= 0.9 + 0.1 * sin(uv.y * iResolution.y * 3.14159);

    // дрожание синего канала (глитч):
    col.b = texture2D(iChannel0, uv + vec2(0.01 * sin(iTime * 10.0), 0.0)).b;

    gl_FragColor = vec4(col, 1.0);
}` },
        { t: 'p', html: '<code>texture2D(tex, uv)</code> — сэмплирование текстуры по координатам: сдвиг uv — эффект линзы/волны/глитча. Анимированный сдвиг по sin — хроматическая аберрация «как в кино». Все фильтры Instagram — такие шейдеры.' },
        { t: 'note', html: 'Порядок слоёв имеет значение: виньетка обычно последняя. Каждая операция дешёвая (миллионы пикселей параллельно), поэтому даже 15 слоёв постэффектов летают на мобильном GPU.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что делает smoothstep(1.2, 0.3, d) при малых d?</p>',
        options: [
          `Возвращает ~0`,
          `Возвращает ~1`,
          `Дробное среднее`,
          `Ошибка — edge0 > edge1`
        ],
        correct: 1,
        explain: 'smoothstep(высокий, низкий, x) — инвертированный переход: при d близком к 0 результат ~1, при d → 1.2 результат → 0. Так делают затемнение от центра.'
      },
      hints: [
        'Границы переставлены — переход обратный.',
        'Виньетка светла в центре.'
      ],
      solution: `Возвращает ~1`
    },

    {
      id: 'glsl-10',
      title: 'Проект: плазма',
      goal: 'Собрать классический шейдер: синусы + время + палитра',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финал — плазма: легендарный демо-эффект 90-х, идеально ложится на GPU. Формула: сумма синусов от x, y, расстояния и времени, раскрашенная косинусной палитрой IQ (Inigo Quilez): <code>0.5 + 0.5*cos(2π(t + смещения))</code>.' },
        { t: 'code', code: `vec3 palette(float t) {
    return 0.5 + 0.5 * cos(6.28318 *
        (t + vec3(0.0, 0.33, 0.67)));
}

void main() {
    vec2 uv = (gl_FragCoord.xy * 2.0 - iResolution) / iResolution.y;

    float v = sin(uv.x * 3.0 + iTime)
            + sin(uv.y * 3.0 + iTime * 0.7)
            + sin(length(uv) * 5.0 - iTime * 1.3)
            + sin(length(uv + vec2(sin(iTime * 0.3)))
                  * 4.0 + iTime);

    v = v / 4.0;                       // нормализуем
    vec3 col = palette(v + iTime * 0.1);

    // виньетка напоследок:
    col *= 1.0 - 0.4 * length(uv);

    gl_FragColor = vec4(col, 1.0);
}` },
        { t: 'list', items: [
          '<b>uv с поправкой на аспект</b> — делим на высоту, чтобы круги были круглыми;',
          '<b>4 синуса</b> — от x, y, расстояния и их комбинаций;',
          '<b>palette(t)</b> — косинусная триада IQ;',
          '<b>виньетка</b> — финальный полиш.'
        ] },
        { t: 'note', html: 'Играй с множителями и смещениями палитры — каждая правка даёт новый мир. Затем открой Shadertoy и посмотри «Sea of clouds» или «Rainier»: теперь ты читаешь их код как открытую книгу — там те же uv, fbm, palette, что собрал ты. Дорога в графику открыта.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ядро палитры IQ и нормализацию суммы.</p>',
        code: `vec3 palette(float t) {
    return 0.5 + 0.5 * {{0}}(6.28318 *
        (t + vec3(0.0, 0.33, 0.67)));
}
...
v = v {{1}} 4.0;
vec3 col = palette(v + iTime * 0.1);`,
        blanks: [
          { answer: 'cos' },
          { answer: '/' }
        ],
        ci: false
      },
      hints: [
        'Палитра — косинусная.',
        'Среднее четырёх синусов — деление на 4.'
      ],
      solution: ['cos', '/']
    }
  ]
};
