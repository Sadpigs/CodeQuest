'use strict';
/* ============ CodeQuest — курс GML (GameMaker) ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.gml = {
  id: 'gml',
  title: 'GML',
  emoji: '🕹️',
  color: '#e8613c',
  lang: 'gml',
  tagline: 'GameMaker Language: 10 уровней',
  description: 'Язык GameMaker — на нём сделаны Hotline Miami, Undertale, Hyper Light Drifter. Идеальная площадка первой игры: объекты, события, комнаты. За 10 уровней: переменные и события, движение, клавиатура, столкновения, функции, массивы, спрайты и финальный прототип платформера.',

  levels: [

    {
      id: 'gml-1',
      title: 'Объекты и события',
      goal: 'Понять модель GameMaker: объекты реагируют на события',
      xp: 30,
      theory: [
        { t: 'p', html: 'GML живёт внутри <b>объектов</b>: у каждого объекта есть события (Create — при появлении, Step — каждый кадр, Draw — при отрисовке) и код внутри них. Игра = комнаты, заполненные объектами-экземплярами. Всё строится вокруг «событие → реакция».' },
        { t: 'code', code: `// Событие Create (один раз при создании):
hp = 100;
speed_x = 0;
name = "Герой";

// Событие Step (каждый кадр):
speed_x += 0.1;

// Вывод в отладку:
show_debug_message("HP: " + string(hp));` },
        { t: 'p', html: 'Переменные не объявляются типом — просто присваиваются в Create. Конкатенация чисел со строками требует <code>string(число)</code> — GML строг к типам в выражениях. Комментарии — // и /* */ как в C.' },
        { t: 'list', items: [
          '<b>Create</b> — инициализация (один раз);',
          '<b>Step</b> — логика каждый кадр (60 fps);',
          '<b>Draw</b> — отрисовка;',
          '<b>show_debug_message()</b> — вывод в консоль.'
        ] },
        { t: 'note', html: 'GMS2.3+ различает объявление var (временная в событии) и поле экземпляра (живёт в объекте). Привычка: всё постоянное — в Create, всё временное — через var.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери инициализацию: здоровье 100 и вывод в отладку.</p>',
        code: `// Create
hp = {{0}};

// Step
show_debug_message("HP: " + {{1}}(hp));`,
        blanks: [
          { answer: '100' },
          { answer: 'string' }
        ],
        ci: false
      },
      hints: [
        'Значение здоровья — число 100.',
        'Число в строку — string().'
      ],
      solution: ['100', 'string']
    },

    {
      id: 'gml-2',
      title: 'Движение и координаты',
      goal: 'Перемещать объекты: x, y, hspeed/vspeed или скорость-направление',
      xp: 35,
      theory: [
        { t: 'p', html: 'Координаты экземпляра — <code>x, y</code> (центр спрайта). Два стиля движения: прямое <code>x += 5;</code> или векторное <code>hspeed/vspeed</code> (по осям), <code>speed + direction</code> (в градусах, 0 — вправо, против часовой!).' },
        { t: 'code', code: `// Create:
speed_x = 3;
speed_y = 2;

// Step:
x += speed_x;
y += speed_y;

// вариант через встроенные:
hspd = 4;
vspd = -2;   // минус = вверх (y растёт вниз!)

// встроенные переменные:
x += hspd;
y += vspd;` },
        { t: 'p', html: 'Ось Y растёт ВНИЗ — как в Processing: минус vy — движение вверх. Встроенные переменные hspeed/vspeed/speed/direction/game maker двигает сам, если их задать: <code>speed = 4; direction = 45;</code> — полёт по диагонали без ручного x +=.' },
        { t: 'list', items: [
          '<b>x, y</b> — позиция (центр спрайта);',
          '<b>hspeed/vspd</b> — скорость по осям;',
          '<b>speed + direction</b> — вектор в градусах;',
          'Y вниз: вверх — отрицательное значение.'
        ] },
        { t: 'note', html: 'Смешивать x += и hspeed не стоит — двойное применение. Выбери стиль на проект: ручное сложение понятнее для платформеров, direction — для снарядов.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Двигай объект вправо и вверх: x увеличивай на 3, y уменьшай на 2 каждый кадр.</p>',
        starter: `// Step
TODO`,
        rules: [
          { desc: 'x растёт на 3', all: ['x\\s*\\+=\\s*3;'] },
          { desc: 'y уменьшается на 2', all: ['y\\s*-=\\s*2;'] }
        ],
        note: 'x += 3; / y -= 2;'
      },
      hints: [
        'Вправо — рост x.',
        'Вверх — уменьшение y (y растёт вниз).'
      ],
      solution: `// Step
x += 3;
y -= 2;`
    },

    {
      id: 'gml-3',
      title: 'Клавиатура',
      goal: 'Управление: keyboard_check и vk-коды',
      xp: 40,
      theory: [
        { t: 'p', html: 'Ввод: <code>keyboard_check(vk_right)</code> — клавиша ЗАЖАТА, <code>keyboard_check_pressed(...)</code> — нажата В ЭТОМ кадре, <code>keyboard_check_released</code> — отпущена. Коды: vk_left/right/up/down, vk_space, vk_enter; буквы — ord("W").' },
        { t: 'code', code: `// Step — движение WASD:
if (keyboard_check(ord("A"))) x -= 4;
if (keyboard_check(ord("D"))) x += 4;
if (keyboard_check(ord("W"))) y -= 4;
if (keyboard_check(ord("S"))) y += 4;

// прыжок — только по нажатию:
if (keyboard_check_pressed(vk_space)) {
    vspeed = -10;
}` },
        { t: 'p', html: 'Разница критична: движение — check (каждый кадр, пока держишь), прыжок/выстрел — pressed (один раз за нажатие, иначе 60 прыжков в секунду!). Классическая ошибка новичка — pressed для движения (дёргается) или check для прыжка (вертолёт).' },
        { t: 'list', items: [
          '<b>check</b> — удержание, для движения;',
          '<b>check_pressed</b> — момент нажатия, для действий;',
          '<b>vk_…</b> — спецклавиши, <b>ord("X")</b> — буквы;',
          'combo: клавиша + направление — условие AND.'
        ] },
        { t: 'note', html: 'Есть и keyboard_check_direct — мимо фокуса окна (для глобальных хоткеев). Для геймпада — gamepad_* функции с мёртвыми зонами.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что случится с прыжком на check_pressed vs keyboard_check?</p>',
        options: [
          `check_pressed: прыжок раз за нажатие — правильно`,
          `check: прыжок раз за нажатие`,
          `Оба работают одинаково`,
          `check_pressed не работает для space`
        ],
        correct: 0,
        explain: 'check_pressed срабатывает единожды в кадр нажатия — один прыжок. check держит истину все 60 кадров удержания — «вертолёт». Для действий — pressed, для движения — check.'
      },
      hints: [
        'Сколько кадров длится нажатие?',
        'Название функции говорит само: «нажата в этот кадр».'
      ],
      solution: `check_pressed: прыжок раз за нажатие — правильно`
    },

    {
      id: 'gml-4',
      title: 'Столкновения',
      goal: 'Реагировать на касания объектов',
      xp: 45,
      theory: [
        { t: 'p', html: 'Функции столкновений: <code>place_meeting(x, y, объект)</code> — «здесь есть кто-то из объекта?», <code>instance_place(...)</code> — вернёт конкретный экземпляр (его поля доступны!). Событие Collision — альтернатива в стиле «сам реагируй».' },
        { t: 'code', code: `// Step монетки-собирателя:
if (place_meeting(x, y, obj_coin)) {
    var inst = instance_place(x, y, obj_coin);
    score += 10;
    instance_destroy(inst);      // убрать монету
}

// событие Collision с obj_enemy:
hp -= 10;
if (hp <= 0) {
    instance_destroy();          // уничтожить СЕБЯ
}` },
        { t: 'p', html: 'instance_destroy() без аргумента убивает экземпляр, в котором вызван; с аргументом — указанный. <code>var inst</code> — временная переменная события. Столкновения считают маску спрайта — прямоугольник по умолчанию, настраивается в спрайте.' },
        { t: 'code', code: `// проверка «передо мной стена»:
if (place_meeting(x + hspd, y, obj_wall)) {
    hspd = 0;    // остановиться
}` },
        { t: 'note', html: 'place_meeting с будущей позицией (x + hspd) — проверка ДО шага: так делают «не проходить сквозь стены». Продвинутое — move_and_collide (GMS 2.3+) с автоматическим скольжением.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Проверь столкновение с obj_wall в будущей позиции x+hspd и обнули hspd при касании.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'place_meeting с будущим x', all: ['place_meeting\\s*\\(\\s*x\\s*\\+\\s*hspd'] },
          { desc: 'Проверка obj_wall', all: [',\\s*obj_wall\\s*\\)'] },
          { desc: 'Обнуление скорости', all: ['hspd\\s*=\\s*0;'] }
        ],
        note: 'if (place_meeting(x + hspd, y, obj_wall)) { hspd = 0; }'
      },
      hints: [
        'Первый аргумент — будущий x.',
        'Внутри if — остановка.'
      ],
      solution: `if (place_meeting(x + hspd, y, obj_wall)) {
    hspd = 0;
}`
    },

    {
      id: 'gml-5',
      title: 'Функции и скрипты',
      goal: 'Писать функции function и использовать аргументы',
      xp: 45,
      theory: [
        { t: 'p', html: 'Функции GML: <code>function имя(параметры) { … return … }</code> — современный синтаксис (в скриптах). Вызов обычный. Аргументы можно проверять argument_count/argument[0] — старый стиль, но встречается.' },
        { t: 'code', code: `// Script: scr_damage
function deal_damage(target, amount) {
    target.hp -= amount;
    show_debug_message(target.name + " получил " + string(amount));
    if (target.hp <= 0) {
        instance_destroy(target);
        return true;
    }
    return false;
}

// использование в Step:
deal_damage(enemy, 25);` },
        { t: 'p', html: 'Функции — первоклассные значения: их можно хранить в переменных и передавать. <code>method()</code> привязывает функцию к экземпляру. Структурируй: расчёт урона, логика ИИ, генерация уровня — каждое в своей функции/скрипте.' },
        { t: 'list', items: [
          '<b>function имя(арг) { }</b> — современное объявление;',
          '<b>return</b> — результат;',
          'скрипты — глобальные функции;',
          'старый стиль: script_execute(scr, a, b), argument0.'
        ] },
        { t: 'note', html: 'Naming-конвенция GML-сообщества: scr_ префикс для скриптов, obj_ для объектов, spr_ для спрайтов. Поиск по проекту мгновенно находит всё по префиксу.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери функцию лечения: прибавляет hp и возвращает новое значение.</p>',
        code: `{{0}} heal(target, amount) {
    target.hp {{1}} amount;
    {{2}} target.hp;
}`,
        blanks: [
          { answer: 'function' },
          { answer: '+=' },
          { answer: 'return' }
        ],
        ci: false
      },
      hints: [
        'Объявление — function имя(параметры).',
        'Прибавление — +=; результат — return.'
      ],
      solution: ['function', '+=', 'return']
    },

    {
      id: 'gml-6',
      title: 'Массивы и структуры',
      goal: 'Хранить данные: массивы, списки, structs',
      xp: 50,
      theory: [
        { t: 'p', html: 'Массив: <code>arr = [10, 20, 30];</code> доступ <code>arr[0]</code> (с нуля!), длина <code>array_length(arr)</code>. <b>Structs</b> — именованные поля: <code>p = {hp: 100, name: "Игрок"};</code> доступ точкой. Современный GML — struct-ориентированный.' },
        { t: 'code', code: `inventory = ["меч", "зелье", "ключ"];
show_debug_message(inventory[0]);        // меч

player = {
    name: "Аня",
    hp: 100,
    speed: 4
};
player.hp -= 10;

// массив структур — инвентарь с данными:
items = [
    {name: "меч",   dmg: 10},
    {name: "щит",   def: 5}
];
show_debug_message(items[0].name);` },
        { t: 'p', html: 'Массив структур — стандарт данных GML-игр: таблицы врагов, диалоги, уровень. Полезные функции: array_push, array_delete, array_sort. Struct + method() = объектная система без объектов-экземпляров (легковесные данные).' },
        { t: 'note', html: 'JSON-подобные structs буквально сериализуются json_stringify/parse — сохранения игр пишутся в три строки. Undertale-моды так и хранят прогресс.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери доступ к данным: массив и struct-поле.</p>',
        code: `player = { hp: 100, name: "Аня" };
player.{{0}} -= 10;

items = ["меч", "щит"];
{{1}}(items);   // "меч"`,
        blanks: [
          { answer: 'hp' },
          { answer: 'items[0]' }
        ],
        ci: false
      },
      hints: [
        'Поле struct — точка.',
        'Первый элемент массива — индекс 0.'
      ],
      solution: ['hp', 'items[0]']
    },

    {
      id: 'gml-7',
      title: 'Спрайты и отрисовка',
      goal: 'Управлять внешностью: sprite_index, image_*, draw-функции',
      xp: 50,
      theory: [
        { t: 'p', html: 'Внешность: <code>sprite_index</code> — текущий спрайт, <code>image_speed</code> — скорость анимации (1 = кадр/тик), <code>image_xscale/yscale</code> — зеркалирование (−1 — отражение!), <code>image_angle</code> — поворот в градусах.' },
        { t: 'code', code: `// поворот к мыши:
image_angle = point_direction(x, y, mouse_x, mouse_y);

// зеркалирование по направлению:
if (hspd != 0) {
    image_xscale = sign(hspd);
}

// кастомная отрисовка (событие Draw):
draw_self();                              // свой спрайт
draw_text(x, y - 40, "HP: " + string(hp)); // полоска текста
draw_sprite(spr_shadow, 0, x, y + 20);    // тень` },
        { t: 'p', html: '<code>point_direction(x1,y1,x2,y2)</code> — угол между точками — основа «смотреть на цель». Событие Draw перехватывает стандартную отрисовку: draw_self() рисует спрайт сам, плюс что угодно сверху: HUD, тени, полоски HP.' },
        { t: 'list', items: [
          '<b>image_angle</b> — поворот (0 = вправо);',
          '<b>image_xscale = -1</b> — зеркало;',
          '<b>draw_self()</b> — нарисовать себя в Draw;',
          '<b>draw_text / draw_sprite</b> — доп. графика.'
        ] },
        { t: 'note', html: 'draw_sprite_ext даёт всё разом: спрайт + масштаб + поворот + цвет + альфа. Глубина отрисовки — depth: меньший depth рисуется поверх.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери поворот к мыши и зеркалирование по движению.</p>',
        code: `image_{{0}} = point_direction(x, y, mouse_x, mouse_y);
if (hspd != 0) image_xscale = {{1}}(hspd);`,
        blanks: [
          { answer: 'angle' },
          { answer: 'sign' }
        ],
        ci: false
      },
      hints: [
        'Поворот — image_angle.',
        'Направление знака — функция sign().'
      ],
      solution: ['angle', 'sign']
    },

    {
      id: 'gml-8',
      title: 'Экземпляры и комнаты',
      goal: 'Создавать объекты динамически, переходить между комнатами',
      xp: 55,
      theory: [
        { t: 'p', html: 'Создание: <code>instance_create_layer(x, y, слой, объект)</code> — рождает экземпляр (вернёт ссылку — можно сразу настроить поля!). Удаление всех: instance_destroy(объект, true). Комнаты: <code>room_goto(комната)</code>, перезапуск <code>room_restart()</code>.' },
        { t: 'code', code: `// выстрел из пушки:
var bullet = instance_create_layer(x, y, "Instances", obj_bullet);
bullet.hspd = 12 * sign(facing);
bullet.damage = 10;

// волна врагов:
for (var i = 0; i < 5; i++) {
    var e = instance_create_layer(600 + i * 40, 100, "Instances", obj_enemy);
    e.hp = 30 + i * 10;
}

// переходы:
if (score >= 100) room_goto(rm_level2);
if (hp <= 0) room_restart();` },
        { t: 'p', html: 'Ссылка из create-функции — главный паттерн: спавни и сразу настраивай (hp, скорость, цель). Пули, враги, эффекты, лут — всё рождается динамически. Слои (layer) организуют порядок отрисовки.' },
        { t: 'note', html: 'persistent-объекты выживают смену комнаты — контроллеры игры, музыка. room_goto_next()/previous для линейных уровней. Глобальный счёт: global.score = 0 — переменная global. видна всем объектам.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Создай пулю на слое Instances и задай ей скорость 10.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'instance_create_layer вызван', all: ['instance_create_layer\\s*\\('] },
          { desc: 'Слой Instances и obj_bullet', all: ['"Instances",\\s*obj_bullet'] },
          { desc: 'Скорость задана через ссылку', all: ['\\.hspd\\s*=\\s*10;|\\.speed\\s*=\\s*10;'] }
        ],
        note: 'var b = instance_create_layer(x, y, "Instances", obj_bullet); / b.hspd = 10;'
      },
      hints: [
        'Порядок аргументов: x, y, слой, объект.',
        'Результат — переменная, её поле настраиваем.'
      ],
      solution: `var b = instance_create_layer(x, y, "Instances", obj_bullet);
b.hspd = 10;`
    },

    {
      id: 'gml-9',
      title: 'Таймеры и alarms',
      goal: 'Отложенные действия: alarm, таймеры и тайм-инг',
      xp: 55,
      theory: [
        { t: 'p', html: 'Alarms: <code>alarm[0] = 60;</code> — через 60 кадров (1 секунда) сработает событие Alarm 0. Современный вариант — счётчики-переменные в Step. <code>delta_time</code> — микросекунды кадра для физики, независимой от FPS.' },
        { t: 'code', code: `// Create:
cooldown = 0;

// Step:
if (cooldown > 0) cooldown--;
if (mouse_check_button(mb_left) && cooldown == 0) {
    shoot();
    cooldown = 30;      // полсекунды перезарядки
}

// Alarm-вариант:
// Step: if (fire_pressed && alarm[0] <= 0) { shoot(); alarm[0] = 30; }
// Alarm 0: (пусто — просто флаг перезарядки сброшен)` },
        { t: 'p', html: 'Кулдаун через счётчик — самый читаемый паттерн: уменьшай каждый кадр, блокируй действие пока больше нуля. Alarms удобны для разовых отложенных событий (respawn через 2 секунды: alarm[1] = 120).' },
        { t: 'list', items: [
          '<b>alarm[i] = кадры</b> — отложенное событие;',
          '<b>cooldown-- каждый Step</b> — ручной таймер;',
          '60 кадров ≈ 1 секунда при 60 FPS;',
          '<b>delta_time</b> — для FPS-независимой физики.'
        ] },
        { t: 'note', html: 'Классическая бага — таймеры на «кадрах» при падении FPS: на слабом ПК всё замедляется. Продакшн-код умножает скорости на delta_time/1e6 — физика становится честной на любом железе.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери кулдаун: уменьшение в Step и блокировка выстрела при cooldown > 0.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Уменьшение кулдауна', all: ['cooldown\\s*--|cooldown\\s*-=?\\s*1;'] },
          { desc: 'Проверка готовности', all: ['cooldown\\s*(==|<=)\\s*0'] },
          { desc: 'Вызов выстрела', all: ['shoot\\s*\\(\\s*\\)\\s*;'] }
        ],
        note: 'if (cooldown > 0) cooldown--; / if (mouse_check_button(mb_left) && cooldown == 0) { shoot(); cooldown = 30; }'
      },
      hints: [
        'Счётчик тикает вниз каждый кадр.',
        'Выстрел только при cooldown == 0.'
      ],
      solution: `if (cooldown > 0) cooldown--;
if (mouse_check_button(mb_left) && cooldown == 0) {
    shoot();
    cooldown = 30;
}`
    },

    {
      id: 'gml-10',
      title: 'Проект: прототип платформера',
      goal: 'Собрать движение, гравитацию, прыжок и землю',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финал — сердце каждой платформенной игры: гравитация, прыжок, контакт с полом. Логика: растущая vspd (гравитация), прыжок — импульс вверх при заземлении, проверка place_meeting на полу — обнуление скорости.' },
        { t: 'code', code: `// Create:
hspd = 0;
vspd = 0;
grav = 0.5;
jump = -11;
on_ground = false;

// Step:
var move = (keyboard_check(ord("D")) - keyboard_check(ord("A"))) * 4;
hspd = move;

vspd += grav;
if (keyboard_check_pressed(vk_space) && on_ground) {
    vspd = jump;
}

// горизонталь со стеной:
if (!place_meeting(x + hspd, y, obj_wall)) x += hspd;

// вертикаль с полом:
if (place_meeting(x, y + vspd, obj_wall)) {
    while (!place_meeting(x, y + sign(vspd), obj_wall)) y += sign(vspd);
    vspd = 0;
    on_ground = true;
} else {
    y += vspd;
    on_ground = false;
}` },
        { t: 'list', items: [
          '<b>Ввод</b> — разность проверок даёт −1/0/1;',
          '<b>grav += vspd</b> — ускорение падения;',
          '<b>прыжок при on_ground</b> — без двойных;',
          '<b>while-подводка</b> — прижатие к полу без застревания;'
        ] },
        { t: 'note', html: 'Это скелет Undertale-класса движений: добавь coyote time (прыжок 6 кадров после схода с края: таймер), jump buffering (запомнить нажатие за 4 кадра до земли) — и управление станет «вкусным», как в лучших платформерах. GameMaker — кратчайший путь от идеи до Steam: Undertale, Hotline Miami и Hollow Knight-прототипы родились ровно на этом коде.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь физику прыжка: гравитация и импульс при заземлении.</p>',
        code: `vspd += {{0}};
if (keyboard_check_pressed(vk_space) && {{1}}) {
    vspd = {{2}};
}`,
        blanks: [
          { answer: 'grav' },
          { answer: 'on_ground' },
          { answer: 'jump' }
        ],
        ci: false
      },
      hints: [
        'Падение ускоряет — grav.',
        'Прыжок разрешён только на земле; импульс — отрицательный jump.'
      ],
      solution: ['grav', 'on_ground', 'jump']
    }
  ]
};
