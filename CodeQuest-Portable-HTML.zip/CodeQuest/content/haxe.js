'use strict';
/* ============ CodeQuest — курс Haxe ============
   Haxe не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами
   и заполнением пропусков.
================================================= */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.haxe = {
  id: 'haxe',
  title: 'Haxe',
  emoji: '🎯',
  color: '#ea8220',
  lang: 'haxe',
  tagline: 'Один язык — все платформы: 6 уровней',
  description: 'Язык Николя Каннассе (2005): один статически типизированный код компилируется в JavaScript, C++, Java, C#, Python, PHP, Lua и HashLink. На Haxe сделаны Dead Cells и Northgard. За 6 уровней дойдём от каркаса class Main до проекта «Менеджер задач»: типы, enum, классы, функции и массив задач со статусами.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'haxe-1',
      title: 'Первая программа',
      goal: 'Собрать каркас программы на Haxe: класс Main, статическую точку входа main и вывод через trace',
      xp: 30,
      theory: [
        { t: 'p', html: 'Haxe придумал Николя Каннассе в 2005 году во французской студии Motion-Twin. Идея простая и дерзкая: пишешь один статически типизированный код, а компилятор переводит его в JavaScript, C++, Java, C#, Python, PHP, Lua и в собственный бэкенд HashLink. На Haxe сделаны игры Dead Cells и Northgard, а также Papers, Please — и это только известные примеры. Сегодня язык развивает некоммерческий Haxe Foundation.' },
        { t: 'h', html: 'Минимальная программа' },
        { t: 'code', code: `class Main {
    static function main() {
        trace("Привет, CodeQuest!");
    }
}` },
        { t: 'p', html: 'Здесь всего три сущности. <code>class Main</code> — класс-контейнер: в Haxe код живёт только внутри классов, свободных функций не существует. <code>static function main()</code> — точка входа: компилятор ищет её в классе, который назван флагом <code>-main</code>. Наконец, <code>trace(...)</code> — встроенная печать со встроенной же магией: вместе со значением она показывает файл и строку, откуда вызывалась.' },
        { t: 'list', items: [
          '<b>class Main</b> — класс с точкой входа;',
          '<b>static function main()</b> — стартовая функция;',
          '<b>trace(...)</b> — печать значения с указанием места в коде;',
          '<b>haxe -main Main --interp</b> — запустить программу сразу через интерпретатор HashLink.'
        ] },
        { t: 'warn', html: '<code>trace</code> печатает в формате «Main.hx:3: значение» — не пугайся префикса, это помощь при отладке. Для JS-цели компиляция выглядит так: <code>haxe -main Main -js out.js</code>. Забыл точку с запятой после вызова — компилятор подскажет: он в Haxe дружелюбный и говорит по делу.' },
        { t: 'note', html: 'Класс для старта задаётся флагом <code>-main ИмяКласса</code>, но функция внутри обязана называться <code>main</code> и быть статической. Методов у класса может быть сколько угодно — исполнение всегда начнётся с main.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Каркас уже собран — допиши вывод: внутри <code>main</code> вызови <code>trace</code> со строкой «Привет, CodeQuest!» и добавь вторую строку о том, что один код работает на многих платформах. Заглушку-комментарий убери.</p>',
        starter: `class Main {
    static function main() {
        // TODO: выведи две строки через встроенную печать
    }
}`,
        rules: [
          { desc: 'Объявлен класс Main', all: ['\\bclass\\s+Main\\b'] },
          { desc: 'Есть статическая точка входа: static function main', all: ['\\bstatic\\s+function\\s+main\\s*\\(\\s*\\)\\s*\\{'] },
          { desc: 'Вывод через trace со строкой в кавычках', all: ['\\btrace\\s*\\(\\s*"'] },
          { desc: 'В кавычках фраза "Привет, CodeQuest!"', all: ['Привет, CodeQuest!'] },
          { desc: 'Напечатано минимум две строки', all: ['\\btrace\\s*\\(\\s*"[^\\n]+"\\s*\\)\\s*;\\s*\\n\\s*\\btrace\\s*\\('] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Первые две строки и закрывающие скобки трогать не нужно — работа только внутри main.',
        'Шаблон вызова: trace("текст"); — кавычки, затем точка с запятой.',
        'Проверь, что внутри строки ровно так: Привет, CodeQuest!'
      ],
      solution: `class Main {
    static function main() {
        trace("Привет, CodeQuest!");
        trace("Один код — много платформ.");
    }
}`
    },

    /* ---------- 2. Переменные и типы ---------- */
    {
      id: 'haxe-2',
      title: 'Переменные и типы',
      goal: 'Объявлять типизированные переменные: Int, Float, String, Bool, Array и Dynamic как люк из статической типизации',
      xp: 35,
      theory: [
        { t: 'p', html: 'Haxe — язык со строгой статической типизацией: тип каждой переменной известен компилятору до запуска. Объявление выглядит как <code>var имя: Тип = значение</code>, и это единственный способ создать локальную переменную. Но писать тип руками не всегда обязательно: если значение уже говорит за себя, компилятор выведет тип сам. Такой вывод типов экономит время без потери надёжности.' },
        { t: 'code', code: `class Main {
    static function main() {
        var hp = 100;           // Int выведен сам
        var name:String = "Ада";
        var pi:Float = 3.14;
        hp = hp - 25;           // var можно менять
        trace(name + ", HP: " + hp);
    }
}` },
        { t: 'table', head: ['Тип', 'Хранит', 'Примеры'], rows: [
          ['Int', 'целое число', '42, -7'],
          ['Float', 'дробное число', '3.14, -0.5'],
          ['String', 'строка в двойных кавычках', '"Ада"'],
          ['Bool', 'логическое', 'true, false'],
          ['Void', 'ничего (для функций без результата)', '-'],
          ['Array&lt;T&gt;', 'список значений одного типа', '[1, 2, 3]']
        ] },
        { t: 'p', html: 'Тип <code>Dynamic</code> — аварийный люк из статической типизации: переменная такого типа принимает что угодно, а проверки переносятся на этап выполнения. Он незаменим для взаимодействия с динамическими целями вроде JavaScript или для разбора «сырых» данных. Но злоупотреблять им не стоит: как только поставил <code>Dynamic</code> — компилятор перестал защищать эту переменную. Правило хорошего тона: чем меньше Dynamic в коде, тем меньше сюрпризов на рантайме.' },
        { t: 'list', items: [
          '<b>var x:Int = 5;</b> — явный тип;',
          '<b>var x = 5;</b> — тип выведен из значения;',
          '<b>final y = 9;</b> — неизменяемая привязка (Haxe 4);',
          '<b>var any:Dynamic = "что угодно";</b> — люк из типизации.'
        ] },
        { t: 'warn', html: 'Имена типов пишутся с большой буквы: <code>Int</code>, <code>String</code> — и это не стиль, а правило языка. Изменяемая переменная объявляется через <code>var</code>; попробуешь присвоить новое значение <code>final</code>-переменной — получишь ошибку компиляции, а не сюрприз в рантайме.' },
        { t: 'note', html: 'Строки склеиваются плюсом: <code>"HP: " + hp</code>. Для более сложной сборки есть интерполяция в одинарных кавычках: шаблон <code>значение: $hp</code> подставит переменную прямо в текст — это единственный случай, когда в Haxe используют одинарные кавычки.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни карточку героя: здоровье — целое, скорость — дробное, имя — строка, флаг жизни — логическое значение, а для лута выбери тип, который принимает что угодно.</p>',
        code: `class Main {
    static function main() {
        var hp:{{1}} = 100;          // целое
        var speed:{{2}} = 4.5;       // дробное
        var name:{{3}} = "Ада";      // строка
        var alive:{{4}} = true;      // да/нет
        var loot:{{5}} = { x: 12 };  // принимает что угодно
        trace(name + ": " + hp);
    }
}`,
        blanks: [
          { answer: 'Int' },
          { answer: 'Float' },
          { answer: 'String' },
          { answer: 'Bool' },
          { answer: 'Dynamic' }
        ]
      },
      hints: [
        'Все пять типов есть в таблице выше.',
        'Целое без точки — Int, с точкой — Float.',
        'Логический тип называется Bool, а «что угодно» — Dynamic.'
      ],
      solution: ['Int', 'Float', 'String', 'Bool', 'Dynamic']
    },

    /* ---------- 3. Enum и switch ---------- */
    {
      id: 'haxe-3',
      title: 'Enum и switch',
      goal: 'Объявить enum с конструкторами и обработать все значения исчерпывающим switch',
      xp: 40,
      theory: [
        { t: 'p', html: 'enum — тип, описывающий конечный набор значений: у статуса может быть «в работе» и «готово», у цвета — красный, зелёный и синий. В Haxe enum — это не числа с красивыми именами, а алгебраические типы данных (ADT), как в Haskell и OCaml. Компилятор знает все конструкторы и следит, чтобы ты обработал каждый. Это делает ветвление по enum безопасным: забыли ветку — код не соберётся.' },
        { t: 'code', code: `enum Color {
    Red;
    Green;
    Blue;
}` },
        { t: 'p', html: 'Ветвление по enum — классический <code>switch</code>. Конструкторы можно писать без префикса: <code>case Red:</code> — компилятор поймёт по типу проверяемого значения. Провала вниз, как в C, здесь нет: каждая ветка живёт своей жизнью, и <code>break</code> не нужен.' },
        { t: 'code', code: `class Main {
    static function main() {
        var c = Color.Green;
        switch (c) {
            case Red: trace("Тёплый");
            case Green: trace("Растущий");
            case Blue: trace("Холодный");
        }
    }
}` },
        { t: 'p', html: 'Конструкторы могут нести данные: <code>enum Shape { Circle(r:Float); Rect(w:Float, h:Float); }</code>. В switch аргументы привязываются к переменным: <code>case Circle(r): trace(r);</code> — и переменная r доступна внутри ветки. Сравнение значений enum делается обычным <code>==</code>.' },
        { t: 'list', items: [
          '<b>enum Color { Red; Green; }</b> — простые конструкторы через точку с запятой;',
          '<b>case Circle(r):</b> — извлечение данных из конструктора;',
          '<b>switch</b> обязан покрыть все конструкторы или иметь ветку default;',
          'значения enum сравниваются через <b>==</b>.'
        ] },
        { t: 'warn', html: 'Забытая ветка — ошибка компиляции, а не баг в продакшене: компилятор перечислит непокрытые конструкторы. Если покрыть всё не хочется, добавь ветку <code>default:</code> — но помни, что она отключает проверку полноты.' },
        { t: 'note', html: 'Имена конструкторов принято писать с большой буквы — это часть культуры языка. Внутри одного модуля имена конструкторов разных enum не должны конфликтовать, иначе квалифицируй их: <code>Color.Red</code>.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери переключатель: enum уже объявлен — положи значение в переменную и напиши <code>switch</code> с веткой для каждого цвета.</p>',
        starter: `enum Color {
    Red;
    Green;
    Blue;
}

class Main {
    static function main() {
        var c = Color.Green;
        // TODO: опиши switch с веткой на каждый цвет
    }
}`,
        rules: [
          { desc: 'Объявлен enum Color с фигурными скобками', all: ['\\benum\\s+Color\\s*\\{'] },
          { desc: 'Конструкторы Red, Green и Blue объявлены через точку с запятой', all: ['\\bRed\\s*;', '\\bGreen\\s*;', '\\bBlue\\s*;'] },
          { desc: 'Переменная получает значение конструктора через Color.', all: ['\\bvar\\s+\\w+\\s*=\\s*Color\\.\\w+'] },
          { desc: 'Есть switch по переменной', all: ['\\bswitch\\s*\\(\\s*\\w+\\s*\\)\\s*\\{'] },
          { desc: 'Три ветки case: Red, Green, Blue', all: ['\\bcase\\s+(Red|Color\\.Red)\\s*:', '\\bcase\\s+(Green|Color\\.Green)\\s*:', '\\bcase\\s+(Blue|Color\\.Blue)\\s*:'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'switch (c) { ... } — проверяемая переменная в скобках.',
        'Форма ветки: case Red: trace("Тёплый");',
        'Покрой все три конструктора — компилятор любит полноту.'
      ],
      solution: `enum Color {
    Red;
    Green;
    Blue;
}

class Main {
    static function main() {
        var c = Color.Green;
        switch (c) {
            case Red: trace("Тёплый");
            case Green: trace("Растущий");
            case Blue: trace("Холодный");
        }
    }
}`
    },

    /* ---------- 4. Классы и поля ---------- */
    {
      id: 'haxe-4',
      title: 'Классы и поля',
      goal: 'Создать класс с публичными полями, конструктором new и доступом к полям экземпляра через точку',
      xp: 45,
      theory: [
        { t: 'p', html: 'Класс в Haxe — чертёж объекта: поля хранят данные, методы — поведение. Начиная с Haxe 3 поля и методы по умолчанию публичные, а слово <code>private</code> ставят явно, когда хотят спрятать. Конструктор — метод с именем <code>new</code>: именно его вызывает <code>new ClassName(...)</code>. Внутри конструктора доступен <code>this</code> — текущий экземпляр.' },
        { t: 'code', code: `class Player {
    public var name:String;
    public var hp:Int;

    public function new(name:String, hp:Int) {
        this.name = name;
        this.hp = hp;
    }
}` },
        { t: 'p', html: 'Здесь поля <code>name</code> и <code>hp</code> объявлены с типами, а параметры конструктора затеняют их имена — поэтому внутри используется <code>this.name</code>. Экземпляр создаётся в одну строку: <code>var hero = new Player("Ада", 100);</code>. После этого поля читаются и меняются через точку: <code>hero.hp = hero.hp - 25;</code>.' },
        { t: 'list', items: [
          '<b>public var hp:Int;</b> — публичное поле с типом;',
          '<b>public function new(...)</b> — конструктор;',
          '<b>private var gold:Int;</b> — скрытое поле;',
          '<b>this.имя</b> — обращение к своему полю при конфликте имён.'
        ] },
        { t: 'p', html: 'Статические члены принадлежат классу, а не экземпляру: <code>public static var total:Int;</code> и <code>static function reset()</code> вызываются как <code>Player.total</code>. Это удобно для счётчиков и вспомогательных функций. У методов, как и у полей, типы параметров и возврата указываются через двоеточия.' },
        { t: 'warn', html: 'Забыл слово <code>new</code> и вызвал класс как функцию — компилятор сразу объяснит, что класс не метод. А если конструктор требует аргументы, передай их все: <code>new Player("Ада", 100)</code> без второго числа не соберётся.' },
        { t: 'note', html: 'Геттеры и сеттеры в Haxe встроены прямо в поля: <code>public var hp(default, set):Int;</code> — но это тема для следующего уровня знакомства; пока хватит простых полей с явным this.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Класс <code>Player</code> ждёт начинку: добавь публичные поля <code>name:String</code> и <code>hp:Int</code>, конструктор с параметрами, который заполняет поля через <code>this</code>. Создание героя в main уже написано — подгони класс под него.</p>',
        starter: `class Player {
    // TODO: добавь поля с типами и конструктор

}

class Main {
    static function main() {
        var hero = new Player("Ада", 100);
        hero.hp = hero.hp - 25;
        trace(hero.name + ": " + hero.hp);
    }
}`,
        rules: [
          { desc: 'Класс Player объявлен', all: ['\\bclass\\s+Player\\s*\\{'] },
          { desc: 'Публичные поля name:String и hp:Int', all: ['\\bpublic\\s+var\\s+name\\s*:\\s*String\\s*;', '\\bpublic\\s+var\\s+hp\\s*:\\s*Int\\s*;'] },
          { desc: 'Конструктор public function new с параметрами', all: ['\\bpublic\\s+function\\s+new\\s*\\([^)]+\\)\\s*\\{'] },
          { desc: 'Поля заполняются через this.', all: ['this\\.name\\s*=', 'this\\.hp\\s*='] },
          { desc: 'Экземпляр создаётся через new Player', all: ['\\bnew\\s+Player\\s*\\('] },
          { desc: 'Поле экземпляра меняется через точку', all: ['hero\\.hp\\s*=\\s*hero\\.hp'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Форма поля: public var name:String; — с точкой с запятой.',
        'Конструктор: public function new(name:String, hp:Int) { this.name = name; this.hp = hp; }',
        'this нужен только там, где параметр совпадает по имени с полем.'
      ],
      solution: `class Player {
    public var name:String;
    public var hp:Int;

    public function new(name:String, hp:Int) {
        this.name = name;
        this.hp = hp;
    }
}

class Main {
    static function main() {
        var hero = new Player("Ада", 100);
        hero.hp = hero.hp - 25;
        trace(hero.name + ": " + hero.hp);
    }
}`
    },

    /* ---------- 5. Функции и типизация ---------- */
    {
      id: 'haxe-5',
      title: 'Функции и типизация',
      goal: 'Писать типизированные функции: аргументы, тип возврата, значения по умолчанию и функции-значения',
      xp: 50,
      theory: [
        { t: 'p', html: 'Функция в Haxe — это поле класса с функциональным типом. Сигнатура читается слева направо: <code>static function add(a:Int, b:Int):Int</code> — имя, типизированные аргументы в скобках, после двоеточия тип результата. Для функций, которые ничего не возвращают, тип результата — <code>Void</code>. Возврат выполняется через <code>return</code>.' },
        { t: 'code', code: `class Calc {
    static function add(a:Int, b:Int):Int {
        return a + b;
    }

    static function greet(name:String):String {
        return "Привет, " + name + "!";
    }

    static function main() {
        trace(add(2, 3));
        trace(greet("Мир"));
    }
}` },
        { t: 'p', html: 'Тип возврата можно опустить — компилятор выведет его из тела, но явная сигнатура надёжнее: она документирует контракт и ловит ошибки раньше. Аргументам задаётся значение по умолчанию через присваивание: <code>function ping(host:String, port:Int = 80)</code> — вызывающий может порт не указывать. Рекурсивные функции, кстати, требуют явного типа возврата: без него вывод типов зациклится.' },
        { t: 'list', items: [
          '<b>(a:Int, b:Int):Int</b> — типы аргументов и возврата;',
          '<b>:Void</b> — функция ничего не возвращает;',
          '<b>port:Int = 80</b> — значение аргумента по умолчанию;',
          '<b>return</b> — досрочный выход со значением.'
        ] },
        { t: 'p', html: 'Функции — значения первого класса: их можно класть в переменные, передавать аргументами и возвращать. <code>var op = add;</code> сохранит ссылку, а <code>op(2, 3)</code> вызовет её. Короткие безымянные функции (лямбды) пишутся как <code>function(x) return x * 2</code> — они часто нужны методам коллекций вроде <code>map</code>.' },
        { t: 'warn', html: 'Если функция обещала результат, но не на всех путях делает <code>return</code>, компилятор остановит сборку с ошибкой про отсутствующий возврат. И помни: свободных функций в Haxe нет — любая функция живёт внутри класса, чаще всего как <code>static</code>.' },
        { t: 'note', html: 'Перегрузки функций в Haxe нет: два add с разными наборами аргументов объявить нельзя. Вместо неё используют значения по умолчанию, union-типы или отдельные имена вроде addInt и addAll.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>В классе <code>Calc</code> объяви две функции: <code>add</code> — складывает два целых числа, <code>greet</code> — возвращает приветствие со строкой-аргументом. Типы аргументов и возврата обязательны. Вызовы в main уже готовы.</p>',
        starter: `class Calc {
    // TODO: объяви add и greet с типами аргументов и возврата

    static function main() {
        trace(add(2, 3));
        trace(greet("Мир"));
    }
}`,
        rules: [
          { desc: 'add принимает два Int и возвращает Int', all: ['\\bfunction\\s+add\\s*\\(\\s*\\w+\\s*:\\s*Int\\s*,\\s*\\w+\\s*:\\s*Int\\s*\\)\\s*:\\s*Int\\s*\\{'] },
          { desc: 'add возвращает сумму через return', all: ['\\breturn\\s+\\w+\\s*\\+\\s*\\w+\\s*;'] },
          { desc: 'greet принимает String и возвращает String', all: ['\\bfunction\\s+greet\\s*\\(\\s*\\w+\\s*:\\s*String\\s*\\)\\s*:\\s*String\\s*\\{'] },
          { desc: 'В main есть вызовы add и greet', all: ['add\\s*\\(\\s*2\\s*,\\s*3\\s*\\)', 'greet\\s*\\(\\s*"'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Шаблон: static function add(a:Int, b:Int):Int { return a + b; }',
        'Тип возврата пишется после скобок: ...):String {',
        'Вызовы в main уже готовы — сигнатуры должны им подходить.'
      ],
      solution: `class Calc {
    static function add(a:Int, b:Int):Int {
        return a + b;
    }

    static function greet(name:String):String {
        return "Привет, " + name + "!";
    }

    static function main() {
        trace(add(2, 3));
        trace(greet("Мир"));
    }
}`
    },

    /* ---------- 6. 🚀 Проект: менеджер задач ---------- */
    {
      id: 'haxe-6',
      title: '🚀 Проект: менеджер задач',
      goal: 'Собрать менеджер задач: enum Status, класс Task, типизированный массив задач и подсчёт по статусу',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — менеджер задач: у каждой задачи заголовок и статус, задачи лежат в массиве, а функция подсчёта отвечает на вопрос «сколько сделано». Это скелет настоящих приложений: enum-статусы и типизированные коллекции встречаются в Haxe-коде повсюду. Соберём всё изученное: enum, класс, поля, функции и цикл по массиву.' },
        { t: 'code', code: `enum Status {
    Todo;
    Done;
}

class Task {
    public var title:String;
    public var status:Status;

    public function new(title:String) {
        this.title = title;
        this.status = Status.Todo;
    }
}` },
        { t: 'p', html: 'Задача — класс с двумя полями. Конструктор принимает заголовок и ставит статус <code>Status.Todo</code>: квалификация через имя enum нужна, потому что внутри класса имена конструкторов напрямую не видны. Поле <code>status</code> типизировано enum-ом, поэтому присвоить ему строку не выйдет — компилятор поймает.' },
        { t: 'code', code: `class Main {
    static var tasks:Array<Task> = [];

    static function add(title:String):Void {
        tasks.push(new Task(title));
    }
}` },
        { t: 'p', html: 'Список задач — статическое поле <code>Array&lt;Task&gt;</code>: обобщённый массив, в котором законны только задачи. <code>push</code> добавляет элемент в конец, а типобезопасность работает на полную: попытка положить в этот массив строку не скомпилируется. Пустой массив задаётся парой квадратных скобок <code>[]</code> и растёт по мере вызовов.' },
        { t: 'code', code: `    static function countBy(s:Status):Int {
        var n = 0;
        for (t in tasks) {
            if (t.status == s) {
                n++;
            }
        }
        return n;
    }

    static function main() {
        add("Изучить Haxe");
        add("Сделать игру");
        tasks[1].status = Status.Done;
        trace("Готово: " + countBy(Status.Done));
        trace("В работе: " + countBy(Status.Todo));
    }` },
        { t: 'p', html: 'Функция <code>countBy</code> проходит циклом <code>for (t in tasks)</code> по массиву и сравнивает статусы через <code>==</code>. В main мы добавляем задачи, переключаем вторую в <code>Done</code> и печатаем два счётчика. Ожидаемый вывод: «Готово: 1» и «В работе: 1».' },
        { t: 'warn', html: 'Обрати внимание на <code>n++</code>: инкремент в Haxe есть, в отличие от некоторых соседей. И не потеряй слово <code>static</code> — из статического main нельзя дотянуться до нестатических полей: компилятор расскажет об этом выразительно.' },
        { t: 'note', html: 'Куда расти: добавь конструктор <code>InProgress</code> в enum, напиши функцию summarize, которая печатает отчёт по всем статусам сразу, и попробуй отсортировать задачи по алфавиту методом <code>sort</code>.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери менеджер задач целиком: enum <code>Status</code> с конструкторами <code>Todo</code> и <code>Done</code>, класс <code>Task</code> с полями, статический массив <code>Array&lt;Task&gt;</code>, функцию <code>add</code> и подсчёт задач по статусу с циклом <code>for..in</code>. В main добавь две задачи и переключи статус одной.</p>',
        starter: `// TODO: собери менеджер задач по шагам из условия

class Main {
    static function main() {
        trace("Пусто");
    }
}`,
        rules: [
          { desc: 'enum Status с конструкторами Todo и Done', all: ['\\benum\\s+Status\\s*\\{', '\\bTodo\\s*;', '\\bDone\\s*;'] },
          { desc: 'Класс Task с публичными полями title:String и status:Status', all: ['\\bclass\\s+Task\\b', '\\bpublic\\s+var\\s+title\\s*:\\s*String\\s*;', '\\bpublic\\s+var\\s+status\\s*:\\s*Status\\s*;'] },
          { desc: 'Массив задач объявлен как Array<Task>', all: ['Array\\s*<\\s*Task\\s*>'] },
          { desc: 'Функция add добавляет новую Task в массив', all: ['\\bfunction\\s+add\\s*\\(\\s*\\w+\\s*:\\s*String\\s*\\)', 'tasks\\.push\\s*\\(\\s*new\\s+Task\\s*\\('] },
          { desc: 'Функция countBy принимает Status и возвращает Int', all: ['\\bfunction\\s+countBy\\s*\\(\\s*\\w+\\s*:\\s*Status\\s*\\)\\s*:\\s*Int'] },
          { desc: 'Цикл for..in по массиву задач', all: ['\\bfor\\s*\\(\\s*\\w+\\s+in\\s+tasks\\s*\\)'] },
          { desc: 'Статус задачи переключается на Status.Done', all: ['Status\\.Done'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Порядок сборки: enum, класс Task, массив и add, countBy, main.',
        'В countBy: for (t in tasks) { if (t.status == s) { n++; } } и return n.',
        'Переключение статуса: tasks[1].status = Status.Done;'
      ],
      solution: `enum Status {
    Todo;
    Done;
}

class Task {
    public var title:String;
    public var status:Status;

    public function new(title:String) {
        this.title = title;
        this.status = Status.Todo;
    }
}

class Main {
    static var tasks:Array<Task> = [];

    static function add(title:String):Void {
        tasks.push(new Task(title));
    }

    static function countBy(s:Status):Int {
        var n = 0;
        for (t in tasks) {
            if (t.status == s) {
                n++;
            }
        }
        return n;
    }

    static function main() {
        add("Изучить Haxe");
        add("Сделать игру");
        tasks[1].status = Status.Done;
        trace("Готово: " + countBy(Status.Done));
        trace("В работе: " + countBy(Status.Todo));
    }
}`
    }
  ],

  cheats: [
    { title: 'Каркас программы', code: `class Main {
    static function main() {
        trace("Привет!");
    }
}
// запуск:  haxe -main Main --interp
// в JS:    haxe -main Main -js out.js` },
    { title: 'Типы и переменные', list: [
      '<code>var x:Int = 5;</code> — явный тип',
      '<code>var y = 5.0;</code> — вывод типа',
      '<code>final z = 9;</code> — неизменяемая',
      '<code>Dynamic</code> — принимает что угодно',
      '<code>Array&lt;T&gt;</code> — типизированный массив',
      'типы с большой буквы: Int, Float, String, Bool'
    ] },
    { title: 'enum и switch', code: `enum Color { Red; Green; }
var c = Color.Red;

switch (c) {
    case Red: trace("тёплый");
    case Green: trace("растущий");
    default: trace("холодный");
}
// с данными: Circle(r:Float) → case Circle(r):` },
    { title: 'Классы и new', code: `class Player {
    public var name:String;
    public function new(name:String) {
        this.name = name;
    }
}
var hero = new Player("Ада");
hero.name;        // чтение поля
Player.total;     // статический член класса` },
    { title: 'Функции', code: `static function add(a:Int, b:Int):Int {
    return a + b;
}
function ping(host:String, port:Int = 80):Void {}
var op = add;                        // функция — значение
var double = function(x) return x * 2;` },
    { title: 'Array и циклы', code: `var tasks:Array<String> = [];
tasks.push("первая");
tasks[0];                // индекс с нуля
tasks.length;            // длина
for (t in tasks) trace(t);
for (i in 0...3) trace(i);   // 0, 1, 2` }
  ]
};
