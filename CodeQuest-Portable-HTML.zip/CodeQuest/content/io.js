'use strict';
/* ============ CodeQuest — курс Io ============
   Io не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами
   и заполнением пропусков.
================================================= */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.io = {
  id: 'io',
  title: 'Io',
  emoji: '🪐',
  color: '#9370db',
  lang: 'io',
  tagline: 'Всё — сообщение: прототипы за 6 уровней',
  description: 'Язык Стива Декорте (2002): нет классов и ключевых слов, только объекты-прототипы и сообщения, как в Self и Smalltalk. За 6 уровней дойдём от первого println до проекта «Счётчик счетов»: слоты, :=, clone, method, List и Range.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'io-1',
      title: 'Первая программа',
      goal: 'Отправить первые сообщения: печать строки через println, write без переноса и комментарии',
      xp: 30,
      theory: [
        { t: 'p', html: 'Io создал Стив Декорте в 2002 году, задавшись вопросом: как устроен язык, если выбросить всё лишнее. За основу взяты прототипы Self, сообщения Smalltalk, однородность Lisp и слоты NewtonScript. Язык получился крошечным — ядро на C укладывается в несколько тысяч строк, — но с корутинами, акторами и будущностями для конкурентности. Широкую известность Io получил благодаря книге «Семь языков за семь недель», где учит мыслить сообщениями.' },
        { t: 'h', html: 'Первые сообщения' },
        { t: 'code', code: `"Привет, CodeQuest!" println
// однострочный комментарий: всё после двух слэшей игнорируется
write("Квадрат семи: ")
(7 * 7) println` },
        { t: 'p', html: 'В Io нет функции печати в привычном смысле: строка — объект, и мы отправляем ей сообщение <code>println</code>. Сообщение выглядит как получатель, пробел, имя, а аргументы перечисляются в скобках. <code>write</code> печатает без переноса строки, а <code>writeln</code> печатает все аргументы подряд и переносит строку.' },
        { t: 'p', html: 'Важнейшая особенность: сообщения без скобок просто читают слот, а вычисления идут слева направо без приоритетов операторов. Поэтому скобки здесь не украшение, а способ задать порядок: сначала вычисляется <code>(7 * 7)</code>, потом результату отправляется <code>println</code>. Запусти файл командой <code>io hello.io</code> или открой интерактивную консоль командой <code>io</code>.' },
        { t: 'list', items: [
          '<b>"текст" println</b> — печать с переносом;',
          '<b>write(...)</b> — печать без переноса;',
          '<b>// комментарий</b> — однострочный (есть и <b>/* блок */</b>);',
          '<b>io файл.io</b> — запуск файла, <b>io</b> — интерактивная консоль.'
        ] },
        { t: 'warn', html: 'Без скобок порядок ломается: <code>7 * 7 println</code> напечатает 7, потому что println прилипнет к правой семёрке, а результат умножения останется непечатным. Привычка из других языков — <code>2 + 2 * 3</code> — тоже подводит: слева направо это 12, а не 14. Всегда расставляй скобки явно.' },
        { t: 'note', html: 'Имена в Io чувствительны к регистру: <code>println</code> и <code>Println</code> — разные сообщения. Точка с запятой разделяет сообщения на одной строке, а перенос строки делает это сам.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напечатай две строки: приветствие «Привет, CodeQuest!» и любое второе сообщение. Добавь хотя бы один комментарий <code>//</code>.</p>',
        starter: `// TODO: напечатай две строки через println`,
        rules: [
          { desc: 'Строка печатается сообщением println', all: ['"[^"]*"\\s+println'] },
          { desc: 'Есть фраза "Привет, CodeQuest!"', all: ['Привет, CodeQuest!'] },
          { desc: 'Есть однострочный комментарий //', all: ['//\\s*\\S'] },
          { desc: 'Печатается минимум две строки', all: ['println[\\s\\S]*"[^\\n]+"\\s+println'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Форма: "текст" println — получатель, пробел, сообщение.',
        'Вторую строку придумай сам: "Моя первая программа на Io" println',
        'Комментарий начинается с двух слэшей и не влияет на вывод.'
      ],
      solution: `"Привет, CodeQuest!" println
// всё — сообщение: строка получает println
"Моя первая программа на Io." println`
    },

    /* ---------- 2. Слоты и сообщения ---------- */
    {
      id: 'io-2',
      title: 'Слоты и сообщения',
      goal: 'Создать объект через Object clone, завести слоты оператором := и читать их сообщениями',
      xp: 35,
      theory: [
        { t: 'p', html: 'Объект в Io — это просто набор слотов: пар «имя — значение». Новый объект создаётся клонированием: <code>Hero := Object clone</code> — клон корневого прототипа Object. Никаких классов и ключевого слова new: клон связан с оригиналом прототипной ссылкой и живёт своей жизнью. Присваивания делаются сообщениями-операторами, и у них строгая грамматика.' },
        { t: 'code', code: `Hero := Object clone
Hero name := "Ада"
Hero hp := 100
Hero name println
Hero hp println` },
        { t: 'p', html: 'Оператор <code>:=</code> создаёт новый слот у получателя — так появились name и hp. Чтение слота — обычное сообщение без скобок: <code>Hero name</code> вернёт строку. А вот оператор <code>=</code> предназначен только для обновления существующего слота: попробуешь обновить несуществующий — получишь ошибку «Slot not found».' },
        { t: 'list', items: [
          '<b>Object clone</b> — создать объект;',
          '<b>Hero name := "Ада"</b> — создать слот;',
          '<b>Hero name</b> — прочитать слот;',
          '<b>Hero name = "Боб"</b> — обновить существующий слот;',
          '<b>Hero hp = 5</b> — ошибка, если hp ещё не создан.'
        ] },
        { t: 'p', html: 'Твои имена на верхнем уровне попадают в Lobby — корневой контекст, от которого всё наследуется. Слот может хранить что угодно: число, строку, другой объект или метод. Сообщения возвращают значения, поэтому цепочки вроде <code>"abc" size println</code> работают естественно.' },
        { t: 'warn', html: 'Самая частая ошибка новичка — перепутать <code>:=</code> и <code>=</code>. Первое создаёт слот, второе обновляет уже существующий; в других языках разницы нет, в Io — есть. Если увидел «Slot hp not found, must define slot using := before updating», просто поменяй оператор.' },
        { t: 'note', html: 'Третий оператор <code>::=</code> создаёт слот с типом и автоматическим сеттером: <code>age ::= 5</code> даст слот age и метод setAge. Он нужен для строгих объектов, но на старте хватит пары := и =.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери героя: клонируй Object, создай слоты name и hp, затем напечатай оба слота сообщениями.</p>',
        code: `Hero := Object {{1}}       // новый объект — клон Object
Hero name := {{2}}          // строка с именем героя
Hero hp := 100              // целый слот
Hero {{3}} println          // прочитай слот name и напечатай
{{4}} println               // прочитай слот hp`,
        blanks: [
          { answer: 'clone' },
          { answer: '"Ада"' },
          { answer: 'name' },
          { answer: 'Hero hp' }
        ]
      },
      hints: [
        'Первый пропуск — сообщение, которым создают объекты.',
        'Имя — строка: не забудь двойные кавычки.',
        'Последние два пропуска — чтение слотов: сначала у Hero, потом hp целиком.'
      ],
      solution: ['clone', '"Ада"', 'name', 'Hero hp']
    },

    /* ---------- 3. Прототипы: clone и наследование ---------- */
    {
      id: 'io-3',
      title: 'Прототипы: clone и наследование',
      goal: 'Построить цепочку прототипов: клонирование, затенение слотов и проверку proto',
      xp: 40,
      theory: [
        { t: 'p', html: 'Наследование в Io — это цепочка прототипов. <code>Dog := Animal clone</code> не копирует слоты Animal, а создаёт пустой объект со ссылкой-прототипом на Animal. Поиск слота идёт снизу вверх: сначала у самого объекта, затем у прототипа, затем у прототипа прототипа. Поэтому Dog отвечает на все сообщения Animal, ничего не объявляя.' },
        { t: 'code', code: `Animal := Object clone
Animal speak := method(
    "..." println
)

Dog := Animal clone
Dog speak := method(
    "Гав!" println
)

Cat := Animal clone

Cat speak
Dog speak` },
        { t: 'p', html: 'Переопределение — это просто создание слота с тем же именем в клоне: <code>Dog speak := method(...)</code> затеняет родительский слот. Кот в примере ничего не переопределяет и унаследует «...» — поведение по умолчанию. Проверить прототип можно сообщением <code>proto</code>: <code>Dog proto</code> вернёт Animal.' },
        { t: 'p', html: 'Такая модель гибче классов: прототип — готовый работающий объект, а не чертёж, и его можно клонировать по ходу программы. Цепочки строятся свободно: от Object к Animal, от Animal к TalkingParrot. Смена прототипа на лету тоже возможна — прототип это обычный слот.' },
        { t: 'list', items: [
          '<b>Parent := Object clone</b> — корневой прототип;',
          '<b>Child := Parent clone</b> — наследник;',
          '<b>child proto</b> — узнать прототип;',
          '<b>child слот := значение</b> — переопределение (затенение);',
          'поиск слота: сам объект → прототип → выше.'
        ] },
        { t: 'warn', html: 'Ловушка: оператор <code>=</code> обновляет слот там, где его нашёл, — включая прототип. Если у экземпляра нет собственного слота, а ты обновляешь унаследованный, изменится значение у прототипа, и его увидят все остальные клоны. Новые слоты для экземпляра создавай только через <code>:=</code>.' },
        { t: 'note', html: 'Пустой клон Object выглядит скучно, но уже умеет отвечать на базовые сообщения: type, print, proto. Достраивай его слотами — так растут все объекты в Io.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери семью прототипов: Animal с методом speak, переопределяющий Dog и унаследовавший Cat — затем отправь обоим потомкам сообщение speak отдельными строками.</p>',
        starter: `// TODO: собери прототипы Animal, Dog и Cat из условия

Animal := Object clone`,
        rules: [
          { desc: 'Прототип Animal создан клонированием Object', all: ['Animal\\s*:=\\s*Object\\s+clone'] },
          { desc: 'У Animal есть слот-метод speak', all: ['Animal\\s+speak\\s*:=\\s*method\\s*\\('] },
          { desc: 'Dog — клон Animal', all: ['Dog\\s*:=\\s*Animal\\s+clone'] },
          { desc: 'Dog переопределяет speak', all: ['Dog\\s+speak\\s*:=\\s*method'] },
          { desc: 'Cat — тоже клон Animal', all: ['Cat\\s*:=\\s*Animal\\s+clone'] },
          { desc: 'Оба потомка получают сообщение speak отдельными строками', all: ['\\n\\s*Cat\\s+speak\\b', '\\n\\s*Dog\\s+speak\\b'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Схема: Animal := Object clone, затем Animal speak := method( ... )',
        'Dog := Animal clone — и новый слот speak с тем же именем.',
        'Вызовы — просто строки: Cat speak и Dog speak, каждая на своей строке.'
      ],
      solution: `Animal := Object clone
Animal speak := method(
    "..." println
)

Dog := Animal clone
Dog speak := method(
    "Гав!" println
)

Cat := Animal clone

Cat speak
Dog speak`
    },

    /* ---------- 4. Методы: method ---------- */
    {
      id: 'io-4',
      title: 'Методы: method',
      goal: 'Создавать методы через method(аргументы, тело), вызывать их и склеивать строки оператором ..',
      xp: 45,
      theory: [
        { t: 'p', html: 'Метод создаётся сообщением <code>method</code>: в скобках через запятую перечисляются аргументы, а затем тело. Сохранённый в слот, он вызывается как обычное сообщение со скобками: <code>double(21)</code>. Аргументы лексические — тело видит именно те имена, что объявлены в заголовке.' },
        { t: 'code', code: `double := method(x, x * 2)

greet := method(name,
    "Привет, " .. name .. "!" println
)

writeln(double(21))
greet("Ада")` },
        { t: 'p', html: 'Возвращается последний вычисленный результат: у <code>double</code> это умножение. Склейку строк делает оператор <code>..</code> — он работает с любыми последовательностями. Обрати внимание на вызов <code>writeln(double(21))</code>: сначала вычисляется аргумент, потом печатается.' },
        { t: 'p', html: 'Внутри метода доступен объект <code>call</code> — зеркало вызова: <code>call sender</code> подскажет, кто отправил сообщение, <code>call message</code> — само сообщение, <code>call argAt(0)</code> — первый аргумент. На этом строятся собственные управляющие конструкции: именно так реализованы foreach и map в стандартной библиотеке. Такой доступ к вызову превращает обычный метод в строительный блок для собственных языковых фич.' },
        { t: 'list', items: [
          '<b>f := method(x, x * 2)</b> — метод с одним аргументом;',
          '<b>f := method("hi" println)</b> — метод без аргументов;',
          '<b>f(21)</b> — вызов со скобками;',
          '<b>call sender / call message / call argAt(0)</b> — интроспекция вызова;',
          '<b>..</b> — склейка строк.'
        ] },
        { t: 'warn', html: 'Запятая в method — разделитель между аргументами и телом: <code>method(x, x * 2)</code>. Забудешь её — тело сольётся с аргументами, и поведение станет загадочным. И помни: метод — это значение; пока он не сохранён в слот через :=, до него не добраться.' },
        { t: 'note', html: 'Методы удобно передавать: <code>nums map(x, double(x))</code> применит твой double к каждому элементу списка. О списках — следующий уровень.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви методы <code>double</code> (удвоение) и <code>greet</code> (приветствие со склейкой строк), затем вызови оба с аргументами.</p>',
        starter: `// TODO: объяви методы double и greet, затем вызови их`,
        rules: [
          { desc: 'Метод double объявлен с аргументом x', all: ['double\\s*:=\\s*method\\s*\\(\\s*\\w+\\s*,'] },
          { desc: 'Тело double умножает на 2', all: ['\\bx\\s*\\*\\s*2\\b'] },
          { desc: 'Метод greet тоже сохранён в слот', all: ['greet\\s*:=\\s*method\\s*\\('] },
          { desc: 'Строки склеиваются оператором ..', all: ['\\.\\.'] },
          { desc: 'Оба метода вызваны с аргументами', all: ['double\\s*\\(\\s*21\\s*\\)', 'greet\\s*\\(\\s*"'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Шаблон: double := method(x, x * 2)',
        'Склейка: "Привет, " .. name .. "!"',
        'Вызовы: writeln(double(21)) и greet("Ада")'
      ],
      solution: `double := method(x, x * 2)

greet := method(name,
    "Привет, " .. name .. "!" println
)

writeln(double(21))
greet("Ада")`
    },

    /* ---------- 5. Списки и циклы ---------- */
    {
      id: 'io-5',
      title: 'Списки и циклы',
      goal: 'Работать с List и Range: создание через list(...), обход foreach, сумма и чтение краёв',
      xp: 50,
      theory: [
        { t: 'p', html: 'Коллекция в Io — прототип <code>List</code>. Литерал <code>list(10, 20, 30)</code> создаёт готовый список, а дальше работают методы: <code>append</code> добавляет в конец, <code>at</code> читает по индексу, <code>size</code> считает элементы. Индексация с нуля, как в большинстве C-подобных языков.' },
        { t: 'code', code: `nums := list(10, 20, 30, 40)

nums foreach(n,
    n println
)

sum := 0
nums foreach(n, sum = sum + n)
writeln("Сумма: ", sum)` },
        { t: 'p', html: 'Цикл — тоже сообщение: <code>nums foreach(n, ...)</code> передаёт в переменную каждый элемент. Форма с двумя переменными даёт индекс и значение: <code>foreach(i, n, ...)</code>. В примере сумма копится через обновление слота <code>sum</code> — оператор <code>=</code> здесь законен, слот уже создан.' },
        { t: 'code', code: `1 to(5) foreach(i,
    write(i, " ")
)
"" println

writeln("Первый: ", nums first)
writeln("Последний: ", nums last)
writeln("Размер: ", nums size)` },
        { t: 'p', html: 'Диапазон чисел создаёт сообщение <code>to</code>: <code>1 to(5)</code> — это Range, и у него тоже есть foreach. Есть и классический цикл в C-стиле — <code>for(i, 1, 5, ...)</code> — тоже сообщение, а не ключевое слово. Края списка отвечают на <code>first</code> и <code>last</code>, а <code>size</code> — длина.' },
        { t: 'list', items: [
          '<b>list(1, 2, 3)</b> — создать список;',
          '<b>append(x) / at(i) / size</b> — базовые операции;',
          '<b>foreach(v, ...) или foreach(i, v, ...)</b> — обход;',
          '<b>1 to(5)</b> — Range с foreach;',
          '<b>map / select</b> — преобразование и фильтрация.'
        ] },
        { t: 'warn', html: 'Индексация с нуля: <code>nums at(0)</code> — первый элемент. <code>size</code> возвращает количество, поэтому последний индекс — size минус один. Не путай <code>first</code> (значение) с <code>at(0)</code> — они возвращают одно и то же, но читаются по-разному.' },
        { t: 'note', html: 'Арифметика уже встроена: <code>nums sum</code>, <code>nums average</code>, <code>nums min</code> и <code>max</code> считают сами. В проекте они пригодятся для итогов.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери набор: список через <code>list(...)</code>, обход <code>foreach</code> с накоплением суммы, диапазон <code>1 to(5)</code> и печати <code>first</code>, <code>last</code>, <code>size</code>.</p>',
        starter: `// TODO: список, foreach с суммой, Range и печати краёв

nums := list(10, 20, 30, 40)`,
        rules: [
          { desc: 'Список создан через list(...)', all: ['\\w+\\s*:=\\s*list\\s*\\([^)]+\\)'] },
          { desc: 'Обход списка через foreach', all: ['nums\\s+foreach\\s*\\(\\s*\\w+\\s*,'] },
          { desc: 'Сумма накапливается в цикле', all: ['sum\\s*=\\s*sum\\s*\\+\\s*\\w+'] },
          { desc: 'Диапазон 1 to(5) или цикл for(i, 1, 5, ...)', any: ['1\\s+to\\s*\\(\\s*5\\s*\\)', '\\bfor\\s*\\(\\s*\\w+\\s*,\\s*1\\s*,\\s*5\\s*,'] },
          { desc: 'Использованы first, last и size', all: ['\\bfirst\\b', '\\blast\\b', '\\bsize\\b'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Обход: nums foreach(n, n println) — а сумму копи в отдельном слоте.',
        'Диапазон: 1 to(5) foreach(i, write(i, " ")) и потом "" println',
        'Края: nums first, nums last, nums size.'
      ],
      solution: `nums := list(10, 20, 30, 40)

nums foreach(n,
    n println
)

sum := 0
nums foreach(n, sum = sum + n)
writeln("Сумма: ", sum)

1 to(5) foreach(i,
    write(i, " ")
)
"" println

writeln("Первый: ", nums first)
writeln("Последний: ", nums last)
writeln("Размер: ", nums size)`
    },

    /* ---------- 6. 🚀 Проект: счётчик банковских счетов ---------- */
    {
      id: 'io-6',
      title: '🚀 Проект: счётчик банковских счетов',
      goal: 'Собрать прототип Account с method-слотами, экземпляры с собственными балансами и итог через List и foreach',
      xp: 110,
      theory: [
        { t: 'p', html: 'Проект — учёт банковских счетов на прототипах. Прототип <code>Account</code> описывает поведение: методы deposit и withdraw. Каждый счёт — клон с собственным слотом balance, экземпляры собираются в список, а итоговая сумма считается обходом foreach. Это каноническая связка слотов, методов и коллекций.' },
        { t: 'code', code: `Account := Object clone
Account deposit := method(amount,
    balance = balance + amount
)
Account withdraw := method(amount,
    balance = balance - amount
)` },
        { t: 'p', html: 'Внутри методов обновление слота делается оператором <code>=</code>: <code>balance = balance + amount</code>. Здесь кроется главная ловушка прототипов: если у экземпляра нет собственного balance, обновится слот прототипа — и деньги смешаются у всех. Поэтому после клонирования каждому счёту сразу создаётся свой слот.' },
        { t: 'code', code: `a1 := Account clone
a1 balance := 100
a2 := Account clone
a2 balance := 250

a1 withdraw(40)
a2 deposit(50)` },
        { t: 'p', html: 'Строка <code>a1 balance := 100</code> создаёт слот в самом a1 — дальше цепочка прототипов для этой переменной не используется, и операции затрагивают только его. Попробуй убрать эту строку и посмотреть, что станет со слотом Account, — отличная лабораторная работа. После создания оба счёта живут независимо: снятие у первого не трогает второй.' },
        { t: 'code', code: `accounts := list(a1, a2)

total := 0
accounts foreach(acc,
    total = total + acc balance
)

writeln("Счетов открыто: ", accounts size)
writeln("Всего денег: ", total)` },
        { t: 'p', html: 'Список счётов — обычный <code>List</code>. Обход <code>foreach(acc, ...)</code> накапливает итог: <code>acc balance</code> читает слот каждого экземпляра. В конце две строки отчёта печатаются через <code>writeln</code>: количество счетов и общая сумма. Шаги проекта: прототип, клоны с балансами, операции, список, итог.' },
        { t: 'warn', html: 'Создавая слоты экземплярам, не забывай <code>:=</code>: через <code>=</code> ты обновишь чужой слот. И следи, чтобы переменная итога тоже была создана заранее: <code>total := 0</code>, иначе обновление не найдёт цель.' },
        { t: 'note', html: 'Куда расти: добавь метод-фабрику <code>open</code>, который клонирует счёт, создаёт баланс и сразу кладёт его в список. А ещё — отдельный метод для подсчёта средних средств.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери реестр счетов: прототип с методами deposit и withdraw, два клона с собственными балансами, список, обход с подсчётом и итоговый отчёт через <code>writeln</code>.</p>',
        starter: `// TODO: прототип Account, два счёта с балансами, список и итог через foreach`,
        rules: [
          { desc: 'Прототип Account — клон Object', all: ['Account\\s*:=\\s*Object\\s+clone'] },
          { desc: 'Методы deposit и withdraw объявлены на прототипе', all: ['Account\\s+deposit\\s*:=\\s*method', 'Account\\s+withdraw\\s*:=\\s*method'] },
          { desc: 'В методах баланс обновляется через = (и плюс, и минус)', all: ['balance\\s*=\\s*balance\\s*\\+\\s*\\w+', 'balance\\s*=\\s*balance\\s*-\\s*\\w+'] },
          { desc: 'Два клона Account с собственными слотами balance', all: ['\\w+\\s*:=\\s*Account\\s+clone', 'balance\\s*:=\\s*\\d+'] },
          { desc: 'Счета собраны в список list(...)', all: ['\\w+\\s*:=\\s*list\\s*\\(\\s*\\w+\\s*,\\s*\\w+\\s*\\)'] },
          { desc: 'Итог накапливается в foreach по списку', all: ['foreach\\s*\\(\\s*\\w+\\s*,', 'total\\s*=\\s*total\\s*\\+\\s*\\w+\\s+balance'] },
          { desc: 'Итоги напечатаны через writeln', all: ['writeln\\s*\\('] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Прототип: Account deposit := method(amount, balance = balance + amount)',
        'Клонам — свои слоты: a1 := Account clone, затем a1 balance := 100',
        'Итог: total := 0, затем accounts foreach(acc, total = total + acc balance)'
      ],
      solution: `Account := Object clone
Account deposit := method(amount,
    balance = balance + amount
)
Account withdraw := method(amount,
    balance = balance - amount
)

a1 := Account clone
a1 balance := 100
a2 := Account clone
a2 balance := 250

a1 withdraw(40)
a2 deposit(50)

accounts := list(a1, a2)

total := 0
accounts foreach(acc,
    total = total + acc balance
)

writeln("Счетов открыто: ", accounts size)
writeln("Всего денег: ", total)`
    }
  ],

  cheats: [
    { title: 'Первые сообщения', code: `"текст" println      // печать с переносом
write("без переноса")
(2 + 2) println      // скобки важны!
// однострочный комментарий
/* блочный комментарий */` },
    { title: 'Слоты: := и =', code: `Hero := Object clone
Hero name := "Ада"   // создать слот
Hero name            // прочитать
Hero name = "Боб"    // обновить существующий
Hero hp = 5          // ошибка: слота нет
age ::= 5            // слот с типом и setAge` },
    { title: 'Прототипы', code: `Animal := Object clone
Animal speak := method("..." println)
Dog := Animal clone  // наследник
Dog proto            // → Animal
Dog speak            // унаследовано
Dog speak := method("Гав!" println)  // затенение` },
    { title: 'Методы', code: `double := method(x, x * 2)
double(21)                    // 42
greet := method(name,
    "Привет, " .. name .. "!" println)
nums map(x, double(x))        // методы — значения
// call sender, call message, call argAt(0)` },
    { title: 'List и Range', code: `nums := list(10, 20, 30)
nums append(40)
nums at(0)          // 10, индекс с нуля
nums size           // 4
nums sum            // 100
nums foreach(i, n, writeln(i, ": ", n))
1 to(5) foreach(i, write(i, " "))
for(i, 1, 5, write(i, " "))   // C-стиль` },
    { title: 'Частые ошибки', code: `// 2 + 2 * 3 == 12 (слева направо!)
// 7 * 7 println печатает 7 — нужны скобки
// = на унаследованном слоте меняет прототип
// забытая запятая в method(x, тело)
// индексация с нуля: at(0)` }
  ]
};
