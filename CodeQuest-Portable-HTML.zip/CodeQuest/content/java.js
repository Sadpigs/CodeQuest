/* ============ CodeQuest — курс Java ============
   Java не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами
   и задачами «предскажи вывод».
================================================= */
window.CQ_LANGS = window.CQ_LANGS || {};
window.CQ_LANGS.java = {
  id: 'java',
  title: 'Java',
  emoji: '☕',
  color: '#b07219',
  lang: 'c',
  tagline: 'Энтерпрайз-классика: от main до Streams и потоков',
  description: 'Строго типизированный язык JVM: от первой программы и ООП до наследования, коллекций, Generics, исключений, лямбд, Streams и первых потоков.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'java-1',
      title: 'Первая программа',
      goal: 'Написать первую программу на Java: класс Main, метод main и вывод в консоль',
      xp: 30,
      theory: [
        { t: 'p', html: 'Java — один из самых востребованных языков в мире: на нём пишут Android-приложения, банковские системы и серверные сервисы. Программа на Java — это всегда набор классов, а запуск начинается с метода <code>main</code>. Строгая типизация и компиляция делают Java «разговорчивой»: она предупредит о большинстве ошибок ещё до запуска программы.' },
        { t: 'h', html: 'Минимальная программа' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        System.out.println("Привет, CodeQuest!");
    }
}` },
        { t: 'p', html: 'Разберём по частям. <code>public class Main</code> объявляет публичный класс с именем Main — код на Java живёт только внутри классов. Файл обязан называться так же, как публичный класс: <b>Main.java</b>. Метод <code>main</code> — точка входа: именно его JVM (виртуальная Java-машина) находит и вызывает первым, когда ты запускаешь программу.' },
        { t: 'list', items: [
          '<b>public</b> — метод доступен отовсюду, включая запуск из командной строки;',
          '<b>static</b> — метод принадлежит классу целиком, объект создавать не нужно;',
          '<b>void</b> — метод ничего не возвращает;',
          '<b>String[] args</b> — аргументы командной строки (пока их просто не трогаем).'
        ] },
        { t: 'note', html: 'Как код превращается в работу: команда <b>javac Main.java</b> компилирует исходник в байт-код — файл Main.class. Затем <b>java Main</b> запускает байт-код на JVM. Компилятор проверяет типы и синтаксис до запуска, поэтому глупые ошибки ловятся сразу — в этом сила компилируемых языков.' },
        { t: 'warn', html: 'Java чувствительна к регистру: <code>System</code> — с большой буквы, <code>main</code> — со строчной. Напишешь <code>Main</code> вместо <code>main</code> — компилятор не найдёт точку входа, а <code>system.out.println</code> с маленькой буквы вообще не скомпилируется.' },
        { t: 'p', html: 'Вывод в консоль делает <code>System.out.println(...)</code>: печатает текст в кавычках и переводит строку. Вариант <code>System.out.print(...)</code> не переводит строку — следующий текст продолжится на той же строке. В этом приложении Java-код не запускается, а проверяется по структуре, поэтому пиши настоящий код — как будто его сейчас скомпилирует javac.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери свою первую программу: класс <code>Main</code> с методом <code>main</code>, который выводит в консоль фразу <code>Привет, CodeQuest!</code> (можно добавить и вторую строку — любую). Каркас уже дан — дополни его и не оставляй пометок в комментариях.</p>',
        starter: `public class Main {
    public static void main(String[] args) {
        // TODO: выведи приветствие здесь
    }
}`,
        rules: [
          { desc: 'Объявлен класс Main', all: ['class\\s+Main'] },
          { desc: 'Есть метод main с параметром String[] args', all: ['main\\s*\\(\\s*String\\s*\\[\\s*\\]\\s*\\w+\\s*\\)'] },
          { desc: 'Есть вывод на экран (System.out.println или print)', any: ['System\\.out\\.println', 'System\\.out\\.print'] },
          { desc: 'В кавычках — фраза "Привет, CodeQuest!"', all: ['"Привет, CodeQuest!"'] },
          { desc: 'Есть вывод на экран, и в коде не осталось пометок TODO', any: ['System\\.out\\.println', 'System\\.out\\.print'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Не трогай каркас public class Main { ... } — он уже правильный.',
        'Внутри main добавь строку System.out.println("Привет, CodeQuest!"); — не забудь точку с запятой.',
        'Фразу пиши точно: Привет, CodeQuest! — с запятой и восклицательным знаком.'
      ],
      solution: `public class Main {
    public static void main(String[] args) {
        System.out.println("Привет, CodeQuest!");
        System.out.println("Это моя первая программа на Java.");
    }
}`
    },

    /* ---------- 2. Переменные и типы ---------- */
    {
      id: 'java-2',
      title: 'Переменные и типы',
      goal: 'Объявлять переменные типов int, double, boolean и String и понимать var',
      xp: 30,
      theory: [
        { t: 'p', html: 'Переменная — это именованная ячейка памяти, в которой хранится значение. Главная особенность Java: у каждой переменной есть строгий тип, задаваемый один раз при объявлении. Положил в переменную целое число — и она навсегда остаётся целочисленной: компилятор не позволит положить туда текст.' },
        { t: 'table', head: ['Тип', 'Что хранит', 'Примеры значений'], rows: [
          ['int', 'целые числа', '42, -7, 0'],
          ['double', 'числа с дробной частью', '3.14, -0.5, 100.0'],
          ['boolean', 'логическое значение', 'true, false'],
          ['char', 'один символ, в одинарных кавычках', "'A', '9', 'я'"],
          ['String', 'текст (это класс, с большой буквы)', '"Привет", "Java 21"']
        ] },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        int age = 25;
        double price = 99.90;
        boolean isStudent = true;
        String name = "Аня";

        System.out.println(name + ", " + age);
    }
}` },
        { t: 'p', html: 'Объявление читается так: «тип имя = значение». Значение можно присвоить и позже, но до первого использования переменная обязана быть инициализирована — иначе компилятор откажется собирать программу. Имена пишутся в стиле camelCase: <code>maxScore</code>, <code>userAge</code> — с маленькой буквы, каждое новое слово с большой.' },
        { t: 'h', html: 'Оператор var' },
        { t: 'p', html: 'С Java 10 появился <code>var</code>: он говорит компилятору «выведи тип сам». Строка <code>var count = 10;</code> создаёт обычную int-переменную — тип всё равно строгий, просто его не нужно писать руками. var работает только для локальных переменных внутри методов; у полей класса и параметров методов тип указывается явно.' },
        { t: 'note', html: 'Ключевое слово <code>final</code> делает переменную константой: <code>final int DAYS_IN_WEEK = 7;</code>. Попытка изменить её позже — ошибка компиляции. Константы по договорённости пишут ЗАГЛАВНЫМИ буквами с подчёркиваниями.' },
        { t: 'warn', html: 'Дробная часть пишется через точку, а не запятую: <code>3.14</code>, но не <code>3,14</code>. И помни: String — с большой буквы, потому что это класс; int, double и boolean — примитивы, они пишутся маленькими.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Заполни пропуски так, чтобы каждая переменная получила правильный тип: <code>score</code> — целое число, <code>pi</code> — дробное, <code>ok</code> — логическое, <code>name</code> — текст. Пиши типы так, как принято в Java.</p>',
        code: `public class Main {
    public static void main(String[] args) {
        {{0}} score = 100;
        {{1}} pi = 3.14;
        {{2}} ok = true;
        {{3}} name = "Java";
        System.out.println(name + " " + score);
    }
}`,
        blanks: [
          { answer: 'int' },
          { answer: 'double' },
          { answer: 'boolean' },
          { answer: 'String' }
        ]
      },
      hints: [
        'Целые числа — это int, дробные — double.',
        'true и false — значения типа boolean, а текст в кавычках — String.',
        'Примитивы пишутся с маленькой буквы, а строковый класс String — с большой.'
      ],
      solution: ['int', 'double', 'boolean', 'String']
    },

    /* ---------- 3. Арифметика и приведение типов ---------- */
    {
      id: 'java-3',
      title: 'Арифметика и приведение типов',
      goal: 'Считать без сюрпризов: целочисленное деление, остаток % и приведение типов',
      xp: 35,
      theory: [
        { t: 'p', html: 'Java умеет всё, что ожидается от калькулятора: <code>+</code>, <code>-</code>, <code>*</code>, <code>/</code> и <code>%</code> — остаток от деления. Но у деления есть коварная особенность, на которой спотыкаются почти все новички.' },
        { t: 'h', html: 'Целочисленное деление' },
        { t: 'p', html: 'Если оба операнда — целые (int), то и результат будет целым: дробная часть просто отбрасывается, без округления. <code>7 / 2</code> — это <code>3</code>, а не 3.5. Оператор <code>%</code> возвращает остаток: <code>7 % 2</code> — это <code>1</code>. Он незаменим для проверки чётности (<code>x % 2 == 0</code>), циклических счётчиков и разбиения чисел на разряды.' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        System.out.println(7 / 2);          // 3 — целочисленное деление
        System.out.println(7 % 2);          // 1 — остаток
        System.out.println(7.0 / 2);        // 3.5 — есть double, деление дробное
        System.out.println((double) 7 / 2); // 3.5 — явное приведение типа
    }
}` },
        { t: 'h', html: 'Приведение типов' },
        { t: 'p', html: 'Типы можно преобразовывать. Из меньшего в большее Java делает сама: int спокойно превращается в double (<code>double d = 7;</code> — будет 7.0). А вот обратно — только вручную, через явное приведение: <code>(int) 3.9</code> даст <code>3</code> — дробная часть отрезается, а не округляется. Чтобы деление двух int стало дробным, приведи любой из операндов: <code>(double) a / b</code>.' },
        { t: 'table', head: ['Выражение', 'Результат', 'Почему'], rows: [
          ['7 / 2', '3', 'оба операнда int — деление целочисленное'],
          ['7 % 2', '1', 'остаток от деления 7 на 2'],
          ['7.0 / 2', '3.5', 'один операнд double — деление дробное'],
          ['(double) 7 / 2', '3.5', '7 приведён к double перед делением'],
          ['(int) 3.9', '3', 'дробная часть отбрасывается'],
          ['2 + 3 * 4', '14', 'умножение раньше сложения']
        ] },
        { t: 'note', html: 'Порядок действий как в математике: сначала *, / и %, потом + и -. Сомневаешься — ставь скобки: <code>(2 + 3) * 4</code> даст 20. Есть и короткие операторы: <code>score += 5</code> то же, что <code>score = score + 5</code>, а <code>i++</code> увеличивает на единицу.' },
        { t: 'warn', html: 'Классическая ошибка: среднее арифметическое <code>(a + b) / 2</code> для двух int даст целое число. Если нужен точный результат — приводи: <code>(a + b) / 2.0</code>.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Внимательно прочитай код и напиши, что он выведет в консоль — по одному значению на строку, в порядке вывода.</p>',
        code: `public class Main {
    public static void main(String[] args) {
        System.out.println(7 / 2);
        System.out.println(7 % 2);
        System.out.println(7.0 / 2);
        System.out.println((double) 7 / 2);
        System.out.println(2 + 3 * 4);
    }
}`,
        answer: `3
1
3.5
3.5
14`
      },
      hints: [
        'Если оба операнда int, дробная часть отбрасывается: 7 / 2 = 3.',
        'Приведи (double) 7 к дробному типу — и деление станет обычным: 3.5.',
        'Не забудь про приоритет операций: сначала умножение, потом сложение.'
      ],
      solution: `3
1
3.5
3.5
14`
    },

    /* ---------- 4. Условия ---------- */
    {
      id: 'java-4',
      title: 'Условия: if, else, switch',
      goal: 'Управлять ходом программы: if/else, операторы сравнения и switch',
      xp: 35,
      theory: [
        { t: 'p', html: 'До сих пор наши программы были прямыми: сверху вниз, строка за строкой. Настоящие программы умеют выбирать дорогу: проверить условие и выполнить разный код. За это отвечают условные операторы — фундамент любой логики.' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        int temp = 25;

        if (temp > 30) {
            System.out.println("Жара!");
        } else if (temp >= 18) {
            System.out.println("Тепло");
        } else {
            System.out.println("Прохладно");
        }
    }
}` },
        { t: 'p', html: 'Условие — это выражение типа boolean в скобках после <code>if</code>. Если оно истинно, выполняется первый блок; иначе проверяются ветки <code>else if</code>; если ни одна не подошла — срабатывает <code>else</code>. Ветвление заканчивается на первой истине, остальные ветки пропускаются.' },
        { t: 'list', items: [
          '<b>Сравнения:</b> <code>==</code> равно, <code>!=</code> не равно, <code>&gt;</code> больше, <code>&lt;</code> меньше, <code>&gt;=</code>, <code>&lt;=</code>;',
          '<b>И:</b> <code>a &amp;&amp; b</code> — истинно, только если истинны оба условия;',
          '<b>ИЛИ:</b> <code>a || b</code> — истинно, если истинно хотя бы одно;',
          '<b>НЕ:</b> <code>!a</code> — переворачивает условие наоборот.'
        ] },
        { t: 'h', html: 'Оператор switch' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        int day = 6;
        switch (day) {
            case 6:
            case 7:
                System.out.println("Выходной!");
                break;
            default:
                System.out.println("Рабочий день");
        }
    }
}` },
        { t: 'p', html: '<code>switch</code> сравнивает значение с вариантами <code>case</code> и переходит к совпавшему. Не забывай <code>break</code>: без него выполнение «проваливается» в следующий case. С Java 14 есть короткая форма: <code>case 6, 7 -&gt; System.out.println("Выходной!");</code> — без break и безопаснее.' },
        { t: 'warn', html: 'Не путай <code>==</code> (сравнение) и <code>=</code> (присваивание): <code>if (x = 5)</code> не скомпилируется для int — а вот внутри boolean-условия случайно присвоится. И запомни на будущее: <code>==</code> подходит для чисел, но строки так сравнивать нельзя — об этом будет уровень 8.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Допиши программу-градусник: переменной <code>temp</code> уже задано значение. Условиями проверь: если <code>temp</code> больше или равно 20 — выведи <code>Тепло</code>, иначе — выведи <code>Холодно</code>. В коде должны быть if, ветка else и вывод на экран.</p>',
        starter: `public class Main {
    public static void main(String[] args) {
        int temp = 15;
        // проверь температуру и выведи результат
    }
}`,
        rules: [
          { desc: 'Есть оператор if с условием в скобках', all: ['\\bif\\s*\\('] },
          { desc: 'Есть ветка else (или switch)', any: ['\\belse\\b', '\\bswitch\\b'] },
          { desc: 'Условие использует сравнение (например, >= 20)', all: ['\\bif\\s*\\([^)]*(>=|<=|==|!=|>|<)[^)]*\\)'] },
          { desc: 'Результат выводится через System.out.println / print', any: ['System\\.out\\.println', 'System\\.out\\.print'] },
          { desc: 'Есть вывод на экран без Scanner', any: ['System\\.out\\.println', 'System\\.out\\.print'], none: ['Scanner'] }
        ]
      },
      hints: [
        'Условие пишется в скобках: if (temp >= 20) { ... }.',
        'Для «иначе» добавь блок else { ... } сразу после закрывающей скобки if.',
        'Не забудь точку с запятой: System.out.println("Тепло");'
      ],
      solution: `public class Main {
    public static void main(String[] args) {
        int temp = 15;
        if (temp >= 20) {
            System.out.println("Тепло");
        } else {
            System.out.println("Холодно");
        }
    }
}`
    },

    /* ---------- 5. Циклы ---------- */
    {
      id: 'java-5',
      title: 'Циклы: for и while',
      goal: 'Повторять действия: цикл for со счётчиком, while с условием, break и continue',
      xp: 40,
      theory: [
        { t: 'p', html: 'Компьютеры не устают — используй это. Цикл повторяет блок кода, пока выполняется условие: вывести сто строк, просуммировать числа, обработать каждый элемент. В Java два главных цикла: <code>for</code> — когда известно, сколько повторений нужно, и <code>while</code> — когда известно условие, при котором продолжать.' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Шаг " + i);
        }
    }
}` },
        { t: 'p', html: 'В скобках у for три части через точку с запятой: <b>инициализация</b> (<code>int i = 1</code>) — выполняется один раз перед началом; <b>условие</b> (<code>i &lt;= 5</code>) — проверяется перед каждым повторением; <b>шаг</b> (<code>i++</code>) — выполняется после каждого повторения. Переменная-счётчик живёт только внутри цикла.' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        int count = 3;
        while (count > 0) {
            System.out.println(count);
            count--;
        }
        System.out.println("Старт!");
    }
}` },
        { t: 'list', items: [
          '<b>for</b> — известно число повторений: «сделай 10 раз»;',
          '<b>while</b> — конец может наступить в любой момент: «пока данные не кончатся»;',
          '<b>do { ... } while (условие);</b> — тело выполнится хотя бы один раз;',
          '<b>for (int x : массив)</b> — for-each: перебор элементов без счётчика.'
        ] },
        { t: 'note', html: 'Оператор <code>break</code> досрочно выходит из цикла, <code>continue</code> пропускает остаток текущего повторения и переходит к следующему. Циклы можно вкладывать друг в друга: for внутри for — так печатают таблицы и обходят двумерные массивы.' },
        { t: 'warn', html: 'Если условие никогда не станет ложным (например, забыл <code>i++</code>), цикл станет бесконечным и программа зависнет. Компилятор такое не ловит — это ошибка логики, следи за счётчиком сам.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Проследи за выполнением каждого цикла и запиши, что выведет программа: каждое значение — на своей строке, в порядке вывода.</p>',
        code: `public class Main {
    public static void main(String[] args) {
        int sum = 0;
        for (int i = 1; i <= 4; i++) {
            sum += i;
        }
        System.out.println(sum);

        int n = 8;
        while (n > 1) {
            n = n / 2;
        }
        System.out.println(n);

        for (int i = 3; i >= 1; i--) {
            System.out.println(i);
        }
    }
}`,
        answer: `10
1
3
2
1`
      },
      hints: [
        'sum накапливает: 1, затем 1+2, затем 1+2+3, и так до 1+2+3+4.',
        'В while число каждый раз делится пополам, пока не станет 1: 8 → 4 → 2 → 1.',
        'Последний цикл идёт в обратную сторону: от 3 вниз до 1.'
      ],
      solution: `10
1
3
2
1`
    },

    /* ---------- 6. Массивы ---------- */
    {
      id: 'java-6',
      title: 'Массивы',
      goal: 'Хранить набор значений в массиве: объявление, индексы, length, обход',
      xp: 40,
      theory: [
        { t: 'p', html: 'Переменная хранит одно значение. А если их сто? Заводить сто переменных — безумие. Для наборов однотипных значений в Java есть массив: фиксированный по длине контейнер, где элементы лежат под порядковыми номерами — индексами.' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        int[] scores = new int[5];      // пять нулей
        scores[0] = 90;                 // первый элемент — индекс 0!
        scores[4] = 75;                 // последний — индекс 4

        int[] primes = {2, 3, 5, 7};    // массив с готовыми значениями

        System.out.println(primes.length); // 4 — длина массива
        System.out.println(primes[1]);     // 3 — второй элемент
    }
}` },
        { t: 'p', html: 'Объявление <code>int[] scores = new int[5];</code> создаёт массив из пяти нулей. Второй способ — литерал в фигурных скобках: размер вычисляется сам. Индексация начинается с <b>нуля</b>: у массива из 4 элементов индексы 0, 1, 2, 3. Последний индекс всегда <code>length - 1</code>.' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        int[] primes = {2, 3, 5, 7};

        for (int i = 0; i < primes.length; i++) {
            System.out.println(primes[i]);
        }

        for (int p : primes) {           // for-each — короче
            System.out.println(p);
        }
    }
}` },
        { t: 'warn', html: 'Обращение к несуществующему индексу — любимая ошибка новичков: <code>primes[4]</code> при длине 4 вызовет <code>ArrayIndexOutOfBoundsException</code> и остановит программу. Условие цикла всегда <code>i &lt; length</code>, а не <code>i &lt;= length</code>.' },
        { t: 'note', html: 'Длина массива задаётся один раз и не меняется. Нужен растущий список — пригодится <code>ArrayList</code>, о нём будет уровень 10. Кстати, length у массива — это поле, без скобок; у строки length() — метод, со скобками.' },
        { t: 'p', html: 'При создании через <code>new</code> массив заполняется автоматически: нулями для чисел, <code>false</code> для boolean и <code>null</code> для объектов и String. Это удобно — массив сразу готов к работе, просто заполняй его по индексам.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Прочитай код и выбери, что он выведет в консоль:</p><pre>int[] a = {10, 20, 30, 40};
System.out.println(a[1] + a[a.length - 1]);</pre>`,
        options: ['30', '50', '60', 'Ошибка: выход за границы массива'],
        correct: 2,
        explain: 'Индексация идёт с нуля: a[1] — это второй элемент, то есть 20. a.length - 1 = 3 — индекс последнего элемента, a[3] = 40. Сумма: 20 + 40 = 60.'
      },
      hints: [
        'Первый элемент массива — a[0], а не a[1].',
        'a.length - 1 — это индекс последнего элемента: для массива из четырёх элементов это 3.'
      ],
      solution: 2
    },

    /* ---------- 7. Методы ---------- */
    {
      id: 'java-7',
      title: 'Методы',
      goal: 'Выносить код в методы: параметры, return, вызов из main',
      xp: 45,
      theory: [
        { t: 'p', html: 'Метод — это именованный блок кода, который можно вызывать сколько угодно раз. Методы спасают от копипасты, разбивают программу на понятные части и дают коду словарь: вместо простыни вычислений — один призыв <code>calculatePrice()</code>. Ты уже писал метод main — теперь напишешь собственный.' },
        { t: 'code', code: `public class Main {

    static int square(int x) {
        return x * x;
    }

    public static void main(String[] args) {
        System.out.println(square(5));   // 25
        System.out.println(square(9));   // 81
    }
}` },
        { t: 'list', items: [
          '<b>static</b> — метод принадлежит классу, его можно звать без объекта;',
          '<b>int</b> — тип возвращаемого значения (что метод отдаёт наружу);',
          '<b>square</b> — имя метода, глагол в camelCase;',
          '<b>int x</b> — параметр: входные данные, доступные внутри метода;',
          '<b>return</b> — возвращает результат и завершает метод.'
        ] },
        { t: 'p', html: 'Если метод ничего не возвращает, вместо типа пишут <code>void</code> — например, метод, который просто печатает строку. Параметров может быть несколько, через запятую: <code>static int sum(int a, int b)</code>. Аргументы передаются копиями значений: изменение параметра внутри метода не затронет внешнюю переменную.' },
        { t: 'p', html: 'Одно имя можно перегрузить: несколько методов с одинаковым именем, но разными параметрами — <code>print(int x)</code> и <code>print(String s)</code>. Компилятор сам выберет нужный по типам аргументов. Так устроено множество методов стандартной библиотеки.' },
        { t: 'note', html: 'Если метод обещал вернуть int — он обязан вернуть значение из всех веток: <code>if (x &gt; 0) { return 1; } else { return -1; }</code> — хорошо, а return только внутри if без else компилятор отвергнет с ошибкой «missing return statement».' },
        { t: 'warn', html: 'Метод, объявленный внутри другого метода, — ошибка компиляции. Все методы живут на уровне класса, рядом с main, а не внутри него.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши статический метод <code>square</code>, который принимает целый параметр и возвращает его квадрат через <code>return</code>. В <code>main</code> вызови метод с числом (например, 5) и выведи результат на экран.</p>',
        starter: `public class Main {
    public static void main(String[] args) {
        // вызови метод square с числом и выведи результат
    }

    // объяви здесь метод square
}`,
        rules: [
          { desc: 'Объявлен метод static int square(...)', all: ['static\\s+int\\s+square\\s*\\('] },
          { desc: 'Метод принимает целый параметр (int)', any: ['square\\s*\\(\\s*int\\s+\\w+'] },
          { desc: 'Результат возвращается через return', all: ['\\breturn\\b'] },
          { desc: 'Метод square вызывается с числом, например square(5)', all: ['square\\s*\\(\\s*[0-9]+\\s*\\)'] },
          { desc: 'Есть класс Main и метод main', all: ['class\\s+Main', 'main\\s*\\(\\s*String'] }
        ]
      },
      hints: [
        'Метод объявляют рядом с main, на уровне класса: static int square(int x) { ... }.',
        'Внутри метода верни результат: return x * x;',
        'В main достаточно одной строки: System.out.println(square(5));'
      ],
      solution: `public class Main {
    static int square(int x) {
        return x * x;
    }

    public static void main(String[] args) {
        System.out.println(square(5));
    }
}`
    },

    /* ---------- 8. Строки ---------- */
    {
      id: 'java-8',
      title: 'Строки String',
      goal: 'Работать со строками: методы String и главное правило — equals вместо ==',
      xp: 45,
      theory: [
        { t: 'p', html: 'String — не примитив, а полноценный класс, поэтому он с большой буквы. Самое важное свойство строк: они <b>неизменяемы</b>. Любая операция — склейка, замена, обрезка — не меняет существующую строку, а создаёт новую. Старая остаётся такой, как была.' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        String s = "CodeQuest";
        System.out.println(s.length());          // 9 — длина
        System.out.println(s.charAt(0));         // C — символ по индексу
        System.out.println(s.substring(0, 4));   // Code — срез [0, 4)
        System.out.println(s.toUpperCase());     // CODEQUEST
        System.out.println(s + "!");             // CodeQuest! — склейка
    }
}` },
        { t: 'list', items: [
          '<code>length()</code> — количество символов;',
          '<code>charAt(i)</code> — символ по индексу (нумерация с нуля);',
          '<code>substring(a, b)</code> — кусок от a до b, не включая b;',
          '<code>toUpperCase() / toLowerCase()</code> — смена регистра;',
          '<code>indexOf("текст")</code> — индекс первого вхождения или -1;',
          '<code>trim()</code> — убирает пробелы по краям.'
        ] },
        { t: 'h', html: 'Почему == не работает' },
        { t: 'p', html: 'Для строк <code>==</code> сравнивает не содержимое, а ссылки — «один ли это объект в памяти». Две внешне одинаковые строки могут быть разными объектами, и <code>==</code> вернёт false. Поэтому строки сравнивают методом <code>equals</code>. Это классическая ловушка Java — запомни её один раз и экономь часы отладки.' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        String a = "Code";
        String b = "Quest";
        String t = a + b;              // новая строка в памяти
        String s = "CodeQuest";

        System.out.println(t.equals(s)); // true — содержимое совпало
        System.out.println(t == s);      // false — это разные объекты!
    }
}` },
        { t: 'note', html: 'Склейка оператором <code>+</code> работает даже с числами: <code>"Счёт: " + 42</code> даст <code>"Счёт: 42"</code>. Если в выражении есть строка, все операнды превращаются в текст. Но осторожно: <code>1 + 2 + "3"</code> даст "33" — вычисление идёт слева направо!' },
        { t: 'warn', html: 'Сравнение строк через <code>==</code> иногда «случайно работает» на литералах — и потом ломается на реальных данных. Правило одно: только <code>equals()</code>. Для сравнения без учёта регистра есть <code>equalsIgnoreCase()</code>.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что выведет эта программа? Запиши вывод построчно. Внимание на последнюю строку — там спрятана знаменитая ловушка Java.</p>',
        code: `public class Main {
    public static void main(String[] args) {
        String s = "CodeQuest";
        System.out.println(s.length());
        System.out.println(s.substring(0, 4));
        System.out.println(s.toUpperCase());

        String a = "Code";
        String b = "Quest";
        String t = a + b;
        System.out.println(t);
        System.out.println(t.equals(s));
        System.out.println(t == s);
    }
}`,
        answer: `9
Code
CODEQUEST
CodeQuest
true
false`
      },
      hints: [
        'length() считает символы: C-o-d-e-Q-u-e-s-t — девять.',
        'substring(0, 4) берёт символы с индекса 0 по 3 включительно.',
        'a + b создаёт новую строку в памяти: equals сравнит содержимое (совпадёт), а == сравнит объекты (не совпадёт).'
      ],
      solution: `9
Code
CODEQUEST
CodeQuest
true
false`
    },

    /* ---------- 9. Классы и объекты ---------- */
    {
      id: 'java-9',
      title: 'Классы и объекты',
      goal: 'Создать собственный класс с полями, конструктором и методом, и поработать с объектом',
      xp: 50,
      theory: [
        { t: 'p', html: 'Класс — это чертёж: описание того, какие данные (поля) и какое поведение (методы) будут у объекта. Объект — конкретный экземпляр, созданный по чертежу. Один класс Dog — и сколько угодно собак: Рекс, Барсик, Шарик, у каждого своё имя и возраст. Такой подход называется объектно-ориентированным программированием (ООП).' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog("Рекс", 3);
        System.out.println(dog.name); // Рекс
        dog.bark();                   // Рекс говорит: Гав!
    }
}

class Dog {
    String name;
    int age;

    Dog(String name, int age) {
        this.name = name;
        this.age = age;
    }

    void bark() {
        System.out.println(name + " говорит: Гав!");
    }
}` },
        { t: 'p', html: 'Оператор <code>new</code> создаёт объект в памяти и вызывает конструктор — специальный метод с именем класса и без типа возврата. Конструктор принимает параметры и записывает их в поля. Запись <code>this.name</code> означает «поле name этого объекта»: слово this отличает поле от параметра с тем же именем.' },
        { t: 'list', items: [
          'Поля объявляются как обычные переменные, прямо внутри класса;',
          'Конструктор вызывается через new и готовит объект к работе;',
          'Методы объекта работают с его полями;',
          'Доступ к полям и методам — через точку: dog.name, dog.bark().'
        ] },
        { t: 'note', html: 'Если конструктор не написать, Java подставит пустой конструктор по умолчанию. Но как только ты объявил конструктор с параметрами, конструктор без параметров исчезает: <code>new Dog()</code> уже не сработает, пока не добавишь его явно.' },
        { t: 'warn', html: 'В одном файле публичным может быть только один класс — тот, что совпадает с именем файла. Вспомогательные классы (как Dog) объявляют рядом без слова public.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Опиши класс <code>Dog</code>: текстовое поле <code>name</code>, числовое поле <code>age</code>, конструктор с двумя параметрами, который записывает их в поля, и метод <code>bark()</code>, выводящий что-нибудь на экран (например, «Гав!»). В <code>main</code> создай собаку через <code>new</code> и вызови у неё <code>bark()</code>.</p>',
        starter: `public class Main {
    public static void main(String[] args) {
        // создай собаку через оператор new и заставь её гавкать
    }
}

// опиши класс собаки ниже: два поля, конструктор, метод лая`,
        rules: [
          { desc: 'Объявлен класс Dog', all: ['class\\s+Dog'] },
          { desc: 'Есть текстовое поле name (String name)', all: ['String\\s+name\\b'] },
          { desc: 'Есть числовое поле age (int age)', all: ['int\\s+age\\b'] },
          { desc: 'Есть конструктор Dog(...) { ... }', all: ['Dog\\s*\\([^)]*\\)\\s*\\{'] },
          { desc: 'Объект создан через new Dog(...)', all: ['new\\s+Dog\\s*\\('] },
          { desc: 'У объекта вызван метод bark()', all: ['\\.bark\\s*\\('] }
        ]
      },
      hints: [
        'Конструктор — метод с именем класса и без void: Dog(String name, int age) { ... }.',
        'Чтобы записать параметр в одноимённое поле, используй this.name = name;',
        'Создание объекта: Dog dog = new Dog("Рекс", 3); затем dog.bark();'
      ],
      solution: `public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog("Рекс", 3);
        dog.bark();
    }
}

class Dog {
    String name;
    int age;

    Dog(String name, int age) {
        this.name = name;
        this.age = age;
    }

    void bark() {
        System.out.println(name + " говорит: Гав!");
    }
}`
    },

    /* ---------- 10. ArrayList ---------- */
    {
      id: 'java-10',
      title: 'ArrayList',
      goal: 'Заменить массив гибким списком: add, get, size, remove',
      xp: 50,
      theory: [
        { t: 'p', html: 'Массив хорош, но его длина неизменяема. Хочется список, который растёт и ужимается сам. Встречай <code>ArrayList</code> из пакета <code>java.util</code> — самый популярный контейнер Java. Внутри он прячет обычный массив и следит за размером, расширяясь, когда нужно.' },
        { t: 'code', code: `import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<String> cities = new ArrayList<>();
        cities.add("Москва");
        cities.add("Казань");
        cities.add("Сочи");

        System.out.println(cities.size());  // 3 — сколько элементов
        System.out.println(cities.get(1));  // Казань — по индексу

        cities.remove("Казань");            // убираем по значению
        System.out.println(cities.size());  // 2
    }
}` },
        { t: 'list', items: [
          '<code>add(x)</code> — добавить элемент в конец;',
          '<code>get(i)</code> — взять элемент по индексу;',
          '<code>set(i, x)</code> — заменить элемент по индексу;',
          '<code>remove(i)</code> или <code>remove(x)</code> — удалить по индексу или значению;',
          '<code>size()</code> — текущее количество элементов;',
          '<code>contains(x)</code> — есть ли элемент в списке.'
        ] },
        { t: 'p', html: 'В угловых скобках указывается тип элементов — это называется дженерик: <code>ArrayList&lt;String&gt;</code> хранит только строки. Примитивы напрямую нельзя: вместо <code>ArrayList&lt;int&gt;</code> пиши <code>ArrayList&lt;Integer&gt;</code> — классы-обёртки Integer, Double и другие автоматически превращаются в примитивы и обратно. Перебор — привычным for с индексами или for-each:' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> nums = new ArrayList<>();
        nums.add(10);
        nums.add(20);
        int total = 0;
        for (int n : nums) {
            total += n;
        }
        System.out.println(total); // 30
    }
}` },
        { t: 'note', html: 'В списке можно хранить и собственные классы: <code>ArrayList&lt;Book&gt;</code> — так делают настоящие каталоги. Именно этот приём ждёт тебя в финальном проекте.' },
        { t: 'warn', html: 'Количество элементов — <code>size()</code>, а не length (как у массива) и не length() (как у строки). И помни: get(5) при размере 5 вызовет IndexOutOfBoundsException — индексы опять с нуля.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Прочитай код и выбери, что он выведет:</p><pre>ArrayList&lt;String&gt; cities = new ArrayList&lt;&gt;();
cities.add("Москва");
cities.add("Казань");
cities.add("Сочи");
cities.remove("Казань");
System.out.println(cities.size() + " " + cities.get(1));</pre>`,
        options: ['2 Сочи', '3 Сочи', '2 Казань', '3 Казань'],
        correct: 0,
        explain: 'После remove("Казань") в списке остаются [Москва, Сочи] — размер 2. Элемент с индексом 1 — это Сочи. Итог: «2 Сочи».'
      },
      hints: [
        'remove удаляет элемент — размер списка уменьшается на один.',
        'После удаления «Казани» индексы сдвигаются: get(1) вернёт то, что стоит на втором месте.'
      ],
      solution: 0
    },

    /* ---------- 11. Инкапсуляция ---------- */
    {
      id: 'java-11',
      title: 'Инкапсуляция',
      goal: 'Спрятать данные класса: private, геттеры, сеттеры и проверка значений',
      xp: 50,
      theory: [
        { t: 'p', html: 'Инкапсуляция — первый столп ООП. Идея: данные объекта спрятаны от внешнего мира, а доступ к ним идёт через методы. Так класс сам контролирует своё состояние: никто не подсунет ему мусор мимо проверок. Если внешний код — гость, то поля с геттерами и сеттерами — сейф с окошком для выдачи.' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        BankAccount acc = new BankAccount(100.0);
        acc.setBalance(250.5);
        System.out.println(acc.getBalance()); // 250.5
    }
}

class BankAccount {
    private double balance;

    BankAccount(double startBalance) {
        if (startBalance >= 0) {
            balance = startBalance;
        }
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double newBalance) {
        if (newBalance >= 0) {
            balance = newBalance;
        }
    }
}` },
        { t: 'p', html: 'Модификатор <code>private</code> прячет поле: обращение <code>acc.balance</code> из другого класса теперь ошибка компиляции. Наружу выставляются <code>public</code>-методы: геттер <code>getBalance()</code> читает значение, сеттер <code>setBalance(...)</code> меняет — но только после проверки. Попытка записать отрицательный баланс просто игнорируется.' },
        { t: 'table', head: ['Модификатор', 'Кто видит'], rows: [
          ['public', 'все классы программы'],
          ['(по умолчанию)', 'классы того же пакета'],
          ['protected', 'пакет + классы-наследники'],
          ['private', 'только свой класс']
        ] },
        { t: 'note', html: 'Сеттеры нужны не всегда: если значение задаётся один раз, лучше принять его в конструкторе и вовсе не давать сеттер. А для режима «только чтение» достаточно одного геттера — объект защищён от случайных изменений.' },
        { t: 'warn', html: 'Не объявляй поля public «на всякий случай». Каждый открытый член класса — обещание поддерживать его в будущих версиях программы. Прятать поля — не паранойя, а профессиональная привычка.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Спроектируй класс <code>BankAccount</code>: приватное поле <code>balance</code> типа double, конструктор с начальным балансом, геттер <code>getBalance()</code> и сеттер <code>setBalance(...)</code> с проверкой — отрицательный баланс не принимать. В <code>main</code> создай счёт, пополни его через сеттер и выведи баланс через геттер.</p>',
        starter: `public class Main {
    public static void main(String[] args) {
        // 1. создай счёт со стартовым балансом 100.0
        // 2. пополни баланс через сеттер до 250.5
        // 3. выведи баланс через геттер
    }
}

// опиши класс счёта ниже`,
        rules: [
          { desc: 'Объявлен класс BankAccount', all: ['class\\s+BankAccount'] },
          { desc: 'Поле balance объявлено приватным (private double balance)', all: ['private\\s+double\\s+balance'] },
          { desc: 'Есть конструктор BankAccount(...) { ... }', all: ['BankAccount\\s*\\([^)]*\\)\\s*\\{'] },
          { desc: 'Есть геттер getBalance()', all: ['getBalance\\s*\\('] },
          { desc: 'Есть сеттер setBalance(...)', all: ['setBalance\\s*\\('] },
          { desc: 'Поле balance приватное (private), а не public', all: ['private\\s+double\\s+balance'], none: ['public\\s+double\\s+balance\\s*;'] }
        ]
      },
      hints: [
        'Синтаксис приватного поля: private double balance;',
        'Геттер возвращает значение: public double getBalance() { return balance; }',
        'В сеттере поставь проверку: if (newBalance >= 0) { ... }'
      ],
      solution: `public class Main {
    public static void main(String[] args) {
        BankAccount acc = new BankAccount(100.0);
        acc.setBalance(250.5);
        System.out.println(acc.getBalance());
    }
}

class BankAccount {
    private double balance;

    BankAccount(double startBalance) {
        balance = startBalance;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double newBalance) {
        if (newBalance >= 0) {
            balance = newBalance;
        }
    }
}`
    },

    /* ---------- 12. Проект: Библиотека книг ---------- */
    {
      id: 'java-12',
      title: 'Проект: Библиотека книг',
      goal: 'Собрать финальный проект: классы Book и Library, список книг, цикл вывода каталога',
      xp: 100,
      theory: [
        { t: 'p', html: 'Финальный экзамен. Ты соберёшь мини-каталог библиотеки из настоящих классов: модель <code>Book</code>, контейнер <code>Library</code> и сценарий в <code>main</code>. Это классическая тройка любого Java-приложения: данные, логика и точка входа. Ничего нового здесь не будет — только всё изученное сразу.' },
        { t: 'list', items: [
          '<b>Book</b> — класс с полями <code>title</code> и <code>author</code>, конструктором и методом, возвращающим строку-описание книги;',
          '<b>Library</b> — класс со списком <code>ArrayList&lt;Book&gt;</code>, методом добавления книги и методом вывода всех книг;',
          '<b>Main</b> — создаёт библиотеку, добавляет минимум две книги через <code>new Book(...)</code> и печатает каталог.'
        ] },
        { t: 'h', html: 'План по шагам' },
        { t: 'list', items: [
          'Опиши класс Book: два поля, конструктор, метод describe(), возвращающий строку «Название — Автор»;',
          'Опиши класс Library: поле-список ArrayList&lt;Book&gt;, метод addBook(Book b) со строкой books.add(b), метод printAll() с циклом for;',
          'В main создай Library, добавь минимум две книги и вызови печать каталога;',
          'Сверься с правилами под заданием — они перечисляют требования.'
        ] },
        { t: 'code', code: `import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // сценарий: библиотека + книги + печать каталога
    }
}

class Book {
    // поля title и author, конструктор, метод-описание
}

class Library {
    // список книг, метод добавления, метод печати всех книг
}` },
        { t: 'note', html: 'Из пройденного пригодится: классы и new (уровень 9), ArrayList с дженериком (уровень 10), цикл for с size() (уровни 5–6), конкатенация строк (уровень 8). Метод describe() возвращает String через return — ровно как в уровне 7.' },
        { t: 'warn', html: 'Не пиши всё в main! Правила проверяют, что классы Book и Library объявлены отдельно и используются. Программа-монолит из одной строки не засчитывается.' },
        { t: 'p', html: 'Дерзай! Когда все правила позеленеют, у тебя будет первая настоящая объектная программа на Java. Дальше можно двигаться к наследованию, интерфейсам и коллекциям — но фундамент уже стоит.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Библиотека книг».</b> Напиши программу из трёх частей: класс <code>Book</code> (поля <code>title</code> и <code>author</code>, конструктор), класс <code>Library</code> (список <code>ArrayList&lt;Book&gt;</code>, метод добавления книги, метод вывода всех книг через цикл for) и <code>main</code>, где создаётся библиотека, добавляются минимум две книги и печатается каталог. Заготовка ниже — ориентир, пиши свой код.</p>',
        starter: `import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // создай библиотеку, добавь две книги и выведи весь каталог
    }
}

// модели: книга и библиотека`,
        rules: [
          { desc: 'Есть класс Book с полями title и author', all: ['class\\s+Book', 'String\\s+title', 'String\\s+author'] },
          { desc: 'У Book есть конструктор Book(...) { ... }', all: ['Book\\s*\\([^)]*\\)\\s*\\{'] },
          { desc: 'Библиотека хранит книги в ArrayList<Book>', all: ['ArrayList\\s*<\\s*Book\\s*>'] },
          { desc: 'Книги добавляются в список (add или addBook)', any: ['\\.add\\s*\\(', '\\.addBook\\s*\\('] },
          { desc: 'Каталог печатается циклом for с выводом в консоль', all: ['for\\s*\\(', 'System\\.out\\.print'] }
        ]
      },
      hints: [
        'Начни с класса Book: поля String title; String author; и конструктор Book(String title, String author) { this.title = title; this.author = author; }',
        'В Library создай поле ArrayList<Book> books = new ArrayList<>(); в printAll() пройди циклом for от 0 до books.size() и выведи books.get(i).',
        'В main: Library library = new Library(); затем library.addBook(new Book("Название", "Автор")); и library.printAll();'
      ],
      solution: `import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        library.addBook(new Book("Мастер и Маргарита", "Булгаков"));
        library.addBook(new Book("Евгений Онегин", "Пушкин"));
        library.printAll();
    }
}

class Book {
    String title;
    String author;

    Book(String title, String author) {
        this.title = title;
        this.author = author;
    }

    String describe() {
        return title + " — " + author;
    }
}

class Library {
    ArrayList<Book> books = new ArrayList<>();

    void addBook(Book book) {
        books.add(book);
    }

    void printAll() {
        for (int i = 0; i < books.size(); i++) {
            System.out.println(books.get(i).describe());
        }
    }
}`
    },

    /* ---------- 13. Классы и объекты: состояние ---------- */
    {
      id: 'java-13',
      title: 'Классы и объекты: состояние',
      goal: 'Погрузиться в ООП глубже: поля и методы класса, состояние объекта, доступ через точку',
      xp: 45,
      theory: [
        { t: 'p', html: 'Уровень 9 познакомил тебя с классами — теперь копнём глубже. Класс — это чертёж, объект — экземпляр, а <b>состояние</b> — значения полей конкретного объекта прямо сейчас. Два объекта одного класса живут независимо: изменил pages у одной книги — вторая даже не заметит. Именно поэтому в реальных системах пользователь, заказ и счёт — отдельные объекты, каждый со своей историей.' },
        { t: 'h', html: 'Модель без конструктора' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        Book b = new Book();      // конструктор по умолчанию
        b.title = "Му-Му";
        b.pages = 96;

        System.out.println(b.describe());
    }
}

class Book {
    String title;
    int pages;

    String describe() {
        return title + " — " + pages + " стр.";
    }
}` },
        { t: 'p', html: 'Пока конструктор не объявлен, Java подставляет пустой: <code>new Book()</code> создаёт объект с нулевыми полями — числа станут 0, ссылки null. Дальше полям присваивают значения через точку, и объект «наполняется жизнью». Метод <code>describe()</code> читает поля того объекта, у которого вызван: внутри класса имена полей видны напрямую, без префиксов.' },
        { t: 'list', items: [
          '<b>Состояние</b> — значения полей: title, pages;',
          '<b>Поведение</b> — методы: describe();',
          '<b>Идентичность</b> — каждый new создаёт независимый объект в памяти;',
          'Доступ к членам класса — через точку: b.title, b.describe().'
        ] },
        { t: 'p', html: 'В энтерпрайзе такие классы называют <b>моделями</b> или POJO (Plain Old Java Object) — чистые данные предметной области без логики базы и HTTP. Их покрывают JUnit-тестами: создал объект, выставил поля, сравнил результат метода с ожиданием. На код-ревью первым делом смотрят, не тащит ли класс чужие обязанности — состояние и поведение держат вместе и по делу.' },
        { t: 'note', html: 'Попробуй вывести объект целиком: System.out.println(b) напечатает что-то вроде Book@1b6d3586 — имя класса и хэш-код. Почему так и как сделать красиво, узнаешь в уровне про наследование: виноват метод toString из прародителя Object.' },
        { t: 'warn', html: 'Обращение к полю объекта, который не создан, — гарантированный NullPointerException: объяви Book b; без new и позови b.title — программа упадёт. Переменная без new хранит null, а не объект.' },
        { t: 'p', html: 'Задание: собери модель книги из двух полей и метода-описания, затем прогони сценарий в main. Конструктор пока не пиши — Java подставит его сама, а уже в следующем уровне ты напишешь собственные.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Опиши класс <code>Book</code>: поле <code>title</code> (String), поле <code>pages</code> (int) и метод <code>describe()</code>, который возвращает строку-описание через <code>return</code>. Конструктор не пиши — Java подставит пустой сама. В <code>main</code> создай объект через <code>new Book()</code>, заполни оба поля через точку и выведи результат метода на экран.</p>',
        starter: `public class Main {
    public static void main(String[] args) {
        // TODO: создай объект книги через оператор создания,
        // заполни оба поля значениями и выведи описание
    }
}

// ниже опиши модель книги: два поля и метод-описание`,
        rules: [
          { desc: 'Объявлен класс Book', all: ['class\\s+Book'] },
          { desc: 'Есть поля title (String) и pages (int)', all: ['String\\s+title\\b', 'int\\s+pages\\b'] },
          { desc: 'Объявлен метод describe(...) с телом', all: ['describe\\s*\\([^)]*\\)\\s*\\{'] },
          { desc: 'Метод возвращает строку через return', all: ['\\breturn\\b'] },
          { desc: 'Объект создан через new Book()', all: ['new\\s+Book\\s*\\(\\s*\\)'] },
          { desc: 'Состояние заполнено: полям присвоены значения', any: ['\\.title\\s*=', '\\.pages\\s*='] },
          { desc: 'Есть вывод на экран, пометки TODO не осталось', any: ['System\\.out\\.println', 'System\\.out\\.print'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Поля объявляются прямо в классе: String title; int pages;',
        'Метод-описание: String describe() { return title + " — " + pages + " стр."; }',
        'В main: Book b = new Book(); затем b.title = "..."; b.pages = 96; и println(b.describe()).'
      ],
      solution: `public class Main {
    public static void main(String[] args) {
        Book b = new Book();
        b.title = "Му-Му";
        b.pages = 96;
        System.out.println(b.describe());
    }
}

class Book {
    String title;
    int pages;

    String describe() {
        return title + " — " + pages + " стр.";
    }
}`
    },

    /* ---------- 14. Конструкторы и this ---------- */
    {
      id: 'java-14',
      title: 'Конструкторы и this',
      goal: 'Писать конструкторы: без параметров и с параметрами, перегрузка и цепочка this(...)',
      xp: 50,
      theory: [
        { t: 'p', html: 'Конструктор — особый метод: имя совпадает с именем класса, а типа возврата у него нет вообще, даже void. JVM вызывает его автоматически при каждом <code>new</code>, поэтому забыть про инициализацию невозможно. Задача конструктора — привести объект в рабочее состояние немедленно: заполнил поля — и объект сразу годится к использованию.' },
        { t: 'code', code: `class Book {
    String title;
    String author;

    Book() {
        this("Без названия", "Неизвестен");
    }

    Book(String title, String author) {
        this.title = title;
        this.author = author;
    }
}` },
        { t: 'p', html: 'Здесь два конструктора — это <b>перегрузка</b>: одно имя, разные списки параметров. Компилятор различает их по сигнатуре и выбирает нужный под вызов: <code>new Book()</code> уйдёт в первый, <code>new Book("Онегин", "Пушкин")</code> — во второй. Так же перегружаются и обычные методы — помнишь print(int) и print(String) из уровня про методы?' },
        { t: 'p', html: 'Слово <code>this</code> — ссылка на текущий объект. Запись <code>this.title = title</code> читается «полю title присвоить параметр title»: без this Java сочтёт обе стороны параметром, и поле останется нулевым. А вызов <code>this(...)</code> с аргументами делегирует другому конструктору того же класса и обязан стоять первой строкой тела.' },
        { t: 'list', items: [
          'Конструктор без параметров — значения по умолчанию;',
          'Конструктор с параметрами — данные приходят снаружи;',
          '<code>this.поле</code> — обращение к полю текущего объекта;',
          '<code>this(...)</code> — вызов другого конструктора (цепочка).'
        ] },
        { t: 'p', html: 'Энтерпрайз-практика: обязательные поля принимай в конструкторе — тогда невозможно создать «полуфабрикат» без имени или кода. Это оценят и ревьюеры, и тестировщики: JUnit-тесты пишутся против готовых объектов, а не заготовок. На собеседованиях спрашивают, чем конструктор отличается от метода и когда исчезает конструктор по умолчанию — ответишь без запинки.' },
        { t: 'note', html: 'Как только ты объявил любой конструктор, пустой конструктор по умолчанию исчезает. Нужен и такой — объяви его явно, как в примере выше: два конструктора мирно живут рядом.' },
        { t: 'warn', html: 'Цепочка this(...) не должна закольцеваться: конструктор A зовёт B, а B зовёт A — компилятор отвергнет код с ошибкой «recursive constructor invocation». И помни: this(...) допустим только первым оператором в теле.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Дополни класс <code>Book</code> двумя конструкторами: без параметров, который через <code>this(...)</code> подставляет значения по умолчанию, и с параметрами <code>title</code> и <code>author</code>, записывающим их в поля через <code>this.поле</code>. В <code>main</code> создай обе книги через <code>new</code> и выведи их поля на экран.</p>',
        starter: `public class Main {
    public static void main(String[] args) {
        // TODO: создай две книги — одну без аргументов,
        // вторую с названием и автором, затем выведи их поля
    }
}

// ниже — модель книги с двумя конструкторами`,
        rules: [
          { desc: 'Объявлен класс Book', all: ['class\\s+Book'] },
          { desc: 'Есть конструктор без параметров Book() { ... }', all: ['Book\\s*\\(\\s*\\)\\s*\\{'] },
          { desc: 'Есть конструктор с параметрами Book(...) { ... }', all: ['Book\\s*\\([^)]+\\)\\s*\\{'] },
          { desc: 'Поля заполняются через this.поле = ...', all: ['this\\.\\w+\\s*='] },
          { desc: 'Один конструктор делегирует другому: this(...);', all: ['this\\s*\\([^)]*\\)\\s*;'] },
          { desc: 'Объекты создаются через new Book(...)', all: ['new\\s+Book\\s*\\('] },
          { desc: 'Есть вывод на экран, пометки TODO не осталось', any: ['System\\.out\\.println', 'System\\.out\\.print'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Пустой конструктор делегирует: Book() { this("Без названия", "Неизвестен"); }',
        'Основной конструктор: Book(String title, String author) { this.title = title; this.author = author; }',
        'В main: Book empty = new Book(); Book b = new Book("Онегин", "Пушкин"); и println для обоих.'
      ],
      solution: `public class Main {
    public static void main(String[] args) {
        Book empty = new Book();
        Book book = new Book("Капитанская дочка", "Пушкин");
        System.out.println(empty.title + " / " + book.title);
    }
}

class Book {
    String title;
    String author;

    Book() {
        this("Без названия", "Неизвестен");
    }

    Book(String title, String author) {
        this.title = title;
        this.author = author;
    }
}`
    },

    /* ---------- 15. Инкапсуляция: private и JavaBeans ---------- */
    {
      id: 'java-15',
      title: 'Инкапсуляция: private и JavaBeans',
      goal: 'Прятать поля за private и открывать доступ через геттеры и сеттеры с проверками',
      xp: 50,
      theory: [
        { t: 'p', html: 'В уровне 11 ты прятал баланс банка — теперь систематизируем приём. <b>Инкапсуляция</b> — правило «данные приватны, доступ через методы»: класс сам следит за своим состоянием и не пропускает мусор мимо проверок. В энтерпрайз-коде поля почти всегда private, а наружу смотрят аккуратные геттеры и сеттеры.' },
        { t: 'table', head: ['Модификатор', 'Кто видит член'], rows: [
          ['public', 'все классы проекта'],
          ['(ничего — default)', 'классы того же пакета'],
          ['protected', 'пакет + классы-наследники'],
          ['private', 'только собственный класс']
        ] },
        { t: 'code', code: `class Reader {
    private String name;
    private int limit;

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        if (newName != null && !newName.isEmpty()) {
            name = newName;
        }
    }
}` },
        { t: 'p', html: 'Геттер <code>getName()</code> возвращает значение, сеттер <code>setName(...)</code> принимает новое и решает — принимать ли. Схема «private-поля + публичные get/set» называется <b>JavaBeans</b>-стилем: так устроены сущности Spring, JPA-модели и DTO, которые встретятся тебе на любой джаве-работе. Имена строятся из get/set плюс имя поля с большой буквы — конвенция, которую ожидают библиотеки и сериализаторы.' },
        { t: 'list', items: [
          'private — данные скрыты от прямого доступа;',
          'геттер — контролируемое чтение;',
          'сеттер с проверкой — контролируемая запись;',
          'без сеттера — режим «только чтение»: поле задаётся один раз.'
        ] },
        { t: 'p', html: 'Зачем это на практике? JUnit-тест проверит, что сеттер отклоняет пустое имя, — поведение задокументировано кодом. Ревьюеру не придётся гадать, кто испортил поле: писать в него можно только через сеттер, где стоит единственная точка контроля. А модификаторы доступа из таблицы — стабильный вопрос собеседований: перечисли четыре и скажи, кто кого видит.' },
        { t: 'note', html: 'IDE генерируют геттеры и сеттеры одной кнопкой, а Lombok сокращает запись до аннотации @Getter/@Setter. Но понимать, что под капотом, обязан каждый: аннотации — сахар над тем же private плюс методы.' },
        { t: 'warn', html: 'Не возвращай из геттера внутренние изменяемые объекты как есть: внешний код получит ссылку и изменит состояние мимо сеттера. Для списков отдавай копию или List.copyOf, для дат — неизменяемые типы.' },
        { t: 'p', html: 'Задание: собери класс читателя библиотеки с двумя приватными полями и парой get/set — с проверкой в сеттере имени.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Опиши класс <code>Reader</code>: приватное поле <code>name</code> (String) и приватное поле <code>limit</code> (int) — сколько книг можно взять. Добавь геттер <code>getName()</code> и сеттер <code>setName(...)</code> с проверкой через <code>if</code> — пустое имя не принимать. В <code>main</code> создай читателя через <code>new Reader()</code>, задай имя сеттером и выведи его геттером.</p>',
        starter: `public class Main {
    public static void main(String[] args) {
        // TODO: создай читателя, задай имя через сеттер
        // и выведи его через геттер
    }
}

// ниже — класс читателя: приватные поля, геттер, сеттер с проверкой`,
        rules: [
          { desc: 'Объявлен класс Reader', all: ['class\\s+Reader'] },
          { desc: 'Поле name приватное (private String name)', all: ['private\\s+String\\s+name\\b'] },
          { desc: 'Поле limit приватное (private int limit)', all: ['private\\s+int\\s+limit\\b'] },
          { desc: 'Геттер getName() объявлен', all: ['String\\s+getName\\s*\\(\\s*\\)\\s*\\{'] },
          { desc: 'Сеттер setName(...) с проверкой if внутри', all: ['setName\\s*\\([^)]*\\)\\s*\\{', '\\bif\\s*\\('] },
          { desc: 'В main: new Reader() и работа через сеттер', all: ['new\\s+Reader\\s*\\(', '\\.setName\\s*\\('] },
          { desc: 'Есть вывод на экран, пометки TODO не осталось', any: ['System\\.out\\.println', 'System\\.out\\.print'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Приватные поля: private String name; private int limit;',
        'Геттер: public String getName() { return name; } — сеттер с проверкой: if (newName != null && !newName.isEmpty()) { ... }',
        'В main: Reader r = new Reader(); r.setName("Аня"); затем println(r.getName()).'
      ],
      solution: `public class Main {
    public static void main(String[] args) {
        Reader r = new Reader();
        r.setName("Аня");
        r.setLimit(5);
        System.out.println(r.getName() + ": лимит " + r.getLimit());
    }
}

class Reader {
    private String name;
    private int limit;

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        if (newName != null && !newName.isEmpty()) {
            name = newName;
        }
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int newLimit) {
        if (newLimit >= 0) {
            limit = newLimit;
        }
    }
}`
    },

    /* ---------- 16. Наследование и Object ---------- */
    {
      id: 'java-16',
      title: 'Наследование и Object',
      goal: 'Наследовать через extends, вызывать super() и переопределять toString с @Override',
      xp: 50,
      theory: [
        { t: 'p', html: '<b>Наследование</b> — механизм, при котором класс-наследник получает поля и методы родителя и добавляет своё. Пишется <code>class Employee extends Person</code>: сотрудник — это человек плюс компания. В больших системах иерархии экономят тысячи строк, а главное — позволяют писать обобщённый код поверх базового типа: один список Person принимает и людей, и сотрудников.' },
        { t: 'code', code: `class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

class Employee extends Person {
    String company;

    Employee(String name, int age, String company) {
        super(name, age);
        this.company = company;
    }
}` },
        { t: 'p', html: 'Конструктор наследника первым делом вызывает <code>super(...)</code> — конструктор родителя: нельзя построить сотрудника, не построив «человеческую часть». Слово super работает и как ссылка на родителя: <code>super.toString()</code> позовёт родительскую версию метода. Без явного вызова компилятор сам подставит super() — пустой конструктор, которого может и не быть: тогда будет ошибка компиляции.' },
        { t: 'list', items: [
          'extends — наследование класса (родитель только один);',
          'super(...) — вызов конструктора родителя, первым оператором;',
          '@Override — маркер переопределения метода;',
          'Object — неявный прародитель всех классов Java.'
        ] },
        { t: 'p', html: 'Любой класс в Java — потомок <code>Object</code>, поэтому у каждого объекта есть его методы: <code>toString()</code>, <code>equals()</code>, <code>hashCode()</code>. Стандартный toString печатает <code>Employee@1b6d3586</code> — то самое заклинание из предыдущего уровня. Переопредели метод — и объекты станут человекочитаемыми в логах, отладчике и отчётах тестов: вместо хэша — понятное описание.' },
        { t: 'p', html: 'Аннотация <code>@Override</code> не меняет поведение, но страхует: опечатался в имени или сигнатуре — компилятор скажет «переопределять нечего». На код-ревью переопределение без @Override вернут на доработку — это правило хорошего тона. А вот equals принято переопределять в паре с hashCode, иначе HashMap и HashSet начнут терять объекты — запомни связку, её любят спрашивать на собеседованиях.' },
        { t: 'note', html: 'Модификатор protected открывает член классам-наследникам: поле name в Person можно объявить protected, и Employee будет видеть его напрямую. Для остального мира поле по-прежнему закрыто.' },
        { t: 'warn', html: 'Множественного наследования классов в Java нет: один extends — один родитель. Вторую, третью и десятую «родословную» добирают интерфейсами — герой следующего уровня.' },
        { t: 'p', html: 'Задание: построй иерархию Person → Employee и научи сотрудника красиво печататься через переопределённый toString.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Опиши класс <code>Person</code> с полями <code>name</code> и <code>age</code> и конструктором. Наследуй <code>Employee extends Person</code> со своим полем (например, <code>company</code>): в его конструкторе вызови <code>super(...)</code>, а метод <code>toString()</code> переопредели с аннотацией <code>@Override</code> и верни из него описание через <code>return</code>. В <code>main</code> создай сотрудника и выведи его на экран.</p>',
        starter: `public class Main {
    public static void main(String[] args) {
        // TODO: создай сотрудника и выведи его на экран
    }
}

// ниже — базовый класс человека
// и класс сотрудника, который наследуется от него`,
        rules: [
          { desc: 'Объявлен класс Person', all: ['class\\s+Person'] },
          { desc: 'Employee наследуется от Person (extends)', all: ['class\\s+Employee\\s+extends\\s+Person'] },
          { desc: 'Конструктор Employee вызывает super(...)', all: ['super\\s*\\([^)]*\\)\\s*;'] },
          { desc: 'toString переопределён с аннотацией @Override', all: ['@Override\\s+(?:public\\s+)?String\\s+toString\\s*\\('] },
          { desc: 'toString возвращает описание через return', all: ['toString\\s*\\([^)]*\\)\\s*\\{[\\s\\S]*?\\breturn\\b'] },
          { desc: 'Сотрудник создан через new Employee(...)', all: ['new\\s+Employee\\s*\\('] },
          { desc: 'Есть вывод на экран, пометки TODO не осталось', any: ['System\\.out\\.println', 'System\\.out\\.print'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас: class Employee extends Person { String company; Employee(...) { super(name, age); ... } }',
        'Метод: @Override public String toString() { return name + ", " + age + ...; }',
        'В main: Employee emp = new Employee("Иван", 35, "Яндекс"); System.out.println(emp); — вызовется твой toString.'
      ],
      solution: `public class Main {
    public static void main(String[] args) {
        Employee emp = new Employee("Иван", 35, "Яндекс");
        System.out.println(emp);
    }
}

class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

class Employee extends Person {
    String company;

    Employee(String name, int age, String company) {
        super(name, age);
        this.company = company;
    }

    @Override
    public String toString() {
        return name + ", " + age + " лет, работает в " + company;
    }
}`
    },

    /* ---------- 17. Абстрактные классы и интерфейсы ---------- */
    {
      id: 'java-17',
      title: 'Абстрактные классы и интерфейсы',
      goal: 'Понимать abstract, интерфейсы с default-методами и полиморфизм списка List<Animal>',
      xp: 55,
      theory: [
        { t: 'p', html: 'Иногда родитель не должен иметь экземпляров: «животного вообще» не бывает — бывают кошки и собаки. Класс с модификатором <code>abstract</code> нельзя создавать через new, но можно наследовать и дополнять. Внутри объявляют <b>абстрактные методы</b> — без тела: «каждый потомок обязан уметь speak(), а как именно — его забота».' },
        { t: 'h', html: 'Интерфейс — чистый контракт' },
        { t: 'p', html: '<code>interface</code> — набор обязательств без состояния: <code>interface Pet { void play(); }</code>. Класс реализует интерфейс через <code>implements</code> и может воплотить сколько угодно их — в отличие от единственного extends. С Java 8 в интерфейсах появились <code>default</code>-методы с готовым телом: контракт с бонусом для тех, кого устраивает поведение по умолчанию.' },
        { t: 'code', code: `interface Pet {
    default void greet() {
        System.out.println("Погладь меня");
    }
}

abstract class Animal {
    String name;

    Animal(String name) { this.name = name; }

    abstract String speak();
}

class Cat extends Animal implements Pet {
    Cat(String name) { super(name); }

    @Override
    String speak() { return name + ": мяу"; }
}` },
        { t: 'p', html: 'Главная награда — <b>полиморфизм</b>: переменная типа Animal ссылается на Cat или Dog, а вызов speak() выполняет версию конкретного класса. Поэтому коллекцию пишут как <code>List&lt;Animal&gt;</code> — список «животных вообще», куда складывают кого угодно из иерархии. Так работает принцип «программируй на интерфейс, а не на реализацию»: энтерпрайз-код зависит от PaymentService и UserRepository, а конкретные классы подставляются извне.' },
        { t: 'list', items: [
          'abstract class — общая база: поля + частичная реализация;',
          'interface — контракт поведения, их много на класс;',
          'default-метод — готовая реализация внутри интерфейса;',
          'List&lt;Animal&gt; — полиморфная коллекция разных потомков.'
        ] },
        { t: 'note', html: 'Ты уже пользовался интерфейсами, не замечая: List, Comparable, Runnable — всё они. Comparator и Runnable — функциональные интерфейсы с одним абстрактным методом, поэтому им можно передавать лямбды — этому посвящён уровень про лямбды.' },
        { t: 'warn', html: 'Неабстрактный класс обязан реализовать все абстрактные методы родителя, иначе сам должен стать abstract. И помни: у абстрактного класса есть конструктор — его вызовет super() наследника, просто сам класс нельзя создать через new.' },
        { t: 'p', html: 'Задание — предскажи вывод: в программе абстрактный класс, два наследника и полиморфный список. Посчитай, что напечатает консоль, и запиши построчно.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Перед тобой программа с абстрактным классом, наследниками и полиморфным списком. Проследи, какой именно метод вызовется для каждого элемента, и запиши вывод построчно — по одному значению на строку.</p>',
        code: `import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Animal> zoo = new ArrayList<>();
        zoo.add(new Cat("Барсик"));
        zoo.add(new Dog("Рекс"));
        zoo.add(new Cat("Мурка"));

        System.out.println(zoo.size());
        for (Animal a : zoo) {
            System.out.println(a.speak());
        }
    }
}

abstract class Animal {
    String name;

    Animal(String name) {
        this.name = name;
    }

    abstract String speak();
}

class Cat extends Animal {
    Cat(String name) {
        super(name);
    }

    @Override
    String speak() {
        return name + ": мяу";
    }
}

class Dog extends Animal {
    Dog(String name) {
        super(name);
    }

    @Override
    String speak() {
        return name + ": гав";
    }
}`,
        answer: `3
Барсик: мяу
Рекс: гав
Мурка: мяу`
      },
      hints: [
        'zoo.size() — сколько элементов добавили через add, столько и получишь.',
        'Переменная типа Animal, объект — Cat или Dog: вызовется переопределённая версия speak() конкретного потомка.',
        'Конструктор каждого наследника зовёт super(name), поэтому поле name заполнено кличкой.'
      ],
      solution: `3
Барсик: мяу
Рекс: гав
Мурка: мяу`
    },

    /* ---------- 18. Коллекции: ArrayList и HashMap ---------- */
    {
      id: 'java-18',
      title: 'Коллекции: ArrayList и HashMap',
      goal: 'Связать данные ключ-значение: put/get/containsKey у HashMap и методы ArrayList',
      xp: 50,
      theory: [
        { t: 'p', html: 'Список отвечает на вопрос «что под номером i», но бизнес чаще спрашивает по смыслу: цена по коду товара, книга по ISBN, читатель по номеру билета. Для пар «ключ → значение» есть <code>HashMap</code> — словарь с мгновенным поиском по ключу. Это вторая по популярности коллекция энтерпрайз-джавы сразу после ArrayList.' },
        { t: 'code', code: `import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Map<String, Integer> prices = new HashMap<>();
        prices.put("Java", 900);
        prices.put("SQL", 700);

        System.out.println(prices.get("Java"));        // 900
        System.out.println(prices.containsKey("C++")); // false
        System.out.println(prices.size());             // 2
    }
}` },
        { t: 'list', items: [
          '<code>put(key, value)</code> — положить пару (перезапишет старое значение);',
          '<code>get(key)</code> — значение по ключу или null;',
          '<code>containsKey(key)</code> — есть ли такой ключ;',
          '<code>remove(key)</code> — удалить пару;',
          '<code>size()</code> — количество пар;',
          '<code>entrySet()</code> — пары для перебора for-each.'
        ] },
        { t: 'p', html: 'Обрати внимание на декларацию: слева интерфейс <code>Map</code>, справа реализация <code>HashMap</code> — знакомый принцип «программируй на интерфейс». Ключи уникальны: повторный put по существующему ключу заменит значение, а не добавит второе. get по отсутствующему ключу вернёт <code>null</code> — проверяй containsKey, прежде чем звать у результата методы.' },
        { t: 'code', code: `for (Map.Entry<String, Integer> pair : prices.entrySet()) {
    System.out.println(pair.getKey() + " → " + pair.getValue());
}` },
        { t: 'p', html: 'Перебор карты идёт через <code>entrySet()</code>: каждая пара — объект <code>Map.Entry</code> с методами getKey() и getValue(). Порядок обхода HashMap не гарантирован — это словарь, а не список. Если порядок важен, возьми <code>LinkedHashMap</code> (помнит порядок вставки) или <code>TreeMap</code> (держит ключи отсортированными).' },
        { t: 'note', html: 'Ключами делают неизменяемые объекты — чаще всего String. Собственный класс в ключи пускают только после переопределения equals и hashCode: HashMap сверяется именно по ним — та самая связка из уровня про наследование.' },
        { t: 'warn', html: 'Примитивов в дженериках нет: Map&lt;String, int&gt; не скомпилируется — нужны обёртки Integer, Double. И не зови методы у результата get, не проверив на null: NullPointerException не заставит себя ждать.' },
        { t: 'p', html: 'Задание — заполни пропуски: собери карту цен и список языков из методов обеих коллекций.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Восстанови пропущенные методы: карту нужно пополнить, проверить ключ в ней, а список — дополнить и прочитать по индексу. Пиши только имя метода, без скобок и аргументов.</p>',
        code: `import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        HashMap<String, Integer> prices = new HashMap<>();
        prices.put("Java", 900);
        prices.put("SQL", 700);
        prices.{{0}}("Python", 800);
        System.out.println(prices.get("Java"));
        System.out.println(prices.{{1}}("C++"));
        System.out.println(prices.size());

        ArrayList<String> langs = new ArrayList<>();
        langs.add("Java");
        langs.{{2}}("Python");
        System.out.println(langs.{{3}}(1));
    }
}`,
        blanks: [
          { answer: 'put' },
          { answer: 'containsKey' },
          { answer: 'add' },
          { answer: 'get' }
        ]
      },
      hints: [
        'Добавить пару в карту — put, проверить наличие ключа — containsKey.',
        'В список элемент дописывает add, а чтение по индексу — get.',
        'Методы пишутся маленькими буквами: prices.put(...), langs.add(...).'
      ],
      solution: ['put', 'containsKey', 'add', 'get']
    },
    /* ---------- 19. Generics ---------- */
    {
      id: 'java-19',
      title: 'Generics',
      goal: 'Понимать угловые скобки: List<String>, Map<String, Integer> и собственный generic-метод',
      xp: 50,
      theory: [
        { t: 'p', html: 'Угловые скобки после имени коллекции — это <b>дженерик</b>: обещание, какого типа элементы живут внутри. <code>List&lt;String&gt;</code> хранит только строки, <code>Map&lt;String, Integer&gt;</code> — пары «строка → целое». Компилятор ловит попытку положить не тот тип ещё до запуска — это и есть типобезопасность, за которую Java ценят в больших проектах.' },
        { t: 'code', code: `List<String> names = new ArrayList<>();
names.add("Анна");
String first = names.get(0);   // без приведения типа` },
        { t: 'p', html: 'До Java 5 коллекции были «сырыми»: <code>List list = new ArrayList()</code> принимал что угодно, а доставать приходилось приведением <code>(String) list.get(0)</code> — и падать в рантайме на чужом типе. Дженерики перенесли эту проверку в момент компиляции. Сырые типы до сих пор встречаются в легаси-коде — на код-ревью их правят сразу же.' },
        { t: 'h', html: 'Свой generic-метод' },
        { t: 'code', code: `static <T> T firstOrNull(List<T> list) {
    return list.isEmpty() ? null : list.get(0);
}` },
        { t: 'p', html: 'Угловая скобка перед типом возврата — <code>&lt;T&gt;</code> — объявляет параметр типа: T — плейсхолдер, который компилятор подставит под конкретный вызов. Для firstOrNull(List&lt;String&gt;) T станет String, для списка чисел — Integer. Именно так написаны Collections.sort, Optional.of и половина стандартной библиотеки.' },
        { t: 'list', items: [
          '<code>&lt;T&gt;</code> — параметр типа у метода;',
          '<code>class Box&lt;T&gt;</code> — дженерик-класс: T доступен во всём теле;',
          '<code>List&lt;?&gt;</code> — «список чего угодно» (wildcard): безопасно только читать;',
          'Тип-параметр нельзя инстанцировать: new T() — ошибка компиляции.'
        ] },
        { t: 'note', html: 'При чтении Integer сам распакуется в int, при записи int упакуется в Integer — это автобоксинг. И держи в голове любимый вопрос собеседований: чем List&lt;Object&gt; отличается от List&lt;?&gt; и почему сырой List — источник ClassCastException в рантайме.' },
        { t: 'warn', html: 'Примитивы в дженериках запрещены: List&lt;int&gt; не скомпилируется — используй обёртки. Компилятор упакует значения сам, но распаковка null из коллекции в int бросит NullPointerException — проверяй прежде, чем разворачивать.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что не так с этим кодом? Найди строку, из-за которой компиляция не пройдёт:</p><pre>List&lt;Integer&gt; nums = new ArrayList&lt;&gt;();
nums.add(42);
nums.add("42");
int x = nums.get(0);</pre>`,
        options: [
          'nums.add(42) — в список нельзя добавлять числа',
          'nums.add("42") — в List<Integer> нельзя положить String',
          'int x = nums.get(0) — Integer нельзя присвоить int',
          'Ошибок нет — код полностью корректен'
        ],
        correct: 1,
        explain: 'Дженерик List<Integer> принимает только Integer: add("42") компилятор отвергнет — в этом и есть защита типов. add(42) корректен: число упакуется в Integer (автобоксинг). А int x = nums.get(0) тоже валиден — Integer автоматически распакуется в int. Всё это проверяется при компиляции, а не в рантайме.'
      },
      hints: [
        'Вспомни, что обещает компилятору запись List<Integer>.',
        'Автоупаковка превращает 42 в Integer автоматически, а вот String в Integer не превратится никогда.'
      ],
      solution: 1
    },

    /* ---------- 20. Исключения ---------- */
    {
      id: 'java-20',
      title: 'Исключения',
      goal: 'Обрабатывать ошибки: try/catch/finally, multi-catch и иерархия Exception',
      xp: 55,
      theory: [
        { t: 'p', html: 'В идеальном мире код всегда работает. В реальном — файл может не открыться, строка оказаться не числом, сеть отвалиться посреди запроса. Java оформляет такие сбои как <b>исключения</b>: объекты-ошибки, которые бросаются (throw) и ловятся (catch). Поймал — обработал и работаешь дальше; не поймал — программа падает со стектрейсом, по которому виден весь путь ошибки.' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) {
        try {
            int x = Integer.parseInt("12");
            System.out.println(x / 0);
        } catch (ArithmeticException | NumberFormatException e) {
            System.out.println("Ошибка: " + e.getMessage());
        } finally {
            System.out.println("Готово");
        }
    }
}` },
        { t: 'p', html: 'Блок <code>try</code> — «опасный» код, <code>catch</code> — план обработки, <code>finally</code> — уборка, которая выполняется всегда: и при ошибке, и без неё. Вертикальная черта — <b>multi-catch</b>: один обработчик сразу на несколько типов. В переменной <code>e</code> лежит сам объект исключения: <code>e.getMessage()</code> даст краткое описание, <code>e.printStackTrace()</code> — полный след в лог.' },
        { t: 'list', items: [
          'try — код, который может бросить исключение;',
          'catch (Тип e) — обработка конкретного типа;',
          'catch (A | B e) — multi-catch: несколько типов сразу;',
          'finally — выполняется всегда: закрыть файл, соединение;',
          'throws в сигнатуре — «метод может бросить, обрабатывай снаружи».'
        ] },
        { t: 'h', html: 'Checked против unchecked' },
        { t: 'p', html: '<b>Проверяемые</b> исключения (потомки Exception — IOException, SQLException) компилятор заставляет либо ловить, либо объявлять в <code>throws</code>: «я знаю, файл может не открыться, — вот план». <b>Непроверяемые</b> (потомки RuntimeException — NullPointerException, ArithmeticException, NumberFormatException) ловить не обязательно: это обычно ошибки программирования, которые чинят кодом, а не catch. Правило большого энтерпрайза: checked — для предсказуемых сбоев внешнего мира, unchecked — для багов.' },
        { t: 'p', html: 'Ресурсы с Java 7 закрывают через <b>try-with-resources</b>: <code>try (BufferedReader br = ...) { ... }</code> — объект с интерфейсом AutoCloseable закроется сам, finally не нужен. В проде исключения не глотают молча: пустой catch — верный способ потерять ошибку и честный минус на ревью. И ловят конкретный тип, а не всеядный Exception.' },
        { t: 'note', html: 'Иерархия: Object → Throwable → Exception и Error. Error не ловят (нехватка памяти и прочие фатальные состояния), Exception — обрабатывают. Своё исключение пишут extends Exception (checked) или extends RuntimeException (unchecked).' },
        { t: 'warn', html: 'Порядок catch важен: сначала конкретные типы, потом общие. Поставишь catch (Exception e) выше catch (NumberFormatException e) — второй блок станет недостижимым, и компилятор откажется собирать код.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Оберни рискованный код в защиту: блок <code>try</code>, один обработчик через multi-catch <code>(ArithmeticException | NumberFormatException e)</code> или два отдельных <code>catch</code>, и блок <code>finally</code> с завершающим выводом. Исключение используй в отчёте — например, <code>e.getMessage()</code>.</p>',
        starter: `public class Main {
    public static void main(String[] args) {
        String raw = "12";
        // TODO: оберни деление в безопасную конструкцию:
        // обработай два типа исключений и добавь финальный блок
        int x = Integer.parseInt(raw);
        System.out.println(x / 0);
    }
}`,
        rules: [
          { desc: 'Есть блок try { ... }', all: ['\\btry\\s*\\{'] },
          { desc: 'catch ловит конкретное исключение (тип в скобках)', all: ['\\bcatch\\s*\\([^)]*Exception[^)]*\\)'] },
          { desc: 'Multi-catch через | или два catch-блока', any: ['\\bcatch\\s*\\([^)]*\\|[^)]*\\)', '\\bcatch\\s*\\([^)]*\\)[\\s\\S]*\\bcatch\\s*\\('] },
          { desc: 'Есть блок finally { ... }', all: ['\\bfinally\\s*\\{'] },
          { desc: 'Исключение используется в отчёте (getMessage, конкатенация с e или println(e))', any: ['\\.getMessage\\s*\\(', '\\+\\s*e\\)', '\\(\\s*e\\s*\\)'] },
          { desc: 'Есть вывод на экран, пометки TODO не осталось', any: ['System\\.out\\.println', 'System\\.out\\.print'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас: try { ... } catch (ArithmeticException | NumberFormatException e) { ... } finally { ... }',
        'В отчёте пригодится e.getMessage() — например, println("Ошибка: " + e.getMessage()).',
        'Деление на ноль бросает ArithmeticException, а parse("abc") — NumberFormatException; finally сработает в любом случае.'
      ],
      solution: `public class Main {
    public static void main(String[] args) {
        String raw = "12";
        try {
            int x = Integer.parseInt(raw);
            System.out.println(x / 0);
        } catch (ArithmeticException | NumberFormatException e) {
            System.out.println("Ошибка: " + e.getMessage());
        } finally {
            System.out.println("Готово");
        }
    }
}`
    },

    /* ---------- 21. Лямбды и функциональные интерфейсы ---------- */
    {
      id: 'java-21',
      title: 'Лямбды и функциональные интерфейсы',
      goal: 'Передавать поведение как значение: лямбды, forEach и Comparator.comparing',
      xp: 55,
      theory: [
        { t: 'p', html: 'До Java 8 «передать поведение» значило заводить класс на пять строк ради одного метода. <b>Лямбда</b> — это метод без имени, записанный на месте: <code>(x, y) -&gt; x + y</code>. Слева от стрелки параметры, справа — результат. Типы компилятор выводит сам, поэтому запись получается короче любой альтернативы.' },
        { t: 'code', code: `Runnable task = () -> System.out.println("Работаю");
Comparator<String> byLen = (a, b) -> a.length() - b.length();` },
        { t: 'p', html: 'Лямбда живёт только там, где ждёт <b>функциональный интерфейс</b> — интерфейс ровно с одним абстрактным методом. Runnable (метод run), Comparator (compare), Consumer (accept) — все они теперь принимают лямбды. Компилятор смотрит на целевой тип и понимает, какой именно метод реализует твоя стрелка.' },
        { t: 'p', html: 'Классика энтерпрайза — сортировка: <code>list.sort(Comparator.comparing(s -&gt; s.length()))</code> — «сравнивай по длине строки». Внутри comparing передают ключевую функцию: она вычисляет признак, а компаратор сравнивает признаки. Читается как английское предложение и почти не содержит шума — за это лямбды и полюбили на ревью.' },
        { t: 'code', code: `List<String> langs = new ArrayList<>();
langs.add("Go");
langs.forEach(s -> System.out.println(s));` },
        { t: 'list', items: [
          '<code>() -&gt; выражение</code> — без параметров;',
          '<code>x -&gt; x * 2</code> — один параметр, скобки можно опустить;',
          '<code>(a, b) -&gt; a + b</code> — несколько параметров через запятую;',
          'forEach + лямбда — «сделай это с каждым элементом».'
        ] },
        { t: 'p', html: 'forEach принимает Consumer — функцию «принял элемент, сделал дело». Ты писал такие обходы циклами ещё с уровня про циклы, а теперь поведение передаётся как значение. Следующий уровень покажет, как на лямбдах строится целый конвейер обработки данных — Streams API.' },
        { t: 'note', html: 'Есть короткая форма для вызова готового метода — ссылка: System.out::println вместо s -&gt; System.out.println(s). Двойное двоеточие — не лямбда со стрелкой; в задании нужна именно стрелка.' },
        { t: 'warn', html: 'Лямбда захватывает только effectively final локальные переменные: изменишь переменную после захвата — компилятор откажется собирать код. Это защита от гонок, если лямбда уедет исполняться в другой поток.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Отсортируй список языков по длине строк: объяви компаратор через <code>Comparator.comparing(...)</code> с лямбдой-ключом, передай его в <code>sort(...)</code>, а затем выведи каждый элемент через <code>forEach</code> с лямбдой-стрелкой. Список из трёх языков уже собран.</p>',
        starter: `import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<String> langs = new ArrayList<>();
        langs.add("Python");
        langs.add("Java");
        langs.add("Go");

        // TODO: отсортируй список по длине строки
        // и выведи каждый элемент через forEach
    }
}`,
        rules: [
          { desc: 'Компаратор построен через Comparator.comparing(...)', all: ['Comparator\\s*\\.\\s*comparing\\s*\\('] },
          { desc: 'Ключ-функция задана лямбдой со стрелкой ->', all: ['Comparator\\s*\\.\\s*comparing\\s*\\([^)]*->'] },
          { desc: 'Список отсортирован через .sort(...)', all: ['\\.sort\\s*\\('] },
          { desc: 'forEach получает лямбду со стрелкой ->', all: ['forEach\\s*\\([^)]*->'] },
          { desc: 'Есть вывод на экран, пометки TODO не осталось', any: ['System\\.out\\.println', 'System\\.out\\.print'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Comparator<String> byLength = Comparator.comparing(s -> s.length()); — ключ: длина строки.',
        'Затем langs.sort(byLength); — список выстроится по возрастанию длины.',
        'Вывод: langs.forEach(s -> System.out.println(s)); — лямбда в forEach.'
      ],
      solution: `import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<String> langs = new ArrayList<>();
        langs.add("Python");
        langs.add("Java");
        langs.add("Go");

        Comparator<String> byLength = Comparator.comparing(s -> s.length());
        langs.sort(byLength);
        langs.forEach(s -> System.out.println(s));
    }
}`
    },

    /* ---------- 22. Streams API ---------- */
    {
      id: 'java-22',
      title: 'Streams API',
      goal: 'Обработать коллекцию конвейером: stream().filter().map().collect()',
      xp: 60,
      theory: [
        { t: 'p', html: 'Цикл по коллекции — это ручное управление: счётчики, if-ы, временные списки-накопители. <b>Streams API</b> (Java 8) предлагает конвейер: источник <code>stream()</code>, промежуточные операции <code>filter</code>, <code>map</code>, <code>sorted</code> и терминальная <code>collect</code>. Код читается как декларация намерения: «возьми, отфильтруй, преобразуй, собери».' },
        { t: 'code', code: `List<String> result = names.stream()
    .filter(n -> n.startsWith("А"))
    .map(n -> n.toUpperCase())
    .collect(Collectors.toList());` },
        { t: 'p', html: '<code>filter</code> оставляет элементы, для которых лямбда-предикат вернула true; <code>map</code> преобразует каждый элемент во что-то другое; <code>collect(Collectors.toList())</code> собирает результат в обычный список. Промежуточные операции <b>ленивы</b>: пока не вызвана терминальная, обхода не происходит — конвейер лишь описан.' },
        { t: 'p', html: 'Лень — фича, а не недоделка: элементы текут по конвейеру по одному, цепочка вычисляется за один проход, а если терминальную операцию так и не позвали — не выполняется вообще ничего. Другие терминалы: <code>forEach</code> — для побочного действия, <code>reduce</code> — свернуть поток в одно значение (сумма, максимум), <code>count()</code> — посчитать количество.' },
        { t: 'list', items: [
          'stream() — открыть конвейер из коллекции;',
          'filter(предикат) — оставить подходящие;',
          'map(функция) — преобразовать каждый;',
          'sorted() — отсортировать;',
          'collect(Collectors.toList()) — собрать в список;',
          'reduce(...) — свернуть в одно значение.'
        ] },
        { t: 'p', html: 'В энтерпрайзе стримы — дефолтный стиль обработки данных: отчёты, фильтры и агрегации на десятки строк циклов сжимаются в три-четыре читаемые. На ревью спросят: нет ли в стриме побочных эффектов и не проще ли обычный цикл? Короткий стрим читается лучше цикла, а цепочка на пять-шесть операций — повод разнести её по методам.' },
        { t: 'note', html: 'С Java 16 у потока есть короткий терминал toList() — без Collectors. Проверка задания примет оба варианта: и collect(Collectors.toList()), и просто .toList().' },
        { t: 'warn', html: 'Поток одноразовый: после терминальной операции стрим «сгорает», повторный вызов бросит IllegalStateException. Нужен второй проход — открой новый stream() из коллекции.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери конвейер: из списка имён <code>names</code> отфильтруй через <code>filter</code> те, что начинаются с «А», приведи каждый к верхнему регистру через <code>map</code> и собери результат в список через <code>collect(Collectors.toList())</code> (или короткое <code>toList()</code>). Итоговый список выведи на экран — он напечатается в квадратных скобках.</p>',
        starter: `import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("Анна", "Борис", "Алиса", "Вера");

        // TODO: собери конвейер — фильтр, преобразование, сбор —
        // и выведи итоговый список
    }
}`,
        rules: [
          { desc: 'Конвейер открыт через .stream()', all: ['\\.stream\\s*\\(\\s*\\)'] },
          { desc: 'Есть .filter(...) с лямбдой', all: ['\\.filter\\s*\\([^)]*->'] },
          { desc: 'Есть .map(...) с лямбдой', all: ['\\.map\\s*\\([^)]*->'] },
          { desc: 'Результат собран: collect(Collectors.toList()) или .toList()', any: ['\\.collect\\s*\\(\\s*Collectors\\.toList\\s*\\(\\s*\\)\\s*\\)', '\\.toList\\s*\\(\\s*\\)'] },
          { desc: 'Есть вывод на экран, пометки TODO не осталось', any: ['System\\.out\\.println', 'System\\.out\\.print'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'names.stream() открывает конвейер; filter(n -> n.startsWith("А")) оставит Анну и Алису.',
        'map(n -> n.toUpperCase()) переведёт каждое имя в верхний регистр.',
        'Собери: .collect(Collectors.toList()) — и println(result) напечатает [АННА, АЛИСА].'
      ],
      solution: `import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("Анна", "Борис", "Алиса", "Вера");

        List<String> result = names.stream()
            .filter(n -> n.startsWith("А"))
            .map(n -> n.toUpperCase())
            .collect(Collectors.toList());
        System.out.println(result);
    }
}`
    },

    /* ---------- 23. Многопоточность: первые шаги ---------- */
    {
      id: 'java-23',
      title: 'Многопоточность: первые шаги',
      goal: 'Запускать потоки через Thread и Runnable, понимать start/join и зачем нужен synchronized',
      xp: 55,
      theory: [
        { t: 'p', html: 'Все программы до сих пор были однонитевыми: main выполнялся строка за строкой. <b>Поток</b> (thread) — независимая линия исполнения внутри одного процесса: у него свой стек вызовов, но общая память с остальными. Серверы Tomcat и Spring обрабатывают каждый запрос в своём потоке — поэтому Java и царствует на бэкенде десятилетиями.' },
        { t: 'code', code: `public class Main {
    public static void main(String[] args) throws InterruptedException {
        Thread worker = new Thread(() -> System.out.println("Работаю в потоке"));
        worker.start();
        worker.join();
        System.out.println("main завершён");
    }
}` },
        { t: 'p', html: 'В конструктор Thread передали лямбду — Runnable функционален, у него один метод run(). Важный нюанс: поток запускает только <code>start()</code> — JVM создаёт новую нить и вызывает в ней run(). Вызов <code>run()</code> напрямую выполнит тело в текущем потоке, как обычный метод, — новая нить не родится. Это ловушка №1 на собеседованиях.' },
        { t: 'list', items: [
          'new Thread(runnable) — создать поток;',
          'start() — запустить: run() выполнится в новой нити;',
          'join() — подождать завершения потока;',
          'setDaemon(true) — фоновый поток, умрёт вместе с main;',
          'ExecutorService — правильный путь в проде: пул потоков вместо ручных.'
        ] },
        { t: 'p', html: 'Когда два потока правят одну переменную, результат непредсказуем: операции перемешиваются на уровне процессора. Страховка — модификатор <code>synchronized</code>: метод или блок захватывает замок объекта, и второй поток ждёт очереди. Это лишь вход в огромный пакет <code>java.util.concurrent</code>: AtomicInteger, ConcurrentHashMap, Lock — туда заглядывают, когда synchronized уже тесно.' },
        { t: 'h', html: 'Проверь себя' },
        { t: 'code', code: `Thread t = new Thread(() -> System.out.println("Привет из потока"));
t.run();` },
        { t: 'p', html: 'Что выведет этот фрагмент? Строку «Привет из потока» — но в main-потоке: run() вызвался как обычный метод, новой нити нет. Замени на <code>t.start()</code> — фраза уйдёт в отдельный поток. Без join() порядок вывода двух нитей предсказать нельзя — планировщик ОС решает сам; с join() гарантия появляется: сначала дождались, потом продолжили.' },
        { t: 'warn', html: 'Не зови run() руками и не переопределяй его у Thread — это анти-паттерн, который заметят на ревью. И помни: synchronized решает гонки, но замедляет код — под замком потоки выстраиваются в очередь.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что гарантированно выведет эта программа?</p><pre>public class Main {
    public static void main(String[] args) throws InterruptedException {
        Thread worker = new Thread(() -&gt; System.out.println("B"));
        worker.start();
        worker.join();
        System.out.println("A");
    }
}</pre>`,
        options: [
          'B, затем A — join() заставил main дождаться потока',
          'A, затем B — main всегда успевает первым',
          'Порядок не гарантирован: то A-B, то B-A',
          'Только A: run() не вызывался, поток не запускался',
          'Только B: main остановился навсегда на join()'
        ],
        correct: 0,
        explain: 'start() реально запускает поток, а join() блокирует main до завершения worker: гарантия «B раньше A». Без join() порядок был бы не гарантирован. Лямбда подходит конструктору, потому что Runnable — функциональный интерфейс. Это классический вопрос собеседований на различение start() и run().'
      },
      hints: [
        'start() — единственный способ породить новую нить; run() просто выполнил бы тело в main.',
        'join() говорит: «подожди, пока worker закончит», — и только потом main печатает свою строку.'
      ],
      solution: 0
    },

    /* ---------- 24. Проект: система «Библиотека» ---------- */
    {
      id: 'java-24',
      title: '🚀 Проект: система «Библиотека»',
      goal: 'Собрать систему: Book, Library на HashMap с методами add/find и потоковой фильтрацией по автору',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный рывок: соберём систему «Библиотека» — модель, хранилище и сценарий, как в настоящем сервисе. От первого проекта курс отличается двумя вещами: книги живут в <code>HashMap&lt;String, Book&gt;</code> с мгновенным поиском по коду, а отчёты считаются стримом. Это типовая связка корпоративной джавы: Map-хранилище + Streams + простые модели.' },
        { t: 'list', items: [
          '<b>Book</b> — модель: код isbn, название, автор, конструктор, переопределённый toString;',
          '<b>Library</b> — хранилище Map&lt;String, Book&gt; и методы add и find;',
          '<b>byAuthor(String)</b> — отчёт: stream().filter(...) собирает список книг одного автора;',
          '<b>Main</b> — сценарий: создать, добавить три книги, найти одну по коду, отфильтровать по автору.'
        ] },
        { t: 'h', html: 'План по шагам' },
        { t: 'list', items: [
          'Опиши Book: три поля, конструктор, toString с @Override — так книги печатаются красиво;',
          'Опиши Library: поле Map&lt;String, Book&gt; books = new HashMap&lt;&gt;(); метод add(Book b) кладёт книгу через books.put(book.isbn, book);',
          'Метод find(String isbn) возвращает books.get(isbn) — мгновенный поиск по ключу;',
          'Метод byAuthor(String author): books.values().stream().filter(b -&gt; b.author.equals(author)).collect(Collectors.toList());',
          'В main собери сценарий и выведи результаты поиска и отчёта.'
        ] },
        { t: 'code', code: `class Library {
    Map<String, Book> books = new HashMap<>();

    void add(Book book) {
        books.put(book.isbn, book);
    }

    Book find(String isbn) {
        return books.get(isbn);
    }
}` },
        { t: 'note', html: 'books.values() — коллекция всех книг карты; у неё можно открыть stream(). Список при печати покажется в квадратных скобках: [Евгений Онегин (Пушкин), Мёртвые души (Пушкин)] — твой toString сработает для каждого элемента.' },
        { t: 'warn', html: 'Не пиши всё в main: правила проверяют, что Book и Library объявлены отдельно, карта — именно Map с ключом String, а фильтр идёт через stream().filter(...). Переопределяя toString, ставь @Override.' },
        { t: 'p', html: 'Из пройденного пригодится всё: классы и this, наследование и @Override toString, HashMap, стримы. После зачёта у тебя на руках миниатюра настоящего CRUD-сервиса — ровно из таких кусков собраны Spring-приложения. Дальше по траектории: JUnit-тесты, Stream API в полную силу и ExecutorService.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Библиотека».</b> Напиши: класс <code>Book</code> (поля isbn, title, author, конструктор, переопределённый toString с @Override), класс <code>Library</code> с картой <code>Map&lt;String, Book&gt;</code>, методами <code>add(Book)</code> (кладёт через <code>put</code>) и <code>find(String)</code> (возвращает через <code>get</code>), а также методом отчёта <code>byAuthor(String)</code>, который фильтрует книги через <code>stream().filter(...)</code> и собирает список через <code>collect</code>. В <code>main</code> создай библиотеку, добавь минимум две книги, найди одну по коду и выведи результаты.</p>',
        starter: `import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        // TODO: собери систему — добавь книги, найди одну по коду,
        // отфильтруй по автору потоком и выведи результаты
    }
}

// модели: книга и библиотека (карта «код → книга»)`,
        rules: [
          { desc: 'Класс Book с конструктором', all: ['class\\s+Book', 'Book\\s*\\([^)]+\\)\\s*\\{'] },
          { desc: 'Класс Library объявлен отдельно', all: ['class\\s+Library'] },
          { desc: 'Книги хранятся в Map<String, Book>', all: ['Map\\s*<\\s*String\\s*,\\s*Book\\s*>'] },
          { desc: 'Метод add(...) объявлен и кладёт книгу через put', all: ['add\\w*\\s*\\([^)]*Book[^)]*\\)\\s*\\{', '\\.put\\s*\\('] },
          { desc: 'Метод find(...) объявлен и читает через get', all: ['find\\w*\\s*\\([^)]*String[^)]*\\)\\s*\\{', '\\.get\\s*\\('] },
          { desc: 'Отчёт через поток: stream() + filter(...)', all: ['\\.stream\\s*\\(\\s*\\)', '\\.filter\\s*\\('] },
          { desc: 'Сценарий в main: new Library(...) и книги через new Book(...)', all: ['public\\s+static\\s+void\\s+main', 'new\\s+Library\\s*\\(', 'new\\s+Book\\s*\\('] },
          { desc: 'Есть вывод на экран, пометки TODO не осталось', any: ['System\\.out\\.println', 'System\\.out\\.print'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Book: три поля и конструктор Book(String isbn, String title, String author) с this-присваиванием; toString верни как title + " (" + author + ")" с @Override.',
        'Library: Map<String, Book> books = new HashMap<>(); add кладёт books.put(book.isbn, book), find возвращает books.get(isbn).',
        'byAuthor: books.values().stream().filter(b -> b.author.equals(author)).collect(Collectors.toList()); в main не забудь println для find и списка.'
      ],
      solution: `import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        library.add(new Book("978-5-17", "Мастер и Маргарита", "Булгаков"));
        library.add(new Book("978-5-04", "Евгений Онегин", "Пушкин"));
        library.add(new Book("978-5-389", "Мёртвые души", "Пушкин"));

        System.out.println(library.find("978-5-04"));

        List<Book> byPushkin = library.byAuthor("Пушкин");
        System.out.println(byPushkin);
    }
}

class Book {
    String isbn;
    String title;
    String author;

    Book(String isbn, String title, String author) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
    }

    @Override
    public String toString() {
        return title + " (" + author + ")";
    }
}

class Library {
    Map<String, Book> books = new HashMap<>();

    void add(Book book) {
        books.put(book.isbn, book);
    }

    Book find(String isbn) {
        return books.get(isbn);
    }

    List<Book> byAuthor(String author) {
        return books.values().stream()
            .filter(b -> b.author.equals(author))
            .collect(Collectors.toList());
    }
}`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас программы',
      code: `public class Main {
    public static void main(String[] args) {
        System.out.println("Привет!");
    }
}
// компиляция: javac Main.java → запуск: java Main`
    },
    {
      title: 'Типы данных',
      list: [
        'int — целые: 42, -7',
        'double — дробные: 3.14, -0.5',
        'boolean — true / false',
        "char — один символ: 'A'",
        'String — текст (класс): "привет"',
        'final int MAX = 10; — константа',
        'var x = 5; — тип выведет компилятор (Java 10+)'
      ]
    },
    {
      title: 'Арифметика',
      code: `int a = 7 / 2;             // 3 — целочисленное деление
double b = 7.0 / 2;        // 3.5
int c = 7 % 2;             // 1 — остаток от деления
double d = (double) 7 / 2; // 3.5 — приведение типа
int e = (int) 3.9;         // 3 — дробная часть отрезается
x++;   // увеличить на 1
x += 5; // то же, что x = x + 5`
    },
    {
      title: 'Условия',
      code: `if (age >= 18) {
    System.out.println("Взрослый");
} else if (age >= 14) {
    System.out.println("Подросток");
} else {
    System.out.println("Ребёнок");
}

switch (day) {
    case 6, 7 -> System.out.println("Выходной!");
    default   -> System.out.println("Будни");
}
// операторы: ==  !=  >  <  >=  <=  &&  ||  !`
    },
    {
      title: 'Циклы',
      code: `for (int i = 0; i < 10; i++) { ... }
while (условие) { ... }
do { ... } while (условие); // хотя бы раз
for (int x : массив) { ... } // for-each
break;    // выйти из цикла
continue; // пропустить шаг`
    },
    {
      title: 'Массивы',
      code: `int[] a = new int[5];   // пять нулей
int[] b = {1, 2, 3};    // литерал
a[0] = 10;              // индексы с нуля
int n = a.length;       // длина (поле, без скобок)
for (int i = 0; i < a.length; i++) {
    System.out.println(a[i]);
}`
    },
    {
      title: 'Методы',
      code: `static int sum(int a, int b) {
    return a + b;
}
static void hello() {              // void — без результата
    System.out.println("Привет");
}
int r = sum(2, 3);                 // вызов`
    },
    {
      title: 'Строки',
      list: [
        's.length() — длина строки',
        's.charAt(i) — символ по индексу',
        's.substring(a, b) — кусок [a, b)',
        's.toUpperCase() / s.toLowerCase()',
        's.indexOf("x") — индекс вхождения или -1',
        's.trim() — убрать пробелы по краям',
        'Сравнение только через s.equals(t), не ==!',
        'Склейка: "Счёт: " + 42 → "Счёт: 42"'
      ]
    },
    {
      title: 'Классы и объекты',
      code: `class Dog {
    String name;                    // поле
    Dog(String name) {              // конструктор
        this.name = name;
    }
    void bark() {                   // метод
        System.out.println(name + ": Гав!");
    }
}
Dog d = new Dog("Рекс");           // объект
System.out.println(d.name);
d.bark();`
    },
    {
      title: 'ArrayList',
      code: `import java.util.ArrayList;

ArrayList<String> list = new ArrayList<>();
list.add("a");        // добавить в конец
list.get(0);          // взять по индексу
list.set(0, "b");     // заменить
list.remove(0);       // удалить
list.size();          // количество элементов
list.contains("a");   // есть ли такой
for (String s : list) System.out.println(s);`
    },
    {
      title: 'Инкапсуляция',
      code: `class Account {
    private double balance;              // прячем поле

    Account(double b) { balance = b; }

    public double getBalance() {         // геттер
        return balance;
    }
    public void setBalance(double b) {   // сеттер с проверкой
        if (b >= 0) balance = b;
    }
}`
    },
    {
      title: 'ООП: наследование и интерфейсы',
      code: `class Employee extends Person {
    Employee(String name, int age) {
        super(name, age);           // конструктор родителя
    }
    @Override
    public String toString() {      // переопределение
        return name + " (" + age + ")";
    }
}

abstract class Animal {
    abstract String speak();        // метод без тела
}
interface Pet {
    default void greet() {          // готовый метод
        System.out.println("Играем!");
    }
}
class Cat extends Animal implements Pet { /* ... */ }`
    },
    {
      title: 'Коллекции: Map',
      code: `import java.util.HashMap;
import java.util.Map;

Map<String, Integer> prices = new HashMap<>();
prices.put("Java", 900);       // добавить / заменить пару
prices.get("Java");            // 900 или null
prices.containsKey("SQL");     // true / false
prices.remove("SQL");          // удалить по ключу
prices.size();                 // количество пар

for (Map.Entry<String, Integer> e : prices.entrySet()) {
    System.out.println(e.getKey() + " → " + e.getValue());
}
// порядок обхода HashMap не гарантирован`
    },
    {
      title: 'Лямбды и Streams',
      code: `Runnable r = () -> System.out.println("Задача");
Comparator<String> cmp = Comparator.comparing(s -> s.length());
list.sort(cmp);
list.forEach(s -> System.out.println(s));

List<String> res = items.stream()
    .filter(n -> n.startsWith("А"))   // оставить подходящие
    .map(n -> n.toUpperCase())        // преобразовать
    .sorted()                         // отсортировать
    .collect(Collectors.toList());    // собрать список
int total = nums.stream().reduce(0, Integer::sum);

// промежуточные операции ленивы, терминальная запускает всё;
// поток одноразовый: после collect нужен новый stream()`
    },
    {
      title: 'Частые ошибки',
      list: [
        '= вместо == в условии if',
        '3,14 вместо 3.14 — дробная часть через точку',
        '7 / 2 ожидается 3.5, а получается 3 (целочисленное деление)',
        'Сравнение строк через == вместо equals()',
        'Индекс length вместо length - 1 — выход за границы',
        'Лишняя точка с запятой: for (...); { ... }',
        'Забыт break в классическом switch',
        'Файл Main.java обязан содержать public class Main'
      ]
    }
  ]
};
