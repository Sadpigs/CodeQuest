'use strict';
/* ============ CodeQuest — курс LOLCODE ============
   Мем-язык 2007 года. Проверки: структурный анализ,
   квизы и заполнение пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.lolcode = {
  id: 'lolcode',
  title: 'LOLCODE',
  emoji: '🐱',
  color: '#a8b434',
  lang: 'lolcode',
  tagline: 'Мем-язык котов: HAI, VISIBLE и O RLY?',
  description: 'Шуточный язык, выросший из мемов с котиками (2007). Смешной снаружи, вполне серьёзный внутри: у него есть переменные, ветвления и циклы — идеальная разминка перед «взрослыми» языками.',

  levels: [

    /* ---------- 1. HAI, мир! ---------- */
    {
      id: 'lolcode-1',
      title: 'HAI, мир!',
      goal: 'Собрать минимальную программу: открытие HAI, вывод VISIBLE и закрытие KTHXBYE',
      xp: 30,
      theory: [
        { t: 'p', html: 'LOLCODE появился в 2007 году как шутка про «кошачий» интернет-сленг (lolcats), но быстро оброс настоящими компиляторами и интерпретаторами. Синтаксис — стилизация под фразы кота: программы «разговаривают» с программистом. Под смехом скрыта полноценная структура: у языка есть переменные, условия, циклы и функции.' },
        { t: 'p', html: 'Каждая программа начинается словом <code>HAI</code> («привет») и заканчивается <code>KTHXBYE</code> («окей, пока»). Вывод на экран делает команда <code>VISIBLE</code>: она печатает всё, что стоит после неё, и переводит строку. Строки пишутся в двойных кавычках.' },
        { t: 'code', code: `HAI 1.2

VISIBLE "O HAI, IM CAT!"
VISIBLE "CAN HAZ CODE?"

KTHXBYE` },
        { t: 'p', html: 'После HAI часто пишут версию стандарта — <code>HAI 1.2</code>, это необязательно, но встречается в большинстве примеров. Команды не разделяются точкой с запятой: одна строка — одна инструкция. Регистр важен: все ключевые слова пишутся ЗАГЛАВНЫМИ.' },
        { t: 'list', items: [
          '<b>HAI</b> — начало программы;',
          '<b>KTHXBYE</b> — конец программы;',
          '<b>VISIBLE "текст"</b> — печать строки;',
          '<b>одна команда</b> — одна строка, без точек с запятой.'
        ] },
        { t: 'note', html: 'Точка с запятой в LOLCODE всё-таки есть — она разделяет несколько команд на одной строке, но новичкам проще держать по команде на строку. В этом приложении код LOLCODE проверяется по структуре: настоящий интерпретатор читать его не будет, но пиши корректно — привычка важнее.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первую котопрограмму: каркас <code>HAI</code> … <code>KTHXBYE</code> и внутри — минимум две команды <code>VISIBLE</code> с сообщениями в кавычках. Одно сообщение должно быть <code>О ХАЙ!</code> в духе классики.</p>',
        starter: `HAI 1.2

VISIBLE "TODO"

KTHXBYE`,
        rules: [
          { desc: 'Программа открывается HAI', all: ['^HAI(\\s+1\\.[0-9])?\\s*$'] },
          { desc: 'Программа закрывается KTHXBYE', all: ['^KTHXBYE\\s*$'] },
          { desc: 'Минимум две команды VISIBLE', all: ['VISIBLE[ \\t]+"', '\\n[ \\t]*VISIBLE[ \\t]+"'] },
          { desc: 'Есть фраза "О ХАЙ!"', any: ['"О ХАЙ!"', '"О ХАЙ"'] },
          { desc: 'Нет заглушек TODO', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'VISIBLE печатает строку: VISIBLE "О ХАЙ!".',
        'Вторую команду VISIBLE добавь отдельной строкой между HAI и KTHXBYE.'
      ],
      solution: `HAI 1.2

VISIBLE "О ХАЙ!"
VISIBLE "CAN HAZ CODE?"

KTHXBYE`
    },

    /* ---------- 2. Переменные ---------- */
    {
      id: 'lolcode-2',
      title: 'Переменные: I HAS A',
      goal: 'Объявлять переменные командой I HAS A и присваивать им значения через ITZ',
      xp: 30,
      theory: [
        { t: 'p', html: 'Объявление переменной — самая фотогеничная команда языка: <code>I HAS A переменная</code> («у меня есть переменная»). Сразу с значением объявляют через <code>ITZ</code> («её значение —»): <code>I HAS A score ITZ 100</code>.' },
        { t: 'code', code: `HAI 1.2
I HAS A name ITZ "Barsik"
I HAS A lives ITZ 9
I HAS A mood        BTW без значения, оно NOOB

VISIBLE name
VISIBLE lives
KTHXBYE` },
        { t: 'p', html: 'Типа нет: значение само решает, что лежит в переменной — строка, число или логическое WIN/FAIL. Неинициализированная переменная имеет значение <code>NOOB</code> — аналог null. Присвоить новое значение позже можно командой присваивания: <code>имя R значение</code>.' },
        { t: 'table', head: ['Команда', 'Что делает', 'Аналог'], rows: [
          ['<code>I HAS A x</code>', 'объявить переменную', 'var x;'],
          ['<code>I HAS A x ITZ 5</code>', 'объявить и присвоить', 'var x = 5;'],
          ['<code>x R 10</code>', 'присвоить новое значение', 'x = 10;'],
          ['<code>NOOB</code>', 'пустое значение', 'null']
        ] },
        { t: 'warn', html: 'В комментариях помогает <code>BTW</code> — всё после него в строке игнорируется («кстати»). Для многострочных комментариев есть <code>OBTW</code> … <code>TLDR</code>. Имена переменных — маленькими буквами: ключевыми словами языка считаются только ЗАГЛАВНЫЕ фразы.' },
        { t: 'p', html: 'Печать переменных удобна вместе с текстом: <code>VISIBLE "Lives: " lives</code> — VISIBLE печатает несколько аргументов подряд через пробел. В реальном LOLCODE для склейки без пробела используют оператор <code>SMOOSH</code>, но для начала хватит и так.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни котопрограмму: подставь ключевое слово объявления («у меня есть»), слово «её значение» для присваивания и оператор присвоения для второго шага.</p>',
        code: `HAI 1.2
I HAS A name
name {{0}} "Murzik"

{{1}} A lives {{2}} 9

VISIBLE "Name: " name
VISIBLE lives
KTHXBYE`,
        blanks: [
          { answer: 'R', alt: ['r'] },
          { answer: 'I HAS', alt: ['i has'] },
          { answer: 'ITZ', alt: ['itz'] }
        ]
      },
      hints: [
        'name R "Murzik" — присвоение существующей переменной.',
        'I HAS A lives ITZ 9 — объявление с начальным значением.'
      ],
      solution: ['R', 'I HAS', 'ITZ']
    },

    /* ---------- 3. Арифметика ---------- */
    {
      id: 'lolcode-3',
      title: 'Арифметика по-кошачьи',
      goal: 'Запомнить префиксные операторы SUM OF / DIFF OF / PRODUKT OF и связку AN',
      xp: 35,
      theory: [
        { t: 'p', html: 'Арифметика в LOLCODE префиксная — оператор стоит перед операндами, а между ними обязательна связка <code>AN</code> («и»): <code>SUM OF 2 AN 2</code> даст 4. Читать надо как фразу: «сумма двух и двух».' },
        { t: 'table', head: ['Оператор', 'Значение', 'Пример'], rows: [
          ['<code>SUM OF a AN b</code>', 'сложение', '<code>SUM OF 2 AN 2 → 4</code>'],
          ['<code>DIFF OF a AN b</code>', 'вычитание', '<code>DIFF OF 10 AN 4 → 6</code>'],
          ['<code>PRODUKT OF a AN b</code>', 'умножение', '<code>PRODUKT OF 3 AN 3 → 9</code>'],
          ['<code>QUOSHUNT OF a AN b</code>', 'деление', '<code>QUOSHUNT OF 8 AN 2 → 4</code>'],
          ['<code>MOD OF a AN b</code>', 'остаток', '<code>MOD OF 10 AN 3 → 1</code>'],
          ['<code>BIGGR OF a AN b</code>', 'максимум', '<code>BIGGR OF 5 AN 9 → 9</code>'],
          ['<code>SMALLR OF a AN b</code>', 'минимум', '<code>SMALLR OF 5 AN 9 → 5</code>']
        ] },
        { t: 'p', html: 'Операторы вкладываются друг в друга: <code>SUM OF 1 AN QUOSHUNT OF 10 AN 2</code> — это 1 + 10/2 = 6. Скобок нет, вложенность читается естественно: сначала внутреннее выражение. Результат можно сразу печатать: <code>VISIBLE SUM OF 2 AN 2</code> выведет 4.' },
        { t: 'p', html: 'Логика тоже в этом стиле: <code>BOTH OF x AN y</code> — «и», <code>EITHER OF x AN y</code> — «или», <code>NOT x</code> — отрицание, <code>WON OF x AN y</code> — исключающее «или». Истина — <code>WIN</code>, ложь — <code>FAIL</code>. Эти слова понадобятся в следующем уровне на ветвлениях.' },
        { t: 'note', html: 'Префиксная запись встречается и в «серьёзных» языках — например, в Lisp: (+ 2 2). После LOLCODE она перестаёт пугать. Привычка читать выражение «от оператора» — полезный навык для функционального программирования.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что напечатает строка <code>VISIBLE PRODUKT OF SUM OF 1 AN 2 AN 4</code>?</p>',
        options: [
          '7',
          '12',
          '9',
          'ошибка синтаксиса',
          '6'
        ],
        correct: 1,
        explain: 'Вложенность читается изнутри: SUM OF 1 AN 2 = 3, затем PRODUKT OF 3 AN 4 = 12. Оператор PRODUKT применяется к результату SUM и числу 4.',
        solution: 1
      },
      hints: [
        'Оператор применяется к двум ближайшим операндам через AN.',
        'Сначала вычисли внутренний SUM OF 1 AN 2, потом умножай на 4.'
      ],
      solution: 1
    },

    /* ---------- 4. Ветвления ---------- */
    {
      id: 'lolcode-4',
      title: 'O RLY? — ветвления',
      goal: 'Писать условие O RLY? с ветками YA RLY / NO WAI и закрытием OIC',
      xp: 40,
      theory: [
        { t: 'p', html: 'Ветвление начинается с вопроса <code>O RLY?</code> («правда, что ли?») и закрывается <code>OIC</code> («о, я понял»). Между ними — ветки: <code>YA RLY</code> («да, правда») выполняется при истинном условии, <code>NO WAI</code> («да ладно») — при ложном.' },
        { t: 'code', code: `HAI 1.2
I HAS A hunger ITZ 8

BOTH SAEM hunger AN BIGGR OF hunger AN 5, O RLY?
  YA RLY
    VISIBLE "FEED ME!"
  NO WAI
    VISIBLE "IM OK, THX"
OIC
KTHXBYE` },
        { t: 'p', html: 'Само условие записывают отдельным выражением перед <code>O RLY?</code> — сравнения: <code>BOTH SAEM a AN b</code> («равны?»), <code>DIFFRINT a AN b</code> («не равны?»). Больше/меньше выражается трюком через <code>BIGGR OF</code> / <code>SMALLR OF</code>. В примере выше: голод не меньше 5, когда он равен своему же максимуму с 5.' },
        { t: 'list', items: [
          '<b>O RLY?</b> — начало ветвления;',
          '<b>YA RLY</b> — тогда (условие истинно);',
          '<b>NO WAI</b> — иначе (условие ложно), ветка необязательна;',
          '<b>OIC</b> — конец ветвления (обязателен!);',
          '<b>MEBBE … IF IT</b> — дополнительная ветка-«а может».'
        ] },
        { t: 'warn', html: 'Самая частая ошибка — забыть <code>OIC</code>: интерпретатор не поймёт, где ветвление закончилось. Отступы язык не требует, но без них трёхслойная вложенность становится нечитаемой. Продвинутый переключатель <code>WTF?</code> … <code>OMG</code> … <code>OMGWTF</code> работает как switch-case, а <code>GTFO</code> — как break.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши ветвление по переменной <code>lives</code>: объявь её со значением 9, задай вопрос <code>O RLY?</code>, в ветке <code>YA RLY</code> выведи <code>MANY LIVES</code>, в ветке <code>NO WAI</code> — <code>FEW LIVES</code>, и закрой блок <code>OIC</code>.</p>',
        starter: `HAI 1.2
I HAS A lives ITZ 9

TODO ветвление здесь

KTHXBYE`,
        rules: [
          { desc: 'Переменная lives объявлена со значением 9', all: ['I HAS A lives ITZ 9'] },
          { desc: 'Есть вопрос O RLY?', all: ['O RLY\\?'] },
          { desc: 'Есть ветка YA RLY с выводом', all: ['YA RLY', '\\n[ \\t]*VISIBLE[ \\t]+"MANY LIVES"'] },
          { desc: 'Есть ветка NO WAI с выводом', all: ['NO WAI', '\\n[ \\t]*VISIBLE[ \\t]+"FEW LIVES"'] },
          { desc: 'Ветвление закрыто OIC', all: ['^\\s*OIC\\s*$'] },
          { desc: 'Нет заглушек TODO', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Условие перед O RLY? достаточно любое логическое — например BOTH SAEM lives AN 9.',
        'Структура: <условие>, O RLY? / YA RLY + VISIBLE / NO WAI + VISIBLE / OIC.'
      ],
      solution: `HAI 1.2
I HAS A lives ITZ 9

BOTH SAEM lives AN 9, O RLY?
  YA RLY
    VISIBLE "MANY LIVES"
  NO WAI
    VISIBLE "FEW LIVES"
OIC
KTHXBYE`
    },

    /* ---------- 5. Проект: счётчик ---------- */
    {
      id: 'lolcode-5',
      title: '🚀 Проект: цикл-счётчик',
      goal: 'Собрать полноценную программу с циклом IM IN YR … UPPIN YR … TIL и выводом значений',
      xp: 100,
      theory: [
        { t: 'p', html: 'Циклы в LOLCODE выглядят как приказы: <code>IM IN YR цикл</code> («я в цикле») начинает, <code>IM OUTTA YR цикл</code> заканчивает. Между ними — имя счётчика и режим: <code>UPPIN YR i</code> увеличивает i на 1, <code>NERFIN YR i</code> уменьшает. Границы задают словами <code>TIL условие</code> («пока не») или <code>WILE условие</code> («пока»).' },
        { t: 'code', code: `HAI 1.2
I HAS A i
IM IN YR loop UPPIN YR i TIL BOTH SAEM i AN 3
  VISIBLE "Step" i
IM OUTTA YR loop
VISIBLE "DONE"
KTHXBYE` },
        { t: 'p', html: 'Такая программа выведет Step 0, Step 1, Step 2 и в конце DONE: счётчик начинается с нуля, TIL останавливает цикл, когда i достигнет 3. Это рабочий алгоритм — на таких циклах в LOLCODE писали настоящие примеры, включая веб-сервер шутки ради.' },
        { t: 'list', items: [
          '<b>IM IN YR имя UPPIN YR счётчик TIL условие</b> — полный каркас цикла;',
          '<b>счётчик с 0</b> — i идёт 0, 1, 2 … до границы-1;',
          '<b>TIL</b> — предусловие «пока не станет»;',
          '<b>WILE</b> — постусловие «пока верно»;',
          '<b>GTFO</b> — досрочный выход (как break).'
        ] },
        { t: 'p', html: 'Финальная котопрограмма соберёт всё изученное: переменные, вывод, сравнение в TIL. Проверка структурная: каркас, счётчик UPPIN, граница TIL с BOTH SAEM и пять строк вывода. После зачёта смело пробуй выводить квадраты чисел через PRODUKT OF i AN i — настоящий алгоритм на мем-языке.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши котопрограмму-счётчик: цикл <code>IM IN YR loop UPPIN YR i TIL BOTH SAEM i AN 5</code>, внутри которого <code>VISIBLE "N" i</code>; после цикла — <code>VISIBLE "DONE"</code>. Каркас HAI/KTHXBYE обязателен.</p>',
        starter: `HAI 1.2
I HAS A i

TODO цикл здесь

KTHXBYE`,
        rules: [
          { desc: 'Открытие цикла с UPPIN YR i', all: ['IM IN YR \\w+ UPPIN YR i'] },
          { desc: 'Граница TIL с BOTH SAEM i AN 5', all: ['TIL[ \\t]+BOTH SAEM i AN 5'] },
          { desc: 'Внутри цикла есть VISIBLE', all: ['VISIBLE'] },
          { desc: 'После цикла печатается DONE', any: ['VISIBLE "DONE"', 'VISIBLE\\s+"DONE[ !]+', 'DONE"]'] },
          { desc: 'Закрытие IM OUTTA YR', all: ['IM OUTTA YR'] },
          { desc: 'Нет заглушек TODO', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Каркас: IM IN YR loop UPPIN YR i TIL BOTH SAEM i AN 5 … IM OUTTA YR loop.',
        'Внутри цикла: VISIBLE "N" i. После выхода — VISIBLE "DONE".'
      ],
      solution: `HAI 1.2
I HAS A i

IM IN YR loop UPPIN YR i TIL BOTH SAEM i AN 5
  VISIBLE "N" i
IM OUTTA YR loop

VISIBLE "DONE"
KTHXBYE`
    }
  ],

  cheats: [
    { title: 'Каркас программы', code: `HAI 1.2
  ...команды...
KTHXBYE` },
    { title: 'Вывод и комментарии', list: [
      '<code>VISIBLE "текст"</code> — печать строки',
      '<code>VISIBLE "a" x</code> — печать нескольких значений',
      '<code>BTW</code> — комментарий до конца строки',
      '<code>OBTW … TLDR</code> — многострочный комментарий'
    ] },
    { title: 'Переменные', list: [
      '<code>I HAS A x</code> — объявить',
      '<code>I HAS A x ITZ 5</code> — объявить и присвоить',
      '<code>x R 10</code> — присвоить',
      '<code>NOOB</code> — пустое значение',
      '<code>WIN</code> / <code>FAIL</code> — истина / ложь'
    ] },
    { title: 'Арифметика (префиксная + AN)', list: [
      '<code>SUM OF a AN b</code> — a + b',
      '<code>DIFF OF a AN b</code> — a − b',
      '<code>PRODUKT OF a AN b</code> — a × b',
      '<code>QUOSHUNT OF a AN b</code> — a / b',
      '<code>MOD OF a AN b</code> — остаток',
      '<code>BIGGR OF</code> / <code>SMALLR OF</code> — max / min'
    ] },
    { title: 'Ветвления и циклы', list: [
      '<code>…, O RLY?</code> — начать ветвление',
      '<code>YA RLY</code> / <code>NO WAI</code> — тогда / иначе',
      '<code>OIC</code> — конец ветвления',
      '<code>IM IN YR цикл UPPIN YR i TIL условие</code> — цикл',
      '<code>IM OUTTA YR цикл</code> — конец цикла',
      '<code>GTFO</code> — break'
    ] }
  ]
};
