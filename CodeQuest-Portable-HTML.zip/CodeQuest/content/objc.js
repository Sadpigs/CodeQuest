'use strict';
/* ============ CodeQuest — курс Objective-C ============
   Objective-C не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.objc = {
  id: 'objc',
  title: 'Objective-C',
  emoji: '🍏',
  color: '#438eff',
  lang: 'objc',
  tagline: 'App Store-эпоха Apple: 10 уровней и список покупок',
  description: 'Надстройка над C, на которой построены iOS и macOS до эпохи Swift: методы вызываются сообщениями в квадратных скобках. За 10 уровней дойдём от NSLog до проектов «Класс Book» и «Список покупок» с инициализаторами, свойствами и NSMutableArray.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'objc-1',
      title: 'Первая программа',
      goal: 'Собрать каркас программы: #import Foundation, @autoreleasepool и вывод через NSLog со строкой @"..."',
      xp: 30,
      theory: [
        { t: 'p', html: 'Objective-C придумал Брэд Кокс в 1984 году: взять строгий и быстрый C и добавить к нему «слой» объектов — как это сделано в Smalltalk. Слой прижился у NeXT, а затем у Apple: все приложения iOS и macOS до 2014 года написаны на Objective-C, и миллионы строк этого кода до сих пор работают в App Store. С приходом Swift язык ушёл в тень, но остался в каждом iOS-проекте — в старых фреймворках, библиотеках и legacy-коде.' },
        { t: 'h', html: 'Каркас программы' },
        { t: 'code', code: `#import <Foundation/Foundation.h>

int main(void) {
    @autoreleasepool {
        NSLog(@"Привет, CodeQuest!");
    }
    return 0;
}` },
        { t: 'p', html: 'Разберём построчно. <code>#import</code> подключает <b>Foundation</b> — базовую библиотеку Apple: строки, массивы, словари, работу с памятью. <code>int main(void)</code> — точка входа, всё как в C. <code>@autoreleasepool { }</code> — пул автоматического освобождения: объекты, созданные внутри, аккуратно убираются на выходе из блока; в современных проектах этот блок есть всегда. <code>return 0</code> — код успеха, знакомый по любой C-подобной программе.' },
        { t: 'list', items: [
          '<b>#import &lt;...&gt;</b> — подключение библиотеки (умнее #include: не дублируется);',
          '<b>@autoreleasepool { }</b> — блок управления памятью;',
          '<b>NSLog(@"...")</b> — печать в консоль с меткой времени;',
          '<b>@"текст"</b> — литерал объектной строки NSString;',
          'каждое выражение заканчивается точкой с запятой.'
        ] },
        { t: 'note', html: 'Сборка на macOS: сохрани код в <b>main.m</b> и выполни <b>clang main.m -o hello -framework Foundation &amp;&amp; ./hello</b>. Компилятор clang понимает и C, и Objective-C, файлы последнего имеют расширение .m. На Linux то же самое делают через GNUstep: <b>clang main.m -o hello -lobjc -lgnustep-base</b>.' },
        { t: 'warn', html: 'Строка без собаки — это C-строка (<code>char *</code>), обычный массив байт. Методы NSString с ней работать не умеют, и <code>NSLog("Привет")</code> вместо <code>NSLog(@"Привет")</code> приведёт к падению или предупреждениям. Правило: всё, что должно быть объектом, — с <code>@</code>.' },
        { t: 'p', html: 'NSLog добавляет к выводу дату, время и имя процесса — в консоли выглядит шумно, зато удобно при отладке. В заданиях этого приложения нас интересует сам текст сообщения. Код не запускается, а проверяется по структуре — пиши настоящий Objective-C, как будто файл сейчас соберёт clang.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первую программу: подключи <code>Foundation</code> через <code>#import</code>, а в <code>main</code> внутри блока <code>@autoreleasepool</code> выведи фразу <code>Привет, CodeQuest!</code> через <code>NSLog</code> со строкой-литералом <code>@""</code>. Каркас дан — допиши вывод.</p>',
        starter: `// первая программа на Objective-C
#import <Foundation/Foundation.h>

int main(void) {
    @autoreleasepool {
        // TODO: выведи приветствие через NSLog
    }
    return 0;
}`,
        rules: [
          { desc: 'Foundation подключён через #import', all: ['#import\\s*<Foundation/Foundation\\.h>'] },
          { desc: 'Есть функция main', all: ['int\\s+main\\s*\\('] },
          { desc: 'Есть блок @autoreleasepool', all: ['@autoreleasepool\\s*\\{'] },
          { desc: 'Вывод через NSLog со строкой @"..."', all: ['NSLog\\s*\\(\\s*@"'] },
          { desc: 'Напечатана фраза "Привет, CodeQuest!", пометок TODO нет', any: ['@"Привет, CodeQuest!"'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Внутри @autoreleasepool добавь одну строку с NSLog.',
        'NSLog(@"Привет, CodeQuest!"); — собака перед кавычками обязательна.',
        'Фразу пиши точно: Привет, CodeQuest! — с запятой и восклицательным знаком.'
      ],
      solution: `#import <Foundation/Foundation.h>

int main(void) {
    @autoreleasepool {
        NSLog(@"Привет, CodeQuest!");
    }
    return 0;
}`
    },

    /* ---------- 2. Типы и переменные ---------- */
    {
      id: 'objc-2',
      title: 'Типы и переменные',
      goal: 'Различать C-типы (int, float, BOOL) и объектные NSString со строкой-литералом @"..."',
      xp: 30,
      theory: [
        { t: 'p', html: 'Objective-C — надстройка над C, поэтому все типы C здесь на месте: <code>int</code> — целые, <code>float</code> и <code>double</code> — дробные, <code>char</code> — символы. Плюс два ObjC-специфичных: <code>BOOL</code> со значениями <code>YES</code> и <code>NO</code> и объектные типы — всегда <b>указатели</b> со звёздочкой: <code>NSString *name</code>.' },
        { t: 'code', code: `int age = 25;
float price = 99.5f;
BOOL isActive = YES;
NSString *name = @"Аня";

NSLog(@"%@, %i лет", name, age);` },
        { t: 'p', html: 'Звёздочка у <code>NSString *</code> не украшение: объект живёт в «куче», а переменная хранит адрес (указатель) на него. Литерал <code>@"текст"</code> создаёт готовый объект строки — самый частый способ получить NSString. Смешивать миры просто: числа и флаги — обычные C-типы, «умные» вещи вроде строк и коллекций — объекты со звёздочкой.' },
        { t: 'table', head: ['Тип', 'Что хранит', 'Пример'], rows: [
          ['<code>int</code>', 'целое число', '<code>int age = 25;</code>'],
          ['<code>float</code> / <code>double</code>', 'дробное число', '<code>float price = 99.5f;</code>'],
          ['<code>BOOL</code>', 'истина/ложь: YES / NO', '<code>BOOL ok = YES;</code>'],
          ['<code>NSString *</code>', 'текст-объект', '<code>NSString *s = @"Аня";</code>']
        ] },
        { t: 'h', html: 'Форматы NSLog' },
        { t: 'p', html: 'NSLog печатает по шаблону в стиле printf, но с расширениями для объектов: <code>%@</code> — любой объект (строка, массив, дата), <code>%i</code> или <code>%d</code> — целое, <code>%f</code> — дробное. Аргументы подставляются по порядку: <code>NSLog(@"%@ набрал %i очков", player, score)</code>. Несовпадение количества форматов и аргументов — гарантированный мусор в выводе.' },
        { t: 'warn', html: 'Ловушки начинающихся: <code>float</code>-литерал пишется с суффиксом f (<code>99.5f</code>), без него это double — не ошибка, но тип другой. Для BOOL канон — <code>YES</code>/<code>NO</code> (true/false тоже сработают, но так пишут только пришедшие из C++). И главное: <code>NSString *name = "Аня"</code> без собаки — это уже не объектная строка, компилятор выдаст предупреждение о несовместимых указателях.' },
        { t: 'note', html: 'В чужом коде встретишь <code>NSInteger</code> и <code>CGFloat</code> — платформенные псевдонимы: на 64-битных системах это long и double. Вводят их, чтобы код компилировался одинаково на разных архитектурах. Для обучения хватает базовых int/float.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни карточку читателя. Возраст — целое, цена подписки — дробное (не забудь суффикс float-литерала), имя — объектная строка с собакой перед кавычками, флаг активности — каноничное логическое значение ObjC.</p>',
        code: `int age = {{0}};
float price = {{1}};
NSString *name = {{2}};
BOOL isActive = {{3}};

NSLog(@"%@, %i лет. Подписка: %f", name, age, price);`,
        blanks: [
          { answer: '25' },
          { answer: '99.5f', alt: ['99.5', '99.50f', '99.50'] },
          { answer: '@"Аня"' },
          { answer: 'YES', alt: ['yes', 'true'] }
        ],
        ci: false
      },
      hints: [
        'Целое — просто число: 25. Для float — суффикс f: 99.5f.',
        'NSString — объектная строка: @"Аня", собака перед кавычками обязательна.',
        'Истина в ObjC-стиле — это YES.'
      ],
      solution: ['25', '99.5f', '@"Аня"', 'YES']
    },

    /* ---------- 3. Условия и циклы ---------- */
    {
      id: 'objc-3',
      title: 'Условия и циклы',
      goal: 'Просчитать C-подобные if/else и for со счётчиком и назвать вывод NSLog',
      xp: 35,
      theory: [
        { t: 'p', html: 'Управляющие конструкции Objective-C — это чистый C: <code>if / else if / else</code>, <code>for</code>, <code>while</code>. Круглые скобки вокруг условия обязательны (в отличие от Go), фигурные скобки блока — как всюду. Если ты знаком с C, Java или JavaScript — эта часть языка уже твоя.' },
        { t: 'code', code: `int total = 0;
for (int i = 2; i <= 8; i += 2) {
    total += i;
}
NSLog(@"total = %i", total);` },
        { t: 'p', html: 'Цикл <code>for (инициализация; условие; шаг)</code>: здесь <code>int i = 2</code> — счётчик, объявленный внутри цикла, <code>i &lt;= 8</code> — условие продолжения, <code>i += 2</code> — шаг на двойку. Переменная i существует только внутри цикла. Оператор <code>+=</code> прибавляет и сохраняет — классический аккумулятор.' },
        { t: 'p', html: 'Ветки if проверяются сверху вниз: первая истинная выполняется, остальные пропускаются. Внутри тела цикла if срабатывает на каждом шаге заново — это частая конструкция «найди нужный элемент»:' },
        { t: 'code', code: `for (int i = 0; i < 3; i++) {
    if (i == 1) {
        NSLog(@"середина");
    }
}` },
        { t: 'list', items: [
          '<b>сравнения</b>: <code>==</code>, <code>!=</code>, <code>&gt;</code>, <code>&lt;</code>, <code>&gt;=</code>, <code>&lt;=</code>;',
          '<b>комбинации</b>: <code>&amp;&amp;</code> — и, <code>||</code> — или, <code>!</code> — не;',
          '<b>шаги</b>: <code>i++</code> — плюс один, <code>i += 2</code> — плюс два;',
          '<b>break</b> — выйти из цикла досрочно, <code>continue</code> — пропустить шаг.'
        ] },
        { t: 'warn', html: 'Классическая ловушка C: <code>=</code> присваивает, <code>==</code> сравнивает. Условие <code>if (x = 10)</code> не сравнит, а присвоит x десятку и посчитает его истиной — компилятор clang предупредит, но только предупреждением. Проверяй каждый if на лишний знак равенства.' },
        { t: 'note', html: 'В выводе NSLog формат <code>%i</code> подставляет целое из аргументов, <code>%@</code> — объект. В задании «предскажи вывод» мы интересуемся только текстом сообщений — метку времени, которую NSLog добавляет в реальной консоли, писать не нужно.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай программу и запиши, что она напечатает: по одной строке на каждый NSLog, в порядке вывода (только текст сообщений, без служебной метки времени, которую NSLog добавляет в реальной консоли).</p>',
        code: `int total = 0;
for (int i = 2; i <= 8; i += 2) {
    total += i;
}
NSLog(@"total = %i", total);

for (int i = 0; i < 3; i++) {
    if (i == 1) {
        NSLog(@"середина");
    }
}`,
        answer: `total = 20
середина`
      },
      hints: [
        'Первый цикл пробегает i = 2, 4, 6, 8 — сложи их вручную.',
        'Второй цикл делает три шага: i = 0, 1, 2. Равенство i == 1 наступает ровно один раз.',
        'Формат %i подставляет число в строку: "total = %i" превратится в total = <число>.'
      ],
      solution: `total = 20
середина`
    },

    /* ---------- 4. Классы и сообщения ---------- */
    {
      id: 'objc-4',
      title: 'Классы и сообщения',
      goal: 'Объявить класс через @interface/@implementation, создать объект alloc/init и отправить сообщение [obj say:]',
      xp: 40,
      theory: [
        { t: 'p', html: 'Класс в Objective-C описывается в два приёма. <b>@interface</b> — объявление: имя класса, родитель и список методов («что умеет»). <b>@implementation</b> — реализация: сами тела методов («как именно»). Обе секции закрываются словом <code>@end</code>. Наследование пишется через двоеточие: <code>: NSObject</code> — почти все классы наследуют от NSObject, корневого класса фреймворка.' },
        { t: 'code', code: `#import <Foundation/Foundation.h>

@interface Greeter : NSObject
- (void)say:(NSString *)msg;
@end

@implementation Greeter
- (void)say:(NSString *)msg {
    NSLog(@"Ты сказал: %@", msg);
}
@end` },
        { t: 'p', html: 'Читаем объявление метода: <code>-</code> — метод <b>объекта</b> (экземпляра), плюс означал бы метод класса. <code>(void)</code> — тип возвращаемого значения в скобках: ничего не возвращаем. <code>say:</code> — имя метода, двоеточие появляется, когда метод принимает аргумент; после двоеточия тип и имя параметра. Двоеточие — часть имени: <code>say</code> и <code>say:</code> — разные методы!' },
        { t: 'h', html: 'Создание объекта и вызов' },
        { t: 'code', code: `int main(void) {
    @autoreleasepool {
        Greeter *g = [[Greeter alloc] init];
        [g say:@"Привет!"];
    }
    return 0;
}` },
        { t: 'p', html: '<code>[[Greeter alloc] init]</code> читается изнутри наружу: выделить память под объект (<code>alloc</code>), затем инициализировать (<code>init</code>). Вызов метода — <b>отправка сообщения</b>: <code>[приёмник сообщение:аргумент]</code>. Это сердце языка: вместо <code>obj.method(arg)</code> пишут <code>[obj method:arg]</code>. Сообщение, которого объект не понимает, — ошибка в рантайме, поэтому имена методов проверяют внимательно.' },
        { t: 'list', items: [
          '<b>- (тип)имя</b> — метод объекта; <b>+ (тип)имя</b> — метод класса;',
          '<b>@end</b> — закрывает и @interface, и @implementation;',
          '<b>[[Класс alloc] init]</b> — создание объекта (короче: <code>[Класс new]</code>);',
          '<b>[g say:@"Привет!"]</b> — отправка сообщения с аргументом.'
        ] },
        { t: 'warn', html: 'Забытый <code>@end</code> — компилятор путается, где кончается класс, и сыплет ошибками по всему файлу. Ставь @end сразу после написания секции. И не забывай звёздочку: <code>Greeter g</code> вместо <code>Greeter *g</code> не скомпилируется — объекты только через указатели. Кстати, метод с несколькими аргументами «разрывается» именами — получается читаемое предложение: <code>- (void)moveX:(int)x andY:(int)y;</code>, вызов <code>[p moveX:3 andY:5]</code>.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Создай класс <code>Greeter</code>: <code>@interface Greeter : NSObject</code> с методом <code>- (void)say:(NSString *)msg;</code> и секция <code>@implementation</code>, где метод печатает сообщение через NSLog. В <code>main</code> создай объект через <code>[[Greeter alloc] init]</code> и отправь ему сообщение <code>say:</code> со строкой.</p>',
        starter: `// класс Greeter и его метод say:
#import <Foundation/Foundation.h>

// TODO: объяви интерфейс класса с наследованием NSObject
// TODO: реализуй класс и его метод

int main(void) {
    @autoreleasepool {
        // TODO: создай объект и отправь ему сообщение
    }
    return 0;
}`,
        rules: [
          { desc: 'Класс объявлен: @interface ... : NSObject, @implementation и @end', all: ['@interface\\s+\\w+\\s*:\\s*NSObject', '@implementation\\s+\\w+', '@end'] },
          { desc: 'Метод say: объявлен в форме - (void)say:(NSString *)', all: ['-\\s*\\(\\s*void\\s*\\)\\s*say\\s*:'] },
          { desc: 'Объект создан через [[Класс alloc] init] или [Класс new]', any: ['\\[\\s*\\[\\s*\\w+\\s+alloc\\s*\\]\\s*init', '\\[\\s*\\w+\\s+new\\s*\\]'] },
          { desc: 'Метод вызван сообщением: [объект say:...]', all: ['\\[\\s*\\w+\\s+say\\s*:'] },
          { desc: 'Есть вывод NSLog, пометок TODO нет', any: ['NSLog\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Объявление: @interface Greeter : NSObject / - (void)say:(NSString *)msg; / @end.',
        'Реализация: @implementation Greeter / тот же метод с телом / @end.',
        'В main: Greeter *g = [[Greeter alloc] init]; затем [g say:@"Привет!"];'
      ],
      solution: `#import <Foundation/Foundation.h>

@interface Greeter : NSObject
- (void)say:(NSString *)msg;
@end

@implementation Greeter
- (void)say:(NSString *)msg {
    NSLog(@"Ты сказал: %@", msg);
}
@end

int main(void) {
    @autoreleasepool {
        Greeter *g = [[Greeter alloc] init];
        [g say:@"Привет!"];
    }
    return 0;
}`
    },

    /* ---------- 5. Коллекции и @property ---------- */
    {
      id: 'objc-5',
      title: 'Коллекции и @property',
      goal: 'Различать литералы NSArray @[...] и NSDictionary @{...}, доставать элементы по индексу и ключу',
      xp: 40,
      theory: [
        { t: 'p', html: 'Литералы — короткий синтаксис коллекций, добавленный в язык в 2012 году: <code>@[...]</code> создаёт массив, <code>@{...}</code> — словарь. Внутри — тоже объекты: строки <code>@"..."</code>, числа <code>@5</code>, другие массивы. До литералов те же вещи писали многословно через <code>[NSArray arrayWithObjects:...]</code> — короткая форма сделала код Objective-C заметно аккуратнее.' },
        { t: 'code', code: `NSArray *langs = @[ @"ObjC", @"Swift" ];
NSDictionary *info = @{ @"год": @"1984" };

NSLog(@"%@", langs[0]);        // ObjC
NSLog(@"%@", info[@"год"]);    // 1984` },
        { t: 'p', html: 'Доступ — через индексную запись: <code>langs[0]</code> достаёт первый элемент массива, <code>info[@"ключ"]</code> — значение словаря по ключу. Внутри это обычные сообщения <code>[langs objectAtIndex:0]</code> и <code>[info objectForKey:@"ключ"]</code>, просто в удобной форме. Нумерация — с нуля, как в C.' },
        { t: 'h', html: '@property — свойства класса' },
        { t: 'code', code: `@interface Book : NSObject
@property NSString *title;
@property int year;
@end` },
        { t: 'p', html: 'Директива <code>@property</code> объявляет свойство: компилятор сам создаёт переменную экземпляра и методы доступа (геттер и сеттер). Читают и пишут свойство через точку: <code>book.title</code> — получить, <code>book.year = 1842</code> — записать. До @property те же геттеры/сеттеры писали руками — строк двадцать бойлерплейта на каждое свойство.' },
        { t: 'list', items: [
          '<b>@[]</b> — литерал массива NSArray;',
          '<b>@{}</b> — литерал словаря NSDictionary (ключ: значение);',
          '<b>langs[0]</b> — элемент по индексу, <b>info[@"ключ"]</b> — по ключу;',
          '<b>langs.count</b> — количество элементов;',
          '<b>for (NSString *s in langs)</b> — быстрый перебор без индексов.'
        ] },
        { t: 'warn', html: 'NSArray и NSDictionary из литералов — <b>неизменяемые</b>: добавить элемент после создания нельзя. Нужен изменяемый список — бери <code>NSMutableArray</code> и его методы <code>addObject:</code> / <code>removeObject:</code>; для него работает и индексная запись на заполнение: <code>mut[0] = @"новое"</code>. И второй подводный камень: <code>nil</code> внутри литерала класть нельзя — массив обрежется на нём, а словарь упадёт в рантайме. Зато перебор <code>for (NSString *s in langs)</code> — безопасная ObjC-версия foreach, короче классического for.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Дан код:</p><pre>NSArray *langs = @[ @"ObjC", @"Swift" ];
NSDictionary *info = @{ @"год": @"1984" };
NSLog(@"%@", langs[0]);
NSLog(@"%@", info[@"год"]);</pre><p>Что напечатают оба NSLog (в порядке вывода)?</p>`,
        options: [
          'ObjC и 1984',
          'Swift и 1984',
          'ObjC и год',
          'Ошибка: литерал @[...] так не индексируется'
        ],
        correct: 0,
        explain: 'Литерал @[...] создаёт NSArray, langs[0] — первый элемент, то есть @"ObjC". Литерал @{...} создаёт NSDictionary, info[@"год"] достаёт значение по ключу — @"1984". Индексная запись [ ] работает и для массивов (индекс), и для словарей (ключ), а формат %@ печатает объект как есть.',
        solution: 0
      },
      hints: [
        'Нумерация массива с нуля: langs[0] — первый элемент, а не второй.',
        'В словаре значение достаётся по ключу: info[@"год"] — это @"1984", а не слово «год».',
        'Индексная запись langs[0] — это обычный синтаксис, а не ошибка.'
      ],
      solution: 0
    },

    /* ---------- 6. Проект: класс Book ---------- */
    {
      id: 'objc-6',
      title: '🚀 Проект: класс Book',
      goal: 'Собрать финальный проект: класс с @property, метод describe и вывод описания книги',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальный проект — маленькая «модель данных», как в настоящем приложении: класс <code>Book</code> со свойствами «название» и «год» и методом <code>describe</code>, который собирает человеческое описание книги. Такие классы-модели кладут в массив и рисуют по ним таблицы в интерфейсе — это фундамент любого iOS-приложения со списками. Вот весь класс целиком, разберём его по частям:' },
        { t: 'code', code: `#import <Foundation/Foundation.h>

@interface Book : NSObject
@property NSString *title;
@property int year;
- (NSString *)describe;
@end

@implementation Book
- (NSString *)describe {
    return [NSString stringWithFormat:@"%@ (%i)", self.title, self.year];
}
@end` },
        { t: 'p', html: 'Читаем: два <code>@property</code> — строка-название и целое-год; метод <code>- (NSString *)describe</code> возвращает строку-объект. Внутри метода <code>self.title</code> — обращение к собственному свойству: <code>self</code> это «сам объект». Конструирует строку сообщение <code>[NSString stringWithFormat:...]</code> — sprintf для объектов: форматы <code>%@</code> и <code>%i</code>, аргументы по порядку.' },
        { t: 'h', html: 'Как использовать' },
        { t: 'code', code: `int main(void) {
    @autoreleasepool {
        Book *b = [[Book alloc] init];
        b.title = @"Мёртвые души";
        b.year = 1842;
        NSLog(@"%@", [b describe]);
    }
    return 0;
}` },
        { t: 'p', html: 'Создали объект, заполнили свойства через точку, вызвали <code>[b describe]</code> — а результат сразу подставили в <code>NSLog</code> через <code>%@</code>. Вложение сообщения внутрь другого сообщения — обычное дело: сначала считается describe, потом печатается.' },
        { t: 'list', items: [
          '<b>@interface Book : NSObject</b> — два @property и объявление describe;',
          '<b>@implementation</b> — тело метода через [NSString stringWithFormat:...];',
          '<b>self.title / self.year</b> — доступ к своим свойствам;',
          '<b>[[Book alloc] init]</b> — создание и инициализация объекта;',
          '<b>b.title = @"..."</b> — заполнение, <b>NSLog(@"%@", [b describe])</b> — вывод.'
        ] },
        { t: 'warn', html: '<code>self</code> внутри метода обязателен для явного стиля: пишешь <code>title</code> без self — тоже сработает, но <code>self.title</code> читается однозначно и не путается с локальными переменными. И не забудь <code>@end</code> после обеих секций: интерфейс и реализация закрываются отдельно. После зачёта расширяй модель: добавь <code>@property NSString *author;</code>, включи автора в describe, создай вторую книгу и собери массив описаний <code>@[book1, book2]</code> — получишь мини-каталог. Дальше по этому пути — таблицы UITableView и настоящие приложения.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Класс Book».</b> Объяви <code>@interface Book : NSObject</code> со свойствами <code>@property NSString *title;</code> и <code>@property int year;</code> и методом <code>describe</code>, возвращающим <code>NSString</code>. Реализуй класс: метод собирает описание через <code>[NSString stringWithFormat:...]</code> из title и year. В <code>main</code> создай книгу через <code>[[Book alloc] init]</code>, заполни оба свойства через точку и выведи <code>[книга describe]</code> через NSLog.</p>',
        starter: `// Проект: класс Book с методом describe
#import <Foundation/Foundation.h>

// TODO: объяви интерфейс Book: два свойства и метод describe
// TODO: реализуй класс: метод собирает описание книги

int main(void) {
    @autoreleasepool {
        // TODO: создай книгу, заполни свойства и выведи describe
    }
    return 0;
}`,
        rules: [
          { desc: 'Класс Book объявлен и реализован (@interface : NSObject, @implementation, @end)', all: ['@interface\\s+Book\\s*:\\s*NSObject', '@implementation\\s+Book', '@end'] },
          { desc: 'Есть @property title (строка) и @property year (число)', all: ['@property[^;]*title', '@property[^;]*year'] },
          { desc: 'Метод describe объявлен (возвращающий NSString или void)', any: ['-\\s*\\(\\s*NSString\\s*\\*\\s*\\)\\s*describe', '-\\s*\\(\\s*void\\s*\\)\\s*describe'] },
          { desc: 'Объект создан, свойства заполнены через точку', all: ['\\[\\s*\\[\\s*Book\\s+alloc', '\\.title\\s*=', '\\.year\\s*='] },
          { desc: 'describe вызывается и выводится через NSLog, пометок TODO нет', all: ['\\bdescribe\\b'], any: ['NSLog\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Интерфейс: @interface Book : NSObject / @property NSString *title; / @property int year; / - (NSString *)describe; / @end.',
        'Реализация: - (NSString *)describe { return [NSString stringWithFormat:@"%@ (%i)", self.title, self.year]; }.',
        'В main: Book *b = [[Book alloc] init]; b.title = @"..."; b.year = 1842; NSLog(@"%@", [b describe]);'
      ],
      solution: `#import <Foundation/Foundation.h>

@interface Book : NSObject
@property NSString *title;
@property int year;
- (NSString *)describe;
@end

@implementation Book
- (NSString *)describe {
    return [NSString stringWithFormat:@"%@ (%i)", self.title, self.year];
}
@end

int main(void) {
    @autoreleasepool {
        Book *b = [[Book alloc] init];
        b.title = @"Мёртвые души";
        b.year = 1842;
        NSLog(@"%@", [b describe]);
    }
    return 0;
}`
    },

    /* ---------- 7. Методы классов и инициализаторы ---------- */
    {
      id: 'objc-7',
      title: 'Методы классов и инициализаторы',
      goal: 'Различать методы класса (+) и объекта (-), писать инициализатор initWith... с self = [super init]',
      xp: 50,
      theory: [
        { t: 'p', html: 'Ты уже писал методы объектов — они начинаются с минуса. Вторая разновидность — <b>методы класса</b> с плюсом: вызываются у самого класса, а не у экземпляра. <code>[Player demoPlayer]</code>, <code>[NSString stringWithFormat:...]</code>, <code>[NSMutableArray array]</code> — всё это плюсовые методы: класс сам отвечает на сообщение, без предварительного alloc.' },
        { t: 'code', code: `+ (instancetype)demoPlayer {
    return [[Player alloc] initWithName:@"Гость" score:0];
}` },
        { t: 'p', html: 'Типичный плюс-метод — фабрика: создать и вернуть готовый объект. Возвращаемый тип <code>instancetype</code> означает «такой же тип, как у приёмника сообщения»: компилятор поймёт, что вернулся Player, и подскажет поля. Старые книги пишут <code>id</code> — это тоже «любой объект», но instancetype точнее и современнее.' },
        { t: 'h', html: 'Инициализатор с параметрами' },
        { t: 'code', code: `- (instancetype)initWithName:(NSString *)name score:(int)score {
    self = [super init];
    if (self) {
        self.name = name;
        self.score = score;
    }
    return self;
}` },
        { t: 'p', html: 'Инициализатор — метод объекта, имя которого начинается с <code>init</code>. Каноническая схема из четырёх шагов: сначала <code>self = [super init]</code> — родитель выделяет и подготавливает базовую часть объекта; родитель может вернуть другой объект или nil, поэтому результат обязательно присваивается self. Затем <code>if (self)</code> — заполняем свои поля, только если объект жив. И <code>return self</code> — отдаём готовый экземпляр.' },
        { t: 'list', items: [
          '<b>- (тип)имя</b> — метод объекта, <b>+ (тип)имя</b> — метод класса;',
          '<b>instancetype</b> — возвращаемый тип «как у приёмника»;',
          '<b>self = [super init];</b> — всегда первая строка инициализатора;',
          '<b>if (self) { ... } return self;</b> — проверка и возврат.'
        ] },
        { t: 'warn', html: 'Порядок обязателен: без <code>self = [super init]</code> поля родителя не подготовятся, без <code>if (self)</code> можно записать поля в nil (тихо и бесполезно), без <code>return self</code> инициализатор не вернёт объект. Вызов с двумя параметрами читается как предложение: <code>[[Player alloc] initWithName:@"Аня" score:1200]</code> — имя, потом очки, в порядке объявления.' },
        { t: 'note', html: 'Инициализаторов у класса может быть несколько: <code>initWithName:</code>, <code>initWithName:score:</code>, <code>initWithFile:</code> — все они в итоге сводятся к одному designated-инициализатору, который и вызывает [super init]. Остальные лишь подставляют значения по умолчанию и вызывают его.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери класс <code>Player</code>: свойства <code>name</code> (строка) и <code>score</code> (целое), инициализатор <code>- (instancetype)initWithName:(NSString *)name score:(int)score;</code> по канонической схеме (<code>self = [super init];</code>, <code>if (self)</code>, заполнение полей, <code>return self;</code>) и плюс-метод класса, возвращающий <code>instancetype</code>. В <code>main</code> создай игрока через <code>[[Player alloc] initWithName:... score:...]</code> и выведи его поля через NSLog.</p>',
        starter: `// класс Player: инициализатор и метод класса
#import <Foundation/Foundation.h>

// TODO: объяви интерфейс со свойствами и initWith, реализуй их

int main(void) {
    @autoreleasepool {
        // TODO: создай игрока через initWith и выведи поля
    }
    return 0;
}`,
        rules: [
          { desc: 'Класс Player объявлен и реализован (@interface : NSObject, @implementation, @end)', all: ['@interface\\s+Player\\s*:\\s*NSObject', '@implementation\\s+Player', '@end'] },
          { desc: 'Свойства name и score объявлены через @property', all: ['@property[^;]*name', '@property[^;]*score'] },
          { desc: 'Инициализатор объявлен: - (instancetype)initWith...', all: ['-\\s*\\(\\s*instancetype\\s*\\)\\s*initWith\\w*\\s*:'] },
          { desc: 'Каноническая схема: self = [super init]; и проверка if (self)', all: ['self\\s*=\\s*\\[\\s*super\\s+init\\s*\\]', 'if\\s*\\(\\s*self\\s*\\)'] },
          { desc: 'Инициализатор возвращает self, объект создаётся через [[Player alloc] initWith...]', all: ['return\\s+self', '\\[\\s*\\[\\s*Player\\s+alloc\\s*\\]\\s*initWith'] },
          { desc: 'Есть плюс-метод класса с instancetype, вывод через NSLog, пометок TODO нет', all: ['\\+\\s*\\(\\s*instancetype\\s*\\)'], any: ['NSLog\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Интерфейс: @interface Player : NSObject / два @property / - (instancetype)initWithName:(NSString *)name score:(int)score; / @end.',
        'Тело инициализатора: self = [super init]; if (self) { self.name = name; self.score = score; } return self;',
        'Плюс-метод: + (instancetype)demoPlayer { return [[Player alloc] initWithName:@"Гость" score:0]; }. В main: Player *p = [[Player alloc] initWithName:@"Аня" score:1200];'
      ],
      solution: `#import <Foundation/Foundation.h>

@interface Player : NSObject
@property NSString *name;
@property int score;
- (instancetype)initWithName:(NSString *)name score:(int)score;
@end

@implementation Player
- (instancetype)initWithName:(NSString *)name score:(int)score {
    self = [super init];
    if (self) {
        self.name = name;
        self.score = score;
    }
    return self;
}

+ (instancetype)demoPlayer {
    return [[Player alloc] initWithName:@"Гость" score:0];
}
@end

int main(void) {
    @autoreleasepool {
        Player *p = [[Player alloc] initWithName:@"Аня" score:1200];
        NSLog(@"%@ — %i очков", p.name, p.score);
    }
    return 0;
}`
    },

    /* ---------- 8. Свойства @property: атрибуты и точка ---------- */
    {
      id: 'objc-8',
      title: 'Свойства @property и точечный синтаксис',
      goal: 'Настраивать @property атрибутами nonatomic, strong, readwrite, readonly и пользоваться точечным синтаксисом',
      xp: 45,
      theory: [
        { t: 'p', html: 'В objc-6 ты объявлял свойства без скобок — тогда компилятор подставлял значения по умолчанию. Полная форма — <code>@property (атрибуты) Тип имя;</code>: в скобках через запятую перечисляются правила доступа и владения. По умолчанию свойство readwrite (читать и писать), atomic (с блокировками) и strong (владеть объектом).' },
        { t: 'code', code: `@interface Album : NSObject
@property (nonatomic) NSString *title;      // без блокировок
@property (nonatomic, strong) NSString *artist;
@property (nonatomic, readonly) int year;   // снаружи только чтение
@end` },
        { t: 'p', html: '<b>nonatomic</b> — доступ без блокировок: быстрее, и так пишут почти весь интерфейсный код. <b>strong</b> — «я владею объектом»: пока свойство ссылается на исполнителя, он не удалится из памяти. <b>weak</b> — противоположность: ссылка без владения, автоматически обнуляется, когда объект исчезает. <b>copy</b> — хранить собственную копию строки, на случай если пришедшую строку кто-то изменит.' },
        { t: 'table', head: ['Атрибут', 'Что означает'], rows: [
          ['nonatomic / atomic', 'без блокировок (быстро) / с блокировкой (по умолчанию)'],
          ['strong / weak', 'владеем объектом / ссылка без владения'],
          ['readwrite / readonly', 'геттер и сеттер / только геттер'],
          ['copy', 'хранить копию присвоенного объекта']
        ] },
        { t: 'p', html: 'Точечный синтаксис из проекта Book работает поверх атрибутов: <code>a.title = @"Белый шум"</code> на самом деле вызывает сеттер <code>[a setTitle:@"Белый шум"]</code>, чтение <code>a.title</code> — геттер. У readonly-свойства сеттер не генерируется: присваивание снаружи, например <code>a.year = 1995</code>, будет ошибкой компиляции — а читать <code>a.year</code> можно сколько угодно.' },
        { t: 'warn', html: 'Не относись к атрибутам как к украшениям: readonly защищает данные от случайной записи, weak спасает от циклов удержания между объектами, nonatomic ускоряет горячие пути. Забыть nonatomic там, где он нужен, — значит получить медленный код; объявить readonly, а потом писать снаружи, — ошибка компиляции.' },
        { t: 'note', html: 'Компилятор сам создаёт переменную экземпляра с подчёркиванием (<code>_title</code>) и методы доступа. Внутри класса иногда пишут напрямую в <code>_year</code> — минуя сеттер; в init именно так и заполняют readonly-свойства.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Разметь интерфейс альбома: подставь директиву секции класса, затем атрибуты свойств — доступ без блокировок, владение объектом-исполнителем, явное разрешение записи и режим «только чтение».</p>',
        code: `{{1}} Album : NSObject

@property ({{2}}) NSString *title;               // без блокировок: быстрее в UI-коде
@property (nonatomic, {{3}}) NSString *artist;   // владеем объектом-исполнителем
@property (nonatomic, {{4}}) NSString *genre;    // и читать, и менять снаружи — явно
@property (nonatomic, {{5}}) int year;           // снаружи доступно только чтение

@end

int main(void) {
    @autoreleasepool {
        Album *a = [[Album alloc] init];
        a.title = @"Белый шум";
        NSLog(@"%@, год: %i", a.title, a.year);
    }
    return 0;
}`,
        blanks: [
          { answer: '@interface', ci: true },
          { answer: 'nonatomic' },
          { answer: 'strong' },
          { answer: 'readwrite' },
          { answer: 'readonly' }
        ],
        ci: false
      },
      hints: [
        'Секция класса открывается директивой @interface (закрывается @end).',
        'Без блокировок — nonatomic, владение объектом — strong.',
        'Явное «можно писать» — readwrite, «только читать» — readonly.'
      ],
      solution: ['@interface', 'nonatomic', 'strong', 'readwrite', 'readonly']
    },

    /* ---------- 9. Массивы NSArray/NSMutableArray и fast enumeration ---------- */
    {
      id: 'objc-9',
      title: 'NSArray/NSMutableArray и fast enumeration',
      goal: 'Создавать NSMutableArray, добавлять и убирать элементы addObject:/removeObject: и перебирать массив через for ... in',
      xp: 50,
      theory: [
        { t: 'p', html: 'Из objc-5 ты помнишь, что литерал <code>@[...]</code> даёт неизменяемый NSArray: создал — и ничего не добавить. Для рабочих списков нужен его изменяемый наследник — <code>NSMutableArray</code>. Его создают фабрикой <code>[NSMutableArray array]</code> или <code>[NSMutableArray arrayWithCapacity:10]</code>, а также через <code>[@[...] mutableCopy]</code> из литерала.' },
        { t: 'code', code: `NSMutableArray *cart = [NSMutableArray array];
[cart addObject:@"Хлеб"];
[cart addObject:@"Молоко"];
NSLog(@"%@", cart);        // ( Хлеб, Молоко )` },
        { t: 'p', html: 'Основные сообщения: <code>addObject:</code> — дописать в конец, <code>insertObject:atIndex:</code> — вставить в позицию, <code>removeObject:</code> — удалить по значению, <code>removeLastObject</code> — снять последний, <code>removeAllObjects</code> — очистить. Длина — <code>cart.count</code>. Пустой список — нормальное состояние, а вот nil внутрь класть нельзя: только настоящие объекты.' },
        { t: 'h', html: 'Fast enumeration' },
        { t: 'code', code: `for (NSString *item in cart) {
    NSLog(@"в корзине: %@", item);
}` },
        { t: 'p', html: 'Быстрый перебор — <code>for (Тип *элемент in массив)</code> — проходит коллекцию без индексов и счётчиков: на каждой итерации <code>item</code> — очередной объект. Это короче и безопаснее классического for с objectAtIndex: — не выйдешь за границы. Так перебираются NSArray, NSDictionary (пары ключ-значение), NSSet и даже строки.' },
        { t: 'list', items: [
          '<b>[NSMutableArray array]</b> — создать изменяемый список;',
          '<b>addObject: / removeObject:</b> — добавить и удалить;',
          '<b>count</b> — количество элементов;',
          '<b>for (NSString *s in list)</b> — быстрый перебор без индексов.'
        ] },
        { t: 'warn', html: 'Нельзя менять массив во время fast enumeration — рантайм бросит исключение «mutation during enumeration». Сначала собери то, что хочешь удалить, во второй массив, потом убери одним циклом. И не путай: у <code>NSArray</code> метода addObject: просто нет — компилятор подскажет.' },
        { t: 'note', html: 'В objc-10 проекте список покупок обернём в класс: коллекция станет @property, а добавление — методом addItem:. Там же встретится перебор со счётчиком — for-in плюс int-переменная для нумерации строк отчёта.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери корзину: создай <code>NSMutableArray</code> фабрикой <code>[NSMutableArray array]</code>, добавь три товара через <code>addObject:</code>, перебери корзину fast enumeration <code>for (NSString *item in cart)</code> и выведи каждый товар через <code>NSLog</code>. Затем удали один товар через <code>removeObject:</code> и напечатай оставшееся содержимое.</p>',
        starter: `// NSMutableArray и быстрый перебор
#import <Foundation/Foundation.h>

int main(void) {
    @autoreleasepool {
        // TODO: создай NSMutableArray, добавь товары,
        // перебери for ... in, удали один и выведи итог
    }
    return 0;
}`,
        rules: [
          { desc: 'Создан NSMutableArray', any: ['\\[\\s*NSMutableArray\\s+array', '\\[\\s*\\[\\s*NSMutableArray\\s+alloc\\s*\\]\\s*init', '\\.mutableCopy'] },
          { desc: 'Элементы добавляются через addObject:', all: ['addObject\\s*:'] },
          { desc: 'Есть быстрый перебор for (Тип *имя in массив)', all: ['for\\s*\\(\\s*\\w+\\s*\\*\\s*\\w+\\s+in\\s+\\w+\\s*\\)'] },
          { desc: 'Элемент выводится через NSLog со строкой-форматом %@', all: ['NSLog\\s*\\(\\s*@"[^"]*%@[^"]*"'] },
          { desc: 'Массив меняется ещё раз (removeObject: или вставка), пометок TODO нет', any: ['removeObject\\s*:', 'insertObject\\s*:'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Создание: NSMutableArray *cart = [NSMutableArray array];',
        'Перебор: for (NSString *item in cart) { NSLog(@"в корзине: %@", item); }',
        'Удаление: [cart removeObject:@"Хлеб"]; затем NSLog(@"%@", cart);'
      ],
      solution: `#import <Foundation/Foundation.h>

int main(void) {
    @autoreleasepool {
        NSMutableArray *cart = [NSMutableArray array];
        [cart addObject:@"Хлеб"];
        [cart addObject:@"Молоко"];
        [cart addObject:@"Сыр"];

        for (NSString *item in cart) {
            NSLog(@"в корзине: %@", item);
        }

        [cart removeObject:@"Хлеб"];
        NSLog(@"осталось: %@", cart);
    }
    return 0;
}`
    },

    /* ---------- 10. 🚀 Проект: список покупок ---------- */
    {
      id: 'objc-10',
      title: '🚀 Проект: список покупок',
      goal: 'Собрать класс-обёртку над NSMutableArray: свойство-список, init-подготовка, addItem и отчёт с перебором',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект собирает курс в одну программу: класс <code>ShoppingList</code>, который владеет изменяемым списком и умеет его пополнять и печатать. Это типовой паттерн «модель + поведение»: данные лежат в @property, а работа с ними — в методах. Такой класс несложно дорастить до корзины интернет-магазина.' },
        { t: 'code', code: `@interface ShoppingList : NSObject
@property NSMutableArray *items;
- (void)addItem:(NSString *)item;
- (void)report;
@end` },
        { t: 'p', html: 'Свойство-список обязательно готовится в инициализаторе — иначе методы уйдут в пустоту: сообщения объекту nil в Objective-C безопасны, но ничего не делают, и список молча останется пустым. Схема из objc-7: <code>self = [super init];</code>, проверка, и внутри — <code>self.items = [NSMutableArray array];</code>.' },
        { t: 'code', code: `- (void)addItem:(NSString *)item {
    [self.items addObject:item];
}

- (void)report {
    int n = 0;
    for (NSString *item in self.items) {
        n++;
        NSLog(@"%i. %@", n, item);
    }
    NSLog(@"Итого позиций: %i", n);
}` },
        { t: 'p', html: 'Метод <code>addItem:</code> делегирует работу списку: <code>[self.items addObject:item]</code>. Отчёт сочетает fast enumeration со счётчиком: int-переменная нумерует строки, формат <code>%i. %@</code> печатает «номер. товар», а после цикла NSLog выводит итог. Обрати внимание на <code>self.items</code> — обращение к собственному свойству, как у Book в objc-6.' },
        { t: 'list', items: [
          '<b>@property NSMutableArray *items;</b> — коллекция внутри класса;',
          '<b>init</b> готовит список: self.items = [NSMutableArray array];',
          '<b>[list addItem:@"Хлеб"]</b> — пополнение из main;',
          '<b>report</b> — перебор со счётчиком и итог через NSLog.'
        ] },
        { t: 'warn', html: 'Три ловушки проекта. Забытая инициализация items — тихий пустой список. Забытый @end после @implementation — каскад ошибок компиляции. И перепутанные форматы: %i — для целого счётчика, %@ — для объектов; NSNumber здесь не нужен, счётчик ведёт обычный int.' },
        { t: 'note', html: 'После зачёта расширяй: метод <code>removeItem:</code> на removeObject:, метод проверки «есть ли товар» через перебор, второй список — «куплено» — и перекладывание между ними. Дальше по этому пути — таблицы UITableView, где источником данных служит ровно такой класс с NSMutableArray внутри.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Список покупок».</b> Объяви класс <code>ShoppingList</code> со свойством <code>@property NSMutableArray *items;</code> и методами <code>addItem:</code> и <code>report</code>. Реализуй: инициализатор со схемой <code>self = [super init];</code> и подготовкой списка <code>[NSMutableArray array]</code>; метод, добавляющий элемент через <code>addObject:</code>; отчёт с fast enumeration по <code>self.items</code>, счётчиком и итоговым NSLog («Итого...»). В <code>main</code> создай список, добавь три товара и вызови отчёт.</p>',
        starter: `// Проект: список покупок
#import <Foundation/Foundation.h>

// TODO: объяви класс ShoppingList со свойством NSMutableArray
// TODO: реализуй init, addItem и отчёт с перебором

int main(void) {
    @autoreleasepool {
        // TODO: создай список, добавь товары, вызови отчёт
    }
    return 0;
}`,
        rules: [
          { desc: 'Класс ShoppingList объявлен и реализован', all: ['@interface\\s+ShoppingList\\s*:\\s*NSObject', '@implementation\\s+ShoppingList', '@end'] },
          { desc: 'Свойство-список объявлено через @property NSMutableArray', all: ['@property[^;]*NSMutableArray\\s*\\*'] },
          { desc: 'init по схеме: self = [super init]; и self.items = [NSMutableArray array]', all: ['self\\s*=\\s*\\[\\s*super\\s+init\\s*\\]', '\\[\\s*NSMutableArray\\s+array\\s*\\]'] },
          { desc: 'Метод addItem: добавляет через addObject:', all: ['-\\s*\\(\\s*void\\s*\\)\\s*addItem\\s*:', 'addObject\\s*:'] },
          { desc: 'Fast enumeration по self.items', all: ['for\\s*\\(\\s*\\w+\\s*\\*\\s*\\w+\\s+in\\s+self\\.\\w+'] },
          { desc: 'Итоговый NSLog с «Итого», товары добавляются addItem:@"...", пометок TODO нет', all: ['NSLog\\s*\\(\\s*@"[^"]*Итого', 'addItem\\s*:\\s*@"'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Интерфейс: @interface ShoppingList : NSObject / @property NSMutableArray *items; / - (void)addItem:(NSString *)item; / - (void)report; / @end.',
        'init: self = [super init]; if (self) { self.items = [NSMutableArray array]; } return self;',
        'report: int n = 0; for (NSString *item in self.items) { n++; NSLog(@"%i. %@", n, item); } NSLog(@"Итого позиций: %i", n);'
      ],
      solution: `#import <Foundation/Foundation.h>

@interface ShoppingList : NSObject
@property NSMutableArray *items;
- (void)addItem:(NSString *)item;
- (void)report;
@end

@implementation ShoppingList
- (instancetype)init {
    self = [super init];
    if (self) {
        self.items = [NSMutableArray array];
    }
    return self;
}

- (void)addItem:(NSString *)item {
    [self.items addObject:item];
}

- (void)report {
    int n = 0;
    for (NSString *item in self.items) {
        n++;
        NSLog(@"%i. %@", n, item);
    }
    NSLog(@"Итого позиций: %i", n);
}
@end

int main(void) {
    @autoreleasepool {
        ShoppingList *list = [[ShoppingList alloc] init];
        [list addItem:@"Хлеб"];
        [list addItem:@"Молоко"];
        [list addItem:@"Сыр"];
        [list report];
    }
    return 0;
}`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас программы',
      code: `#import <Foundation/Foundation.h>

int main(void) {
    @autoreleasepool {
        NSLog(@"Привет!");
    }
    return 0;
}
// clang main.m -o hello -framework Foundation
// ./hello`
    },
    {
      title: 'Типы и форматы',
      list: [
        'int — целое: 25',
        'float / double — дробное: 99.5f / 99.5',
        'BOOL — истина/ложь: YES / NO',
        'NSString * — текст-объект: @"Аня"',
        'форматы NSLog: %@ объект, %i целое, %f дробное',
        'NSInteger, CGFloat — платформенные псевдонимы'
      ]
    },
    {
      title: 'Классы и сообщения',
      code: `@interface Greeter : NSObject
- (void)say:(NSString *)msg;
@end

@implementation Greeter
- (void)say:(NSString *)msg { /* ... */ }
@end

Greeter *g = [[Greeter alloc] init];
[g say:@"Привет!"];
// - метод объекта, + метод класса
// say и say: — разные имена методов`
    },
    {
      title: 'Свойства и self',
      code: `@interface Book : NSObject
@property NSString *title;
@property int year;
@end

book.title = @"Мёртвые души"; // запись
NSLog(@"%@", book.title);     // чтение
self.title  // внутри метода — «моё» свойство`
    },
    {
      title: 'Коллекции',
      code: `NSArray *langs = @[ @"ObjC", @"Swift" ];
NSDictionary *info = @{ @"год": @"1984" };
langs[0]              // "ObjC" — по индексу
info[@"год"]          // "1984" — по ключу
langs.count           // количество
for (NSString *s in langs) { /* ... */ }
// литералы неизменяемы: NSMutableArray — для правок`
    },
    {
      title: 'Частые ошибки',
      list: [
        'строка без @ — это C-строка, NSString её не примет',
        'забыт @end — компилятор теряет границы класса',
        '= вместо == в if: присваивание вместо сравнения',
        'nil внутри литерала @[...] — обрезка или падение',
        'NSLog("...") без @"..." — неверный формат строки',
        'нет звёздочки: Greeter g вместо Greeter *g'
      ]
    },
    {
      title: 'Инициализаторы и методы класса',
      code: `- (instancetype)initWithName:(NSString *)name score:(int)score {
    self = [super init];
    if (self) {
        self.name = name;
        self.score = score;
    }
    return self;
}

Player *p = [[Player alloc] initWithName:@"Аня" score:1200];

+ (instancetype)demoPlayer {   // метод класса
    return [[Player alloc] initWithName:@"Гость" score:0];
}
//instancetype — «тип как у приёмника»`
    },
    {
      title: 'Атрибуты свойств и NSMutableArray',
      code: `@property (nonatomic) NSString *title;      // без блокировок
@property (nonatomic, strong) NSString *s;  // владеем объектом
@property (nonatomic, readonly) int year;   // только чтение
a.title = @"...";   // это [a setTitle:@"..."]

NSMutableArray *list = [NSMutableArray array];
[list addObject:@"Хлеб"];       // добавить
[list removeObject:@"Хлеб"];    // удалить
for (NSString *s in list) { /* ... */ }
[list count];                   // длина`
    }
  ]
};
