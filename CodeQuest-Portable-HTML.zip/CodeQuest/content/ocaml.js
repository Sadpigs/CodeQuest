'use strict';
/* ============ CodeQuest — курс OCaml ============
   OCaml не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.ocaml = {
  id: 'ocaml',
  title: 'OCaml',
  emoji: '🐫',
  color: '#e9740a',
  lang: 'ocaml',
  tagline: 'Промышленный ML: 10 уровней до дерева выражений',
  description: 'Промышленная реализация семейства ML из французского института INRIA (1996): строгие типы с выведением ловят баги ещё до запуска. Предок Rust, на нём сделаны доказатель Coq и инструменты Facebook (Flow, Infer). За 10 уровней — от print_endline до вариантных типов, immutable-обновления записей и дерева выражений.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'ocaml-1',
      title: 'Первая программа',
      goal: 'Собрать точку входа let () = с двумя выводами print_endline',
      xp: 30,
      theory: [
        { t: 'p', html: 'OCaml — промышленная реализация семейства языков ML, сделанная во французском институте INRIA (первый релиз — 1996 год). Ставка — строгая статическая типизация с выведением типов: компилятор сам понимает типы и ловит целые классы багов до запуска. На OCaml написаны доказатель теорем Coq, анализаторы кода Facebook (Flow, Hack, Infer), а компилятор Rust вырос из OCaml.' },
        { t: 'h', html: 'Первая программа' },
        { t: 'code', code: `let () =
  print_endline "Привет, CodeQuest!";
  print_endline "Это моя первая программа на OCaml."` },
        { t: 'p', html: '<code>let () = ...</code> — точка входа: «выполни этот блок сейчас». Внутри блока выражения разделяются точкой с запятой. <code>print_endline</code> печатает строку и переводит строку — никаких форматов, просто текст.' },
        { t: 'p', html: 'Комментарии в OCaml — <code>(* вот такие *)</code>, со скобками и звёздочкой. <code>//</code> комментарий не откроет — одна из мелочей, которая выдаёт новичка.' },
        { t: 'note', html: 'Запуск в терминале: <b>ocaml main.ml</b> — интерпретатор выполнит файл (под капотом компилирует байткод на лету). Для экспериментов есть интерактивный toplevel: команда <b>ocaml</b> (или более удобный <b>utop</b>). В этом приложении OCaml-код не запускается, а проверяется по структуре — пиши настоящий код.' },
        { t: 'warn', html: 'Имена — с маленькой буквы: <code>total</code>, <code>items</code>. Имя с большой буквы в OCaml зарезервировано для конструкторов и модулей — <code>Total</code> будет означать совсем другое. Строки — в двойных кавычках.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первую программу на OCaml: точка входа <code>let () =</code> и два вывода <code>print_endline</code> через точку с запятой, первый — с фразой <code>Привет, CodeQuest!</code>.</p>',
        starter: `(* TODO: выведи приветствие через print_endline *)`,
        rules: [
          { desc: 'Есть точка входа let () =', all: ['let\\s*\\(\\s*\\)\\s*='] },
          { desc: 'Вывод через print_endline со строкой в кавычках', all: ['print_endline\\s+"'] },
          { desc: 'Выводится фраза "Привет, CodeQuest!"', all: ['"Привет, CodeQuest!'] },
          { desc: 'Минимум два вызова print_endline', any: ['print_endline[\\s\\S]*print_endline'] },
          { desc: 'Пометок TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'let () = print_endline "..." — минимальная точка входа.',
        'Второй вывод: print_endline "..."; — выражения внутри let () разделяются точкой с запятой.',
        'Фраза — точно Привет, CodeQuest! в двойных кавычках.'
      ],
      solution: `let () =
  print_endline "Привет, CodeQuest!";
  print_endline "Это моя первая программа на OCaml."`
    },

    /* ---------- 2. let и типы ---------- */
    {
      id: 'ocaml-2',
      title: 'let и типы',
      goal: 'Связывать значения через let, различать int и float и их операторы',
      xp: 30,
      theory: [
        { t: 'p', html: '<code>let</code> связывает имя со значением: <code>let age = 20</code>. Тип выводится сам: 20 — <code>int</code>, 3.14 — <code>float</code>, текст — <code>string</code>, <code>true</code>/<code>false</code> — <code>bool</code>. Аннотации не обязательны, но возможны: <code>let age: int = 20</code>.' },
        { t: 'table', head: ['Значение', 'Тип', 'Операторы'], rows: [
          ['<code>20</code>', '<code>int</code>', '<code>+ - * mod</code>'],
          ['<code>3.14</code>', '<code>float</code>', '<code>+. -. *. /.</code>'],
          ['<code>"Аня"</code>', '<code>string</code>', 'склейка <code>^</code>'],
          ['<code>true</code>', '<code>bool</code>', '<code>&amp;&amp;</code> <code>||</code> <code>not</code>']
        ] },
        { t: 'h', html: 'Два мира чисел' },
        { t: 'p', html: 'int и float — разные типы, и у дробных свои операторы с точкой: <code>+.</code>, <code>-.</code>, <code>*.</code>, <code>./.</code>. Смешивать нельзя: <code>1 + 1.5</code> не скомпилируется — нужно <code>1.0 +. 1.5</code>. Строгость раздражает поначалу, зато никто случайно не потеряет дробную часть.' },
        { t: 'code', code: `let pi = 3.14
let half = pi /. 2.0      (* 1.57 *)` },
        { t: 'p', html: 'Дробный литерал обязан иметь точку: <code>2</code> — int, <code>2.0</code> — float. Целочисленный остаток — <code>mod</code>: <code>7 mod 2</code> даст 1. Сравнение — одиночное <code>=</code>.' },
        { t: 'note', html: 'Полезные преобразования: <code>string_of_int</code>, <code>int_of_string</code>, <code>float_of_int</code>. Строки склеиваются оператором <code>^</code>: <code>"Сумма: " ^ string_of_int 10</code> даст «Сумма: 10».' },
        { t: 'warn', html: 'Привычка из Python — делить через <code>/</code> что угодно — тут не работает: <code>/</code> только для int и делит нацело. Для дробей — <code>./.</code> и float-операнды, иначе компилятор не пропустит.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни программу: подставь целое 20, имя «Аня» (кавычки уже стоят), дробное 3.14 и логическое <code>true</code>. Типы выведутся сами.</p>',
        code: `let age = {{0}}
let name = "{{1}}"
let pi = {{2}}
let is_fun = {{3}}

let half = pi /. 2.0

let () =
  print_endline name;
  print_endline (string_of_int age);
  print_endline (string_of_float pi);
  print_endline (string_of_bool is_fun)`,
        blanks: [
          { answer: '20' },
          { answer: 'Аня' },
          { answer: '3.14' },
          { answer: 'true' }
        ]
      },
      hints: [
        'Целое без точки (20), дробное — с точкой (3.14).',
        'true/false в OCaml пишутся с маленькой буквы.',
        'Имя подставь между уже стоящими кавычками.'
      ],
      solution: ['20', 'Аня', '3.14', 'true']
    },

    /* ---------- 3. if-then-else и рекурсия ---------- */
    {
      id: 'ocaml-3',
      title: 'if-then-else и рекурсия',
      goal: 'Использовать if-then-else как выражение и писать рекурсию let rec по списку',
      xp: 35,
      theory: [
        { t: 'p', html: '<code>if ... then ... else</code> в OCaml — выражение: возвращает значение ветки, и обе ветки обязаны иметь один тип. Без <code>else</code> можно обойтись только когда результат не нужен (тогда получится unit — «ничего»).' },
        { t: 'code', code: `let classify n =
  if n mod 2 = 0 then "чётное"
  else "нечётное"` },
        { t: 'p', html: '<code>mod</code> — инфиксный остаток: <code>8 mod 2</code> равно 0. Сравнение — одиночное <code>=</code> (не <code>==</code>): <code>n mod 2 = 0</code> читается «остаток от деления n на 2 равен нулю».' },
        { t: 'h', html: 'Рекурсия: let rec' },
        { t: 'p', html: 'Рекурсивная функция объявляется с <code>let rec</code>. Список разбираем по краям: <code>[]</code> — пустой список, <code>List.hd</code> — голова (первый элемент), <code>List.tl</code> — хвост (список без головы).' },
        { t: 'code', code: `let rec sum lst =
  if lst = [] then 0
  else List.hd lst + sum (List.tl lst)` },
        { t: 'p', html: 'Шаги вычисления: sum [1; 2; 3; 4] = 1 + sum [2; 3; 4] = 1 + 2 + sum [3; 4] = ... = 1 + 2 + 3 + 4 + 0 = 10. База — пустой список: сумма ничего есть ноль. Каждый шаг откусывает голову, пока список не кончится.' },
        { t: 'warn', html: 'База обязательна: убери ветку <code>lst = []</code>, и рекурсия провалится к голове пустого списка с исключением. На следующем уровне тот же обход напишется изящнее — через match.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай программу: if-выражения и рекурсия <code>let rec</code> по списку. Что она выведет? По одной строке на каждый вывод, в порядке появления.</p>',
        code: `let rec sum lst =
  if lst = [] then 0
  else List.hd lst + sum (List.tl lst)

let classify n =
  if n mod 2 = 0 then "чётное"
  else "нечётное"

let () =
  print_endline (classify 8);
  print_endline (classify 7);
  print_int (sum [1; 2; 3; 4]);
  print_newline ()`,
        answer: `чётное
нечётное
10`
      },
      hints: [
        '8 mod 2 = 0 — какая строка вернётся? А для 7?',
        'sum [1; 2; 3; 4] откусывает голову, пока список не кончится: 1 + 2 + 3 + 4 + 0.',
        'print_int печатает число без перевода строки, print_newline добавляет перенос.'
      ],
      solution: `чётное
нечётное
10`
    },

    /* ---------- 4. Функции и match ---------- */
    {
      id: 'ocaml-4',
      title: 'Функции и match',
      goal: 'Писать match с образцами: ветки по значениям, ловушка _ и разбор списка',
      xp: 40,
      theory: [
        { t: 'p', html: '<code>match</code> — сопоставление с образцом, сердце OCaml: значение сравнивается с образцами сверху вниз, срабатывает первый подходящий. Ветки начинаются с <code>|</code>, каждая — «образец <code>-&gt;</code> результат».' },
        { t: 'code', code: `let describe n =
  match n with
  | 0 -> "ноль"
  | 1 -> "один"
  | _ -> "много"` },
        { t: 'p', html: 'Образец <code>_</code> — «что угодно»: его ветка ловит всё, что не подошло выше. Компилятор проверяет полноту: забудешь общий случай для чисел — получишь предупреждение, а в рантайме упадёшь с Match_failure.' },
        { t: 'h', html: 'Разбор списка' },
        { t: 'p', html: 'Классические образцы списка: <code>[]</code> — пустой, <code>x :: rest</code> — голова x и хвост rest. Два случая покрывают любой список — на них строится вся рекурсия по спискам:' },
        { t: 'code', code: `let rec total lst =
  match lst with
  | [] -> 0
  | x :: rest -> x + total rest` },
        { t: 'p', html: 'Функция берёт голову, складывает её с суммой хвоста, база — пустой список. Это та же сумма из прошлого уровня, только выраженная не if-ами, а таблицей случаев: пусто — ноль, иначе голова плюс рекурсия. Образцами могут быть и конкретные числа, и строки: <code>| "да" -&gt; ...</code>, а имена из образца (<code>x</code>, <code>rest</code>) внутри ветки — обычные переменные.' },
        { t: 'warn', html: 'Забыл ветку <code>| _ -&gt;</code> для непокрытых значений (например, всех чисел, кроме 0 и 1) — программа скомпилируется с предупреждением, но упадёт на непредусмотренном входе. Для открытых наборов всегда оставляй общий случай.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши функцию <code>describe</code>: она принимает число и через <code>match</code> возвращает «ноль» для 0, «один» для 1 и «много» для всего остального. В <code>let () =</code> выведи три вызова: <code>describe 0</code>, <code>describe 1</code> и <code>describe 42</code> через <code>print_endline</code>.</p>',
        starter: `(* TODO: напиши функцию describe с match и ветками *)

let () =
  print_endline "готово"`,
        rules: [
          { desc: 'Функция describe объявлена через let с параметром', all: ['let\\s+describe\\s+\\w+\\s*='] },
          { desc: 'Есть сопоставление match ... with', all: ['match\\s+\\w+\\s+with'] },
          { desc: 'Ветки по числам 0 и 1 и ловушка | _ ->', all: ['\\|\\s*0\\s*->', '\\|\\s*1\\s*->', '\\|\\s*_\\s*->'] },
          { desc: 'describe вызывается с числом и выводится через print_endline', all: ['describe\\s+\\d', 'print_endline\\s+'] },
          { desc: 'Пометок TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас: let describe n = match n with | 0 -> ... | 1 -> ... | _ -> ....',
        'Ловушка | _ -> ставится последней — она ловит все остальные числа, например 42.',
        'Вывод: print_endline (describe 42); — вызовы разделяются точкой с запятой.'
      ],
      solution: `let describe n =
  match n with
  | 0 -> "ноль"
  | 1 -> "один"
  | _ -> "много"

let () =
  print_endline (describe 0);
  print_endline (describe 1);
  print_endline (describe 42)`
    },

    /* ---------- 5. Идиомы: List-модуль и option ---------- */
    {
      id: 'ocaml-5',
      title: 'Идиомы: List-модуль и option',
      goal: 'Применять List.map/filter/fold_left и понимать тип option (Some/None)',
      xp: 40,
      theory: [
        { t: 'p', html: 'Модуль <code>List</code> — рабочая лошадка OCaml. <code>List.map</code> преобразует каждый элемент, <code>List.filter</code> оставляет подходящие, <code>List.length</code> считает, <code>List.rev</code> разворачивает. Аргумент-функция пишется лямбдой <code>fun x -&gt; ...</code>.' },
        { t: 'code', code: `List.map (fun x -> x * 10) [1; 2; 3]
(* [10; 20; 30] *)

List.filter (fun x -> x mod 2 = 0) [1; 2; 3; 4]
(* [2; 4] *)` },
        { t: 'h', html: 'fold_left — свёртка' },
        { t: 'p', html: '<code>List.fold_left f начало список</code> сворачивает список в одно значение слева направо: на каждом шаге функция получает накопленное и очередной элемент. <code>List.fold_left (+) 0 [1; 2; 3; 4]</code> — сумма: (((0 + 1) + 2) + 3) + 4 = 10. Запись <code>(+)</code> — оператор в скобках, использованный как функция.' },
        { t: 'p', html: 'Комбинируй: список → filter → map → fold — типовой конвейер обработки данных без единого цикла. Именно поэтому функциональный код такой компактный: каждая ступень маленькая, а вместе они описывают поток данных.' },
        { t: 'h', html: 'Option: Some и None' },
        { t: 'p', html: 'Функции поиска не возвращают «магическое значение не найдено» — они возвращают <code>option</code>: <code>Some x</code>, если нашли, или <code>None</code>, если нет. <code>List.find_opt (fun x -&gt; x &gt; 10) [1; 5; 8]</code> даст <code>None</code>. Достать значение из Some можно через match.' },
        { t: 'warn', html: '<code>List.hd []</code> бросает исключение Failure — голова пустого списка не существует. Для «может быть пусто» используй match с <code>[]</code> или функции вида *_opt, которые возвращают option.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что вернёт это выражение? <code>fold_left</code> сворачивает список слева направо.</p><pre>List.fold_left (+) 0 [1; 2; 3; 4]</pre>`,
        options: [
          '10',
          '24',
          '[1; 2; 3; 4]',
          '0'
        ],
        correct: 0,
        explain: 'fold_left проходит список слева направо, накапливая результат: (((0 + 1) + 2) + 3) + 4 = 10. Ноль — начальное значение аккумулятора, (+) — оператор сложения, использованный как функция.',
        solution: 0
      },
      hints: [
        'Начальное значение аккумулятора — 0, дальше каждый элемент прибавляется к накопленному.',
        'Пройдись вручную: 0+1=1, 1+2=3, 3+3=6, 6+4=10.',
        'fold_left возвращает одно значение, а не список.'
      ],
      solution: 0
    },

    /* ---------- 6. Проект: инвентарь ---------- */
    {
      id: 'ocaml-6',
      title: '🚀 Проект: инвентарь',
      goal: 'Объявить record-тип, собрать список товаров и посчитать сумму рекурсией с match',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальный проект — инвентарь на record. <b>Запись</b> (record) — тип с именованными полями: <code>type item = { name: string; price: int }</code>. Теперь у товаров есть структура, а не безымянные кортежи, и опечатка в поле невозможна — компилятор проверит.' },
        { t: 'code', code: `type item = { name: string; price: int }

let sample = { name = "Кружка"; price = 250 }` },
        { t: 'p', html: 'В объявлении типа поля с двоеточием (<code>name: string</code>), в литерале — со знаком равенства (<code>name = "Кружка"</code>). Доступ к полю — точка: <code>sample.price</code>.' },
        { t: 'h', html: 'План' },
        { t: 'list', items: [
          '<code>type item</code> с полями <code>name: string</code> и <code>price: int</code>;',
          'список <code>items</code> из 2–3 литералов записи;',
          'рекурсивная <code>total</code> через <code>let rec</code> и <code>match</code> с ветками <code>[]</code> и <code>it :: rest</code>;',
          'вывод суммы и количества (<code>List.length</code>) через <code>print_endline</code> или <code>Printf.printf</code>.'
        ] },
        { t: 'p', html: 'Печать с форматом: <code>Printf.printf "Сумма: %d\\n" (total items)</code> — <code>%d</code> для чисел, <code>\\n</code> — перенос строки. Альтернатива без форматов — склейка строк: <code>"Сумма: " ^ string_of_int (total items)</code> и <code>print_endline</code>.' },
        { t: 'note', html: 'После зачёта: добавь поле <code>qty</code> и считай <code>it.price * it.qty</code>, напиши <code>most_expensive</code> — максимум рекурсией по списку, посчитай среднюю цену через <code>float_of_int</code>.' },
        { t: 'warn', html: 'Поля в литерале записи разделяются <code>;</code>, а не запятой, и все обязательны. Определи <code>type</code> до списка литералов — компилятор должен знать тип к моменту его использования.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Инвентарь».</b> Объяви record-тип <code>item</code> с полями <code>name: string</code> и <code>price: int</code>. Создай список <code>items</code> из 2–3 товаров. Напиши рекурсивную <code>total</code> через <code>let rec</code> и <code>match</code> (база <code>[] -&gt; 0</code>, шаг <code>it :: rest -&gt; it.price + total rest</code>). Выведи количество позиций и сумму цен.</p>',
        starter: `(* TODO: объяви record-тип с полями name (string) и price (int) *)

(* TODO: создай список items и рекурсивную функцию total *)

let () =
  print_endline "Инвентарь готов"`,
        rules: [
          { desc: 'Record-тип объявлен с полями name (string) и price (int)', all: ['type\\s+\\w+\\s*=\\s*\\{', 'name\\s*:\\s*string', 'price\\s*:\\s*int'] },
          { desc: 'Список минимум из двух литералов записи', any: ['\\{\\s*name\\s*=[\\s\\S]*\\{\\s*name\\s*='] },
          { desc: 'Рекурсивная функция total объявлена через let rec', all: ['let\\s+rec\\s+total'] },
          { desc: 'match с базой [] -> 0 и шагом голова :: хвост', all: ['\\|\\s*\\[\\s*\\]\\s*->\\s*0', '\\|\\s*\\w+\\s*::\\s*\\w+'] },
          { desc: 'Поле записи используется в сумме с рекурсивным вызовом', any: ['\\.price\\s*\\+\\s*total', '\\+\\s*total\\s+[\\w(]'] },
          { desc: 'Результат выводится, пометок TODO нет', all: ['\\S'], any: ['print_endline', 'Printf\\.printf', 'print_int'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Тип: type item = { name: string; price: int } — в объявлении двоеточия.',
        'Литералы: { name = "Кружка"; price = 250 } — в литерале знак = и ; между полями.',
        'Рекурсия: let rec total lst = match lst with | [] -> 0 | it :: rest -> it.price + total rest.'
      ],
      solution: `type item = { name: string; price: int }

let items = [
  { name = "Кружка"; price = 250 };
  { name = "Блокнот"; price = 120 };
  { name = "Рюкзак"; price = 1500 }
]

let rec total lst =
  match lst with
  | [] -> 0
  | it :: rest -> it.price + total rest

let () =
  print_endline ("Позиций: " ^ string_of_int (List.length items));
  print_endline ("Сумма: " ^ string_of_int (total items))`
    },

    /* ---------- 7. Варианты и сопоставление: match с ветками ---------- */
    {
      id: 'ocaml-7',
      title: 'Варианты и match с ветками',
      goal: 'Объявлять вариантный тип с конструкторами of float и разбирать его через match по веткам',
      xp: 50,
      theory: [
        { t: 'p', html: 'До сих пор match разбирал готовые значения — числа и списки. Теперь сделаем собственный тип: <b>вариантный</b> (он же sum type) — значение одного из нескольких вариантов, и у каждого варианта свои данные. Это главная «фишка» семейства ML: данные описываются точно, а match заставляет обработать каждый случай.' },
        { t: 'code', code: `type shape =
  | Circle of float
  | Rect of float * float` },
        { t: 'p', html: 'Читаем: значение типа shape — либо <code>Circle r</code> (радиус), либо <code>Rect (w, h)</code> (две стороны). Слово <code>of</code> описывает данные варианта и живёт только в объявлении. Конструкторы пишутся <b>с большой буквы</b> — помнишь предупреждение из первого уровня: имена с большой буквы в OCaml зарезервированы именно для них. Создание — просто вызов: <code>Circle 2.0</code>, <code>Rect (3.0, 4.0)</code>.' },
        { t: 'code', code: `let area s =
  match s with
  | Circle r -> 3.14 *. r *. r
  | Rect (w, h) -> w *. h` },
        { t: 'p', html: 'Match обязан покрыть все варианты — компилятор проверяет полноту и предупреждает о забытой ветке. Добавишь в тип третий вариант — компилятор сам перечислит функции, где его не обработали. Ветка <code>Rect (w, h)</code> заодно распаковывает пару данных в имена w и h — образцы вкладываются друг в друга.' },
        { t: 'code', code: `let () =
  print_endline ("Круг: " ^ string_of_float (area (Circle 2.0)));
  print_endline ("Прямоугольник: " ^ string_of_float (area (Rect (3.0, 4.0))))` },
        { t: 'list', items: [
          '<b>type имя = | A of t | B of t * t</b> — вариантный тип;',
          '<b>Circle 2.0</b> — конструктор создаёт значение;',
          '<b>match s with | Circle r -&gt; ...</b> — разбор по веткам;',
          'полноту веток проверяет компилятор.'
        ] },
        { t: 'warn', html: 'Типичные ошибки: <code>Circle of 2.0</code> — of пишется только в объявлении; <code>circle 2.0</code> с маленькой буквы — это попытка вызвать несуществующую функцию. И не забывай float-операторы: у площадей здесь <code>*.</code>, а не <code>*</code>.' },
        { t: 'note', html: 'Варианты бывают и без данных: <code>type color = Red | Green | Blue</code> — перечисление. Match по ним не требует of вовсе. На таких простых перечислениях и больших деревьях (как в финальном проекте) построена вся идиоматика OCaml.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви вариантный тип с двумя фигурами: <code>Circle of float</code> и <code>Rect of float * float</code>. Напиши функцию <code>area</code>, которая через <code>match</code> считает площадь: круг — 3.14·r·r с float-операторами, прямоугольник — произведение сторон. Выведи оба вычисления через <code>string_of_float</code> и <code>print_endline</code>.</p>',
        starter: `(* TODO: объяви вариантный тип с Circle и Rect и функцию площади через match *)`,
        rules: [
          { desc: 'Вариантный тип объявлен: | Circle of float и | ... of float * float', all: ['\\btype\\s+\\w+\\s*=', '\\|\\s*Circle\\s+of\\s+float', '\\|\\s*\\w+\\s+of\\s+float\\s*\\*\\s*float'] },
          { desc: 'Функция area объявлена и разбирает значение через match ... with', all: ['let\\s+area\\s+\\w+\\s*=', 'match\\s+\\w+\\s+with'] },
          { desc: 'Ветки по обоим конструкторам: Circle r -> и Rect (w, h) ->', all: ['\\|\\s*Circle\\s+\\w+\\s*->', '\\|\\s*Rect\\s*\\(\\s*\\w+\\s*,\\s*\\w+\\s*\\)\\s*->'] },
          { desc: 'Используются float-операторы и string_of_float', all: ['\\*\\.', 'string_of_float'] },
          { desc: 'Обе площади вычисляются и выводятся, пометок TODO нет', all: ['area\\s*\\(\\s*Circle', 'area\\s*\\(\\s*Rect', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Тип: type shape = | Circle of float | Rect of float * float — конструкторы с большой буквы.',
        'Match: match s with | Circle r -> 3.14 *. r *. r | Rect (w, h) -> w *. h.',
        'Вызовы: area (Circle 2.0) и area (Rect (3.0, 4.0)) — скобки вокруг пары обязательны.'
      ],
      solution: `type shape =
  | Circle of float
  | Rect of float * float

let area s =
  match s with
  | Circle r -> 3.14 *. r *. r
  | Rect (w, h) -> w *. h

let () =
  print_endline ("Круг: " ^ string_of_float (area (Circle 2.0)));
  print_endline ("Прямоугольник: " ^ string_of_float (area (Rect (3.0, 4.0))))`
    },

    /* ---------- 8. Списки и рекурсия с :: и @ ---------- */
    {
      id: 'ocaml-8',
      title: 'Списки и рекурсия с :: и @',
      goal: 'Читать операторы cons и конкатенации, писать рекурсию с образцом x :: rest и склеивать списки через @',
      xp: 50,
      theory: [
        { t: 'p', html: 'Список в OCaml — односвязный: <code>[1; 2; 3]</code> на самом деле <code>1 :: 2 :: 3 :: []</code>. Оператор <code>::</code> («cons») прикрепляет один элемент к списку спереди — мгновенно, без копирования хвоста. Понимание этого оператора — ключ ко всей рекурсии по спискам.' },
        { t: 'code', code: `1 :: [2; 3]        (* [1; 2; 3] *)
1 :: 2 :: []       (* [1; 2] *)` },
        { t: 'p', html: 'В образцах <code>::</code> работает в обратную сторону — разбирает: <code>| x :: rest -&gt;</code> связывает x с головой, rest — с хвостом. Рекурсивный фильтр чётных: база <code>[] -&gt; []</code>, шаг — если голова чётная, прикрепляем её к рекурсии <code>x :: evens rest</code>, если нет — просто пропускаем.' },
        { t: 'code', code: `let rec evens lst =
  match lst with
  | [] -> []
  | x :: rest ->
      if x mod 2 = 0 then x :: evens rest
      else evens rest` },
        { t: 'p', html: 'Оператор <code>@</code> — другой: он <b>склеивает два списка целиком</b>, копируя левый. <code>[1; 2; 3] @ [100; 200]</code> даст <code>[1; 2; 3; 100; 200]</code>. Прикреплять один элемент в конец через <code>lst @ [x]</code> можно, но дорого — каждый раз копируется весь левый список; поэтому в рекурсиях копят хвост-аккумулятор, а в образцах @ не встречается вовсе.' },
        { t: 'code', code: `let joined = evens [1; 2; 3; 4; 5; 6] @ [100; 200]
(* [2; 4; 6; 100; 200] *)` },
        { t: 'list', items: [
          '<b>::</b> — элемент + список → список (быстро, спереди);',
          '<b>@</b> — список + список → список (копирует левый);',
          '<b>| x :: rest -&gt;</b> — образец: голова и хвост;',
          'база рекурсии — всегда пустой список [].'
        ] },
        { t: 'warn', html: 'Не перепутай: <code>1 @ [2; 3]</code> не скомпилируется — @ ждёт список слева; правильный вариант <code>1 :: [2; 3]</code>. И наоборот, <code>[1] :: [2; 3]</code> — ошибка типов: слева от :: должен быть элемент. Вывод типов ругнётся понятно — читай сообщение компилятора, он честно покажет, что ожидал.' },
        { t: 'note', html: 'Для больших списков рекурсию переписывают хвостово с аккумулятором: <code>aux acc lst</code> копит результат в acc, а в конце применяют <code>List.rev acc</code>. В стандартной библиотеке почти всё это уже есть: List.filter, List.append — но понимать :: и @ нужно, чтобы читать их сигнатуры.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши рекурсивный <code>evens</code>: через <code>let rec</code> и <code>match</code> с базой <code>[] -&gt; []</code> и шагом <code>x :: rest</code> оставляет только чётные числа (чётная голова прикрепляется через <code>::</code>, нечётная — пропускается). Склей результат с хвостом <code>[100; 200]</code> оператором <code>@</code> и выведи итог: элементы через <code>List.iter</code>/<code>print_int</code> и длину через <code>List.length</code>.</p>',
        starter: `(* TODO: рекурсивный фильтр чётных через :: и склейка через @ *)`,
        rules: [
          { desc: 'Рекурсивная функция объявлена через let rec', all: ['let\\s+rec\\s+\\w+'] },
          { desc: 'match с базой [] -> [] и шагом | x :: rest ->', all: ['\\|\\s*\\[\\s*\\]\\s*->', '\\|\\s*\\w+\\s*::\\s*\\w+'] },
          { desc: 'Чётная голова прикрепляется через :: (элемент + рекурсия)', all: ['\\w+\\s*::\\s*\\w+\\s+\\w+'] },
          { desc: 'Списки склеиваются оператором @', all: ['\\]\\s*@\\s*\\['] },
          { desc: 'Результат выводится, пометок TODO нет', all: ['\\S'], any: ['print_int', 'print_endline', 'print_string', 'Printf\\.printf'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Шаг: if x mod 2 = 0 then x :: evens rest else evens rest.',
        'Склейка: let joined = evens [1; 2; 3; 4; 5; 6] @ [100; 200].',
        'Вывод: List.iter (fun x -> print_int x; print_string " ") joined; затем print_newline ().'
      ],
      solution: `let rec evens lst =
  match lst with
  | [] -> []
  | x :: rest ->
      if x mod 2 = 0 then x :: evens rest
      else evens rest

let joined = evens [1; 2; 3; 4; 5; 6] @ [100; 200]

let () =
  List.iter (fun x -> print_int x; print_string " ") joined;
  print_newline ();
  print_endline ("Длина: " ^ string_of_int (List.length joined))`
    },

    /* ---------- 9. Record и immutable update ---------- */
    {
      id: 'ocaml-9',
      title: 'Record и immutable update',
      goal: 'Обновлять записи функционально: { запись with поле = значение } без изменения оригинала',
      xp: 45,
      theory: [
        { t: 'p', html: 'В проекте «Инвентарь» ты собирал record — тип с именованными полями. Важное свойство, которое там осталось за кадром: записи <b>неизменяемы</b>. Поле нельзя переприсвоить, как в объектах; «изменение» записи — это всегда новая запись, собранная из старой с заменой одного или нескольких полей.' },
        { t: 'code', code: `type player = { name: string; hp: int }

let hero = { name = "Герой"; hp = 100 }
let wounded = { hero with hp = 40 }` },
        { t: 'p', html: 'Синтаксис обновления: <code>{ старая with поле = новое }</code>. Читается «копия hero, где hp равно 40». Все остальные поля переносятся как есть, оригинал остаётся прежним — старые переменные продолжают видеть старые данные. Это называется функциональным обновлением и делает код предсказуемым: передал запись в функцию — никто её тихо не испортит.' },
        { t: 'p', html: 'Полей в with можно перечислить несколько через точку с запятой: <code>{ p with hp = 10; lvl = 2 }</code>. Вложенные записи обновляются по слоям — сначала достаёшь внутреннюю, обновляешь её, потом собираешь внешнюю: <code>{ p with addr = { p.addr with city = "Казань" } }</code>. Многословно, зато честно видно, что копируется.' },
        { t: 'code', code: `let healed = { wounded with hp = wounded.hp + 30 }
(* hero.hp = 100, wounded.hp = 40, healed.hp = 70 *)` },
        { t: 'list', items: [
          '<b>{ запись with поле = значение }</b> — новая запись поверх старой;',
          'в объявлении поля с <b>:</b>, в литерале и with — с <b>=</b>;',
          '<b>доступ к полю</b> — через точку: <code>wounded.hp</code>;',
          'оригинал при with не меняется никогда.'
        ] },
        { t: 'warn', html: 'Компилятор проверяет имена полей по типу: <code>{ hero with score = 5 }</code> не скомпилируется, если у player нет поля score. И не путай контексты: в объявлении типа — двоеточия, в литерале и with — знак равенства. Ошибка unbound record field почти всегда означает опечатку в имени поля.' },
        { t: 'note', html: 'Такой стиль — фундамент архитектур вроде Redux и Elm: состояние не мутирует, каждое изменение — новая версия. OCaml делает это дёшево: копируются только изменённые поля, остальное разделяется между версиями записи.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни боевую цепочку: подставь имя исходной записи перед <code>with</code>, само слово функционального обновления, поле, которое складывается с тридцатью, и поля для выводов через точку.</p>',
        code: `type player = { name: string; hp: int }

let hero = { name = "Герой"; hp = 100 }

(* копия с изменённым hp — оригинал не трогаем *)
let wounded = { {{1}} {{2}} hp = 40 }

let healed = { wounded with hp = wounded.{{3}} + 30 }

let () =
  print_endline (hero.{{4}} ^ ": " ^ string_of_int hero.hp);
  print_endline (wounded.name ^ ": " ^ string_of_int wounded.hp);
  print_endline (healed.name ^ ": " ^ string_of_int healed.{{5}})`,
        blanks: [
          { answer: 'hero' },
          { answer: 'with' },
          { answer: 'hp' },
          { answer: 'name' },
          { answer: 'hp' }
        ]
      },
      hints: [
        'Синтаксис: { старая with поле = значение } — сначала запись, потом with.',
        'healed копит hp: wounded.hp + 30 — поле называется hp.',
        'Имя записи достаётся полем name: hero.name, wounded.name, healed.name.'
      ],
      solution: ['hero', 'with', 'hp', 'name', 'hp']
    },

    /* ---------- 10. 🚀 Проект: стек выражений ---------- */
    {
      id: 'ocaml-10',
      title: '🚀 Проект: стек выражений',
      goal: 'Построить дерево выражений из вариантов Num/Add/Mul и вычислить его рекурсивным eval с match',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — сердце компиляторов и калькуляторов: <b>дерево выражений</b> (AST). Число — лист дерева, операции — узлы с двумя поддеревьями. Записывается это вариантным типом из ocaml-7, а вычисляется рекурсией с match — идеальная пара для структур, определённых через себя.' },
        { t: 'code', code: `type expr =
  | Num of int
  | Add of expr * expr
  | Mul of expr * expr` },
        { t: 'p', html: 'Читай: <code>expr</code> — это либо число, либо сумма двух expr, либо произведение двух expr. Тип ссылается на себя — так описываются деревья. <code>Num 5</code> — готовый лист; <code>Add (Num 2, Num 3)</code> — узел с двумя листами; поддеревья могут быть любой глубины.' },
        { t: 'code', code: `let rec eval e =
  match e with
  | Num n -> n
  | Add (a, b) -> eval a + eval b
  | Mul (a, b) -> eval a * eval b` },
        { t: 'p', html: 'Eval читается как определение арифметики: лист — само число; узел сложения — вычислить левое поддерево, вычислить правое, сложить. Рекурсия спускается вниз до листьев и собирает ответ снизу вверх. Компилятор проверяет: все три варианта покрыты — забудешь Mul, получишь предупреждение ещё до запуска.' },
        { t: 'code', code: `let tree = Add (Num 2, Mul (Num 3, Num 4))
(* 2 + (3 * 4) = 14 *)
print_endline (string_of_int (eval tree))` },
        { t: 'list', items: [
          '<b>type expr</b> — тип-дерево: Num — лист, Add/Mul — узлы;',
          '<b>eval</b> — рекурсивный обход: лист возвращает n, узел комбинирует eval a и eval b;',
          '<b>вложенные конструкторы</b> — дерево собирается как матрёшка;',
          '<b>string_of_int (eval tree)</b> — печать результата.'
        ] },
        { t: 'warn', html: 'Скобки в данных варианта обязательны: <code>Add (Num 2, Num 3)</code> — пара поддеревьев в скобках, а <code>Add Num 2</code> — ошибка: конструктор применится только к Num, и компилятор запутается. И не путай вычисление с печатью: eval возвращает int, для вывода нужен string_of_int.' },
        { t: 'note', html: 'После зачёта добавь <code>Sub</code> и <code>Div</code> (деление на ноль перехвати через guard-условие when или верни 0), функцию <code>size</code> — число узлов дерева. Каждый новый вариант компилятор потребует обработать во всех match — в этом и сила: баги не пролезают.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Стек выражений».</b> Объяви вариантный тип <code>expr</code>: <code>Num of int</code>, <code>Add of expr * expr</code>, <code>Mul of expr * expr</code>. Напиши рекурсивный <code>eval</code> через <code>match</code>: лист возвращает число, узлы вычисляют оба поддерева и складывают/умножают. Собери дерево <code>Add (Num 2, Mul (Num 3, Num 4))</code> и выведи его значение (14) и значение <code>Add (tree, Num 10)</code> (24) через <code>string_of_int</code> и <code>print_endline</code>.</p>',
        starter: `(* TODO: объяви вариантный тип expr и рекурсивный eval через match *)`,
        rules: [
          { desc: 'Тип expr объявлен: Num of int и узлы of expr * expr', all: ['\\btype\\s+expr\\s*=', '\\|\\s*Num\\s+of\\s+int', '\\|\\s*\\w+\\s+of\\s+expr\\s*\\*\\s*expr'] },
          { desc: 'eval объявлен рекурсивно', all: ['let\\s+rec\\s+eval\\s+\\w+\\s*='] },
          { desc: 'match покрывает Num и узлы, узлы вызывают eval для обоих поддеревьев', all: ['\\|\\s*Num\\s+\\w+\\s*->', '\\|\\s*\\w+\\s*\\(\\s*\\w+\\s*,\\s*\\w+\\s*\\)\\s*->', 'eval\\s+\\w+\\s*\\+\\s*eval\\s+\\w+', 'eval\\s+\\w+\\s*\\*\\s*eval\\s+\\w+'] },
          { desc: 'Дерево собрано из вложенных конструкторов', all: ['Add\\s*\\(\\s*Num', 'Mul\\s*\\(\\s*Num'] },
          { desc: 'Значения выводятся через string_of_int (eval ...), пометок TODO нет', all: ['string_of_int\\s*\\(\\s*eval', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Тип: type expr = | Num of int | Add of expr * expr | Mul of expr * expr.',
        'eval: | Num n -> n | Add (a, b) -> eval a + eval b | Mul (a, b) -> eval a * eval b.',
        'Дерево: let tree = Add (Num 2, Mul (Num 3, Num 4)); вывод: print_endline (string_of_int (eval tree)).'
      ],
      solution: `type expr =
  | Num of int
  | Add of expr * expr
  | Mul of expr * expr

let rec eval e =
  match e with
  | Num n -> n
  | Add (a, b) -> eval a + eval b
  | Mul (a, b) -> eval a * eval b

let tree = Add (Num 2, Mul (Num 3, Num 4))

let () =
  print_endline ("(2 + (3 * 4)) = " ^ string_of_int (eval tree));
  print_endline ("Если прибавить 10: " ^ string_of_int (eval (Add (tree, Num 10))))`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас и запуск',
      code: `let () =
  print_endline "Привет!"

(* запуск: ocaml main.ml *)
(* toplevel: ocaml или utop *)
(* комментарии: (* ... *) *)`
    },
    {
      title: 'let и типы',
      code: `let age = 20          (* int *)
let pi = 3.14         (* float — обязательно с точкой *)
let name = "Аня"      (* string *)
let ok = true         (* bool *)
let half = pi /. 2.0  (* float-операторы: +. -. *. /. *)
let s = "Сумма: " ^ string_of_int 10   (* склейка строк *)`
    },
    {
      title: 'Функции, if и рекурсия',
      code: `let describe n =
  if n mod 2 = 0 then "чётное"
  else "нечётное"

let rec sum lst =
  if lst = [] then 0
  else List.hd lst + sum (List.tl lst)

(* let rec — обязательно для рекурсии *)
(* if-then-else — выражение: else нужен *)`
    },
    {
      title: 'Списки и match',
      code: `let nums = [1; 2; 3]     (* ; между элементами *)
List.length nums          (* 3 *)
List.hd nums              (* 1 — голова *)
List.tl nums              (* [2; 3] — хвост *)

let rec total lst =
  match lst with
  | [] -> 0
  | x :: rest -> x + total rest`
    },
    {
      title: 'List-модуль и option',
      code: `List.map (fun x -> x * 10) [1; 2; 3]
List.filter (fun x -> x mod 2 = 0) [1; 2; 3; 4]
List.fold_left (+) 0 [1; 2; 3; 4]   (* 10 *)
List.find_opt (fun x -> x > 10) [1; 5]  (* None *)

(* Some x | None — option вместо null *)
(* (+) — оператор как функция *)`
    },
    {
      title: 'Вывод и частые ошибки',
      code: `print_endline "текст"       (* строка + перенос *)
print_int 42                (* число без переноса *)
Printf.printf "Сумма: %d\\n" (a + b)

(* ловушки:
   1 + 1.5 — нельзя: int и float не смешиваются
   /  — целочисленное деление, для float — /. 
   Имя с большой буквы — конструктор, не переменная
   List.hd [] — исключение *)`
    },
    {
      title: 'Вариантные типы и match',
      code: `type shape =
  | Circle of float
  | Rect of float * float

let area s =
  match s with
  | Circle r -> 3.14159 *. r *. r
  | Rect (w, h) -> w *. h

(* конструкторы с большой буквы: Circle 2.0 *)`
    },
    {
      title: 'Списки :: @ и record with',
      code: `1 :: [2; 3]          (* [1; 2; 3] *)
[1; 2] @ [3]         (* [1; 2; 3] — склейка *)

let rec evens lst =
  match lst with
  | [] -> []
  | x :: rest ->
      if x mod 2 = 0 then x :: evens rest
      else evens rest

let w = { hero with hp = hero.hp - 60 }  (* копия *)`
    }
  ]
};
