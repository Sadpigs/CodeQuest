'use strict';
/* ============ CodeQuest — курс PL/SQL ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.plsql = {
  id: 'plsql',
  title: 'PL/SQL',
  emoji: '🛢️',
  color: '#c94f7c',
  lang: 'plsql',
  tagline: 'Хранимые процедуры Oracle: 10 уровней',
  description: 'Процедурное расширение SQL от Oracle: триггеры, курсоры, пакеты — сердце банковских и ERP-систем. За 10 уровней: блоки DECLARE/BEGIN/END, переменные, SELECT INTO, условия, циклы, курсоры, процедуры и функции, исключения и финальный пакет.',

  levels: [

    {
      id: 'plsql-1',
      title: 'Блок DECLARE-BEGIN-END',
      goal: 'Структура анонимного блока и вывод dbms_output',
      xp: 30,
      theory: [
        { t: 'p', html: 'Программа PL/SQL — <b>блок</b>: <code>DECLARE … BEGIN … END;</code>. DECLARE — объявления переменных, BEGIN — исполняемая часть. Вывод — <code>dbms_output.put_line(...)</code>; в SQL*Plus/SQL Developer включи <code>SET SERVEROUTPUT ON</code>.' },
        { t: 'code', code: `SET SERVEROUTPUT ON

DECLARE
    v_name VARCHAR2(50) := 'Мир';
BEGIN
    dbms_output.put_line('Привет, ' || v_name || '!');
END;
/` },
        { t: 'p', html: 'Переменные объявляются <code>имя ТИП := значение</code>. Типы: <code>VARCHAR2(n)</code> — строки, <code>NUMBER(p,s)</code> — числа, <code>DATE</code> — даты, <code>BOOLEAN</code> — логика (только внутри PL/SQL!). Конкатенация — <code>||</code>. Слэш / исполняет блок из буфера.' },
        { t: 'list', items: [
          '<b>VARCHAR2(50)</b> — строка до 50 символов;',
          '<b>NUMBER(10,2)</b> — 10 цифр, 2 после точки;',
          '<b>:=</b> — присваивание (не =!);',
          '<b>||</b> — склейка строк.'
        ] },
        { t: 'note', html: 'По соглашению переменные называют v_name, константы c_, курсоры cur_ — в промышленном коде Oracle это правило благословлено стандартами кодирования.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери блок: переменная числа и вывод.</p>',
        code: `DECLARE
    v_price NUMBER {{0}} 99.9;
BEGIN
    dbms_output.{{1}}('Цена: ' || v_price);
{{2}};
/`,
        blanks: [
          { answer: ':=' },
          { answer: 'put_line' },
          { answer: 'END' }
        ],
        ci: false
      },
      hints: [
        'Присваивание при объявлении — :=.',
        'Вывод — put_line; блок закрывается END;'
      ],
      solution: [':=', 'put_line', 'END']
    },

    {
      id: 'plsql-2',
      title: 'SELECT INTO',
      goal: 'Читать данные из таблиц в переменные',
      xp: 35,
      theory: [
        { t: 'p', html: '<code>SELECT колонки INTO переменные FROM … WHERE</code> — чтение одной строки в переменные. Обязательно: запрос должен вернуть РОВНО ОДНУ строку, иначе исключение NO_DATA_FOUND (0 строк) или TOO_MANY_ROWS (&gt;1).' },
        { t: 'code', code: `DECLARE
    v_name   employees.last_name%TYPE;
    v_salary employees.salary%TYPE;
BEGIN
    SELECT last_name, salary
      INTO v_name, v_salary
      FROM employees
     WHERE employee_id = 100;

    dbms_output.put_line(v_name || ': ' || v_salary);
END;
/` },
        { t: 'p', html: '<code>%TYPE</code> — «тип как у колонки таблицы»: при изменении схемы код не сломается — профессиональная практика. Альтернатива для целых строк — <code>%ROWTYPE</code>: переменная-строка, доступ к полям через точку.' },
        { t: 'code', code: `DECLARE
    v_emp employees%ROWTYPE;
BEGIN
    SELECT * INTO v_emp FROM employees WHERE employee_id = 100;
    dbms_output.put_line(v_emp.last_name);
END;
/` },
        { t: 'note', html: 'Для строк, которых может НЕ БЫТЬ, оборачивай SELECT INTO в BEGIN-EXCEPTION или используй COUNT: SELECT COUNT(*) INTO v_cnt — count всегда вернёт строку и не бросит исключение.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Прочитай имя сотрудника id=101 в переменную v_name с %TYPE и выведи его.</p>',
        starter: `DECLARE
    TODO
BEGIN
    NULL;
END;
/`,
        rules: [
          { desc: 'Переменная с %TYPE', all: ['v_name\\s+\\w+\\.\\w+%TYPE'] },
          { desc: 'SELECT INTO', all: ['SELECT\\s+last_name\\s+INTO\\s+v_name'] },
          { desc: 'WHERE по id 101', all: ['WHERE\\s+employee_id\\s*=\\s*101'] }
        ],
        note: 'v_name employees.last_name%TYPE; / SELECT last_name INTO v_name FROM employees WHERE employee_id = 101;'
      },
      hints: [
        'Тип колонки: таблица.колонка%TYPE.',
        'Порядок: SELECT … INTO … FROM … WHERE.'
      ],
      solution: `DECLARE
    v_name employees.last_name%TYPE;
BEGIN
    SELECT last_name INTO v_name
      FROM employees
     WHERE employee_id = 101;
    dbms_output.put_line(v_name);
END;
/`
    },

    {
      id: 'plsql-3',
      title: 'IF и CASE',
      goal: 'Ветвления: IF/ELSIF и CASE-выражения',
      xp: 40,
      theory: [
        { t: 'p', html: 'Ветвление: <code>IF cond THEN … ELSIF cond THEN … ELSE … END IF;</code>. Обрати внимание ELSIF (без E!) и END IF двумя словами. CASE — выражение: возвращает значение, годится для присваиваний.' },
        { t: 'code', code: `DECLARE
    v_score NUMBER := 85;
    v_grade VARCHAR2(10);
BEGIN
    IF v_score >= 90 THEN
        v_grade := 'A';
    ELSIF v_score >= 70 THEN
        v_grade := 'B';
    ELSE
        v_grade := 'C';
    END IF;

    v_grade := CASE
                   WHEN v_score >= 90 THEN 'A'
                   WHEN v_score >= 70 THEN 'B'
                   ELSE 'C'
               END;
END;
/` },
        { t: 'p', html: 'Обе конструкции дают один результат; CASE компактнее для «выбрать значение», IF — для «выполнить действия». Логика: AND, OR, NOT; NULL-безопасность: сравнение с NULL через <code>IS NULL</code>, не равно!' },
        { t: 'note', html: 'Трёхзначная логика Oracle: NULL != NULL! Условие v_x = NULL никогда не истинно — только IS NULL / IS NOT NULL. Забытая NULL-ловушка — источник половины багов в PL/SQL.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что выведет программа?</p>',
        code: `DECLARE
    v_x NUMBER := NULL;
BEGIN
    IF v_x = NULL THEN
        dbms_output.put_line('равно');
    ELSIF v_x IS NULL THEN
        dbms_output.put_line('is null');
    ELSE
        dbms_output.put_line('иначе');
    END IF;
END;`,
        options: [
          `равно`,
          `is null`,
          `иначе`,
          `ошибка`
        ],
        correct: 1,
        explain: 'Сравнение с NULL (= NULL) всегда UNKNOWN — первая ветка не сработает. IS NULL — единственный правильный тест: вывод "is null".'
      },
      hints: [
        'Вспомни трёхзначную логику.',
        'Какой оператор проверяет NULL законно?'
      ],
      solution: `is null`
    },

    {
      id: 'plsql-4',
      title: 'Циклы',
      goal: 'Три вида циклов: FOR, WHILE, LOOP',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>FOR i IN 1..10 LOOP … END LOOP;</code> — счётный (i не объявляют!). <code>WHILE cond LOOP … END LOOP;</code> — с предусловием. <code>LOOP … EXIT WHEN cond; END LOOP;</code> — бесконечный с выходом. Обратный: <code>FOR i IN REVERSE 1..5</code>.' },
        { t: 'code', code: `BEGIN
    FOR i IN 1..5 LOOP
        dbms_output.put_line(i * i);
    END LOOP;

    FOR i IN REVERSE 1..3 LOOP
        dbms_output.put_line(i);    -- 3 2 1
    END LOOP;
END;
/` },
        { t: 'code', code: `DECLARE
    v_n NUMBER := 1;
BEGIN
    WHILE v_n < 100 LOOP
        v_n := v_n * 2;
    END LOOP;
    dbms_output.put_line(v_n);    -- 128
END;
/` },
        { t: 'note', html: 'EXIT WHEN — «выйти когда»; EXIT — немедленно. FOR-переменная локальна для цикла и не объявляется в DECLARE — частый вопрос на собеседованиях Oracle.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что выведет последний put_line? Одно число.</p>',
        code: `DECLARE
    v_total NUMBER := 0;
BEGIN
    FOR i IN 1..4 LOOP
        v_total := v_total + i * i;
    END LOOP;
    dbms_output.put_line(v_total);
END;`,
        solution: `30`,
        ci: false
      },
      hints: [
        'Складываются квадраты: 1 + 4 + 9 + 16.',
        '1²+2²+3²+4² = 30.'
      ],
      solution: `30`
    },

    {
      id: 'plsql-5',
      title: 'Курсоры',
      goal: 'Обрабатывать множества строк: явные курсоры и FOR-записи',
      xp: 50,
      theory: [
        { t: 'p', html: 'SELECT INTO берёт одну строку; для МНОЖЕСТВА строк — курсоры. Современный стиль — <code>FOR запись IN (запрос) LOOP</code>: неявный курсор, запись-переменная с полями колонок, открытие/закрытие автоматически.' },
        { t: 'code', code: `BEGIN
    FOR r IN (SELECT employee_id, last_name, salary
                FROM employees
               WHERE department_id = 20) LOOP
        dbms_output.put_line(r.last_name || ' - ' || r.salary);
    END LOOP;
END;
/` },
        { t: 'p', html: 'Явный курсор: <code>CURSOR c IS запрос;</code> в DECLARE, потом OPEN/FETCH/CLOSE — ручное управление, нужное для построчной логики с контролем. BULK COLLECT собирает всё в коллекцию одним махом — быстро на больших объёмах:' },
        { t: 'code', code: `DECLARE
    TYPE t_tab IS TABLE OF employees.last_name%TYPE;
    v_names t_tab;
BEGIN
    SELECT last_name BULK COLLECT INTO v_names
      FROM employees WHERE department_id = 20;

    FOR i IN 1..v_names.COUNT LOOP
        dbms_output.put_line(v_names(i));
    END LOOP;
END;
/` },
        { t: 'note', html: 'Правило производительности Oracle: «не тянуть построчно, что можно bulk». FOR-цикл по курсору читаем, BULK COLLECT — быстр. FORALL — обратная операция для INSERT/UPDATE пачками.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Пройди курсором сотрудников отдела 30 и выведи зарплаты через r.salary.</p>',
        starter: `BEGIN
    TODO
END;
/`,
        rules: [
          { desc: 'FOR-цикл по курсору', all: ['FOR\\s+r\\s+IN\\s*\\(\\s*SELECT'] },
          { desc: 'Фильтр отдела 30', all: ['department_id\\s*=\\s*30'] },
          { desc: 'Вывод r.salary', all: ['r\\.salary'] },
          { desc: 'END LOOP', all: ['END\\s+LOOP;'] }
        ],
        note: 'FOR r IN (SELECT salary FROM employees WHERE department_id = 30) LOOP / dbms_output.put_line(r.salary); / END LOOP;'
      },
      hints: [
        'Форма: FOR r IN (запрос) LOOP … END LOOP;',
        'Поле записи — r.salary.'
      ],
      solution: `BEGIN
    FOR r IN (SELECT salary FROM employees
               WHERE department_id = 30) LOOP
        dbms_output.put_line(r.salary);
    END LOOP;
END;
/`
    },

    {
      id: 'plsql-6',
      title: 'Процедуры и функции',
      goal: 'Создавать хранимые объекты CREATE PROCEDURE/FUNCTION',
      xp: 50,
      theory: [
        { t: 'p', html: '<code>CREATE OR REPLACE PROCEDURE имя(параметры) IS … BEGIN … END;</code> — хранимая процедура: компилируется в базе, вызывается кем угодно. Параметры: IN (вход, по умолчанию), OUT (выход), IN OUT. Функция — <code>CREATE FUNCTION … RETURN тип</code> с RETURN в теле.' },
        { t: 'code', code: `CREATE OR REPLACE PROCEDURE raise_salary(
    p_id    IN  employees.employee_id%TYPE,
    p_pct   IN  NUMBER,
    p_new   OUT NUMBER
) IS
BEGIN
    UPDATE employees
       SET salary = salary * (1 + p_pct / 100)
     WHERE employee_id = p_id;

    SELECT salary INTO p_new FROM employees
     WHERE employee_id = p_id;
END;
/` },
        { t: 'code', code: `CREATE OR REPLACE FUNCTION bonus(p_salary NUMBER)
    RETURN NUMBER IS
BEGIN
    RETURN p_salary * 0.1;
END;
/

SELECT employee_id, bonus(salary) FROM employees;` },
        { t: 'note', html: 'CREATE OR REPLACE — «пересоздай если есть», стандартный префикс итеративной разработки. Функции можно звать в SQL-запросах (если они не меняют данные — правила чистоты Oracle).' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые слова функции.</p>',
        code: `CREATE OR {{0}} FUNCTION tax(p_amt NUMBER)
    {{1}} NUMBER IS
BEGIN
    RETURN p_amt * 0.13;
{{2}};
/`,
        blanks: [
          { answer: 'REPLACE' },
          { answer: 'RETURN' },
          { answer: 'END' }
        ],
        ci: false
      },
      hints: [
        'Пересоздание — CREATE OR REPLACE.',
        'Функция обещает RETURN типа; тело закрывает END;'
      ],
      solution: ['REPLACE', 'RETURN', 'END']
    },

    {
      id: 'plsql-7',
      title: 'Исключения',
      goal: 'Обрабатывать ошибки: EXCEPTION WHEN',
      xp: 55,
      theory: [
        { t: 'p', html: 'Секция <code>EXCEPTION WHEN … THEN</code> ловит ошибки блока. Встроенные: NO_DATA_FOUND, TOO_MANY_ROWS, ZERO_DIVIDE, DUP_VAL_ON_INDEX. Свой текст: <code>RAISE_APPLICATION_ERROR(-20001, &apos;сообщение&apos;)</code>. Свой тип: <code>DECLARE e_my EXCEPTION;</code> + RAISE.' },
        { t: 'code', code: `DECLARE
    v_name employees.last_name%TYPE;
BEGIN
    SELECT last_name INTO v_name
      FROM employees WHERE employee_id = 9999;
    dbms_output.put_line(v_name);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        dbms_output.put_line('Сотрудник не найден');
    WHEN TOO_MANY_ROWS THEN
        dbms_output.put_line('Уточни фильтр!');
    WHEN OTHERS THEN
        dbms_output.put_line('Ошибка: ' || SQLERRM);
END;
/` },
        { t: 'p', html: 'OTHERS — «все прочие ошибки», последний обработчик. SQLERRM — текст ошибки, SQLCODE — номер. Деструктивный анти-паттерн — пустой WHEN OTHERS THEN NULL: ошибка исчезает бесследно; в проде за такое увольняют.' },
        { t: 'note', html: 'Исключения всплывают из вложенных блоков наверх до первого обработчика. Блок-в-блоке с собственным EXCEPTION позволяет «проглотить» конкретную ошибку и продолжить цикл — идиомы отказоустойчивых загрузок.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Какое исключение бросит SELECT INTO, если запрос вернул 3 строки?</p>',
        options: [
          `NO_DATA_FOUND`,
          `TOO_MANY_ROWS`,
          `ZERO_DIVIDE`,
          `OTHERS`
        ],
        correct: 1,
        explain: 'SELECT INTO допускает ровно одну строку: 0 строк — NO_DATA_FOUND, больше одной — TOO_MANY_ROWS.'
      },
      hints: [
        'Считай строки запроса.',
        'Название говорит само: слишком много строк.'
      ],
      solution: `TOO_MANY_ROWS`
    },

    {
      id: 'plsql-8',
      title: 'Триггеры',
      goal: 'Писать триггеры на события таблицы',
      xp: 55,
      theory: [
        { t: 'p', html: 'Триггер — код, срабатывающий на DML: <code>CREATE OR REPLACE TRIGGER имя BEFORE/AFTER INSERT/UPDATE/DELETE ON таблица FOR EACH ROW</code>. В теле доступны :NEW.поле (новые значения) и :OLD.поле (старые).' },
        { t: 'code', code: `CREATE OR REPLACE TRIGGER trg_audit_salary
    AFTER UPDATE OF salary ON employees
    FOR EACH ROW
BEGIN
    INSERT INTO salary_audit(emp_id, old_sal, new_sal, changed)
    VALUES (:OLD.employee_id, :OLD.salary, :NEW.salary, SYSDATE);
END;
/` },
        { t: 'p', html: 'Классические применения: аудит изменений, автозаполнение (BEFORE INSERT — заполнить created_date), валидация (RAISE_APPLICATION_ERROR при нарушении бизнес-правила). UPDATE OF salary — триггер только на изменение конкретной колонки.' },
        { t: 'code', code: `CREATE OR REPLACE TRIGGER trg_touch
    BEFORE INSERT ON orders
    FOR EACH ROW
BEGIN
    :NEW.created := SYSDATE;
    IF :NEW.qty <= 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Количество > 0');
    END IF;
END;
/` },
        { t: 'note', html: 'Осторожно: триггер выполняется неявно при каждой строке — тяжёлая логика в триггере тормозит весь DML. Иерархия триггеров может стать лабиринтом: современный тренд — минимальные триггеры + явная логика в процедурах.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши триггер trg_log AFTER UPDATE ON orders FOR EACH ROW, вставляющий :OLD.id в таблицу log.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'CREATE TRIGGER объявлен', all: ['CREATE\\s+OR\\s+REPLACE\\s+TRIGGER\\s+trg_log'] },
          { desc: 'AFTER UPDATE FOR EACH ROW', all: ['AFTER\\s+UPDATE\\s+ON\\s+orders\\s+FOR\\s+EACH\\s+ROW'] },
          { desc: 'Использовано :OLD', all: [':OLD\\.id'] },
          { desc: 'INSERT в log', all: ['INSERT\\s+INTO\\s+log'] }
        ],
        note: '... AFTER UPDATE ON orders FOR EACH ROW / BEGIN / INSERT INTO log(id) VALUES (:OLD.id); / END;'
      },
      hints: [
        'Событие: AFTER UPDATE ON orders FOR EACH ROW.',
        'Старое значение — :OLD.id.'
      ],
      solution: `CREATE OR REPLACE TRIGGER trg_log
    AFTER UPDATE ON orders
    FOR EACH ROW
BEGIN
    INSERT INTO log(order_id) VALUES (:OLD.id);
END;
/`
    },

    {
      id: 'plsql-9',
      title: 'Пакеты',
      goal: 'Группировать код: спецификация и тело пакета',
      xp: 55,
      theory: [
        { t: 'p', html: 'Пакет — контейнер: <b>спецификация</b> (PACKAGE — публичный интерфейс) и <b>тело</b> (PACKAGE BODY — реализация). Переменные пакета живут на время сессии — это «глобальные данные» PL/SQL. Вызов — <code>пакет.процедура</code>.' },
        { t: 'code', code: `-- спецификация:
CREATE OR REPLACE PACKAGE emp_api AS
    PROCEDURE fire(p_id employees.employee_id%TYPE);
    FUNCTION bonus(p_sal NUMBER) RETURN NUMBER;
    v_company VARCHAR2(50) := 'ACME';
END emp_api;
/

-- тело:
CREATE OR REPLACE PACKAGE BODY emp_api AS
    PROCEDURE fire(p_id employees.employee_id%TYPE) IS
    BEGIN
        DELETE FROM employees WHERE employee_id = p_id;
    END;

    FUNCTION bonus(p_sal NUMBER) RETURN NUMBER IS
    BEGIN
        RETURN p_sal * 0.1;
    END;
END emp_api;
/` },
        { t: 'p', html: 'Скрытие реализации: тело можно менять, не трогая спецификацию — зависимые объекты не перекомпилируются. Инициализационный блок пакета (в конце тела) исполняется при первом обращении за сессию — одноразовая настройка.' },
        { t: 'note', html: 'Промышленный Oracle-код живёт пакетами: emp_api, orders_api — API-слой над таблицами. Прямой доступ к таблицам из приложений запрещают — только через пакеты: так строят инкапсуляцию в мире БД.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые слова пакета.</p>',
        code: `CREATE OR REPLACE PACKAGE math_api {{0}}
    FUNCTION dbl(x NUMBER) RETURN NUMBER;
END math_api;
/

CREATE OR REPLACE PACKAGE {{1}} math_api AS
    FUNCTION dbl(x NUMBER) RETURN NUMBER IS
    BEGIN
        RETURN x * 2;
    END;
END math_api;
/`,
        blanks: [
          { answer: 'AS' },
          { answer: 'BODY' }
        ],
        ci: false
      },
      hints: [
        'Спецификация заканчивается AS.',
        'Реализация — PACKAGE BODY.'
      ],
      solution: ['AS', 'BODY']
    },

    {
      id: 'plsql-10',
      title: 'Проект: пакет учёта заказов',
      goal: 'Собрать API: процедуры, функции, исключения, аудит',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финал — пакет orders_api: размещение заказа с проверками, расчёт суммы, аудит через триггер. Композиция всех уровней курса в промышленный шаблон: так выглядят реальные модули Oracle-ERP.' },
        { t: 'code', code: `CREATE OR REPLACE PACKAGE orders_api AS
    PROCEDURE place(p_cust IN NUMBER, p_amt IN NUMBER);
    FUNCTION total(p_cust IN NUMBER) RETURN NUMBER;
END orders_api;
/

CREATE OR REPLACE PACKAGE BODY orders_api AS
    PROCEDURE place(p_cust IN NUMBER, p_amt IN NUMBER) IS
    BEGIN
        IF p_amt <= 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Сумма > 0');
        END IF;
        INSERT INTO orders(cust_id, amount, created)
        VALUES (p_cust, p_amt, SYSDATE);
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            RAISE_APPLICATION_ERROR(-20002, 'Дубль заказа');
    END;

    FUNCTION total(p_cust IN NUMBER) RETURN NUMBER IS
        v_sum NUMBER;
    BEGIN
        SELECT NVL(SUM(amount), 0) INTO v_sum
          FROM orders WHERE cust_id = p_cust;
        RETURN v_sum;
    END;
END orders_api;
/` },
        { t: 'list', items: [
          '<b>Спецификация</b> — контракт: place + total;',
          '<b>Проверки</b> — RAISE_APPLICATION_ERROR;',
          '<b>NVL</b> — NULL заменяется нулём;',
          '<b>EXCEPTION</b> — обработка дублей;',
          '<b>SYSDATE</b> — время сервера.'
        ] },
        { t: 'note', html: 'Дополни пакет процедурой cancel (UPDATE status) и триггером аудита отмен. Теперь ты понимаешь, почему банки, работающие на Oracle десятилетиями, держат штаты PL/SQL-разработчиков: ядро бизнеса живёт в таких пакетах, и заменять их некому и незачем.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые элементы пакета.</p>',
        code: `IF p_amt <= 0 THEN
    RAISE_{{0}}_ERROR(-20001, 'Сумма > 0');
END IF;

SELECT NVL({{1}}(amount), 0) INTO v_sum
  FROM orders WHERE cust_id = p_cust;`,
        blanks: [
          { answer: 'APPLICATION' },
          { answer: 'SUM' }
        ],
        ci: false
      },
      hints: [
        'Свой код ошибки — RAISE_APPLICATION_ERROR.',
        'Сумма колонки — SUM с защитой NVL.'
      ],
      solution: ['APPLICATION', 'SUM']
    }
  ]
};
