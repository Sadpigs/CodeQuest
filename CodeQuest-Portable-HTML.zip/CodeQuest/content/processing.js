'use strict';
/* ============ CodeQuest — курс Processing ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.processing = {
  id: 'processing',
  title: 'Processing',
  emoji: '🎨',
  color: '#0f9aa8',
  lang: 'processing',
  tagline: 'Код как искусство: 10 уровней',
  description: 'Язык творческого кодирования (основа p5.js): рисование, анимация, генеративное искусство. Учился он легко — и учил программированию миллионы художников. За 10 уровней: setup/draw, координаты и фигуры, мышь и клавиши, циклы, функции, классы, шум Перлина и финальный генеративный проект.',

  levels: [

    {
      id: 'processing-1',
      title: 'setup, draw и холст',
      goal: 'Структура скетча: холст и цикл кадров',
      xp: 30,
      theory: [
        { t: 'p', html: 'Программа Processing называется <b>скетч</b>. Две обязательные функции: <code>setup()</code> — выполняется один раз при старте, <code>draw()</code> — крутится непрерывно (~60 раз в секунду). <code>size(w, h)</code> задаёт холст, <code>background(цвет)</code> — заливка фона.' },
        { t: 'code', code: `void setup() {
  size(800, 600);
}

void draw() {
  background(30);          // тёмный фон каждый кадр
  ellipse(400, 300, 100, 100);   // круг в центре
}` },
        { t: 'p', html: 'Каждый кадр: draw() стирает фон и рисует заново — «кинематографическая» модель. Убери background — и кадры будут НАКЛАДЫВАТЬСЯ: след шара, кисть. Это не баг, а главный приём генеративной графики.' },
        { t: 'list', items: [
          '<b>size(w, h)</b> — размер холста (в setup);',
          '<b>background(gray)</b> — 0 чёрный … 255 белый;',
          '<b>draw()</b> — ~60 кадров/с;',
          'без background — эффект «следа».'
        ] },
        { t: 'note', html: 'Процессинг-сообщество называет программы скетчами как художники — набросками. Идея Кейси Реаса и Бена Фрая (MIT): код — материал творчества.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери скелет скетча: холст 400×400 и фон каждый кадр.</p>',
        code: `void {{0}}() {
  size(400, 400);
}

void draw() {
  {{1}}(30);
}`,
        blanks: [
          { answer: 'setup' },
          { answer: 'background' }
        ],
        ci: false
      },
      hints: [
        'Одноразовая инициализация — setup().',
        'Заливка фона — background().'
      ],
      solution: ['setup', 'background']
    },

    {
      id: 'processing-2',
      title: 'Фигуры и координаты',
      goal: 'Рисовать примитивы: ellipse, rect, line, точка и система координат',
      xp: 35,
      theory: [
        { t: 'p', html: 'Начало координат — ЛЕВЫЙ ВЕРХНИЙ угол, y растёт ВНИЗ. <code>ellipse(x, y, ширина, высота)</code> — эллипс (центр), <code>rect(x, y, w, h)</code> — прямоугольник (левый верх!), <code>line(x1, y1, x2, y2)</code>, <code>point(x, y)</code>.' },
        { t: 'code', code: `void setup() {
  size(400, 300);
}

void draw() {
  background(255);
  fill(220, 90, 60);           // цвет заливки R,G,B
  noStroke();                  // без обводки
  ellipse(200, 150, 120, 120);

  fill(60, 120, 220);
  rect(50, 50, 80, 60);

  stroke(0);
  line(0, 0, 400, 300);
}` },
        { t: 'p', html: 'Стиль: <code>fill(r, g, b)</code> — заливка, <code>stroke(...)</code> — обводка, <code>strokeWeight(n)</code> — толщина, <code>noFill()/noStroke()</code> — отключение. Настройки действуют на ВСЕ последующие фигуры — задавай перед каждой.' },
        { t: 'list', items: [
          '<b>ellipse</b> — центр + размеры;',
          '<b>rect</b> — угол + размеры;',
          '<b>fill/stroke/noStroke</b> — стиль;',
          'y растёт вниз — не путай с математикой!'
        ] },
        { t: 'note', html: 'ellipseMode(CENTER) / rectMode(CENTER) меняют трактовку координат: некоторые художники ставят rectMode(CENTER) для симметричной логики.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Нарисуй красный (220,40,40) круг в центре холста 400×400 без обводки.</p>',
        starter: `void setup() {
  size(400, 400);
}

void draw() {
  TODO
}`,
        rules: [
          { desc: 'noStroke вызван', all: ['noStroke\\s*\\(\\s*\\)\\s*;'] },
          { desc: 'fill красный', all: ['fill\\s*\\(\\s*220\\s*,\\s*40\\s*,\\s*40\\s*\\)\\s*;'] },
          { desc: 'ellipse в центре', all: ['ellipse\\s*\\(\\s*200\\s*,\\s*200\\s*,\\s*\\d+\\s*,\\s*\\d+\\s*\\)\\s*;'] }
        ],
        note: 'noStroke(); / fill(220, 40, 40); / ellipse(200, 200, 100, 100);'
      },
      hints: [
        'Центр 400×400 — точка (200, 200).',
        'Сначала стиль (noStroke, fill), затем фигура.'
      ],
      solution: `void setup() {
  size(400, 400);
}

void draw() {
  background(255);
  noStroke();
  fill(220, 40, 40);
  ellipse(200, 200, 100, 100);
}`
    },

    {
      id: 'processing-3',
      title: 'Переменные и движение',
      goal: 'Анимировать: изменение переменных между кадрами',
      xp: 40,
      theory: [
        { t: 'p', html: 'Глобальные переменные объявляются ВНЕ функций и живут между кадрами. Изменяя их в draw(), анимируем: x += скорость — шар полетит вправо. Отражение от стены — if + смена знака скорости.' },
        { t: 'code', code: `float x = 0;
float speed = 3;

void setup() {
  size(400, 300);
}

void draw() {
  background(20);
  fill(255, 200, 0);
  ellipse(x, 150, 40, 40);

  x += speed;
  if (x > width || x < 0) {
    speed = -speed;      // отражение
  }
}` },
        { t: 'p', html: 'width и height — размер холста (после size()). Скорость — «сколько пикселей за кадр»; умножив на frameRate-множители, получают независимость от FPS. Классическая анимация = позиция + скорость + границы.' },
        { t: 'note', html: 'Приём «стирание полупрозрачным» вместо background: fill(20, 15); rect(0, 0, width, height); — даёт шлейфы-хвосты. Любимый эффект генеративщиков.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Сколько кадров пройдёт, прежде чем шар с x=0 и speed=4 выйдет за width=200? Одно число.</p>',
        code: `float x = 0, speed = 4;
// width = 200
// шар «выйдет», когда x превысит 200`,
        solution: `50`,
        ci: false
      },
      hints: [
        'Каждый кадр x растёт на 4.',
        '200 / 4 = 50.'
      ],
      solution: `50`
    },

    {
      id: 'processing-4',
      title: 'Мышь и клавиши',
      goal: 'Интерактив: mouseX/mouseY и keyPressed',
      xp: 45,
      theory: [
        { t: 'p', html: 'Системные переменные: <code>mouseX, mouseY</code> — позиция мыши, <code>pmouseX</code> — прошлокадровая (для линий-кистей!). События: <code>void mousePressed()</code>, <code>void keyPressed()</code> — вызываются разово; внутри проверяют <code>key</code> или <code>keyCode</code>.' },
        { t: 'code', code: `void draw() {
  background(255);
  stroke(0);
  strokeWeight(3);
  line(pmouseX, pmouseY, mouseX, mouseY);   // кисть
}

void mousePressed() {
  fill(random(255), random(255), random(255));
}

void keyPressed() {
  if (key == 'c') background(255);      // очистка
  if (keyCode == UP) strokeWeight(strokeWeight + 1);
}` },
        { t: 'p', html: 'Линия от pmouse к mouse каждый кадр — рисование мышью в 4 строки. keyPressed читает key (символы) и keyCode (стрелки, спецклавиши). random(n) — случайное число 0..n — цветовые всплески на клик.' },
        { t: 'list', items: [
          '<b>mouseX/Y</b> — текущие координаты мыши;',
          '<b>pmouseX/Y</b> — предыдущего кадра;',
          '<b>key</b> — нажатый символ, <b>keyCode</b> — код клавиши;',
          'события — отдельные функции, не if внутри draw.'
        ] },
        { t: 'note', html: 'mousePressed — и переменная (true пока зажата), и функция-событие. В draw можно непрерывно проверять if (mousePressed), в mousePressed() — реагировать на сам клик.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери кисть: линия от прошлой позиции мыши к текущей.</p>',
        code: `void draw() {
  line({{0}}, {{1}}, mouseX, mouseY);
}`,
        blanks: [
          { answer: 'pmouseX' },
          { answer: 'pmouseY' }
        ],
        ci: false
      },
      hints: [
        'Прошлокадровые координаты — с префиксом p.',
        'line(прошлыйX, прошлыйY, текущийX, текущийY).'
      ],
      solution: ['pmouseX', 'pmouseY']
    },

    {
      id: 'processing-5',
      title: 'Циклы и паттерны',
      goal: 'Рисовать сетки и узлы for-циклами',
      xp: 45,
      theory: [
        { t: 'p', html: 'Вложенные for — сетка: внешний цикл по строкам (y), внутренний по столбцам (x). На каждом пересечении — фигура, чей размер/цвет зависит от координат:Patterns arise из формул. randomSeed фиксирует случайность для стабильного паттерна.' },
        { t: 'code', code: `void setup() {
  size(400, 400);
  noLoop();                  // один кадр достаточно
}

void draw() {
  background(245);
  int step = 40;

  for (int y = step/2; y < height; y += step) {
    for (int x = step/2; x < width; x += step) {
      float d = dist(x, y, 200, 200);     // расстояние до центра
      float r = map(d, 0, 300, 25, 4);    // размер убывает
      ellipse(x, y, r, r);
    }
  }
}` },
        { t: 'p', html: '<code>dist(x1, y1, x2, y2)</code> — расстояние, <code>map(v, a1, a2, b1, b2)</code> — перевод диапазона в диапазон. Дуэт dist+map — главный инструмент реагирующих паттернов: размер, цвет, поворот от позиции. <code>noLoop()</code> — статичная картинка, draw один раз.' },
        { t: 'list', items: [
          '<b>вложенный for</b> — сетка элементов;',
          '<b>dist</b> — радиальная зависимость;',
          '<b>map</b> — перекалибровка значений;',
          '<b>noLoop()</b> — стоп анимации.'
        ] },
        { t: 'note', html: 'Замени ellipse на повёрнутые rect (pushMatrix/rotate) или линии — получишь шедевры в стиле 10 PRINT. Генеративное искусство — это математика формул + вкус перебора параметров.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери сетку: вложенный for с шагом 50 по ширине и высоте.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Внешний цикл по y', all: ['for\\s*\\(\\s*int\\s+y\\s*=\\s*\\d+\\s*;\\s*y\\s*<\\s*height\\s*;\\s*y\\s*\\+=\\s*50\\s*\\)'] },
          { desc: 'Внутренний по x', all: ['for\\s*\\(\\s*int\\s+x\\s*=\\s*\\d+\\s*;\\s*x\\s*<\\s*width\\s*;\\s*x\\s*\\+=\\s*50\\s*\\)'] }
        ],
        note: 'for (int y = 25; y < height; y += 50) { / for (int x = 25; x < width; x += 50) { ... } }'
      },
      hints: [
        'Сначала строки (y), внутри — столбцы (x).',
        'Шаг — += 50.'
      ],
      solution: `for (int y = 25; y < height; y += 50) {
  for (int x = 25; x < width; x += 50) {
    ellipse(x, y, 10, 10);
  }
}`
    },

    {
      id: 'processing-6',
      title: 'Функции',
      goal: 'Свои функции рисования с параметрами',
      xp: 50,
      theory: [
        { t: 'p', html: 'Свои функции структурируют скетч: <code>void drawStar(float x, float y, float size)</code> — многократно используемый элемент. Возврат значений — <code>float / тип</code> вместо void. Функции + параметры = библиотека собственных фигур.' },
        { t: 'code', code: `void setup() { size(400, 400); }

void draw() {
  background(20);
  drawFlower(200, 200, 60, color(220, 80, 120));
  drawFlower(100, 300, 30, color(80, 180, 220));
}

void drawFlower(float x, float y, float r, color c) {
  fill(c);
  noStroke();
  for (int i = 0; i < 6; i++) {
    float a = TWO_PI * i / 6;
    ellipse(x + cos(a) * r, y + sin(a) * r, r, r);
  }
  fill(255);
  ellipse(x, y, r, r);   // серединка
}` },
        { t: 'p', html: 'Тригонометрия: <code>cos/sin(угол) * радиус</code> — позиции по окружности, TWO_PI — полный круг. Шесть эллипсов вокруг центра — цветок. Параметризация (x, y, размер, цвет) делает функцию универсальной.' },
        { t: 'note', html: 'Возврат значений тоже живёт в графике: функция angleTo(x, y) возвращает atan2(y − cy, x − cx) — поворот к цели. Пригодится в играх и агентах.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери позицию на окружности через косинус и синус.</p>',
        code: `float px = x + {{0}}(a) * r;
float py = y + {{1}}(a) * r;`,
        blanks: [
          { answer: 'cos' },
          { answer: 'sin' }
        ],
        ci: false
      },
      hints: [
        'Горизонтальная координата — cos.',
        'Вертикальная — sin.'
      ],
      solution: ['cos', 'sin']
    },

    {
      id: 'processing-7',
      title: 'Классы',
      goal: 'Объекты-частицы: класс, поля, конструктор, методы',
      xp: 50,
      theory: [
        { t: 'p', html: 'Класс — чертёж: поля (данные), конструктор <code>Имя(параметры)</code>, методы <code>update()/display()</code>. Список объектов — <code>ArrayList&lt;Particle&gt;</code>: добавление add, обход for-each. Так строятся системы частиц — душа генеративного искусства.' },
        { t: 'code', code: `ArrayList<Particle> particles = new ArrayList<Particle>();

void setup() { size(400, 400); }

void draw() {
  background(20);
  particles.add(new Particle(200, 50));

  for (Particle p : particles) {
    p.update();
    p.display();
  }
}

class Particle {
  float x, y, vy;
  Particle(float x0, float y0) {
    x = x0; y = y0; vy = random(1, 3);
  }
  void update() {
    y += vy;
  }
  void display() {
    fill(255);
    ellipse(x, y, 8, 8);
  }
}` },
        { t: 'p', html: 'Каждый кадр рождается частица сверху и падает. Расширение: gravity в update, lifespan с fade (alpha), удаление отработанных <code>particles.remove(i)</code> в обратном цикле. Тысячи частиц — снег, искры, конфетти.' },
        { t: 'note', html: 'Идиома Particle system — тот же паттерн, что в игровых движках: data (поля) + behavior (update) + render (display). Освоил один класс — освоил архитектуру эффектов.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Добавь новый объект Particle в список particles каждый кадр.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'add с new Particle', all: ['particles\\.add\\s*\\(\\s*new\\s+Particle\\s*\\('] }
        ],
        note: 'particles.add(new Particle(200, 50));'
      },
      hints: [
        'Добавление в ArrayList — метод add.',
        'Создание объекта — new Particle(...).'
      ],
      solution: `particles.add(new Particle(200, 50));`
    },

    {
      id: 'processing-8',
      title: 'Шум Перлина',
      goal: 'Органическая случайность noise()',
      xp: 55,
      theory: [
        { t: 'p', html: '<code>noise(x)</code> — шум Перлина: плавная псевдослучайность (в отличие от random, значения соседних точек близки). Диапазон 0..1. Одно измерение — колебания, два — «карта высот», три — облака во времени: <code>noise(x, y, t)</code>.' },
        { t: 'code', code: `float t = 0;

void draw() {
  background(245);
  noFill();
  stroke(30);
  beginShape();
  for (int x = 0; x <= width; x += 5) {
    float y = noise(x * 0.01, t) * height;   // волна
    vertex(x, y);
  }
  endShape();
  t += 0.02;      // время шума
}` },
        { t: 'p', html: 'Масштаб входа важен: noise(1) скачет, noise(0.01·x) плывёт — правило «медленный вход — плавный выход». <code>beginShape/vertex/endShape</code> — произвольные кривые. noiseDetail(октавы) добавляет деталировку.' },
        { t: 'list', items: [
          '<b>noise()</b> — плавный 0..1;',
          'масштаб 0.005–0.05 — «природная» скорость;',
          '3-й аргумент — время: анимированные поля;',
          '<b>map(noise(...), 0, 1, min, max)</b> — привести к делу.'
        ] },
        { t: 'note', html: 'Шум Перлина придумал Кен Перлин для фильма Tron (1986) — получил Оскар за технические достижения. Сегодня noise() — в каждом генераторе ландшафтов, облаков и текстур, включая Minecraft.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Подключи шум: медленный вход и время третьим измерением.</p>',
        code: `float y = {{0}}(x * 0.01, t);
t {{1}}= 0.02;`,
        blanks: [
          { answer: 'noise' },
          { answer: '+' }
        ],
        ci: false
      },
      hints: [
        'Плавная случайность — noise().',
        'Время течёт вперёд: t += …'
      ],
      solution: ['noise', '+']
    },

    {
      id: 'processing-9',
      title: 'Трансформации',
      goal: 'pushMatrix, translate, rotate — рисовать в системе объекта',
      xp: 55,
      theory: [
        { t: 'p', html: 'Трансформации: <code>translate(x, y)</code> — перенести начало координат, <code>rotate(a)</code> — повернуть мир, <code>scale(s)</code> — масштаб. <code>pushMatrix()</code> сохраняет состояние, <code>popMatrix()</code> восстанавливает — вложенные системы координат.' },
        { t: 'code', code: `void setup() { size(400, 400); }

void draw() {
  background(20);
  translate(width/2, height/2);     // центр — новый origin
  rotate(frameCount * 0.01);        // вращение со временем

  fill(255, 120, 60);
  rect(-50, -50, 100, 100);         // рисуется ВОКРУГ центра

  pushMatrix();                     // вложенная система
    translate(120, 0);              // спутник
    rotate(frameCount * 0.05);
    fill(80, 180, 255);
    rect(-15, -15, 30, 30);
  popMatrix();
}` },
        { t: 'p', html: 'Порядок трансформаций важен: translate → rotate вращает объект НА МЕСТЕ, rotate → translate крутит орбиту. frameCount — номер кадра со старта: встроенный таймер анимации. Вложенные push/pop — ветвящиеся структуры (фрактальные деревья).' },
        { t: 'note', html: 'Три трансформации — вся математика сцен: спрайты, камеры, иерархии. Понимание матричных стеков здесь переносится в любой движок: three.js, Unity, Godot используют ту же модель.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь парные трансформации: сохранить и восстановить.</p>',
        code: `{{0}}();
translate(120, 0);
rotate(a);
rect(-15, -15, 30, 30);
{{1}}();`,
        blanks: [
          { answer: 'pushMatrix' },
          { answer: 'popMatrix' }
        ],
        ci: false
      },
      hints: [
        'Сохранение стека — pushMatrix().',
        'Восстановление — popMatrix().'
      ],
      solution: ['pushMatrix', 'popMatrix']
    },

    {
      id: 'processing-10',
      title: 'Проект: генеративная галерея',
      goal: 'Собрать авторский арт: шум, частицы, интерактив, экспорт',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финал — авторский генератор: поле шума Перлина управляет тысячами линий-«травинок», мышь искажает поле, клик пересеивает зерно, клавиша S сохраняет PNG. Композиция всех приёмов курса в один арт-инструмент.' },
        { t: 'code', code: `void setup() {
  size(800, 600);
  background(250);
  randomSeed(second());      // зерно от часов
  noLoop();
}

void draw() {
  strokeWeight(1);
  for (int i = 0; i < 900; i++) {
    float x = random(width);
    float y0 = height;

    // стебель: подъём по шуму
    beginShape();
    for (int s = 0; s < 20; s++) {
      float yy = y0 - s * 8;
      float bend = noise(x * 0.005, s * 0.1) * 60 - 30;
      vertex(x + bend + (mouseX - width/2) * 0.05 * s / 20, yy);
    }
    endShape();
  }
}

void mousePressed() { draw(); }          // пересеять
void keyPressed() {
  if (key == 's') save("art-" + millis() + ".png");
}` },
        { t: 'list', items: [
          '<b>noLoop + redraw по клику</b> — статичная композиция;',
          '<b>noise-изгиб</b> — органичность каждого стебля;',
          '<b>влияние mouseX</b> — интерактивное поле ветра;',
          '<b>save()</b> — экспорт арт-работы в PNG;'
        ] },
        { t: 'note', html: 'Доработай палитру (цвет от noise), добавь second-слой тумана полупрозрачными rect и режим анимации через loop(). Опубликуй работы в сообществе OpenProcessing — там миллионы скетчей, и твой следующий шаг — p5.js, веб-версия Processing, где код живёт в браузере. Из художника-зрителя ты стал художником-программистом.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь элементы арт-скетча: зерно от часов и экспорт PNG.</p>',
        code: `randomSeed({{0}}());
...
if (key == 's') {{1}}("art.png");`,
        blanks: [
          { answer: 'second' },
          { answer: 'save' }
        ],
        ci: false
      },
      hints: [
        'Секунды часов — функция second().',
        'Сохранение изображения — save(имя).'
      ],
      solution: ['second', 'save']
    }
  ]
};
