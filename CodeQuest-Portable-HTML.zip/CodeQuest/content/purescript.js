'use strict';
/* ============ CodeQuest — курс PureScript ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.purescript = {
  id: 'purescript',
  title: 'PureScript',
  emoji: '🧘',
  color: '#83599f',
  lang: 'purescript',
  tagline: 'Haskell для веба: 10 уровней',
  description: 'Строгий функциональный язык, компилирующийся в JavaScript: типы как в Haskell, вывод — чистый JS. За 10 уровней: выражения и функции, типы, pattern matching, Maybe и Either, рекурсия, типоклассы, records, Effect и финальный модуль.',

  levels: [

    {
      id: 'purescript-1',
      title: 'Выражения и функции',
      goal: 'Писать чистые функции: оператор -> и каррирование',
      xp: 30,
      theory: [
        { t: 'p', html: 'PureScript — функциональный язык: всё выражения, функции чистые (одни аргументы — всегда один результат). Сигнатура через <code>::</code>, стрелки <code>-&gt;</code> показывают каррирование: функция многих аргументов — функция одного аргумента, возвращающая функцию.' },
        { t: 'code', code: `add :: Int -> Int -> Int
add a b = a + b

-- add 2 3  ==  5
-- частичное применение:
add5 :: Int -> Int
add5 = add 5` },
        { t: 'p', html: 'Тело функции — после <code>=</code>. Вызов — без скобок: <code>add 2 3</code>. Комментарии — <code>--</code>. Все значения иммутабельны: «изменить» значение нельзя, только вычислить новое. Это даёт предсказуемость: функция не зависит от скрытого состояния.' },
        { t: 'list', items: [
          '<b>::</b> — «имеет тип»;',
          '<b>Int</b> — целые, <b>Number</b> — дробные, <b>String</b> — текст;',
          '<b>-&gt;</b> — тип функции, читается справа налево;'
        ] },
        { t: 'note', html: 'Частичное применение — суперсила каррирования: add 5 уже функция. Конвейеры строятся из «недоделанных» функций без лямбда-обёрток.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь пропуски в сигнатуру и определение.</p>',
        code: `mul :: {{0}} -> Int -> Int
mul a b = a {{1}} b`,
        blanks: [
          { answer: 'Int' },
          { answer: '*' }
        ],
        ci: false
      },
      hints: [
        'Тип целых чисел — Int.',
        'Умножение — *.'
      ],
      solution: ['Int', '*']
    },

    {
      id: 'purescript-2',
      title: 'let и where',
      goal: 'Вводить локальные определения двумя способами',
      xp: 35,
      theory: [
        { t: 'p', html: 'Локальные вспомогательные значения — <code>let … in выражение</code> (перед телом) или секция <code>where</code> (после тела). Стиль выбирается по читаемости: let — «сначала заготовим», where — «определения после факта».' },
        { t: 'code', code: `hypot :: Number -> Number -> Number
hypot a b = sqrt (sq a + sq b)
  where
    sq x = x * x

-- то же через let:
hypot2 :: Number -> Number -> Number
hypot2 a b =
  let a2 = a * a
      b2 = b * b
  in sqrt (a2 + b2)` },
        { t: 'p', html: 'Чистота функций означает: сколько бы раз ни вызывалась hypot 3 4, результат одинаков — компилятор может кешировать и оптимизировать смело. Where-определения видны только в своей функции — инкапсуляция деталей.' },
        { t: 'note', html: 'Отступы в PureScript значимы, как в Python: тело where сдвигается вправо. Компилятор psc настроен строго — он ошибётся на неаккуратных отступах раньше, чем ты.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши функцию area с where-помощником double (удвоение): area r = double (r * r).</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Сигнатура функции', all: ['\\w+\\s*::\\s*Number\\s*->\\s*Number'] },
          { desc: 'Определение через double', all: ['=\\s*double\\s*\\(\\s*\\w+\\s*\\*\\s*\\w+\\s*\\)'] },
          { desc: 'where с double', all: ['where', '\\s+double\\s+\\w+\\s*=\\s*\\w+\\s*\\*\\s*\\w+'] }
        ],
        note: 'area r = double (r * r) where double x = x * x'
      },
      hints: [
        'Сначала сигнатура с ::.',
        'where-определение идёт после тела с отступом.'
      ],
      solution: `area :: Number -> Number
area r = double (r * r)
  where
    double x = x * x`
    },

    {
      id: 'purescript-3',
      title: 'Свои типы данных',
      goal: 'Объявлять алгебраические типы data и разбирать их match-ем',
      xp: 40,
      theory: [
        { t: 'p', html: 'Свои типы объявляются <code>data Тип = Конструктор1 | Конструктор2</code>. Каждый вариант-конструктор может нести поля: <code>data Shape = Circle Number | Rect Number Number</code>. Разбор вариантов — <b>pattern matching</b> в case-выражении.' },
        { t: 'code', code: `data Shape = Circle Number | Rect Number Number

area :: Shape -> Number
area shape = case shape of
  Circle r    -> 3.14159 * r * r
  Rect w h    -> w * h

-- area (Circle 2.0)  == 12.56636
-- area (Rect 3.0 4.0) == 12.0` },
        { t: 'p', html: 'case … of перечисляет образцы; пропущенные поля связываются с именами (r, w, h). Неисчерпывающий match — ошибка компиляции: PureScript требует покрыть ВСЕ варианты — целый класс багов исчезает.' },
        { t: 'note', html: 'Такие типы называют <b>sum types</b> (сумма вариантов) — та же идея, что enum с данными в Rust и discriminated union в TypeScript. Освоив их здесь, ты поймёшь современные системы типов.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что вернёт выражение?</p>',
        code: `data Color = Red | Green | Blue

code :: Color -> Int
code c = case c of
  Red   -> 1
  Green -> 2
  Blue  -> 3

main = code Green`,
        options: [
          `1`,
          `2`,
          `3`,
          `ошибка компиляции`
        ],
        correct: 1,
        explain: 'Образец Green связался со второй веткой — результат 2. Все три варианта покрыты, компиляция проходит.'
      },
      hints: [
        'Ищи ветку case, совпадающую с аргументом.',
        'Green — второй конструктор.'
      ],
      solution: `2`
    },

    {
      id: 'purescript-4',
      title: 'Maybe: безопасное отсутствие',
      goal: 'Моделировать «нет значения» через Maybe и убирать вложенность',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>Maybe a = Nothing | Just a</code> — вместо null. Функция честно заявляет в типе, что результата может не быть: <code>head :: Array a -&gt; Maybe a</code>. Забыть проверить Nothing невозможно — тип не даст.' },
        { t: 'code', code: `import Data.Maybe (Maybe(..), fromMaybe)

safeDiv :: Int -> Int -> Maybe Int
safeDiv _ 0 = Nothing
safeDiv a b = Just (a / b)

-- явная обработка
show :: Int -> Int -> String
show a b = case safeDiv a b of
  Nothing -> "делить нельзя"
  Just v  -> "итог: " <> show v

-- или значение по умолчанию:
fallback = fromMaybe 0 (safeDiv 10 0)   -- 0` },
        { t: 'p', html: 'Оператор <code>&lt;&gt;</code> — конкатенация строк. <code>fromMaybe</code> разворачивает Maybe со значением по умолчанию. Цепочки Maybe обрабатываются через bind <code>&gt;&gt;=</code> — «если предыдущий шаг дал Just, передай значение дальше».' },
        { t: 'note', html: 'Мир без null reference errors — заслуга Maybe. Тот же приём: Option в Rust, Optional в Java, None в Python-типизации. PureScript — самое чистое воплощение.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши safeHead: возвращает Nothing для пустого массива и Just первого элемента иначе.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Сигнатура с Maybe', all: ['Maybe\\s+\\w+'] },
          { desc: 'Ветка пустого массива → Nothing', all: ['\\[\\]\\s*=\\s*Nothing'] },
          { desc: 'Ветка Just с головой', all: ['Just\\s+\\(\\s*\\w+\\s+\\w+\\s*\\)|Just\\s+\\w+\\s+\\w+'] }
        ],
        note: 'safeHead [] = Nothing; safeHead (x : xs) = Just x'
      },
      hints: [
        'Два образца: [] и (x : xs).',
        'Список-пары: (x : xs) разбирает голову и хвост.'
      ],
      solution: `safeHead :: Array Int -> Maybe Int
safeHead [] = Nothing
safeHead (x : xs) = Just x`
    },

    {
      id: 'purescript-5',
      title: 'Рекурсия списков',
      goal: 'Обрабатывать списки через образцы (x : xs) и аккумулировать',
      xp: 45,
      theory: [
        { t: 'p', html: 'Список — либо <code>[]</code>, либо голова с хвостом <code>(x : xs)</code>. Рекурсия с образцами заменяет циклы: сумма списка — база на [], шаг cons-разбором. Анонимный параметр <code>_</code> — «не важно».' },
        { t: 'code', code: `sum :: Array Int -> Int
sum [] = 0
sum (x : xs) = x + sum xs

-- хвостовая версия с аккумулятором
sumAcc :: Array Int -> Int -> Int
sumAcc [] acc = acc
sumAcc (x : xs) acc = sumAcc xs (acc + x)` },
        { t: 'p', html: 'В хвостовой версии вызов последний — PureScript компилирует её в JS-цикл без роста стека. Комбинаторы библиотеки Prelude — map, filter, foldl — делают то же без ручной рекурсии:' },
        { t: 'code', code: `import Data.Foldable (foldl)
import Data.Array (filter)

evens = filter (_ \`mod\` 2 == 0) [1,2,3,4]   -- [2,4]
total = foldl (+) 0 evens                    -- 6` },
        { t: 'note', html: 'Плейсхолдер <code>_</code> в (_ `mod` 2 == 0) — аргумент, который заполнится позже. Инфиксные функции в апострофах (обратных): x `mod` 2 — вызов mod как оператора.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что вернёт функция? Одно число.</p>',
        code: `count :: Array Int -> Int
count [] = 0
count (_ : xs) = 1 + count xs

count [5, 6, 7, 8, 9]`,
        solution: `5`,
        ci: false
      },
      hints: [
        'Каждый элемент добавляет единицу.',
        'Элементов пять — неважно какие.'
      ],
      solution: `5`
    },

    {
      id: 'purescript-6',
      title: 'Типоклассы',
      goal: 'Обобщать функции через class и instance',
      xp: 50,
      theory: [
        { t: 'p', html: '<b>Типокласс</b> — контракт для типов: <code>class Eq a where eq :: a -&gt; a -&gt; Boolean</code> обещает сравнение. Типы подписываются через <code>instance</code>. Функции пишут ограничения в сигнатуре: <code>equals3 :: forall a. Eq a =&gt; a -&gt; a -&gt; a -&gt; Boolean</code> — «для любого a, умеющего Eq».' },
        { t: 'code', code: `class Describe a where
  describe :: a -> String

instance describeInt :: Describe Int where
  describe _ = "число"

instance describeString :: Describe String where
  describe _ = "строка"

f :: forall a. Describe a => a -> String
f x = describe x

-- f 5     == "число"
-- f "x"   == "строка"` },
        { t: 'p', html: 'Стандартные классы Prelude: <code>Eq</code> сравнение, <code>Ord</code> порядок, <code>Show</code> — текстовое представление, <code>Semigroup</code> — склейка (&lt;&gt;), <code>Functor</code> — map над контейнером. Это полиморфизм «подключи контракт» без наследования.' },
        { t: 'note', html: 'Типоклассы — invention Haskell, унаследованный PureScript дословно. В Rust это traits, в Scala — typeclasses. Универсальный способ обобщать код в современном мире.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые слова типокласса.</p>',
        code: `{{0}} Sized a where
  size :: a -> Int

{{1}} sizedArray :: Sized (Array a) where
  size xs = 1 + size xs`,
        blanks: [
          { answer: 'class' },
          { answer: 'instance' }
        ],
        ci: false
      },
      hints: [
        'Контракт объявляет class.',
        'Реализация для типа — instance.'
      ],
      solution: ['class', 'instance']
    },

    {
      id: 'purescript-7',
      title: 'Records',
      goal: 'Работать с записями-структурами и расширять их',
      xp: 50,
      theory: [
        { t: 'p', html: 'Записи (records) — структуры с именованными полями: <code>type User = { name :: String, age :: Int }</code>. Доступ — точкой: <code>user.name</code>. Обновление — <code>user { age = 31 }</code> — создаёт НОВУЮ запись (иммутабельность).' },
        { t: 'code', code: `type User = { name :: String, age :: Int }

alice :: User
alice = { name: "Алиса", age: 30 }

older :: User
older = alice { age = 31 }

greet :: User -> String
greet u = u.name <> ", " <> show u.age` },
        { t: 'p', html: 'Уникальная фишка — <b>row polymorphism</b>: функция может требовать «запись, где есть поле name» без указания остальных полей: <code>getName :: forall r. { name :: String | r } -&gt; String</code>. Пайп <code>|</code> — «прочие поля любые».' },
        { t: 'code', code: `getName :: forall r. { name :: String | r } -> String
getName u = u.name

-- работает и для User, и для {name, city}, и т.д.
getName { name: "Боб", city: "Омск" }   -- "Боб"` },
        { t: 'note', html: 'Row polymorphism — типизация «утиной» во время компиляции: принимай объекты с нужными полями, не требуя конкретного типа. В TypeScript это structural typing — PureScript делает то же строже.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви type Point с полями x и y типа Number и функцию magnitude, читающую оба поля точкой.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'type Point с двумя полями', all: ['type\\s+Point\\s*=\\s*\\{\\s*x\\s*::\\s*Number,\\s*y\\s*::\\s*Number\\s*\\}'] },
          { desc: 'Доступ через точку', all: ['\\.x', '\\.y'] }
        ],
        note: 'magnitude p = sqrt (p.x * p.x + p.y * p.y)'
      },
      hints: [
        'type Имя = { поле :: Тип, … }.',
        'Доступ к полям — p.x и p.y.'
      ],
      solution: `type Point = { x :: Number, y :: Number }
magnitude :: Point -> Number
magnitude p = sqrt (p.x * p.x + p.y * p.y)`
    },

    {
      id: 'purescript-8',
      title: 'Either и ошибки',
      goal: 'Моделировать результат с ошибкой через Either',
      xp: 55,
      theory: [
        { t: 'p', html: '<code>Either a b = Left a | Right b</code> — значение-«или»: по соглашению Left — ошибка (с описанием), Right — успех. Функции возвращают Either, чтобы ошибки стали частью типа: потерять их невозможно.' },
        { t: 'code', code: `import Data.Either (Either(..))

parseAge :: String -> Either String Int
parseAge s
  | s == "" = Left "пустая строка"
  | otherwise =
      let n = toInt s
      in if n < 0 then Left "отрицательный возраст"
         else Right n

-- использование:
case parseAge "-5" of
  Left err  -> log ("Ошибка: " <> err)
  Right age -> log ("Принято")` },
        { t: 'p', html: 'Стражи <code>| условие = …</code> и otherwise — «во всех прочих случаях» — многоусловный разбор без case. Цепочки Either соединяются bind, как Maybe: первая Left прерывает конвейер.' },
        { t: 'note', html: 'Either — идейный предок Result в Rust и Try в Scala. Обработка ошибок через тип вместо исключений — тренд всей современной индустрии, и PureScript показывает его в идеальной форме.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что вернёт parseAge "30" из теории?</p>',
        options: [
          `Left "пустая строка"`,
          `Left "отрицательный возраст"`,
          `Right 30`,
          `30 (число без обёртки)`
        ],
        correct: 2,
        explain: 'Строка непустая, число неотрицательное — срабатывает финальный страж, возвращается Right 30. Успех всегда в Right.'
      },
      hints: [
        'Проверь стражи по порядку.',
        'Успех оборачивается в Right.'
      ],
      solution: `Right 30`
    },

    {
      id: 'purescript-9',
      title: 'Effect: выход в реальность',
      goal: 'Работать с побочными эффектами через тип Effect',
      xp: 55,
      theory: [
        { t: 'p', html: 'Чистота функций не отменяет консоль, сеть и случайность — они выносятся в тип <code>Effect a</code>: «действие, при выполнении дающее a». Функция с эффектом честно помечена в типе: <code>log :: String -&gt; Effect Unit</code>. Unit — «ничего полезного».' },
        { t: 'code', code: `import Effect (Effect)
import Effect.Console (log)

main :: Effect Unit
main = do
  log "Привет, PureScript!"
  log "Скомпилировано в JS"` },
        { t: 'p', html: 'Блок <code>do</code> — «выполняй по очереди»: эффекты соединяются последовательно, результаты связываются стрелкой <code>&lt;-</code>: <code>x &lt;- someEffect</code>. Чистое ядро программы остаётся чистым, эффекты — на границе.' },
        { t: 'code', code: `-- чистая функция + эффект границей
render :: Int -> String
render n = "Счёт: " <> show n

main :: Effect Unit
main = do
  let s = render 42
  log s` },
        { t: 'note', html: 'Effect — та же идея, что IO в Haskell и Promise в JS: тип описывает действие, а не результат. Компиляция в JavaScript даёт лёгкий, читаемый выходной код — поэтому PureScript любят во фронтенд-командах.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери do-блок: два лога и связывание результата.</p>',
        code: `main :: Effect {{0}}
main = {{1}} do
  msg <- pure "готово"
  {{2}} msg`,
        blanks: [
          { answer: 'Unit' },
          { answer: '' },
          { answer: 'log' }
        ],
        ci: false
      },
      hints: [
        'Функция без полезного результата — Effect Unit.',
        'Связывание результата эффектов — оператор <-.'
      ],
      solution: ['Unit', '', 'log']
    },

    {
      id: 'purescript-10',
      title: 'Проект: конвейер обработки заказов',
      goal: 'Собрать модуль: records, Maybe, Either, типокласс и чистое ядро',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финальный проект — конвейер заказов: запись Order, валидация с Either, расчёт скидки с типоклассом, отчёт чистой функцией. Так выглядит реальный PureScript-домен: типы описывают бизнес, функции — правила, эффекты только на границе.' },
        { t: 'code', code: `type Order = { id :: Int, total :: Int, promo :: String }

validate :: Order -> Either String Order
validate o
  | o.total <= 0 = Left "пустой заказ"
  | otherwise    = Right o

class Discount a where
  discount :: a -> Int -> Int

instance disc :: Discount String where
  discount "VIP" total = total * 90 / 100
  discount _ total     = total

final :: Order -> Either String Int
final o = do
  ok <- validate o
  pure (discount ok.promo ok.total)` },
        { t: 'list', items: [
          '<b>type Order</b> — доменная модель;',
          '<b>Either</b> — ошибки как значения;',
          '<b>class Discount</b> — правило-контракт;',
          '<b>do + pure</b> — конвейер без эффектов.'
        ] },
        { t: 'note', html: 'Добавь сюда Effect с логом и JSON-парсингом — получится серверный обработчик. PureScript доказывает: строгие функциональные языки — не академия, а рабочий инструмент, компилирующийся в тот же JS, что и всё вокруг.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые части конвейера.</p>',
        code: `validate o
  | o.total <= 0 = {{0}} "пустой заказ"
  | otherwise    = {{1}} o

{{2}} ok <- validate o
  pure (discount ok.promo ok.total)`,
        blanks: [
          { answer: 'Left' },
          { answer: 'Right' },
          { answer: 'do' }
        ],
        ci: false
      },
      hints: [
        'Ошибка — Left, успех — Right.',
        'Последовательность Either — в do-блоке.'
      ],
      solution: ['Left', 'Right', 'do']
    }
  ]
};
