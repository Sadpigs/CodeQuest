'use strict';
/* ============ CodeQuest — курс Q (kdb+) ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.q = {
  id: 'q',
  title: 'Q (kdb+)',
  emoji: '🗃️',
  color: '#1f6f8b',
  lang: 'q',
  tagline: 'Базы времени в финтехе: 10 уровней',
  description: 'Язык колоночной СУБД kdb+ — стандарт трейдинга Уолл-стрит: миллиарды тиков, SQL-подобные запросы на скорости массивов. За 10 уровней: атомы и списки, функции, таблицы, q-SQL select, группировки, соединения, временные типы и финальный аналитический отчёт.',

  levels: [

    {
      id: 'q-1',
      title: 'Атомы и списки',
      goal: 'Работать со скалярами и списками q',
      xp: 30,
      theory: [
        { t: 'p', html: 'q — язык векторный: данные — списки. Литерал списка — точка с запятой внутри скобок: <code>(1; 2; 3)</code> или проще — пробелами: <code>1 2 3</code>. Скаляры: целые <code>42i/42</code>, long <code>42</code>, float <code>1.5</code>, символ (строка-атом) <code>`abc</code> с бэктиком.' },
        { t: 'code', code: `1 2 3              / список long
1.5 2.5            / float-список
\`apple \`banana     / список символов
count 1 2 3        / 3
first 1 2 3        / 1
last 1 2 3         / 3` },
        { t: 'p', html: 'Комментарии — слэш <code>/</code> до конца строки. count/first/last — встроенные функции. Символ `abc — «интернированная строка», аналог enum: сравнение мгновенное, хранение компактное. Настоящие строки — списки символов: "hello".' },
        { t: 'list', items: [
          '<b>`sym</b> — символ-атом;',
          '<b>"text"</b> — строка = список char;',
          '<b>count / first / last</b> — базовые функции;',
          'вычисление справа налево (наследие APL).'
        ] },
        { t: 'note', html: 'q — обёртка над языком k (Артур Уитни), сумевшая стать стандартом хайфрека: биржи NYSE, банки, хедж-фонды хранят тиковые данные в kdb+. Понимание q — билет в финтех-аналитику с зарплатой на другом уровне.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь функции: количество и последний элемент.</p>',
        code: `xs: 10 20 30 40
count {{0}}
{{1}} xs        / 40`,
        blanks: [
          { answer: 'xs' },
          { answer: 'last' }
        ],
        ci: false
      },
      hints: [
        'Аргумент count — список xs.',
        'Последний элемент — last.'
      ],
      solution: ['xs', 'last']
    },

    {
      id: 'q-2',
      title: 'Присваивания и функции',
      goal: 'Определять переменные и функции, индексировать списки',
      xp: 35,
      theory: [
        { t: 'p', html: 'Присваивание — двоеточие: <code>x: 10</code>. Индексация — квадратными скобками: <code>xs[1]</code> или <code>xs 1</code>. Функция — фигурные скобки: <code>{x + y}</code>, аргументы — x, y, z по позиции. Вызов — f[арг].' },
        { t: 'code', code: `x: 10
xs: 5 10 15
xs[1]           / 10
xs 2            / 15

add: {x + y}
add[2; 3]       / 5
double: {2 * x}
double 7        / 14` },
        { t: 'p', html: 'Функция с несколькими аргументами вызывается списком <code>f[2; 3]</code> — точка с запятой разделяет. Аргумент-список без скобок: <code>double 1 2 3</code> → 2 4 6 — векторизация автоматична, циклы не нужны.' },
        { t: 'code', code: `sum3: {x + y + z}
sum3[1; 2; 3]        / 6

/ частичное применение:
add5: add[5;]
add5 10              / 15` },
        { t: 'note', html: 'Частичное применение add[5;] — фиксация первого аргумента: каррирование как в функциональных языках. Аргумент-заполнитель nul:: оставляют пустым — проекция функции.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Определи функцию sq: {x*x} и примени к 7, сохранив в r.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Функция определена', all: ['sq:\\s*\\{\\s*x\\s*\\*\\s*x\\s*\\}'] },
          { desc: 'Вызов с 7 в r', all: ['r:\\s*sq\\[?\\s*7\\s*\\]?'] }
        ],
        note: 'sq: {x*x} / r: sq 7'
      },
      hints: [
        'Функция — фигурные скобки, аргумент x.',
        'Вызов: r: sq 7'
      ],
      solution: `sq: {x * x}
r: sq 7`
    },

    {
      id: 'q-3',
      title: 'Таблицы',
      goal: 'Создавать таблицы: ключевой формат kdb+',
      xp: 40,
      theory: [
        { t: 'p', html: 'Таблица — список колонок: <code>([] name: (...); price: (...))</code>. Двойные скобки [] означают «таблица» (без ключей). Каждая колонка — массив одинаковой длины. Строки — воображаемые: kdb+ хранит КОЛОНКИ, поэтому сканирование миллиардов строк быстрое.' },
        { t: 'code', code: `t: ([] sym: \`AAPL\`MSFT\`AAPL; price: 150.5 320.1 149.9; qty: 100 50 200)

count t          / 3 строки
cols t           / \`sym\`price\`qty
t[\`sym]          / колонка-символов
exec price from t / колонка значением` },
        { t: 'p', html: 'Доступ к колонке — <code>t[`sym]</code>, к строке — <code>t[1]</code>. <code>exec</code> возвращает колонку как простой список. Обновление — <code>update</code>, добавление строк — <code>insert</code> / `, (доллар-запятая).' },
        { t: 'code', code: `update total: price * qty from t
update price: price * 1.1 from t where sym = \`AAPL` },
        { t: 'note', html: 'Понимание колоночного хранения — причина, почему kdb+ обрабатывает дневной тик Facebook за секунды: читаются только нужные колонки, каждая — непрерывный массив для векторных операций.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери таблицу с двумя колонками.</p>',
        code: `t: ([] city: \`Moscow\`Paris; pop: {{0}})
count t        / 2
exec {{1}} from t / колонка pop`,
        blanks: [
          { answer: '12 2' },
          { answer: 'pop' }
        ],
        ci: false
      },
      hints: [
        'Колонка pop — список чисел 12 2 (12 млн и 2 млн).',
        'exec выбирает колонку pop.'
      ],
      solution: ['12 2', 'pop']
    },

    {
      id: 'q-4',
      title: 'q-SQL: select',
      goal: 'Запрашивать таблицы SQL-подобным синтаксисом',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>select колонки from t where условие</code> — q-SQL: SQL-читаемость, векторная скорость. Функции агрегации встроены: sum, avg, max, min, count. Сортировка — <code>xborder</code>/<code>by</code>.' },
        { t: 'code', code: `select from t where price > 150

select sym, price from t where qty > 80

select sum qty from t            / агрегат по всей таблице
select max price by sym from t   / группировка!` },
        { t: 'p', html: 'Ключевая конструкция <b>by</b> — GROUP BY: <code>select avg price by sym from t</code> даст среднюю цену на каждый тикер. where-цепочки читаются слева направо: <code>where sym=`AAPL, price&lt;200</code> — сначала тикер, потом цена (порядок влияет на скорость!).' },
        { t: 'code', code: `select count i by sym from t
/ i — встроенный индекс строки: счётчик записей

select last price, first price by sym from t
/ open-close бары — классика тик-аналитики` },
        { t: 'note', html: 'last/first по времени — как строятся свечи OHLC: first=open, last=close, max=high, min=low. Трейдеры kdb+ собирают бары одной строкой select — ты это умеешь уже сейчас.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Выбери из таблицы trades колонки sym,price где qty больше 100.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'select с колонками', all: ['select\\s+sym,\\s*price\\s+from'] },
          { desc: 'where с порогом', all: ['where\\s+qty\\s*>\\s*100'] }
        ],
        note: 'select sym, price from trades where qty > 100'
      },
      hints: [
        'Форма: select cols from t where cond.',
        'Колонки перечисляются через запятую.'
      ],
      solution: `select sym, price from trades where qty > 100`
    },

    {
      id: 'q-5',
      title: 'Группировки и агрегации',
      goal: 'Освоить by-конструкции и стек функций агрегации',
      xp: 45,
      theory: [
        { t: 'p', html: 'Агрегации: <code>sum, avg, prd (произведение), max, min, count, last, first</code>. by-группировка принимает и выражения: <code>by sym</code>, <code>by 10 xbar time</code> — группировка по 10-минутным интервалам времени (xbar — «округлить вниз до кратного»).' },
        { t: 'code', code: `trades: ([] time: 09:30:00 09:35:00 09:41:00 09:52:00;
              sym: \`A\`A\`A\`B; price: 10 11 9.5 20)

select avg price by sym from trades
select count i by sym, 10 xbar time.min from trades

/ xbar — окно времени:
select last price by sym, 10 xbar time from trades` },
        { t: 'p', html: 'Функция <code>xbar</code> — дискретизация: 10 xbar 09:37 → 09:30. Вместе с by она строит временные окна — так считают 5-минутные бары из тиков. <code>bin</code>, <code>bucket</code> — продвинутые версии той же идеи.' },
        { t: 'code', code: `10 xbar 09:37:15      / 09:30:00
5 xbar 42              / 40` },
        { t: 'note', html: 'Комбинация by + xbar + агрегаты = «движок расчёта баров» на 15 символов. На Wall Street за умение писать такие селекты платят шестизначные суммы — это буквально рабочий код трейдинг-инфраструктуры.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь функции: округление времени и агрегат средней цены.</p>',
        code: `select {{0}} price by sym, 5 xbar time from trades
select count {{1}} by sym from trades`,
        blanks: [
          { answer: 'avg' },
          { answer: 'i' }
        ],
        ci: false
      },
      hints: [
        'Среднее — avg.',
        'Счётчик строк — count i (встроенный индекс).'
      ],
      solution: ['avg', 'i']
    },

    {
      id: 'q-6',
      title: 'Join: соединения таблиц',
      goal: 'Соединять таблицы: lj, aj, uj',
      xp: 50,
      theory: [
        { t: 'p', html: 'Соединения: <code>lj</code> (left join по ключам), <code>aj</code> (as-of join — ПО ВРЕМЕНИ! уникальность kdb+), <code>uj</code> (union — объединение строк). Для lj таблица-справочник должна быть keyed (ключи в первых скобках: ([k: (...)] v: (...))).' },
        { t: 'code', code: `prices: ([sym: \`AAPL\`MSFT] px: 150.0 320.0)
trades: ([] sym: \`AAPL\`MSFT\`AAPL; qty: 100 50 30)

trades lj prices
/ добавит колонку px к каждой сделке

/ as-of join: последняя цена ДО момента сделки
quotes: ([] sym: \`AAPL\`AAPL\`MSFT; time: 09:30 09:35 09:31; bid: 149 150 319)
trades2: ([] sym: \`AAPL\`AAPL; time: 09:33 09:36)
aj[\`sym\`time; trades2; quotes]` },
        { t: 'p', html: 'aj — «as-of»: для каждой сделки берёт последнюю котировку, случившуюся НЕ ПОЗЖЕ сделки. Это операция, вокруг которой построена вся тик-аналитика: сопоставить сделки с котировками без точного совпадения времени. Ни в SQL, ни в pandas её нет в таком виде.' },
        { t: 'note', html: 'Ключевые таблицы (keyed) создаются вторыми скобками ([sym: ...]). lj требует ключей — так оптимизатор делает hash-lookup. Обратное преобразование — 0! (ungkey).' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Какая функция соединяет таблицы по совпадению времени «не позже»?</p>',
        options: [
          `lj`,
          `uj`,
          `aj`,
          `join`
        ],
        correct: 2,
        explain: 'aj (as-of join) сопоставляет записи по последнему доступному времени — фирменная операция kdb+ для связки сделок и котировок.'
      },
      hints: [
        'Название расшифровывается as-of join.',
        'lj — точные ключи, aj — время.'
      ],
      solution: `aj`
    },

    {
      id: 'q-7',
      title: 'Временные типы',
      goal: 'Работать с датами и временем: date, time, timestamp',
      xp: 50,
      theory: [
        { t: 'p', html: 'Типы времени: <code>2024.01.15</code> (date), <code>09:30:15.500</code> (time), <code>2024.01.15T09:30:15.500</code> (timestamp). Арифметика дат: разность — целые дни, сложение — дни. Даты хранятся как дни с 2000.01.01 — поэтому огромные массивы дат занимают 4 байта на элемент.' },
        { t: 'code', code: `d1: 2024.01.10
d2: 2024.01.15
d2 - d1           / 5

t1: 09:30:00
t2: 10:15:30
t2 - t1           / 00:45:30

\`date$2024.01.15T09:30:00    / вырезать дату
\`time$2024.01.15T09:30:00    / вырезать время` },
        { t: 'p', html: 'Компоненты даты-времени: <code>d1.yyyy</code>, <code>d1.mm</code>, <code>d1.dd</code>, <code>t1.hh</code>, <code>t1.mm</code>. Приведение типов — бэктик-тип: `int$..., `date$... — система типов q единообразна и компакта.' },
        { t: 'code', code: `2024.01.15 . mm        / 1
09:30:15 . hh          / 9

/ границы дня:
\`date$09:30:15 + 3600  / вычисления со временем` },
        { t: 'note', html: 'Раз дата — число дней, диапазон «за последний месяц» — просто where date &gt; .z.d-30 (.z.d — сегодня). Вся временная аналитика сводится к целочисленной арифметике — отсюда скорость kdb+.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь типы: дату и извлечение времени из timestamp.</p>',
        code: `d: {{0}}2024.03.01
t: \`{{1}}$2024.03.01T09:30:00`,
        blanks: [
          { answer: '' },
          { answer: 'time' }
        ],
        ci: false
      },
      hints: [
        'Литерал даты — точки: 2024.03.01.',
        'Приведение — `time$...'
      ],
      solution: ['', 'time']
    },

    {
      id: 'q-8',
      title: 'Vector conditional и итерации',
      goal: 'Условия по массивам и итеративные функции',
      xp: 55,
      theory: [
        { t: 'p', html: '<code>?[cond; then; else]</code> — векторное условие: cond — список-маска, результат — элемент then/else по месту. <code>over/scan (/ и \\)</code> — итерации: f/ — свёртка, f\\ — скан (все промежуточные).' },
        { t: 'code', code: `prices: 100 105 98 110
?[prices > 100; prices; 0]
/ 100 105 0 110

+/ 1 2 3           / 6 — сумма через over
+\\ 1 2 3           / 1 3 6 — накопительные суммы

maxs 1 5 3 8       / 1 5 5 8 — бегущий максимум
sums 1 2 3         / 1 3 6` },
        { t: 'p', html: 'Монадические сканы: <code>sums, maxs, mins, ratios, deltas</code> — накопительные суммы, бегущие максимумы, отношения и разности соседей. Дельты: <code>deltas prices</code> — изменения цены между тиками, фундамент расчёта доходностей.' },
        { t: 'code', code: `deltas 100 105 98    / 100 5 -7
ratios 100 105 98    / 100 1.05 0.9333

/ доходность в процентах:
rtn: {100 * -1 + x % prev x}
rtn 100 105 98       / 5 -6.66...` },
        { t: 'note', html: 'Векторное ?[...] — ternary оператор для массивов: избегай where+update, когда ?[...] делает всё за один проход. Сканы over/scan — замена циклов while для аккумуляторов.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что вернёт выражение? Числа через пробел.</p>',
        code: `sums 2 3 4`,
        solution: `2 5 9`,
        ci: false
      },
      hints: [
        'sums — накопительная сумма.',
        '2, 2+3, 2+3+4.'
      ],
      solution: `2 5 9`
    },

    {
      id: 'q-9',
      title: 'Функции высшего порядка',
      goal: 'each (\\’), over (/), scan (\\), each-both',
      xp: 55,
      theory: [
        { t: 'p', html: 'Итераторы: <code>f&apos;</code> (each) — применить к каждому, <code>f/</code> (over) — свёртка, <code>f\\</code> (scan) — все шаги, <code>f&apos;</code> — each-right/each-both для диад: <code>,&apos;</code> — попарная склейка.' },
        { t: 'code', code: `sq: {x*x}
sq' 1 2 3           / 1 4 9

,/' ("ab"; "cd")    / объединить внутренности: "abcd"
+' (1 2; 3 4)       / попарно: (1 3; 2 4)? осторожно

/ each-both: две колонки попарно
{[a; b] a + b}'[1 2 3; 10 20 30]   / 11 22 33` },
        { t: 'p', html: 'Итераторы комбинируются: <code>+&apos;/</code> — сумма попарных склеек. Путь знакомства с q — через итераторы: каждый цикл обычного языка выражается одним из четырёх (/ \\ &apos; &apos;).' },
        { t: 'code', code: `/ сумма квадратов:
{y + x*x}/[0; 1 2 3]      / 14

/ с начальным значением и списком
+/ {x*x}' 1 2 3           / то же 14` },
        { t: 'note', html: 'Функции q — первоклассные значения: их можно передавать в f/[начальное; список]. Аккумуляторные алгоритмы (running stats, рекурсивные фильтры) пишутся через over с функцией двух аргументов.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь итераторы: each для квадрата и over для суммы.</p>',
        code: `sq: {x*x}
{{0}}[1 2 3]          / 1 4 9
{{1}}/[0; 1 2 3]      / 6`,
        blanks: [
          { answer: "sq'" },
          { answer: '+' }
        ],
        ci: false
      },
      hints: [
        'Each — апостроф после функции.',
        'Сумма — редукция плюса: +/'
      ],
      solution: ["sq'", '+']
    },

    {
      id: 'q-10',
      title: 'Проект: тик-аналитика дня',
      goal: 'Собрать отчёт трейдера: select, xbar, aj, vwap',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финал — расчёт VWAP (средневзвешенная по объёму цена) — метрика, которую считают каждое утро на каждой бирже мира. Формула: сумма(price×qty) / сумма(qty) по интервалам. На q — одна строка с by и xbar.' },
        { t: 'code', code: `trades: ([] time: 09:30:05 09:31:12 09:31:55 09:32:10;
              sym: \`A\`A\`A\`A;
              price: 100 101 99.5 100.2;
              qty: 100 300 200 150)

/ VWAP по 1-минутным окнам
select vwap: sum price * qty % sum qty
       by sym, 1 xbar time
from trades

/ количество сделок и оборот
select cnt: count i, turnover: sum price*qty
       by sym from trades` },
        { t: 'list', items: [
          '<b>by sym, 1 xbar time</b> — минутные окна;',
          '<b>sum price*qty % sum qty</b> — VWAP внутри окна;',
          '<b>count i</b> — число сделок;',
          '<b>sum price*qty</b> — оборот (notional).'
        ] },
        { t: 'note', html: 'Добавь as-of join с котировками (aj) и рассчитай спред исполнения: сделка.price − quote.bid в момент сделки. Поздравляю — ты написал ядро Transaction Cost Analysis, за которое консультанты выставляют счёты фондам. И это ровно 20 строк q.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь формулу VWAP и агрегаты.</p>',
        code: `select vwap: {{0}} price * qty % sum qty
       by sym, 1 xbar time
from trades

select cnt: {{1}} i, turnover: {{2}} price*qty
       by sym from trades`,
        blanks: [
          { answer: 'sum' },
          { answer: 'count' },
          { answer: 'sum' }
        ],
        ci: false
      },
      hints: [
        'VWAP: числитель — sum price*qty.',
        'Число строк — count i; оборот — sum price*qty.'
      ],
      solution: ['sum', 'count', 'sum']
    }
  ]
};
