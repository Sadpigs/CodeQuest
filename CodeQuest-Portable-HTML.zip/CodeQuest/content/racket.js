'use strict';
/* ============ CodeQuest — курс Racket ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.racket = {
  id: 'racket',
  title: 'Racket',
  emoji: '🎾',
  color: '#a51d2d',
  lang: 'racket',
  tagline: 'Лисп для обучения и языков: 10 уровней',
  description: 'Современный наследник Scheme, на котором построен знаменитый курс программирования MIT и учебник HTDP. За 10 уровней: выражения, define, cond, рекурсия, структуры structs, сопоставление с образцом, функции высшего порядка и собственный мини-язык — Racket создан для того, чтобы строить языки.',

  levels: [

    {
      id: 'racket-1',
      title: 'Выражения и DrRacket',
      goal: 'Освоить префиксную запись: операция первая, аргументы следом',
      xp: 30,
      theory: [
        { t: 'p', html: 'Racket — диалект Лиспа с сильным акцентом на обучение: среда DrRacket подсвечивает пары скобок и мгновенно запускает код. Синтаксис как в Scheme: любое выражение — список в скобках, где первый элемент — операция. Арифметика пишется префиксно, приоритетов нет — вложенные скобки решают всё.' },
        { t: 'code', code: `(+ 2 3)             → 5
(* 2 (+ 3 4))       → 14
(expt 2 10)         → 1024
(quotient 17 5)     → 3    — целая часть деления
(remainder 17 5)    → 2    — остаток` },
        { t: 'p', html: 'В отличие от C-семейства, в Racket дробные и целые числа различаются: <code>(/ 10 4)</code> даст точную дробь <code>5/2</code>, а не 2.5 — язык честно работает с рациональными числами. Чтобы получить десятичную дробь, нужен хотя бы один «плавающий» аргумент: <code>(/ 10.0 4)</code> → 2.5.' },
        { t: 'list', items: [
          '<b>(+ a b)</b>, <b>(* a b)</b>, <b>(- a b)</b>, <b>(/ a b)</b> — арифметика;',
          '<b>(quotient a b)</b> — целочисленное деление, <b>(remainder a b)</b> — остаток;',
          '<b>(min a b)</b>, <b>(max a b)</b>, <b>(expt a b)</b> — утилиты;',
          '<code>;</code> — комментарий до конца строки.'
        ] },
        { t: 'note', html: 'Пары скобок бывают и квадратными <code>[…]</code> — они полностью равны круглым и используются для читаемости: например, в cond для веток. Скобки всегда балансируются — редактор DrRacket помогает не потерять закрывающую.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь операции, чтобы выражения дали указанные результаты.</p>',
        code: `({{0}} 9 4)          → 36
({{1}} 20 4)         → 5
({{2}} 23 5)         → 3 (целая часть)
({{3}} 23 5)         → 3 (остаток)`,
        blanks: [
          { answer: '*' },
          { answer: '/' },
          { answer: 'quotient' },
          { answer: 'remainder' }
        ],
        ci: false
      },
      hints: [
        '36 — это 9 × 4, операция умножения — *.',
        'Целая часть деления — quotient, остаток — remainder.'
      ],
      solution: ['*', '/', 'quotient', 'remainder']
    },

    {
      id: 'racket-2',
      title: 'define и строки',
      goal: 'Связывать имена со значениями, работать со строками и булевыми значениями',
      xp: 35,
      theory: [
        { t: 'p', html: '<code>(define имя значение)</code> — привязка имени. Строки в Racket — в двойных кавычках, для них есть операции конкатенации <code>string-append</code>, длины <code>string-length</code> и числа-в-строку <code>number->string</code>. Булевы значения — <code>#true</code> и <code>#false</code> (кратко #t/#f).' },
        { t: 'code', code: `(define name "Ада")
(define greeting (string-append "Привет, " name "!"))

greeting                    → "Привет, Ада!"
(string-length greeting)    → 12
(string? name)              → #true
(number? 42)                → #true` },
        { t: 'p', html: 'Предикаты — проверки типов — заканчиваются знаком вопроса: <code>string?</code>, <code>number?</code>, <code>boolean?</code>. Это соглашение всего Лисп-семейства: читая код, ты сразу видишь, что функция возвращает #t/#f.' },
        { t: 'warn', html: 'Строки и символы — разные вещи! Символ (например <code>’red</code>) — это атом-метка для сравнения, строка — текст-данные. Сравнивать строки между собой надо <code>string=?</code>, а символы — просто <code>equal?</code>.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери приветствие: определите <code>user</code> со значением "Лена" и <code>msg</code> — строку "Привет, Лена!" через string-append. Затем проверь длину msg.</p>',
        starter: `(define user ...)
(define msg ...)
; проверка длины
TODO`,
        rules: [
          { desc: 'Заглушки убраны', all: ['\\S'], none: ['TODO', '\\\\.\\.\\.'] },
          { desc: 'user = "Лена"', all: ['\\(define\\s+user\\s+"Лена"\\s*\\)'] },
          { desc: 'msg через string-append', all: ['\\(define\\s+msg\\s+\\(string-append\\s+"Привет,\\s*"\\s+user\\s+"!"\\s*\\)\\s*\\)'] },
          { desc: 'Длина msg вычисляется', all: ['\\(string-length\\s+msg\\s*\\)'] }
        ],
        note: 'string-append склеивает: (string-append "Привет, " user "!").'
      },
      hints: [
        '(define user "Лена") — начало.',
        'Финальная проверка — выражение (string-length msg), без define.'
      ],
      solution: `(define user "Лена")
(define msg (string-append "Привет, " user "!"))
(string-length msg)`
    },

    {
      id: 'racket-3',
      title: 'Функции',
      goal: 'Определять функции двух форм и вызывать их с аргументами',
      xp: 40,
      theory: [
        { t: 'p', html: 'Функция в Racket определяется двумя способами. Полный: <code>(define имя (lambda (параметры) тело))</code> — подчёркивает, что функция это значение. Краткий: <code>(define (имя параметры) тело)</code> — его пишут обычно. Оба эквивалентны.' },
        { t: 'code', code: `(define (area w h) (* w h))
(area 3 4)              → 12

(define cube (lambda (x) (* x x x)))
(cube 2)                → 8` },
        { t: 'p', html: 'Тело функции может содержать несколько выражений — результатом будет последнее. Аргументы передаются по значению и видны только внутри тела. Хороший стиль — маленькие функции с одним назначением: их легко тестировать и комбинировать.' },
        { t: 'code', code: `(define (bmi w h) (/ w (* h h)))
(define (bmi-verdict w h)
  (if (> (bmi w h) 25)
      "избыток"
      "норма"))

(bmi-verdict 90 1.8)   → "избыток"` },
        { t: 'note', html: 'Функция — полноценное значение: её можно передать в другую функцию или сохранить в списке. Например, <code>(list area cube)</code> — список из двух функций. Это основа функционального стиля, к которому вернёмся на 8-м уровне.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что вернёт выражение?</p>',
        code: `(define (f x) (* x (+ x 1)))
(f 4)`,
        options: [
          `16`,
          `20`,
          `24`,
          `ошибка`
        ],
        correct: 1,
        explain: 'Сначала (+ x 1) = 5, затем (* 4 5) = 20. Внутренние выражения вычисляются раньше внешних.'
      },
      hints: [
        'Сначала считается самый внутренний вызов.',
        '(+ 4 1) = 5, потом 4 × 5.'
      ],
      solution: `20`
    },

    {
      id: 'racket-4',
      title: 'cond и case',
      goal: 'Ветвления: if для двух веток, cond для лестницы условий',
      xp: 40,
      theory: [
        { t: 'p', html: '<code>(if условие тогда-выражение иначе-выражение)</code> — базовое ветвление. Обе ветки обязательны. Для множественного выбора используется <code>cond</code>: набор пар [условие, результат], проверяемых сверху вниз; ветка <code>[else …]</code> срабатывает, если ни одно условие не подошло.' },
        { t: 'code', code: `(define (ticket age)
  (cond
    [(< age 7)   "бесплатно"]
    [(< age 18)  "детский"]
    [(< age 65)  "полный"]
    [else        "льготный"]))

(ticket 15)   → "детский"` },
        { t: 'p', html: 'Ветви cond принято записывать в квадратных скобках для читаемости. Ложь — только #false, всё остальное считается истиной. Порядок веток важен: первое подошедшее условие завершает проверку, поэтому от частного к общему.' },
        { t: 'warn', html: 'Частая ошибка — переставить условия местами: [(< age 65) "полный"] перед [(< age 7) "бесплатно"] перехватит всех детей. Всегда проверяй порядок: сначала самые узкие условия.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши <code>sign</code>: 1 для положительного x, −1 для отрицательного, 0 для нуля. Используй cond с тремя ветками.</p>',
        starter: `(define (sign x)
  (cond
    ; [(> x 0) 1]
    TODO))`,
        rules: [
          { desc: 'Заглушка убрана', all: ['\\S'], none: ['TODO'] },
          { desc: 'cond присутствует', all: ['\\(cond'] },
          { desc: 'Ветка (> x 0) → 1', all: ['\\[\\(>\\s+x\\s+0\\)\\s*1\\s*\\]'] },
          { desc: 'Ветка (< x 0) → -1', all: ['\\[\\(<\\s+x\\s+0\\)\\s*-1\\s*\\]'] },
          { desc: 'else → 0', all: ['\\[else\\s*0\\s*\\]'] }
        ],
        note: 'Ветки в квадратных скобках: [условие результат].'
      },
      hints: [
        'Три ветки: [(> x 0) 1], [(< x 0) -1], [else 0].',
        'else всегда последняя.'
      ],
      solution: `(define (sign x)
  (cond
    [(> x 0) 1]
    [(< x 0) -1]
    [else 0]))`
    },

    {
      id: 'racket-5',
      title: 'Рекурсия',
      goal: 'Писать рекурсивные функции с явной базой',
      xp: 45,
      theory: [
        { t: 'p', html: 'Циклы в Racket традиционно выражаются рекурсией: функция решает малую часть и вызывает себя для остатка. Обязательные части — база (условие остановки) и шаг, приближающий к базе. Классика — факториал и сумма чисел.' },
        { t: 'code', code: `(define (fact n)
  (if (<= n 1)
      1
      (* n (fact (- n 1)))))

(fact 6)   → 720` },
        { t: 'p', html: 'Хвостовая рекурсия с аккумулятором — приём, при котором вызов себя является последним действием. Racket обязан оптимизировать её в цикл, поэтому такие функции не переполняют стек даже на миллионах итераций:' },
        { t: 'code', code: `(define (sum-to n) (sum-acc n 0))
(define (sum-acc n acc)
  (if (= n 0)
      acc
      (sum-acc (- n 1) (+ acc n))))

(sum-to 1000000)   → 500000500000` },
        { t: 'note', html: 'Ключевая разница: в первой версии после рекурсивного вызова остаётся умножение — стек растёт. Во второй вызов последний — стек не нужен. Аккумулятор хранит промежуточный результат вместо стека.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что вернёт вызов? Напиши одно число.</p>',
        code: `(define (pow2 n)
  (if (= n 0)
      1
      (* 2 (pow2 (- n 1)))))

(pow2 8)`,
        solution: `256`,
        ci: false
      },
      hints: [
        'Каждый шаг умножает на 2: цепочка из 8 умножений на 2 и единица в базе.',
        '2⁸ = 256.'
      ],
      solution: `256`
    },

    {
      id: 'racket-6',
      title: 'Списки',
      goal: 'Создавать списки, брать голову и хвост, считать длину',
      xp: 45,
      theory: [
        { t: 'p', html: 'Список — базовая коллекция Racket: <code>(list 1 2 3)</code> или <code>’(1 2 3)</code>. Операции: <code>first</code> — первый элемент, <code>rest</code> — хвост без первого, <code>cons</code> — приклеить элемент спереди, <code>empty?</code> — проверка на пустоту, <code>length</code> — длина.' },
        { t: 'code', code: `(define xs (list 10 20 30))
(first xs)      → 10
(rest xs)       → (20 30)
(cons 5 xs)     → (5 10 20 30)
(empty? '())    → #true
(length xs)     → 3` },
        { t: 'p', html: 'Шаблон обработки списка: пустой — база; непустой — обработай first и рекурсивно rest. Так пишется сумма элементов:' },
        { t: 'code', code: `(define (sum-list xs)
  (if (empty? xs)
      0
      (+ (first xs) (sum-list (rest xs)))))

(sum-list '(1 2 3 4))   → 10` },
        { t: 'note', html: 'В Racket есть и pair-версии Lisp-классики: car/cdr/cons работают так же (car = first, cdr = rest), но HTDP-стиль с first/rest считается нагляднее для обучения.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь имена операций, чтобы функция находила первый чётный элемент списка (или #false).</p>',
        code: `(define (first-even xs)
  (cond
    [(empty? xs) #false]
    [(even? ({{0}} xs)) ({{1}} xs)]
    [else (first-even ({{2}} xs))]))`,
        blanks: [
          { answer: 'first' },
          { answer: 'first' },
          { answer: 'rest' }
        ],
        ci: false
      },
      hints: [
        'Голова списка — first, хвост — rest.',
        'Проверяем голову на чётность, если нет — уходим в хвост.'
      ],
      solution: ['first', 'first', 'rest']
    },

    {
      id: 'racket-7',
      title: 'map и filter',
      goal: 'Обрабатывать коллекции функциями высшего порядка',
      xp: 50,
      theory: [
        { t: 'p', html: 'Вместо ручной рекурсии Racket предлагает комбинаторы. <code>map</code> преобразует каждый элемент, <code>filter</code> отбирает по предикату, <code>foldl</code> сворачивает в одно значение, <code>andmap</code>/<code>ormap</code> проверяют «все/хотя бы один».' },
        { t: 'code', code: `(map (λ (x) (* x x)) '(1 2 3 4))     → (1 4 9 16)
(filter even? '(1 2 3 4 5 6))        → (2 4 6)
(foldl + 0 '(10 20 30))              → 60
(ormap negative? '(-1 5 3))          → #true` },
        { t: 'p', html: 'λ — краткая запись lambda. Именованные функции тоже можно передавать без лямбды: <code>(map add1 xs)</code> прибавит 1 к каждому. Это делает код конвейерным: <code>(map sqrt (filter positive? xs))</code> — корни из положительных.' },
        { t: 'code', code: `; сумма квадратов чётных
(foldl + 0 (map (λ (x) (* x x)) (filter even? '(1 2 3 4 5 6))))
→ 4 + 16 + 36 = 56` },
        { t: 'note', html: 'Комбинаторы — мостик к языкам вроде Elixir и Haskell: там map/filter/reduce — основной способ обработки данных. Racket готовит к этому мышлению на родном синтаксисе.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что вернёт выражение?</p>',
        code: `(foldl * 1 (filter odd? '(1 2 3 4 5)))`,
        options: [
          `120`,
          `15`,
          `6`,
          `9`
        ],
        correct: 1,
        explain: 'filter odd? оставит (1 3 5), свёртка умножением: 1×1×3×5 = 15.'
      },
      hints: [
        'Сначала filter: останутся нечётные.',
        'Затем произведение отобранных чисел.'
      ],
      solution: `15`
    },

    {
      id: 'racket-8',
      title: 'Структуры struct',
      goal: 'Создавать собственные типы данных с полями',
      xp: 50,
      theory: [
        { t: 'p', html: '<code>struct</code> создаёт новый тип с полями и автоматическими функциями доступа: <code>(struct point (x y))</code> даёт конструктор <code>(point 2 3)</code>, доступ <code>(point-x p)</code>, <code>(point-y p)</code> и предикат <code>(point? v)</code>. Это способ описать сущность предметной области — книгу, игрока, заказ.' },
        { t: 'code', code: `(struct book (title pages))
(define b (book "Муми-тролли" 256))

(book-title b)    → "Муми-тролли"
(book-pages b)    → 256
(book? b)         → #true` },
        { t: 'p', html: 'Структуры комбинируются со списками: <code>(list (book "A" 100) (book "B" 200))</code> — библиотека. Обработка — конвейер: filter по предикату структуры, map по полю, foldl для агрегата. Так моделируются реальные задачи вроде «средняя цена книг дороже 500».' },
        { t: 'code', code: `(struct city (name pop))
(define cs (list (city "Казань" 1300000) (city "Тверь" 420000)))

; город-миллионник
(map city-name (filter (λ (c) (> (city-pop c) 1000000)) cs))
→ '("Казань")` },
        { t: 'note', html: 'struct в Racket — неизменяемый по умолчанию: поля задаются при создании. Мутабельность возможна, но функциональный стиль предпочитает создавать новые значения вместо изменения старых.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери доступ к структуре: объяви struct и достань поля.</p>',
        code: `({{0}} player (name score))
(define p (player "Игорь" 77))
({{1}} p)        → "Игорь"
({{2}} p)        → 77`,
        blanks: [
          { answer: 'struct' },
          { answer: 'player-name' },
          { answer: 'player-score' }
        ],
        ci: false
      },
      hints: [
        'Объявление: (struct имя (поля…)).',
        'Доступы генерируются автоматически: имя-поле.'
      ],
      solution: ['struct', 'player-name', 'player-score']
    },

    {
      id: 'racket-9',
      title: 'match: сопоставление с образцом',
      goal: 'Разбирать данные декларативно через match',
      xp: 55,
      theory: [
        { t: 'p', html: '<code>match</code> — мощная форма разбора данных: значение сравнивается с образцами, первый совпавший связывает переменные и вычисляет своё тело. Образец <code>(list x rest …)</code> разбирает список на голову и хвост, <code>_</code> — «что угодно».' },
        { t: 'code', code: `(define (describe lst)
  (match lst
    ['()            "пусто"]
    [(list x)       (string-append "один: " (number->string x))]
    [(list x y ...) "несколько, первая — голова"]))

(describe '())        → "пусто"
(describe '(5))       → "один: 5"
(describe '(5 6 7))   → "несколько, первая — голова"` },
        { t: 'p', html: 'match заменяет лестницы if/cond при разборе структур: вместо ручных first/rest достаточно описать форму данных. Работает и со struct-ами, и с вложенными списками — образцы могут быть сколь угодно глубокими: <code>(list (point x y) rest ...)</code>.' },
        { t: 'code', code: `; рекурсивная сумма через match
(define (m-sum xs)
  (match xs
    ['() 0]
    [(cons x tail) (+ x (m-sum tail))]))` },
        { t: 'note', html: 'Сопоставление с образцом — центральная фича Haskell, Elixir, Rust и OCaml. Racket — отличное место, чтобы освоить мышление «опиши форму данных — получи переменные».' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что вернёт выражение?</p>',
        code: `(match '(1 2 3)
  [(list a b) (+ a b)]
  [(list a b c) (* a b c)]
  [_ 'nope])`,
        options: [
          `3`,
          `6`,
          `'nope`,
          `ошибка`
        ],
        correct: 1,
        explain: 'Первый образец (list a b) не подходит — элементов три. Второй подходит: 1×2×3 = 6.'
      },
      hints: [
        'Образцы проверяются сверху вниз.',
        'Три элемента списка — образец (list a b c).'
      ],
      solution: `6`
    },

    {
      id: 'racket-10',
      title: 'Проект: библиотека книг',
      goal: 'Собрать систему: структуры, фильтры, агрегаты и отчёт',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финал: маленькая «система каталога». Определяем struct book, собираем список, и строим функции: средний объём, поиск по названию, самая толстая книга. Каждая — одна-две строки над конвейерами map/filter/foldl — вот ради чего изучались комбинаторы.' },
        { t: 'code', code: `(struct book (title pages))
(define lib (list
  (book "Лис" 320) (book "Дюна" 600) (book "Улей" 180)))

(define (avg-pages books)
  (/ (foldl (λ (b acc) (+ acc (book-pages b))) 0 books)
     (length books)))

(define (thickest books)
  (foldl (λ (b acc)
           (if (> (book-pages b) (book-pages acc)) b acc))
         (first books) lib))

(avg-pages lib)     → 1100/3
(book-title (thickest lib))   → "Дюна"` },
        { t: 'list', items: [
          '<b>foldl с λ-аккумулятором</b> — и сумма, и поиск максимума;',
          '<b>filter + map</b> — отбор и извлечение полей;',
          '<b>struct</b> — каркас данных всего проекта.'
        ] },
        { t: 'note', html: 'Эта же архитектура (модель-данные + конвейеры) в реальном мире превращается в отчёты SQL, обработку pandas и MapReduce. Racket показал её в самом чистом виде.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь пропущенные имена, чтобы функции каталога работали.</p>',
        code: `(define (avg-pages books)
  (/ (foldl (λ (b acc) (+ acc (book-pages b))) 0 books)
     ({{0}} books)))

(define (titles books)
  (map {{1}} books))

(define (long-books books)
  ({{2}} (λ (b) (> (book-pages b) 500)) books))`,
        blanks: [
          { answer: 'length' },
          { answer: 'book-title' },
          { answer: 'filter' }
        ],
        ci: false
      },
      hints: [
        'Число книг — length.',
        'Список названий — map по доступу book-title; отбор — filter.'
      ],
      solution: ['length', 'book-title', 'filter']
    }
  ]
};
