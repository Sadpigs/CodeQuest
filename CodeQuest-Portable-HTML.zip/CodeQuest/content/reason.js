'use strict';
/* ============ CodeQuest — курс Reason (ReasonML) ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.reason = {
  id: 'reason',
  title: 'Reason',
  emoji: '🤖',
  color: '#d64242',
  lang: 'reason',
  tagline: 'OCaml с синтаксисом JS: 10 уровней',
  description: 'Синтаксический слой над OCaml, созданный в Facebook для надёжного фронтенда (React был сначала написан на нём). Строгий вывод типов, варианты и pattern matching. За 10 уровней: let, функции, варианты, match, Option, списки, records, рекурсия и проект.',

  levels: [

    {
      id: 'reason-1',
      title: 'let и вывод типов',
      goal: 'Связывать значения let-ом и доверять выводу типов',
      xp: 30,
      theory: [
        { t: 'p', html: 'Reason — OCaml в одежде JavaScript: те же мощные типы, но знакомые фигурные скобки и точка с запятой. Привязка значения — <code>let имя = значение;</code>. Типы выводятся автоматически: писать аннотации нужно редко.' },
        { t: 'code', code: `let age = 30;          /* тип выведен: int */
let name = "Ада";      /* string */
let pi = 3.14;         /* float */

let add = (a, b) => a + b;
let sum = add(2, 3);   /* 5 */` },
        { t: 'p', html: 'Анонимная функция — <code>(параметры) =&gt; тело</code> — стрелка, как в JS. Комментарии — <code>/* … */</code>. Числа двух типов: <code>int</code> и <code>float</code> — и операторы разные: + для int, <code>+.</code> для float! Это строгое наследие OCaml.' },
        { t: 'list', items: [
          '<b>let</b> — привязка значения;',
          '<b>=&gt;</b> — стрелка функции;',
          '<b>+.</b>, <b>-.</b>, <b>*.</b> — арифметика float;',
          'иммутабельность по умолчанию.'
        ] },
        { t: 'note', html: 'Разделение int/float кажется занудством, но убирает целый класс ошибок округления: компилятор не даст сложить 1 и 2.5 случайно.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь пропуски: привязка и стрелка.</p>',
        code: `{{0}} greet = (name) => "Привет, " ++ name;
let msg = {{1}}("Мир");`,
        blanks: [
          { answer: 'let' },
          { answer: 'greet' }
        ],
        ci: false
      },
      hints: [
        'Привязка — let.',
        'Вызов функции — имя со скобками.'
      ],
      solution: ['let', 'greet']
    },

    {
      id: 'reason-2',
      title: 'Варианты',
      goal: 'Объявлять варианты (variants) и понимать их силу',
      xp: 35,
      theory: [
        { t: 'p', html: 'Вариант — тип «одно из»: <code>type color = | Red | Green | Blue;</code>. Варианты могут нести данные: <code>type shape = | Circle(float) | Rect(float, float);</code>. Это главный инструмент моделирования состояний в Reason.' },
        { t: 'code', code: `type shape =
  | Circle(float)
  | Rect(float, float);

let c = Circle(2.0);
let r = Rect(3.0, 4.0);` },
        { t: 'p', html: 'Вариант — закрытый тип: компилятор знает ВСЕ случаи. Забыть обработать один — ошибка компиляции при match (следующий уровень). Полиморфные варианты <code>[`Ok | `Error]</code> — встроенный механизм без объявления.' },
        { t: 'note', html: 'Варианты Reason — то же, что enum с данными в Rust и discriminated unions в TS. Источник — ML-семейство (OCaml), которому 40+ лет.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви type status с вариантами Loading, Done(string) и Failed(string).</p>',
        starter: `TODO`,
        rules: [
          { desc: 'type status объявлен', all: ['type\\s+status\\s*='] },
          { desc: 'Три варианта', all: ['Loading', 'Done\\s*\\(\\s*string\\s*\\)', 'Failed\\s*\\(\\s*string\\s*\\)'] }
        ],
        note: 'type status = | Loading | Done(string) | Failed(string);'
      },
      hints: [
        'Каждый вариант начинается с |.',
        'Данные в скобках: Done(string).'
      ],
      solution: `type status =
  | Loading
  | Done(string)
  | Failed(string);`
    },

    {
      id: 'reason-3',
      title: 'match',
      goal: 'Разбирать значения pattern matching-ом',
      xp: 40,
      theory: [
        { t: 'p', html: '<code>switch значение { | образец =&gt; результат }</code> — сопоставление с образцом. Проверяется сверху вниз; компилятор требует <b>исчерпывающести</b> — все варианты покрыты или есть <code>_</code>.' },
        { t: 'code', code: `let area = (shape) =>
  switch (shape) {
    | Circle(r)   => 3.14159 *. r *. r
    | Rect(w, h)  => w *. h
  };

area(Circle(2.0));  /* 12.56636 */
area(Rect(3.0, 4.0));  /* 12.0 */` },
        { t: 'p', html: 'Образцы могут связывать поля, вкладываться и включать константы: <code>| 0 =&gt; "ноль"</code>. Выражение match возвращает значение — его можно присвоить. Добавишь новый вариант в тип — компилятор сам покажет все match-и, которые нужно дополнить.' },
        { t: 'note', html: 'Исчерпывающий match — «рефакторинг под защитой»: изменение типа данных проталкивается во все места использования автоматически через ошибки компиляции. Усталость от if-цепочек проходит навсегда.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что вернёт выражение?</p>',
        code: `let f = (x) =>
  switch (x) {
    | 0 => "zero"
    | n when n < 0 => "minus"
    | _ => "plus"
  };
f(-5);`,
        options: [
          `zero`,
          `minus`,
          `plus`,
          `ошибка`
        ],
        correct: 1,
        explain: 'Образец с when (охранное условие) ловит -5: n < 0 истинно — результат "minus".'
      },
      hints: [
        'Порядок образцов важен.',
        'when добавляет условие к образцу.'
      ],
      solution: `minus`
    },

    {
      id: 'reason-4',
      title: 'Option',
      goal: 'Работать с отсутствием значений через option',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>option</code> — встроенный вариант: <code>Some(значение)</code> или <code>None</code>. Никаких null: «может не быть» — часть типа. Функции библиотеки возвращают option, а код обязан разобрать оба случая.' },
        { t: 'code', code: `let divide = (a, b) =>
  b == 0 ? None : Some(a / b);

let show = (a, b) =>
  switch (divide(a, b)) {
    | Some(v) => "итог: " ++ string_of_int(v)
    | None    => "на ноль делить нельзя"
  };

show(10, 2);   /* итог: 5 */
show(1, 0);    /* на ноль делить нельзя */` },
        { t: 'p', html: 'Библиотечные помощники: <code>Belt.Option.getWithDefault(opt, по-умолчанию)</code>, <code>Option.map</code> — преобразование внутри. Цепочки option соединяются bind (flatMap) — первая None прерывает конвейер.' },
        { t: 'note', html: 'Причина, по которой в Reason-коде нет «cannot read property of undefined»: None-случаи обязательны к разбору. TypeScript Optional chaining решает проблему наполовину — тут полностью.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши safeHead: Some первого элемента непустого списка, None для пустого. Сигнатура: list(int) => option(int).</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Ветка пустого списка → None', all: ['\\[\\]\\s*=>\\s*None'] },
          { desc: 'Ветка головы → Some', all: ['Some\\s*\\(\\s*\\w+\\s*\\)'] }
        ],
        note: 'let safeHead = (xs) => switch (xs) { | [] => None | [x, ...rest] => Some(x) };'
      },
      hints: [
        'Список-образцы: [] и [x, ...rest].',
        'Голова связывается с x.'
      ],
      solution: `let safeHead = (xs) =>
  switch (xs) {
    | [] => None
    | [x, ...rest] => Some(x)
  };`
    },

    {
      id: 'reason-5',
      title: 'Списки и рекурсия',
      goal: 'Обрабатывать списки рекурсивно с Accumulator',
      xp: 45,
      theory: [
        { t: 'p', html: 'Список Reason — иммутабельный связный список: <code>[1, 2, 3]</code>, разбор образцами <code>[]</code> и <code>[x, ...xs]</code>. Рекурсия — способ обхода; функция объявляется <code>let rec</code>, если вызывает себя.' },
        { t: 'code', code: `let rec sum = (xs) =>
  switch (xs) {
    | [] => 0
    | [x, ...rest] => x + sum(rest)
  };

sum([1, 2, 3, 4]);   /* 10 */` },
        { t: 'p', html: 'Хвостовая рекурсия с аккумулятором не растит стек: результат копится в параметре, вызов — последнее действие. Стандартные списочные функции: List.map, List.filter, List.foldLeft из Belt.' },
        { t: 'code', code: `let rec sumAcc = (xs, acc) =>
  switch (xs) {
    | [] => acc
    | [x, ...rest] => sumAcc(rest, acc + x)
  };` },
        { t: 'note', html: 'rec-рекурсия + match — идиоматичное ядро ML-языков. Быстрые последовательности — массивы <code>[|1, 2, 3|]</code> с изменением по индексу, когда иммутабельность не нужна.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что вернёт функция? Одно число.</p>',
        code: `let rec len = (xs) =>
  switch (xs) {
    | [] => 0
    | [_, ...rest] => 1 + len(rest)
  };
len([10, 20, 30, 40, 50, 60]);`,
        solution: `6`,
        ci: false
      },
      hints: [
        'Образец _ игнорирует значение элемента.',
        'Считается только количество.'
      ],
      solution: `6`
    },

    {
      id: 'reason-6',
      title: 'Records',
      goal: 'Объявлять типы-записи и обновлять их иммутабельно',
      xp: 50,
      theory: [
        { t: 'p', html: 'Запись: <code>type user = { name: string, age: int };</code>. Создание — литералом с теми же полями: <code>{name: "Боб", age: 25}</code>. Доступ — точкой. Обновление — <code>{...user, age: 26}</code> — spread-синтаксис создаёт новую запись.' },
        { t: 'code', code: `type user = { name: string, age: int };

let bob = { name: "Боб", age: 25 };
let older = { ...bob, age: 26 };

/* bob.age    == 25 — старая не изменилась
   older.age  == 26 */` },
        { t: 'p', html: 'Мутирующие поля возможны: <code>type counter = { mutable count: int }</code> — поле помечено mutable, изменение <code>c.count = c.count + 1</code>. По умолчанию всё иммутабельно — мутация осознанное решение.' },
        { t: 'code', code: `type counter = { mutable count: int };
let c = { count: 0 };
c.count = c.count + 1;
c.count = c.count + 1;
/* c.count == 2 */` },
        { t: 'note', html: 'Иммутабельные записи — фундамент React-модели: «новое состояние вместо изменения старого». Не случайно Reason и React выросли в одной команде.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь пропуски: объявление типа и иммутабельное обновление.</p>',
        code: `type point = { {{0}}: float, y: float };

let p = { x: 1.0, y: 2.0 };
let moved = { {{1}}p, y: 5.0 };`,
        blanks: [
          { answer: 'x' },
          { answer: '...' }
        ],
        ci: false
      },
      hints: [
        'Первое поле записи — x.',
        'Spread «...» копирует остальные поля.'
      ],
      solution: ['x', '...']
    },

    {
      id: 'reason-7',
      title: 'Модули',
      goal: 'Группировать код в модули и ограничивать интерфейсы',
      xp: 50,
      theory: [
        { t: 'p', html: 'Модуль — просто файл: <code>MathUtils.re</code> создаёт модуль MathUtils, доступ к его значениям — через точку: <code>MathUtils.add(1, 2)</code>. Вложенные модули — <code>module Sort = { … };</code> внутри файла. Интерфейс <code>.rei</code> описывает публичную часть.' },
        { t: 'code', code: `/* MathUtils.re */
let add = (a, b) => a + b;
let secret = 42;

module Ops = {
  let mul = (a, b) => a * b;
};

/* другой файл: */
let s = MathUtils.add(2, 3);
let m = MathUtils.Ops.mul(2, 3);` },
        { t: 'p', html: 'Модули Reason — «пространства имён с типами»: в них прячут детали и показывают интерфейс. Модульная система компилируется в JS-модули — интеграция с npm-миром прямая.' },
        { t: 'note', html: 'Открытие модуля <code>open MathUtils;</code> поднимает все его значения в текущую область — удобно, но злоупотреблять не стоит: имена перестают быть очевидными.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Как вызвать mul из вложенного модуля Ops файла MathUtils?</p>',
        options: [
          `mul(2, 3)`,
          `Ops.mul(2, 3)`,
          `MathUtils.Ops.mul(2, 3)`,
          `MathUtils.mul(2, 3)`
        ],
        correct: 2,
        explain: 'Путь строится через точки: сначала модуль-файл MathUtils, затем вложенный Ops, затем значение mul.'
      },
      hints: [
        'Имя файла — корневой модуль.',
        'Вложенные модули разделяются точкой.'
      ],
      solution: `MathUtils.Ops.mul(2, 3)`
    },

    {
      id: 'reason-8',
      title: 'Promise и Belt',
      goal: 'Работать с асинхронностью и стандартной библиотекой Belt',
      xp: 55,
      theory: [
        { t: 'p', html: 'Асинхронность — через JS-промисы: <code>Js.Promise.then_</code>, <code>catch</code>, <code>resolve</code>. Belt — современная стандартная библиотека: <code>Belt.Array</code>, <code>Belt.List</code>, <code>Belt.Map</code> — быстрый, типизированный, документированный набор.' },
        { t: 'code', code: `let p =
  Js.Promise.resolve(21)
  |> Js.Promise.then_(x => Js.Promise.resolve(x * 2))
  |> Js.Promise.then_(x => Js.Promise.resolve(x + 1))
  |> Js.Promise.catch(_ => Js.Promise.resolve(0));
/* итог: 43 */` },
        { t: 'p', html: 'Оператор <code>|&gt;</code> — пайп: передаёт значение первым аргументом следующей функции. Он превращает вложенные вызовы в конвейер — читается сверху вниз, как данные текут.' },
        { t: 'code', code: `/* пайпы вместо вложенности */
[1, 2, 3, 4]
  |> Belt.Array.filter(x => x > 2)
  |> Belt.Array.map(x => x * 10);
/* [30, 40] */` },
        { t: 'note', html: 'Пайп-оператор Reason — родич |> в Elixir и F#. Счастливый случай экосистемы:Bel t.List.map — те же map/filter/fold, что во всех функциональных языках.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери пайп: фильтр и преобразование.</p>',
        code: `[1, 2, 3, 4, 5]
  |> Belt.Array.{{0}}(x => x % 2 == 1)
  |> Belt.Array.{{1}}(x => x * x);`,
        blanks: [
          { answer: 'filter' },
          { answer: 'map' }
        ],
        ci: false
      },
      hints: [
        'Отбор по условию — filter.',
        'Преобразование — map.'
      ],
      solution: ['filter', 'map']
    },

    {
      id: 'reason-9',
      title: 'Функции высшего порядка',
      goal: 'Передавать функции и строить конвейеры',
      xp: 55,
      theory: [
        { t: 'p', html: 'Функции — значения: параметр типа <code>(int) =&gt; int</code> — функция из int в int. Композиция: <code>compose(f, g) = (x) =&gt; f(g(x))</code>. Каррирование встроено: <code>let add = (a) =&gt; (b) =&gt; a + b;</code> позволяет частичное применение.' },
        { t: 'code', code: `let twice = (f, x) => f(f(x));
twice(x => x * 3, 2);   /* 18 */

let add = (a) => (b) => a + b;
let add10 = add(10);
add10(5);   /* 15 */` },
        { t: 'p', html: 'Пайп + частичное применение = элегантные конвейеры данных. Функции сортировки принимают компаратор: <code>Array.sort((a, b) =&gt; a - b)</code> — поведение настраивается передачей функции.' },
        { t: 'code', code: `let prices = [500, 1200, 300];
let total =
  prices
  |> Belt.Array.filter(p => p > 400)
  |> Belt.Array.reduce(0, (acc, p) => acc + p);
/* 1700 */` },
        { t: 'note', html: 'reduce — свёртка: аккумулятор 0 и функция слияния. Все три комбинатора (map/filter/reduce) покрывают 90% обработки коллекций — и в Reason, и в любом другом языке.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что вернёт twice(x => x + 3, 1)?</p>',
        options: [
          `4`,
          `7`,
          `6`,
          `3`
        ],
        correct: 1,
        explain: 'twice применяет f два раза: 1 + 3 = 4, затем 4 + 3 = 7.'
      },
      hints: [
        'f(f(x)) — двойное применение.',
        'Сначала 1+3, потом результат снова +3.'
      ],
      solution: `7`
    },

    {
      id: 'reason-10',
      title: 'Проект: корзина покупок',
      goal: 'Собрать модуль: типы, вариант статуса, конвейер расчёта',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финальный проект — корзина: записи товаров, вариант результата, фильтрация пайпом, итог с reduce. Компактный домен показывает силу Reason: 15 строк типизированного кода заменяют сотни JS с ручными проверками.' },
        { t: 'code', code: `type item = { name: string, price: int, qty: int };

let cart = [
  { name: "книга",  price: 500,  qty: 1 },
  { name: "ручка",  price: 50,   qty: 3 },
  { name: "папка",  price: 0,    qty: 2 },
];

let total =
  cart
  |> Belt.Array.filter(i => i.price > 0)
  |> Belt.Array.reduce(0, (acc, i) => acc + i.price * i.qty);
/* 650 */

let status = (n) =>
  switch (n) {
    | 0 => "пусто"
    | _ => "к оплате: " ++ string_of_int(n)
  };` },
        { t: 'list', items: [
          '<b>type item</b> — доменная модель;',
          '<b>filter</b> отсекает нулевые цены;',
          '<b>reduce</b> сворачивает в сумму;',
          '<b>match</b> формирует текст статуса.'
        ] },
        { t: 'note', html: 'Добавь вариант Discounted(int) и учти его в расчёте — получишь полноценную логику промо. Компилятор сам подскажет все места для правки: в этом и есть сила строгих типов Reason.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые части расчёта.</p>',
        code: `cart
  |> Belt.Array.{{0}}(i => i.price > 0)
  |> Belt.Array.reduce({{1}}, (acc, i) => acc + {{2}}.price * i.qty);`,
        blanks: [
          { answer: 'filter' },
          { answer: '0' },
          { answer: 'i' }
        ],
        ci: false
      },
      hints: [
        'Отбор — filter, аккумулятор суммы стартует с нуля.',
        'Каждый элемент в reduce — i.'
      ],
      solution: ['filter', '0', 'i']
    }
  ]
};
