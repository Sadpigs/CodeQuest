'use strict';
/* ============ CodeQuest — курс REBOL ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.rebol = {
  id: 'rebol',
  title: 'REBOL',
  emoji: '🔴',
  color: '#cc2b2b',
  lang: 'rebol',
  tagline: 'Диалекты и message-язык: 10 уровней',
  description: 'Relative Expression Based Object Language Карла Сассенрата (1997): код — данные, данные — код, всё — значения с типами. За 10 уровней: values и words, блоки, функции, условия, циклы, серии, объекты, диалекты и финальный мини-язык на parse.',

  levels: [

    {
      id: 'rebol-1',
      title: 'Values: всё типизировано',
      goal: 'Понять, что любое значение REBOL знает свой тип',
      xp: 30,
      theory: [
        { t: 'p', html: 'REBOL — язык значений: каждое значение несёт собственный тип. <code>5</code> — integer!, <code>1.5</code> — decimal!, <code>"текст"</code> — string!, <code>10:30</code> — время!, <code>1-Jan-2024</code> — дата! Прямо в литералах — без объявлений и обёрток.' },
        { t: 'code', code: `print 5 + 3
print 2.5 * 2
print now/date            ; дата сегодня
print 12:00 + 3:30        ; 15:30 — время!

; вывод типов:
probe type? 5             ; integer!
probe type? "abc"         ; string!` },
        { t: 'p', html: '<code>print</code> — вывод с переводом строки, <code>probe</code> — показать значение «как есть» (с типом), <code>type?</code> — вернуть тип значения. Время и даты — полноценные значения с арифметикой: сложение времён, разность дат — работают из коробки.' },
        { t: 'list', items: [
          '<b>print</b> — вывести, <b>probe</b> — показать структуру;',
          '<b>type?</b> — тип значения;',
          'литералы: 3 (integer!), 3.5 (decimal!), 09:15 (time!), 5-Feb-2030 (date!);'
        ] },
        { t: 'note', html: 'Комментарии — точка с запятой <code>;</code> до конца строки. REBOL не требует объявлений: значения типизируются сами, но строго — «5 + "abc"» даст ошибку, а не строку.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь литералы: время и вывод значения.</p>',
        code: `{{0}} 10:00 + 2:00      ; 12:00
{{1}} type? 10:00       ; time!`,
        blanks: [
          { answer: 'print' },
          { answer: 'probe' }
        ],
        ci: false
      },
      hints: [
        'Вывод — print.',
        'Показ типа — probe.'
      ],
      solution: ['print', 'probe']
    },

    {
      id: 'rebol-2',
      title: 'Words и set-word',
      goal: 'Различать слова и их вычисление, присваивать двоеточием',
      xp: 35,
      theory: [
        { t: 'p', html: 'Слово (word!) — базовый элемент: <code>x</code> — слово. Присваивание — <code>x: 10</code> (set-word!, двоеточие после имени!). Кавычка перед словом <code>&apos;x</code> — «литеральное слово», без вычисления. Это триединость: значение, вычисление, символ.' },
        { t: 'code', code: `x: 10
y: x + 5
print y              ; 15

; различие:
probe 'x             ; слово x, не значение
probe x              ; 10` },
        { t: 'p', html: 'Присваивание двоеточием вместо «=» — фирменный стиль REBOL (унаследован от Forth/Lisp-культуры). Читается «x получает 10». Внутри выражений set-word работает и в середине: <code>a: 2 + 3 b: a * 10</code> — две привязки в одной строке.' },
        { t: 'note', html: 'Позже set-word сойдёт с ума красиво: `x: y: 5` присвоит пятерку обоим. А слово с двоеточием ПЕРЕД именем (get-word: :x) — «взять функцию, не вызывая».' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Присвой total значение 42 (через двоеточие!), затем doubled — total * 2, и выведи doubled.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Set-word total', all: ['total:\\s*42'] },
          { desc: 'Set-word doubled через total', all: ['doubled:\\s*total\\s*\\*\\s*2'] },
          { desc: 'Вывод print', all: ['print\\s+doubled'] }
        ],
        note: 'total: 42 / doubled: total * 2 / print doubled'
      },
      hints: [
        'Присваивание — имя: значение.',
        'Используй total в следующем выражении.'
      ],
      solution: `total: 42
doubled: total * 2
print doubled`
    },

    {
      id: 'rebol-3',
      title: 'Блоки: данные и код',
      goal: 'Создавать блоки [ ] — отложенные последовательности значений',
      xp: 40,
      theory: [
        { t: 'p', html: 'Блок <code>[1 + 2 print "hi"]</code> — последовательность значений, НЕ вычисляемая при создании. Блок — одновременно данные (список), код (исполняется do) и разметка. <code>first</code>, <code>second</code>, <code>last</code> берут элементы, <code>length?</code> — размер.' },
        { t: 'code', code: `data: [10 20 30 "текст" + 5]
print first data          ; 10
print length? data        ; 6

; блок как код:
code: [print 2 + 2]
do code                   ; 4` },
        { t: 'p', html: 'Ключевая идея: <b>код — данные</b>. Блок [print 2 + 2] можно сохранить в файл, передать по сети, изменить (append) и потом исполнить. Так работают все условные конструкции REBOL: if берёт БЛОК тела, потому что тело — просто данные до момента исполнения.' },
        { t: 'note', html: 'Двоеточие-литерал «перед блоком не ставят» — блок и так не вычисляется. Операции блоков: append (добавить), insert (вставить), remove, sort, copy (копия — иначе изменения пойдут в оригинал).' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Что напечатает программа?</p>',
        code: `block: [10 + 5 print "ok"]
print length? block`,
        options: [
          `2`,
          `5`,
          `15`,
          `ошибка вычисления`
        ],
        correct: 1,
        explain: 'Блок НЕ вычисляется при создании: внутри лежат сырые значения 10, +, 5, print, "ok" — всего 5 элементов. length? считает элементы блока, а не результат.'
      },
      hints: [
        'Блок хранит значения в сыром виде.',
        'Посчитай: 10, +, 5, print, "ok".'
      ],
      solution: `5 элементов: блок не вычисляется при создании`
    },

    {
      id: 'rebol-4',
      title: 'Функции func',
      goal: 'Определять функции со спецификацией и локальными переменными',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>func [спецификация] [тело]</code> — функция. Спецификация описывает аргументы и их типы: <code>func [a [integer!] b [integer!]] [a + b]</code>. Строка-документация перед аргументами становится справкой: <code>help имя-функции</code> её покажет.' },
        { t: 'code', code: `total: func [
    "Сумма с учётом скидки"
    price [decimal!]
    count [integer!]
][
    price * count
]

print total 9.99 3        ; 29.97` },
        { t: 'p', html: 'Функции возвращают последнее значение тела. Рефайнменты (опции) — /ключевые слова в спецификации: <code>func [s [series!] /all] [...]</code> вызывается <code>f data/all</code>. Локальные переменные — <code>/local x y</code> в конце спецификации.' },
        { t: 'code', code: `greet: func [name [string!] /upper /local msg] [
    msg: join "Привет, " name
    either upper [uppercase msg] [msg]
]

print greet "Аня"          ; Привет, Аня
print greet/upper "Аня"    ; ПРИВЕТ, АНЯ` },
        { t: 'note', html: 'join — склейка строк/значений, either — двухветвное условие-выражение. Refайнменты — элегантный ответ на «булевы флаги»: вместо f data true пишут f data/all — самодокументировано.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Определи функцию square для integer с телом a * a и выведи square 7.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'Функция через func', all: ['square:\\s*func\\s*\\['] },
          { desc: 'Тип integer в спецификации', all: ['\\[\\s*integer!\\s*\\]'] },
          { desc: 'Тело с умножением', all: ['\\w+\\s*\\*\\s*\\w+'] },
          { desc: 'Вызов print square 7', all: ['print\\s+square\\s+7'] }
        ],
        note: 'square: func [a [integer!]] [a * a] / print square 7'
      },
      hints: [
        'Форма: имя: func [арг [тип]] [тело].',
        'Вызов — print square 7 без скобок.'
      ],
      solution: `square: func [a [integer!]] [a * a]
print square 7`
    },

    {
      id: 'rebol-5',
      title: 'if, either, switch',
      goal: 'Управлять потоком: условия-функции с блоками',
      xp: 45,
      theory: [
        { t: 'p', html: 'В REBOL условия — обычные ФУНКЦИИ, принимающие блоки: <code>if условие [тело]</code>, <code>either условие [да] [нет]</code>, <code>switch значение [case1 [тело] case2 [тело]]</code>. Никаких ключевых слов if/then/else — только функции и блоки-данные.' },
        { t: 'code', code: `temp: 35

if temp > 30 [print "жара"]

either temp > 30 [
    print "лето"
][
    print "прохладно"
]

switch temp [
    30 [print "ровно 30"]
    35 [print "ровно 35"]
]` },
        { t: 'p', html: 'Сравнения — обычные операторы: =, &lt;&gt; (не равно), &lt;, &gt;, &lt;=, &gt;=. Логика: <code>and</code>, <code>or</code>, <code>not</code> (или в префиксе). either возвращает значение выбранной ветви — можно присваивать: <code>msg: either ok ["ок"] ["сбой"]</code>.' },
        { t: 'note', html: 'Тот факт, что if — функция, объясняет блоки: тело не вычисляется до передачи внутрь. Единообразие — «всё есть значение» работает и для управления потоком.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь формы условий: двухветвную и множественную.</p>',
        code: `score: 85
{{0}} score > 80 [print "хорошо"] [print "учись"]

{{1}} score [
    85 [print "A-"]
    100 [print "A+"]
]`,
        blanks: [
          { answer: 'either' },
          { answer: 'switch' }
        ],
        ci: false
      },
      hints: [
        'Две ветви — either.',
        'Много случаев — switch.'
      ],
      solution: ['either', 'switch']
    },

    {
      id: 'rebol-6',
      title: 'Циклы',
      goal: 'Повторения: loop, repeat, foreach, until',
      xp: 50,
      theory: [
        { t: 'p', html: 'Циклы — тоже функции с блоками. <code>loop n [тело]</code> — n раз. <code>repeat i n [тело]</code> — счётчик i. <code>foreach x список [тело]</code> — перебор. <code>until [тело]</code> — пока условие в теле не станет истинным.' },
        { t: 'code', code: `loop 3 [print "тик"]

repeat i 5 [print i * i]      ; 1 4 9 16 25

foreach day ["пн" "вт" "ср"] [
    print "день: " day
]

count: 0
until [
    count: count + 1
    count > 3
]` },
        { t: 'p', html: 'Ключевое слово <code>break</code> выходит из цикла. Перебор блоков/строк универсален: foreach работает со списками значений любых типов, а <code>forall</code> даёт позицию для продвинутых обходов.' },
        { t: 'note', html: 'Обрати внимание: repeat i 5 пробегает 1..5 — REBOL-циклы 1-индексные, как у людей, а не 0-индексные. foreach с блочной переменной не требует объявлений.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Что напечатает цикл? Перечисли числа через пробел.</p>',
        code: `total: 0
repeat i 4 [
    total: total + i
]
print total`,
        solution: `10`,
        ci: false
      },
      hints: [
        'i пробегает 1, 2, 3, 4.',
        'Сумма 1+2+3+4.'
      ],
      solution: `10`
    },

    {
      id: 'rebol-7',
      title: 'Серии: строки и файлы',
      goal: 'Обрабатывать строки (series) операциями блоков',
      xp: 50,
      theory: [
        { t: 'p', html: 'Строки — тоже <b>series</b>: те же операции, что для блоков. <code>copy</code> — копия, <code>find</code> — поиск (возвращает серию с позиции находки!), <code>insert</code>, <code>append</code>, <code>remove</code>, <code>length?</code> — размер. Файлы: <code>read %file.txt</code> читает, <code>write %out.txt данные</code> пишет.' },
        { t: 'code', code: `s: "привет мир"
print find s "мир"           ; мир (хвост с позиции!)
print length? s              ; 10
insert s "АБВ "              ; вставка в начало
print s                      ; АБВ привет мир

text: read %notes.txt
write %copy.txt text` },
        { t: 'p', html: 'УНИВЕРСАЛЬНОСТЬ: одна серия-операции для строк, блоков, файлов, URL — потому что всё они «последовательности значений». find вернул хвост — удобно для последовательного разбора: нашёл — срезал — нашёл дальше.' },
        { t: 'code', code: `; конвейер: разрезать по разделителю
text: "a,b,c"
parse text [collect [some [keep to "," skip | keep copy x to end]]]` },
        { t: 'note', html: 'Проценты перед именем — литерал файла (%file.txt), URL — литерал web: http://… — read умеет качать страницы. Вся сетевая работа — те же series-операции.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь операции серий: чтение файла и поиск подстроки.</p>',
        code: `text: {{0}} %data.txt
found: {{1}} text "ключевое"`,
        blanks: [
          { answer: 'read' },
          { answer: 'find' }
        ],
        ci: false
      },
      hints: [
        'Чтение файла — read %имя.',
        'Поиск — find серия подстрока.'
      ],
      solution: ['read', 'find']
    },

    {
      id: 'rebol-8',
      title: 'Объекты context',
      goal: 'Создавать объекты с полями и методами',
      xp: 55,
      theory: [
        { t: 'p', html: '<code>context [поля и функции]</code> создаёт объект. Поля — set-word-ами, методы — func-ами. Доступ — точкой: <code>obj.поле</code>. Наследование — <code>make parent [переопределения]</code>.' },
        { t: 'code', code: `counter: context [
    count: 0
    inc: func [/by n [integer!]] [
        count: count + any [n 1]
    ]
]

counter/inc
counter/inc/by 5
print counter.count        ; 6` },
        { t: 'p', html: 'Refайнмент /by с необязательным n и <code>any [n 1]</code> («первое непустое значение») — идиоматичный дефолт. Объекты REBOL — прототипные (как JS): клонируются make-ом, без классов.' },
        { t: 'note', html: 'self внутри context — сам объект. Полиморфизм через make-клонирование: parent-объект + изменения = новый объект. Просто и без ceremony классов.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь создание объекта и доступ к полю.</p>',
        code: `point: {{0}} [
    x: 3
    y: 4
]
print point.{{1}}`,
        blanks: [
          { answer: 'context' },
          { answer: 'x' }
        ],
        ci: false
      },
      hints: [
        'Объект создаётся context [ … ].',
        'Доступ — точка и имя поля.'
      ],
      solution: ['context', 'x']
    },

    {
      id: 'rebol-9',
      title: 'Parse: мини-диалекты',
      goal: 'Разбирать текст правилами диалекта parse',
      xp: 55,
      theory: [
        { t: 'p', html: '<code>parse серия правила</code> — парсер встроен в язык. Правила читаются почти как человеческая речь: <code>some [текст]</code> — «несколько раз», <code>skip</code> — любой символ, <code>to "x"</code> — до символа x, <code>|</code> — альтернатива. На parse строятся ЦЕЛЫЕ мини-языки — главная суперсила REBOL.' },
        { t: 'code', code: `text: "добавить 5 яблок"
rule: [
    "добавить" 
    copy num to " " 
    skip
    copy item to end
    (print "Добавили " num " " item)
]
parse text rule
; Добавили 5 яблок` },
        { t: 'p', html: '<code>copy имя to маркер</code> — захватить кусок в переменную, круглые скобки <code>(действие)</code> — исполняемый код внутри правил. Итераторы: some (1+), any (0+), opt (0..1). Разбор конфигов, команд, данных — десятки строк вместо внешних библиотек.' },
        { t: 'note', html: 'REBOL-диалекты вдохновили современные idea: LINQ, DSL-конфигурации, шаблоны «код как данные». Создатель REBOL называл это «message language» — язык сообщений между людьми и машиной.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши parse-правило: слово "старт", затем copy-захват до конца (to end) и действие (print target).</p>',
        starter: `TODO`,
        rules: [
          { desc: 'parse с текстом и правилом', all: ['parse\\s+\\w+\\s+\\['] },
          { desc: 'Слово старт в правиле', all: ['"старт"'] },
          { desc: 'copy-захват до конца', all: ['copy\\s+\\w+\\s+to\\s+end'] },
          { desc: 'Действие в скобках', all: ['\\(\\s*print\\s+\\w+\\s*\\)'] }
        ],
        note: 'parse text ["старт" copy target to end (print target)]'
      },
      hints: [
        'Сначала литерал "старт" в правиле.',
        'Затем copy имя to end и (print имя).'
      ],
      solution: `text: "старт компьютеры"
parse text [
    "старт"
    copy target to end
    (print target)
]`
    },

    {
      id: 'rebol-10',
      title: 'Проект: конфиг-язык приложения',
      goal: 'Собрать диалект: блок настроек, parse, объект-конфиг',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финал — конструктор конфигураций: пользователь пишет блок <code>[название "Чат" порт 8080 логи on]</code>, парсер превращает его в объект. Это фирменный стиль REBOL: данные-конфиг читаются человеком, исполняются машиной.' },
        { t: 'code', code: `config-block: [
    название "Чат-сервер"
    порт 8080
    логи on
]

cfg: context [
    name: ""
    port: 0
    logs: false
]

parse config-block [
    'название set cfg/name copy name to 'порт (cfg/name: name)
]` },
        { t: 'list', items: [
          '<b>Блок-конфиг</b> — данные и DSL одновременно;',
          '<b>set + copy</b> — захват значений в объект;',
          '<b>context</b> — целевой контейнер настроек;',
          '<b>литеральные слова</b> (&apos;название) — маркеры схемы.'
        ] },
        { t: 'note', html: 'Расширь проект: parse с some-итератором для любого числа настроек, валидация типов (integer!), дефолты через any. Такой «настроечный язык» — реальный продукт REBOL-культуры: пользователи описывали конфиги на почти-английском, не зная программирования.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые слова диалекта конфигурации.</p>',
        code: `parse config-block [
    {{0}} set cfg/name copy name to 'порт (cfg/name: name)
    {{1}} set cfg/port (integer!)
]`,
        blanks: [
          { answer: "'название" },
          { answer: "'порт" }
        ],
        ci: false
      },
      hints: [
        'Литеральные слова-маркеры начинаются с апострофа.',
        'Сначала маркер названия, затем порта.'
      ],
      solution: ["'название", "'порт"]
    }
  ]
};
