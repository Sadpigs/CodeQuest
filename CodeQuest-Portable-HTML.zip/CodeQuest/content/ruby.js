'use strict';
/* ============ CodeQuest — курс Ruby ============
   Ruby не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.ruby = {
  id: 'ruby',
  title: 'Ruby',
  emoji: '💎',
  color: '#701516',
  lang: 'ruby',
  tagline: 'Ruby: от puts до блоков, классов и исключений',
  description: 'Язык Юкихиро Мацумото (1995), построенный вокруг «радости программиста»: всё является объектом, а код читается почти как текст. На Ruby работает Rails — фундамент GitHub, Shopify и Airbnb. За 18 уровней пройдёшь путь от puts до блоков и yield, procs и лямбд, классов с attr_accessor, модулей-миксинов и исключений — финал: проект «Список дел» на двух классах.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'ruby-1',
      title: 'Первая программа',
      goal: 'Написать первую программу на Ruby: команда puts со строкой — и ничего лишнего',
      xp: 30,
      theory: [
        { t: 'p', html: 'Ruby придумал Юкихиро Мацумото (друзья зовут его Мац) в 1995 году с явной целью сделать программистов счастливыми: «Я хотел язык, который был бы удобен прежде всего мне самому». Философия — «радость программиста» и принцип наименьшего удивления. На Ruby построен фреймворк Rails, а на Rails — GitHub, Shopify и Airbnb. Ruby ценят за выразительность: его код читается почти как английский текст.' },
        { t: 'h', html: 'Минимальная программа' },
        { t: 'code', code: `puts "Привет, CodeQuest!"` },
        { t: 'p', html: 'Одна строка — уже целая программа. Не нужны ни точка с запятой, ни каркас вида main(), ни закрывающие скобки: Ruby пишет то, что нужно, и ничего сверх. Запуск: сохрани код в файл <code>main.rb</code> и выполни в терминале <code>ruby main.rb</code>. Для экспериментов есть <code>irb</code> — интерактивная консоль: пишешь строку, ответ приходит сразу.' },
        { t: 'p', html: 'Точки с запятой не нужны — конец строки сам завершает инструкцию. Комментарии начинаются с решётки. Фигурных скобок для блоков кода почти нет — вместо них ключевое слово <code>end</code>, а отступы (два пробела — стандарт сообщества) помогают глазу видеть структуру.' },
        { t: 'list', items: [
          '<b>puts</b> — вывод строки с переносом в конце;',
          '<b>print</b> — вывод без переноса, <b>p</b> — вывод «как есть» для отладки;',
          '<b>#</b> — комментарий до конца строки;',
          '<b>end</b> — закрывает любой блок: метод, класс, условие, цикл.'
        ] },
        { t: 'note', html: 'В Ruby всё является объектом — даже числа: у единицы есть методы (<code>1.to_s</code>), у строки тоже (<code>"код".upcase</code>). Не всё сразу понятно, но привычка «у всего есть методы» будет кормить тебя весь курс.' },
        { t: 'warn', html: 'В этом приложении Ruby-код не запускается — задания проверяются по структуре кода, квизами и задачами «предскажи вывод». Синтаксис тем не менее настоящий: всё, что ты напишешь, заработает в настоящем интерпретаторе Ruby без правок.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первую программу: одна команда <code>puts</code> со строкой-приветствием в кавычках. Точка с запятой Ruby не нужна — просто строка кода.</p>',
        starter: `# TODO: поздоровайся с миром — команда вывода и строка`,
        rules: [
          { desc: 'Вывод через puts (или print / p)', any: ['\\bputs\\b', '\\bprint\\b', '\\bp\\s+"', "\\bp\\s+'"] },
          { desc: 'Выводится непустая строка в кавычках', any: ['"[^"\\s][^"]*"', "'[^'\\s][^']*'"] },
          { desc: 'Точки с запятой не нужны — конец строки и так завершает инструкцию', all: ['\\S'], none: [';'] },
          { desc: 'Пометок TODO не осталось', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Вся программа — одна строка: puts "текст".',
        'Кавычки — двойные или одинарные, главное — парные.',
        'Строку с TODO замени настоящим выводом; точки с запятой не ставь.'
      ],
      solution: `puts "Привет, CodeQuest!"`
    },

    /* ---------- 2. Переменные и интерполяция ---------- */
    {
      id: 'ruby-2',
      title: 'Переменные и интерполяция',
      goal: 'Создавать переменные присваиванием и подставлять значения в строки через #{...}',
      xp: 30,
      theory: [
        { t: 'p', html: 'Переменные создаются простым присваиванием: <code>name = "Аня"</code> — без ключевых слов и без знака доллара (это PHP-стиль, в Ruby он не нужен). Тип определяется значением, а узнать его можно методом <code>.class</code>: <code>20.class</code> → <code>Integer</code>, <code>1.5.class</code> → <code>Float</code>, <code>"код".class</code> → <code>String</code>.' },
        { t: 'code', code: `name = "Аня"
age = 20
height = 1.68
student = true

puts "Привет, #{name}!"` },
        { t: 'p', html: '<b>Интерполяция</b> — двойные кавычки и решётка с фигурными скобками: <code>#{выражение}</code>. Внутри можно любое выражение: <code>"Через год мне #{age + 1}"</code>. В одинарных кавычках интерполяции нет: <code>\'Привет, #{name}\'</code> выведется буквально, со скобками. Зеркальное правило PHP — там то же самое, только со знаком доллара.' },
        { t: 'table', head: ['Тип', 'Пример', '.class'], rows: [
          ['целое', '<code>42</code>, <code>-7</code>', '<code>Integer</code>'],
          ['дробное', '<code>1.68</code>', '<code>Float</code>'],
          ['строка', '<code>"текст"</code>', '<code>String</code>'],
          ['истина/ложь', '<code>true</code>, <code>false</code>', '<code>TrueClass</code> / <code>FalseClass</code>'],
          ['«ничего»', '<code>nil</code>', '<code>NilClass</code>']
        ] },
        { t: 'p', html: 'Имена переменных — snake_case: маленькими буквами, слова через подчёркивание: <code>total_price</code>, <code>first_name</code>. Стиль CamelCase (<code>TotalPrice</code>) оставь для классов — компилятор не запретит, но сообщество скажет спасибо.' },
        { t: 'warn', html: 'Интерполяция работает только в двойных кавычках. Написал <code>puts \'Привет, #{name}\'</code> — получил в выводе фигурные скобки как есть. Вторая ловушка: <code>nil</code> — «значения нет»; не путай с пустой строкой <code>""</code> — та тоже строка, просто без символов, и методы у неё есть.' },
        { t: 'note', html: 'Переменную можно переопределить и даже сменить у неё тип — Ruby динамический: <code>age = 20</code>, а потом <code>age = "двадцать"</code>. Свобода без ответственности: следи сам, что лежит в переменной, — интерпретатор предупреждать не станет.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Допиши метеоскрипт: подставь температуру (целое число 18), интерполяцию переменной <code>city</code> в двойных кавычках и прибавление пяти к <code>temp</code> внутри шаблона.</p>',
        code: `city = "Москва"
temp = {{0}}

puts "В городе {{1}} сейчас #{temp}°C"
puts 'Шаблон не сработает: #{temp}'
puts "Через пять градусов: #{temp {{2}}}°C"`,
        blanks: [
          { answer: '18' },
          { answer: '#{city}' },
          { answer: '+ 5' }
        ],
        ci: false
      },
      hints: [
        'Первый пропуск — просто число без кавычек.',
        'Второй — интерполяция: решётка, фигурные скобки, имя переменной внутри.',
        'Внутри #{...} можно вычислять выражения: #{temp + 5}.'
      ],
      solution: ['18', '#{city}', '+ 5']
    },

    /* ---------- 3. Условия ---------- */
    {
      id: 'ruby-3',
      title: 'Условия: if, elsif, unless',
      goal: 'Ветвить программу через if / elsif / else, знать unless и помнить, что в Ruby ложны только false и nil',
      xp: 30,
      theory: [
        { t: 'p', html: 'Условия в Ruby — это <code>if</code>, <code>elsif</code>, <code>else</code> и закрывающий <code>end</code>. Условие пишется без круглых скобок, тело — с отступом, блок закрывается словом <code>end</code>. Слово <code>elsif</code> — одним куском, без «e» внутри!' },
        { t: 'code', code: `temp = 15

if temp >= 25
  puts "Жарко"
elsif temp >= 10
  puts "Нормально"
else
  puts "Холодно"
end` },
        { t: 'p', html: '<code>unless</code> — «если НЕ»: тело выполняется, когда условие ложно. И фирменный модификатор-стиль: <code>puts "Идём" if temp &gt; 10</code> — условие пишется после инструкции. Код начинает читаться как английские фразы: <code>do_something unless done</code> — «сделай, если ещё не сделано».' },
        { t: 'code', code: `raining = false

unless raining
  puts "Зонт не нужен"
end

temp = 22
puts "Идём гулять" if temp > 10` },
        { t: 'table', head: ['Оператор', 'Смысл'], rows: [
          ['<code>==</code> <code>!=</code>', 'равно / не равно'],
          ['<code>&gt;</code> <code>&lt;</code> <code>&gt;=</code> <code>&lt;=</code>', 'сравнения'],
          ['<code>&amp;&amp;</code> и <code>||</code>', '«И» и «ИЛИ» (можно словами and / or)'],
          ['<code>!</code> и <code>not</code>', 'отрицание'],
          ['<code>? :</code>', 'тернарный: cond ? a : b']
        ] },
        { t: 'warn', html: 'Главная ловушка Ruby: ложны ТОЛЬКО <code>false</code> и <code>nil</code>. Число <code>0</code> — истина! Пустая строка <code>""</code> — истина! Пришедшие из C или JavaScript регулярно обжигаются: <code>if 0</code> в Ruby сработает, а в C — нет.' },
        { t: 'note', html: 'Сравнение <code>==</code> возвращает <code>true</code> или <code>false</code> — их можно присваивать: <code>is_even = n % 2 == 0</code>. Методы-вопросы Ruby принято называть со знаком вопроса: <code>4.even?</code> → <code>true</code>, <code>"код".empty?</code> → <code>false</code>. Об этом ещё будет разговор в уровне про методы.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет этот код?</p><pre>count = 0

if count
  puts "раз"
end

unless count == 0
  puts "два"
end</pre>`,
        options: [
          'ничего не выведет',
          'два',
          'раз',
          'раз два'
        ],
        correct: 2,
        explain: 'В Ruby ложны только false и nil. Число 0 — истина, значит ветка if срабатывает: печатается «раз». Сравнение count == 0 даёт true, а unless выполняется при ЛОЖНОМ условии — поэтому «два» не печатается.',
        solution: 2
      },
      hints: [
        'Вспомни: что в Ruby считается ложным? Перечитай warn-блок теории.',
        'unless — это «если не»: тело выполняется, только когда условие ложно.'
      ],
      solution: 2
    },

    /* ---------- 4. Циклы ---------- */
    {
      id: 'ruby-4',
      title: 'Циклы: times, while, each',
      goal: 'Повторять код через 3.times и while и обходить массивы через each',
      xp: 40,
      theory: [
        { t: 'p', html: '<code>times</code> — фирменный цикл Ruby: <code>3.times { ... }</code> повторяет блок трижды. Параметр блока <code>|i|</code> получает номер шага, причём нумерация начинается с нуля: 0, 1, 2.' },
        { t: 'code', code: `3.times do |i|
  puts "Шаг #{i}"
end

# то же самое одной строкой:
3.times { |i| puts i }` },
        { t: 'p', html: '<code>each</code> обходит массив: <code>[2, 5, 3].each do |n| ... end</code> — на каждом шаге <code>n</code> — очередной элемент. <code>while</code> — классика: крутится, пока условие истинно. Есть и <code>until</code> — «пока НЕ станет истинным», зеркальный брат <code>unless</code>.' },
        { t: 'code', code: `total = 0
[2, 5, 3].each do |n|
  total = total + n
end
puts total # 10

k = 10
while k > 2
  k = k - 3
end
puts k # 1` },
        { t: 'list', items: [
          '<b>break</b> — выйти из цикла немедленно;',
          '<b>next</b> — пропустить остаток текущего шага (аналог continue);',
          '<b>1.upto(5) { |i| ... }</b> и <b>5.downto(1)</b> — перебор по возрастанию и убыванию;',
          '<b>(1..3).each</b> — тоже перебор, диапазон в круглых скобках.'
        ] },
        { t: 'warn', html: 'Прокручивая while в голове, следи за условием: цикл делает шаг, ПОКА условие истинно, и выходит, как только оно стало ложным. Ошибка на единицу — самая частая ошибка «предсказаний»: не останавливайся раньше и не делай лишний шаг.' },
        { t: 'note', html: 'Блоки <code>do ... end</code> и <code>{ }</code> равнозначны; договорённость сообщества: многострочные — <code>do ... end</code>, однострочные — фигурные скобки. К блокам мы вернёмся в уровне 9: <code>map</code> и <code>select</code> — те же блоки, только возвращающие результат.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай код и напиши всё, что он выведет в консоль, — по одной строке на каждый вывод, в порядке появления.</p>',
        code: `total = 0
[2, 5, 3].each do |n|
  total = total + n
end
puts "total: #{total}"

3.times do |i|
  puts "row#{i}"
end

k = 10
while k > 2
  k = k - 3
end
puts "k: #{k}"`,
        answer: `total: 10
row0
row1
row2
k: 1`
      },
      hints: [
        'each складывает 2 + 5 + 3 — сумма равна 10.',
        'times нумерует шаги с нуля: i принимает значения 0, 1, 2.',
        'while уменьшает k на 3: 10 → 7 → 4 → ... Поймай момент, когда условие k > 2 станет ложным.'
      ],
      solution: `total: 10
row0
row1
row2
k: 1`
    },

    /* ---------- 5. Массивы и строки ---------- */
    {
      id: 'ruby-5',
      title: 'Массивы и строки',
      goal: 'Работать с массивами (длина, добавление, join) и строковыми методами upcase / reverse',
      xp: 40,
      theory: [
        { t: 'p', html: 'Массив — список значений в квадратных скобках. Индексация с нуля, а отрицательные индексы считают с конца: <code>arr[-1]</code> — последний элемент. Длину дают <code>.length</code> и <code>.size</code> — это синонимы.' },
        { t: 'code', code: `words = ["рубин", "код", "блок"]

puts words[0]      # рубин
puts words[-1]     # блок — последний
puts words.length  # 3` },
        { t: 'p', html: 'Добавление: <code>words.push("x")</code> или короче — <code>words &lt;&lt; "x"</code>. Удаление: <code>words.delete("код")</code> по значению или <code>words.delete_at(0)</code> по индексу. А <code>.first</code> и <code>.last</code> дают первый и последний элемент без всяких индексов.' },
        { t: 'h', html: 'Строки — тоже объекты с методами' },
        { t: 'code', code: `s = "codequest"

puts s.upcase             # CODEQUEST
puts s.capitalize         # Codequest
puts s.reverse            # tseuqedoc
puts s.include?("quest")  # true
puts s.length             # 9` },
        { t: 'p', html: '<code>.join</code> склеивает массив в строку с разделителем: <code>["а", "б"].join(", ")</code> → <code>"а, б"</code>. Обратное — <code>.split</code>: <code>"а, б".split(", ")</code> → массив. Пара join/split встречается в Ruby повсюду — от обработки файлов до парсинга CSV.' },
        { t: 'table', head: ['Выражение', 'Результат'], rows: [
          ['<code>arr.length</code> / <code>arr.size</code>', 'длина массива'],
          ['<code>arr &lt;&lt; "x"</code> / <code>arr.push("x")</code>', 'дописать элемент'],
          ['<code>arr.first</code> / <code>arr.last</code>', 'первый / последний'],
          ['<code>s.upcase</code> / <code>s.downcase</code>', 'регистр'],
          ['<code>s.reverse</code>', 'строка наоборот'],
          ['<code>arr.join(", ")</code>', 'элементы → одна строка'],
          ['<code>s.split(", ")</code>', 'строка → массив']
        ] },
        { t: 'warn', html: 'Методы с восклицательным знаком меняют объект на месте: <code>s.upcase!</code> переписывает саму <code>s</code>, а <code>s.upcase</code> возвращает новую строку, не трогая старую. Забыл восклицательный знак — получил копию и удивился. Это правило Ruby: «!» — осторожно, мутация.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери программу-словарик: массив минимум из трёх слов, добавь ещё два элемента (один раз через <code>.push</code> или <code>&lt;&lt;</code> — второй способ тоже можно), выведи количество слов, склей список через <code>.join</code> и покажи, что умеют строки: <code>.upcase</code>, <code>.downcase</code>, <code>.reverse</code> или <code>.capitalize</code> — хотя бы один из них.</p>',
        starter: `# TODO: собери список слов и проделай операции из условия`,
        rules: [
          { desc: 'Создан массив с элементами', any: ['\\[\\s*["\']', '\\[\\s*\\d', '%w\\['] },
          { desc: 'Длина через .length или .size', any: ['\\.length\\b', '\\.size\\b'] },
          { desc: 'Добавление элемента: .push(...) или <<', any: ['\\.push\\s*\\(', '<<\\s*'] },
          { desc: 'Склейка через .join(...)', all: ['\\.join\\s*\\('] },
          { desc: 'Строковый метод: upcase/downcase/reverse/capitalize', any: ['\\.upcase\\b', '\\.downcase\\b', '\\.reverse\\b', '\\.capitalize\\b'] },
          { desc: 'Вывод через puts/print, пометок TODO нет', any: ['\\bputs\\b', '\\bprint\\b'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Массив: words = ["рубин", "код", "блок"]. Добавление: words << "объект" или words.push("объект").',
        'Количество: words.length. Склейка: words.join(", ").',
        'Строковые методы вешаются цепочкой: words.first.upcase — сначала first, потом upcase.'
      ],
      solution: `words = ["рубин", "код", "блок"]
words.push("объект")
words << "класс"

puts words.length
puts words.join(", ")
puts words.first.upcase
puts words.last.reverse`
    },

    /* ---------- 6. Методы ---------- */
    {
      id: 'ruby-6',
      title: 'Методы: def и неявный return',
      goal: 'Объявлять методы через def ... end, понимать неявный return и параметры по умолчанию',
      xp: 40,
      theory: [
        { t: 'p', html: 'Метод объявляется через <code>def имя ... end</code>. Параметры перечисляются в скобках; при вызове скобки часто опускают — Ruby и так всё поймёт (но в спорных случаях ставь их). Главная фишка: метод возвращает значение <b>последнего выражения</b> — даже без <code>return</code>.' },
        { t: 'code', code: `def add(a, b)
  a + b          # последнее выражение — результат
end

def greet(name = "гость")
  "Привет, #{name}!"
end

puts add(2, 3)     # 5
puts greet         # Привет, гость!
puts greet("Аня")  # Привет, Аня!` },
        { t: 'p', html: '<code>return</code> тоже существует — он завершает метод немедленно. Его удобно использовать с модификатором-если, который ты знаешь из уровня 3:' },
        { t: 'code', code: `def sign(n)
  return "плюс" if n > 0
  return "минус" if n < 0
  "ноль"
end` },
        { t: 'table', head: ['Приём', 'Что происходит'], rows: [
          ['<code>a + b</code> (последняя строка)', 'неявный return — значение вернётся само'],
          ['<code>return x</code>', 'явный выход со значением'],
          ['<code>def f(x = 5)</code>', 'параметр по умолчанию'],
          ['<code>f 2, 3</code>', 'вызов без скобок — то же, что f(2, 3)'],
          ['<code>имя?</code>', 'метод-вопрос, возвращает true/false'],
          ['<code>имя!</code>', 'метод-мутатор, меняет объект на месте']
        ] },
        { t: 'warn', html: 'Локальные переменные снаружи метода внутрь не попадают — параметры и есть вход. И нечаянная ловушка неявного return: если последней строкой метода окажется <code>puts</code>, метод вернёт <code>nil</code> (puts всегда возвращает nil!). Хочешь вернуть значение — последней строкой должно быть само значение, а не его вывод.' },
        { t: 'note', html: 'Методы-предикаты — со знаком вопроса: <code>def adult?(age) age &gt;= 18 end</code> — вызов <code>adult?(20)</code> → <code>true</code>. Ruby разрешает <code>?</code> и <code>!</code> прямо в имени метода — редкая фишка, из-за которой код читается как речь: <code>list.empty?</code> — «список пуст?».' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет этот код (две строки)?</p><pre>def mystery(n)
  n = n * 2
  n &gt; 10
end

x = 4
result = mystery(x)
puts result
puts x</pre>`,
        options: [
          'true, затем 4',
          '8, затем 4',
          'false, затем 4',
          'false, затем 2'
        ],
        correct: 2,
        explain: 'Тело метода: сначала n = n * 2 — локальная копия стала 8, затем последнее выражение n > 10 — оно и вернулось неявно: 8 > 10 → false. Внешняя x не изменилась: параметр — копия значения. Итого: false, затем 4.',
        solution: 2
      },
      hints: [
        'Последнее выражение метода возвращается само — здесь это сравнение n > 10.',
        'Параметр n — копия значения x: что бы ни происходило внутри, снаружи x остаётся прежней.'
      ],
      solution: 2
    },

    /* ---------- 7. Классы ---------- */
    {
      id: 'ruby-7',
      title: 'Классы и объекты',
      goal: 'Описать класс с initialize и переменными экземпляра @, создать объект через Book.new и вызвать его метод',
      xp: 50,
      theory: [
        { t: 'p', html: 'Класс — чертёж: <code>class Имя ... end</code>, имя с большой буквы в стиле CamelCase. Внутри объявляют <code>initialize</code> (конструктор) и методы. Данные конкретного объекта хранятся в <b>переменных экземпляра</b> — они начинаются с собачки: <code>@title</code>. Объект создаётся через <code>Класс.new(...)</code>, методы вызываются точкой.' },
        { t: 'code', code: `class User
  attr_accessor :name

  def initialize(name)
    @name = name
  end

  def greet
    "Привет, я #{@name}!"
  end
end

user = User.new("Аня")

puts user.name   # Аня
puts user.greet  # Привет, я Аня!` },
        { t: 'p', html: '<code>initialize</code> вызывается автоматически при <code>.new</code> — его параметры передаются в скобках: <code>User.new("Аня")</code>. Переменная <code>@name</code> живёт внутри объекта и доступна во всех его методах — у каждого экземпляра своя, собственная.' },
        { t: 'p', html: '<code>attr_reader :name</code> создаёт метод для чтения <code>@name</code>; <code>attr_writer</code> — для записи (<code>name=</code>); <code>attr_accessor</code> — оба сразу. Без них снаружи к <code>@name</code> не добраться: Ruby не даёт трогать внутренности объекта напрямую, всё через методы.' },
        { t: 'table', head: ['Кусочек', 'Роль'], rows: [
          ['<code>class Book ... end</code>', 'чертёж объекта'],
          ['<code>@title</code>', 'переменная экземпляра — данные объекта'],
          ['<code>def initialize</code>', 'конструктор, срабатывает при .new'],
          ['<code>attr_reader :title</code>', 'геттер — доступ на чтение'],
          ['<code>book.title</code>', 'чтение поля через геттер'],
          ['<code>book.greet</code>', 'вызов обычного метода']
        ] },
        { t: 'warn', html: 'Две конвенции, по которым rubyist виден сразу: классы — CamelCase, методы и переменные — snake_case. И не пиши скобки там, где читаемость важнее: <code>book.greet</code> чище, чем <code>book.greet()</code>. Символы вроде <code>:name</code> (двоеточие плюс слово) — неизменяемые «имена»; разберём их в уровне 8, а <code>attr_accessor</code> принимает именно их.' },
        { t: 'note', html: '<code>new</code> — метод самого класса: <code>Book.new</code> создаёт экземпляр и тут же вызывает <code>initialize</code> с теми же аргументами. Забыл <code>initialize</code> — объект создастся «пустым», а обращение к <code>@title</code> вернёт <code>nil</code>, а не ошибку.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери класс <code>Book</code>: конструктор <code>initialize</code>, который заполняет переменные экземпляра <code>@...</code>, метод, возвращающий описание книги, и создание объекта <code>Book.new(...)</code> с вызовом метода. <code>attr_reader</code> — по желанию.</p>',
        starter: `# TODO: класс книги — конструктор, поля, метод описания

# TODO: создай объект и вызови его метод`,
        rules: [
          { desc: 'Класс объявлен и закрыт end-ом: class Book ... end', all: ['class\\s+Book\\b', '\\bend\\b'] },
          { desc: 'Конструктор initialize объявлен', all: ['def\\s+initialize\\b'] },
          { desc: 'Переменная экземпляра @имя присваивается', all: ['@\\w+\\s*='] },
          { desc: 'Объявлен метод (def имя)', all: ['def\\s+\\w+'] },
          { desc: 'Объект создаётся через Book.new(...)', all: ['Book\\.new'] },
          { desc: 'Метод объекта вызывается, пометок TODO нет', all: ['new\\b[\\s\\S]*\\.\\w+'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас: class Book ... def initialize(title, author) ... @title = title ... end ... end',
        'Метод: def describe ... "#{@title} — #{@author}" ... end — последнее выражение вернётся само.',
        'Снаружи: book = Book.new("Мёртвые души", "Гоголь"), затем puts book.describe'
      ],
      solution: `class Book
  attr_reader :title, :author

  def initialize(title, author)
    @title = title
    @author = author
  end

  def describe
    "#{@title} — #{@author}"
  end
end

book = Book.new("Мастер и Маргарита", "Булгаков")

puts book.describe
puts book.title`
    },

    /* ---------- 8. Хэши и символы ---------- */
    {
      id: 'ruby-8',
      title: 'Хэши и символы',
      goal: 'Хранить пары ключ-значение в хэше {key: val} и понимать, что такое символы :sym',
      xp: 45,
      theory: [
        { t: 'p', html: 'Хэш — пары «ключ → значение» в фигурных скобках. Современный синтаксис: <code>{ name: "Аня", age: 20 }</code> — ключи становятся <b>символами</b>. Символ <code>:name</code> — неизменяемое «имя»: два одинаковых символа в программе — один и тот же объект, поэтому их и используют как ключи.' },
        { t: 'code', code: `prices = { coffee: 150, tea: 90 }

puts prices[:coffee]   # 150
prices[:juice] = 120   # добавили пару

prices.each do |name, price|
  puts "#{name}: #{price}"
end` },
        { t: 'p', html: 'Доступ — по символу в квадратных скобках: <code>prices[:coffee]</code>. Старый синтаксис тоже встречается в чужом коде: <code>{ "coffee" =&gt; 150 }</code> — со «стрелкой» можно использовать любые ключи, включая строки.' },
        { t: 'table', head: ['Приём', 'Результат'], rows: [
          ['<code>h[:key]</code>', 'значение (nil, если ключа нет)'],
          ['<code>h[:key] = v</code>', 'добавить или перезаписать пару'],
          ['<code>h.key?(:key)</code> / <code>h.include?(:key)</code>', 'есть ли ключ (true/false)'],
          ['<code>h.keys</code> / <code>h.values</code>', 'массив ключей / массив значений'],
          ['<code>h.length</code>', 'количество пар'],
          ['<code>h.each { |k, v| }</code>', 'перебор пар']
        ] },
        { t: 'warn', html: 'Читаешь отсутствующий ключ — получаешь <code>nil</code>, ошибки нет. Это удобно (<code>if prices[:sale]</code>) и опасно: опечатка в ключе не упадёт, а тихо вернёт nil. Для строгого доступа есть <code>h.fetch(:key)</code> — он поднимает KeyError, если ключа нет.' },
        { t: 'note', html: 'Сокращения арифметики работают и с хэшами: <code>stock[:pens] += 2</code> — то же, что <code>stock[:pens] = stock[:pens] + 2</code>. Символы чуть быстрее строк и экономят память при повторении — поэтому <code>:name</code> вместо <code>"name"</code> в ключах это идиома, а не каприз.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет этот код (три строки)?</p><pre>stock = { pens: 3, books: 7 }
stock[:pens] += 2
puts stock.length
puts stock[:pens]
puts stock.include?(:markers)</pre>`,
        options: [
          '2, затем 5, затем true',
          '3, затем 5, затем false',
          '2, затем 5, затем false',
          '2, затем 6, затем false'
        ],
        correct: 2,
        explain: 'В хэше две пары — length даёт 2. stock[:pens] += 2 превращает 3 в 5; ключ уже существовал, новой пары не появилось, поэтому length не изменился. Ключа :markers в хэше нет — include? даёт false.',
        solution: 2
      },
      hints: [
        '+= не добавляет новый ключ, а меняет существующий — length остаётся прежним.',
        'include? проверяет наличие ключа: :markers в хэше нет.'
      ],
      solution: 2
    },

    /* ---------- 9. Блоки и итераторы ---------- */
    {
      id: 'ruby-9',
      title: 'Блоки, map и select',
      goal: 'Передавать методы блоки { |n| ... } и do ... end, преобразовывать массивы через map и фильтровать через select',
      xp: 45,
      theory: [
        { t: 'p', html: '<b>Блок</b> — кусок кода, который ты передаёшь методу: либо в фигурных скобках <code>{ |x| ... }</code>, либо между <code>do</code> и <code>end</code>. Метод сам решает, сколько раз блок выполнится: <code>each</code> — на каждом элементе, <code>times</code> — N раз. Вертикальные черты — параметры блока.' },
        { t: 'code', code: `numbers = [1, 2, 3, 4, 5, 6]

numbers.each { |n| puts n }   # по одному

numbers.each do |n|
  puts n * 2                  # то же, но с умножением
end` },
        { t: 'p', html: '<code>map</code> <b>преобразует</b>: возвращает новый массив из результатов блока. <code>select</code> <b>отбирает</b>: возвращает элементы, для которых блок вернул <code>true</code>. <code>reject</code> — наоборот, выкидывает такие элементы. Это и есть функциональный стиль Ruby — вместо ручных циклов с аккумуляторами.' },
        { t: 'code', code: `numbers = [1, 2, 3, 4, 5]

squares = numbers.map { |n| n * n }
puts squares.inspect    # [1, 4, 9, 16, 25]

evens = numbers.select { |n| n.even? }
puts evens.inspect      # [2, 4]` },
        { t: 'table', head: ['Метод', 'Что делает'], rows: [
          ['<code>each</code>', 'просто перебрать; возвращает исходный массив'],
          ['<code>map</code>', 'новый массив из результатов блока'],
          ['<code>select</code>', 'оставить те, где блок дал true'],
          ['<code>reject</code>', 'выкинуть те, где блок дал true'],
          ['<code>sum</code> / <code>min</code> / <code>max</code>', 'сумма / минимум / максимум'],
          ['<code>sort</code> / <code>reverse</code>', 'отсортировать / перевернуть']
        ] },
        { t: 'p', html: 'Блоки можно чейнить — соединять конвейером: <code>numbers.map { |n| n * 2 }.select { |n| n &gt; 4 }</code> — сначала удвоили, потом отобрали. Читается слева направо, как поток данных. А <code>.inspect</code> показывает объект «как есть» — удобно для вывода массивов.' },
        { t: 'warn', html: '<code>map</code> возвращает НОВЫЙ массив и исходный не трогает (мутация — это <code>map!</code>, осторожно). Не путай <code>each</code> и <code>map</code>: each возвращает исходный массив, его результат обычно выбрасывают, а map — именно собирает. Хочешь посчитать сумму — <code>numbers.sum</code>, а не цикл с ручным аккумулятором (хотя и цикл никто не запрещает).' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Обработай массив блоками: наполни массив <code>numbers</code> числами, пропусти его через <code>.map</code> с блоком-преобразованием и через <code>.select</code> (или <code>.reject</code>) с блоком-фильтром. У блоков должен быть свой параметр <code>|n|</code>. Результаты выведи через <code>puts</code> — удобно с <code>.inspect</code>.</p>',
        starter: `numbers = [] # TODO: наполни массив и обработай блоками

# TODO: выведи результаты преобразования и отбора`,
        rules: [
          { desc: 'Создан массив с элементами', any: ['\\[\\s*["\']', '\\[\\s*\\d', '%w\\['] },
          { desc: 'Блок с параметром: |имя| — у { } или do ... end', all: ['\\|\\s*\\w+\\s*\\|'] },
          { desc: 'Преобразование через .map', all: ['\\.map\\b'] },
          { desc: 'Отбор через .select или .reject', any: ['\\.select\\b', '\\.reject\\b'] },
          { desc: 'Результат выводится через puts/print/p', any: ['\\bputs\\b', '\\bprint\\b', '\\bp\\s+'] },
          { desc: 'Код непустой, пометок TODO нет', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Параметр блока пишется между чертами: numbers.map { |n| n * n }.',
        'Фильтр: numbers.select { |n| n >= 4 } — блок возвращает true/false для каждого элемента.',
        'Для вывода массива удобно puts squares.inspect — увидишь [1, 4, 9].'
      ],
      solution: `numbers = [1, 2, 3, 4, 5, 6]

squares = numbers.map { |n| n * n }
big = numbers.select do |n|
  n >= 4
end

puts squares.inspect
puts big.inspect
puts numbers.map { |n| n * 2 }.join(", ")`
    },

    /* ---------- 10. Проект ---------- */
    {
      id: 'ruby-10',
      title: '🚀 Проект: Библиотека книг на классах',
      goal: 'Собрать библиотеку: класс Book с initialize, массив книг, перебор через each и вывод каталога',
      xp: 100,
      theory: [
        { t: 'p', html: 'Финальный проект — электронная библиотека. Ты соберёшь в одной программе всё, что изучил: класс с конструктором и переменными экземпляра, метод описания, массив объектов и перебор через <code>each</code>. Скелет настоящего Rails-приложения начинается ровно так же — с модели.' },
        { t: 'list', items: [
          'класс <b>Book</b> с переменными экземпляра (title, author, year — на твой выбор);',
          'конструктор <b>initialize</b>, заполняющий поля;',
          'метод, возвращающий описание книги;',
          'массив библиотеки минимум из двух-трёх книг через <b>Book.new(...)</b>;',
          'перебор библиотеки <b>each</b> (или map) с выводом каталога;',
          'любой итог на твой вкус: количество книг, средний год, что угодно.'
        ] },
        { t: 'code', code: `class Book
  def initialize(title, author, year)
    @title = title
    @author = author
    @year = year
  end

  def describe
    "#{@title} (#{@author}, #{@year})"
  end
end

# дальше — массив книг, each и итог` },
        { t: 'p', html: 'Итог можно посчитать через <code>map</code>: <code>years = library.map { |b| b.year }</code> — но для чтения поля снаружи нужен <code>attr_reader :year</code>. Либо проще: количество книг — <code>library.length</code>. Выбор за тобой — правила требуют лишь необходимый минимум.' },
        { t: 'note', html: 'После зачёта расширяй: поиск по автору (select!), сортировка <code>sort_by</code>, класс Library с методами add и search. Модель Book плюс коллекция — так выглядят настоящие приложения на Rails, только там Book наследует ApplicationRecord и живёт в базе данных.' },
        { t: 'warn', html: 'Помни о конвенциях: класс — CamelCase, методы — snake_case. И не забудь <code>attr_reader</code>, если хочешь читать поля снаружи: <code>b.year</code> без геттера вернёт ошибку NoMethodError, а не nil.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери библиотеку: класс <code>Book</code> с конструктором <code>initialize</code> и переменными экземпляра <code>@...</code>, метод-описание. Затем — массив минимум из двух книг через <code>Book.new(...)</code>, перебери его <code>each</code>-ем (или <code>map</code>-ом) и выведи каталог. Для итога пригодится <code>attr_reader</code> — или любой метод на твой вкус.</p>',
        starter: `# TODO: класс книги — конструктор, поля, метод описания

# TODO: массив библиотеки и вывод каталога`,
        rules: [
          { desc: 'Класс Book объявлен и закрыт end-ом', all: ['class\\s+Book\\b', '\\bend\\b'] },
          { desc: 'Конструктор initialize присваивает переменные экземпляра @...', all: ['def\\s+initialize\\b', '@\\w+\\s*='] },
          { desc: 'Класс содержит обычный метод (не только initialize)', any: ['def\\s+(?!initialize)\\w+'] },
          { desc: 'Созданы минимум две книги: Book.new ... Book.new', all: ['Book\\.new[\\s\\S]*Book\\.new'] },
          { desc: 'Книги лежат в массиве и перебираются each/map', all: ['\\[\\s*Book\\.new'], any: ['\\.each\\b', '\\.map\\b'] },
          { desc: 'Вывод через puts/print, пометок TODO нет', any: ['\\bputs\\b', '\\bprint\\b'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас класса — в теории выше. Метод: def describe ... "#{@title} (#{@author}, #{@year})" ... end',
        'Библиотека: library = [Book.new("Мёртвые души", "Гоголь", 1842), Book.new("Преступление и наказание", "Достоевский", 1866)]',
        'Перебор: library.each { |book| puts book.describe } — и итог, например puts "Книг: #{library.length}"'
      ],
      solution: `class Book
  attr_reader :title, :author, :year

  def initialize(title, author, year)
    @title = title
    @author = author
    @year = year
  end

  def describe
    "#{@title} (#{@author}, #{@year})"
  end
end

library = [
  Book.new("Мёртвые души", "Гоголь", 1842),
  Book.new("Преступление и наказание", "Достоевский", 1866),
  Book.new("Война и мир", "Толстой", 1869)
]

library.each do |book|
  puts book.describe
end

years = library.map { |b| b.year }
puts "Средний год издания: #{years.sum / years.length}"`
    },

    /* ---------- 11. Массивы и хеши глубоко ---------- */
    {
      id: 'ruby-11',
      title: 'Массивы и хеши глубоко',
      goal: 'Сворачивать массивы через reduce, обходить с индексами через each_with_index и строить хэши с дефолтом Hash.new(0)',
      xp: 45,
      theory: [
        { t: 'p', html: 'Киты обработки коллекций ты уже знаешь наполовину: <code>each</code> — просто перебор, <code>map</code> — преобразование, <code>select</code> — отбор. Четвёртый кит — <code>reduce</code> (брат-близнец <code>inject</code>): сворачивает массив в одно значение. Блок получает два параметра — накопитель и текущий элемент; то, что блок вернёт, становится новым накопителем.' },
        { t: 'code', code: `orders = [320, 150, 90]

total = orders.reduce(0) { |acc, o| acc + o }
puts total   # 560

max_order = orders.reduce { |a, b| a > b ? a : b }
puts max_order   # 320` },
        { t: 'p', html: 'Число в скобках — стартовое значение накопителя: <code>reduce(0)</code> начинает с нуля. Без стартового значения накопителем становится первый элемент. Для номеров при переборе есть <code>each_with_index</code>: первым параметром идёт элемент, вторым — индекс с нуля. Нумерованный список — классические две строки.' },
        { t: 'code', code: `list = ["купить кофе", "написать тест"]

list.each_with_index do |item, i|
  puts "#{i + 1}. #{item}"
end
# 1. купить кофе
# 2. написать тест` },
        { t: 'p', html: 'Хэш тоже умеет больше, чем казалось. Обычный хэш на отсутствующем ключе отвечает <code>nil</code> — и <code>counter[:word] += 1</code> падает с NoMethodError: единицу нельзя прибавить к nil. Лекарство — <code>Hash.new(0)</code>: хэш, у которого отсутствующие ключи отвечают нулём. Идеален для счётчиков — никаких проверок «а есть ли ключ».' },
        { t: 'code', code: `counter = Hash.new(0)
counter[:ruby] += 1
counter[:ruby] += 1

puts counter[:ruby]   # 2
puts counter[:js]     # 0 — дефолт вместо nil` },
        { t: 'table', head: ['Выражение', 'Что даёт'], rows: [
          ['<code>arr.reduce(0) { |acc, x| ... }</code>', 'свернуть массив, начав с 0'],
          ['<code>arr.each_with_index { |x, i| }</code>', 'перебор с номером элемента'],
          ['<code>Hash.new(0)</code>', 'хэш с дефолтом для отсутствующих ключей'],
          ['<code>h.fetch(:k, 0)</code>', 'значение или запасное, если ключа нет'],
          ['<code>h.dig(:a, :b)</code>', 'безопасное чтение вложенных хэшей']
        ] },
        { t: 'warn', html: 'Символ и строка — РАЗНЫЕ ключи: <code>:ruby</code> и <code>"ruby"</code> в одном хэше — это две разные пары. Записал <code>{ tea: 90 }</code> (ключ-символ), а читаешь <code>prices["tea"]</code> — получишь nil без всякой ошибки. И помни: <code>puts [1, 2]</code> печатает каждый элемент на своей строке — puts перебирает массивы; для вывода «в одну строку» нужен <code>.inspect</code> или <code>.join(", ")</code>.' },
        { t: 'note', html: 'Счётчик слов через <code>Hash.new(0)</code> плюс <code>reduce</code> — классическая задача собеседований на Ruby, а в Rails те же приёмы живут в отчётах: <code>group(:status).count</code> возвращает именно хэш. Ключи там — символы, и это неслучайно: подробнее о символах и строках — в уровне 17.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Допиши скрипт: сворачивающий метод массива, хвост <code>each_with...</code>, конструктор хэша с дефолтом и правильный ключ для хэша со строковыми ключами.</p>',
        code: `data = [5, 12, 8, 3]

# 1) свернуть массив в сумму
total = data.{{0}} { |acc, n| acc + n }

# 2) перебор с индексом
data.each_{{1}} do |n, i|
  puts "#{i}: #{n}"
end

# 3) хэш с дефолтом 0
counter = Hash.{{2}}(0)
counter[:ruby] += 1
counter[:ruby] += 1

# 4) у этого хэша ключи — СТРОКИ
prices = { "tea" => 90 }
puts prices[{{3}}]`,
        blanks: [
          { answer: 'reduce', alt: ['inject'] },
          { answer: 'with' },
          { answer: 'new' },
          { answer: '"tea"', alt: ["'tea'"] }
        ]
      },
      hints: [
        'Сворачивает массив reduce (или inject): data.reduce(0) { |acc, n| acc + n }.',
        'each_with_index — each, дополненный индексом: пропущенный кусок — with.',
        'Хэш с дефолтом — Hash.new(0). А ключ "tea" — строка: в кавычках.'
      ],
      solution: ['reduce', 'with', 'new', '"tea"']
    },

    /* ---------- 12. Блоки и yield ---------- */
    {
      id: 'ruby-12',
      title: 'Блоки и yield',
      goal: 'Писать методы, вызывающие блок через yield, проверять block_given? и принимать блок через &',
      xp: 50,
      theory: [
        { t: 'p', html: 'Блок, который ты передаёшь методу, — код «на потом». Метод исполняет его ключевым словом <code>yield</code>: «вот место, где сработает твой блок». yield может вызваться сколько угодно раз и с какими угодно аргументами: <code>yield</code> — просто выполнить, <code>yield(n)</code> — выполнить, передав n: параметр <code>|x|</code> блока получит это значение.' },
        { t: 'code', code: `def twice
  puts "до"
  yield
  yield
  puts "после"
end

twice { puts "середина" }
# до
# середина
# середина
# после` },
        { t: 'p', html: 'Метод может не только вызывать блок, но и «кормить» его данными — так устроены все итераторы Ruby: <code>each</code>, <code>map</code>, <code>times</code> — обычные методы, внутри которых крутится yield. Напишем свой итератор: метод сам знает, КОГДА, а блок решает, ЧТО делать с каждым значением.' },
        { t: 'code', code: `def countdown(from)
  while from > 0
    yield from            # отдаём текущее число блоку
    from -= 1
  end
end

countdown(3) { |n| puts "Осталось: #{n}" }` },
        { t: 'p', html: 'А если блок не передали? yield без блока поднимет LocalJumpError («no block given»). Защита — метод-вопрос <code>block_given?</code>: true, если блок пришёл. Идиома: <code>return unless block_given?</code> — «нет блока — делать нечего». А через <code>def run(&amp;blk)</code> блок и вовсе приходит внутрь как объект Proc: его можно сохранить, передать дальше и вызвать <code>blk.call(...)</code>; обратное направление — <code>arr.map(&amp;:upcase)</code>, символ-метод превращается в блок.' },
        { t: 'code', code: `def report(title)
  return "нет блока" unless block_given?
  "#{title}: #{yield}"
end

puts report("Сумма") { 2 + 2 }   # Сумма: 4
puts report("Пусто")             # нет блока` },
        { t: 'table', head: ['Запись', 'Что происходит'], rows: [
          ['<code>yield</code>', 'выполнить блок внутри метода'],
          ['<code>yield(n)</code>', 'выполнить блок, передав аргумент'],
          ['<code>block_given?</code>', 'передан ли блок (true/false)'],
          ['<code>def m(&blk)</code>', 'принять блок как объект Proc'],
          ['<code>blk.call(5)</code>', 'вызвать Proc вручную'],
          ['<code>arr.map(&:upcase)</code>', 'символ-метод как блок']
        ] },
        { t: 'warn', html: 'Приоритет скобок — коварная ловушка: <code>puts [1, 2].map { |n| n * 2 }</code> печатает две строки — блок прилип к map. А вот <code>puts [1, 2].map do |n| n * 2 end</code> — блок достанется puts (do...end «липнет» слабее фигурных скобок), map вызовется без блока, и вывод будет совсем не тот, что ждался. Правило: однострочные цепочки — фигурные скобки, многострочные — do ... end.' },
        { t: 'note', html: 'yield — это инверсия контроля: каркас пишут один раз, а «мясо» подставляют при каждом вызове. На этом стоят each и map внутри самого Ruby, колбэки Rails (before_action) и идиома «открой ресурс — сделай — закрой»: <code>File.open("log.txt") { |f| f.puts "запись" }</code> закрывает файл за тебя именно через yield.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши метод <code>countdown(from)</code>: он сам ничего не печатает — он <b>отдаёт</b> числа блоку через <code>yield</code> (от <code>from</code> до 1). Защити метод проверкой <code>block_given?</code> — или прими блок через <code>&amp;имя</code>. Затем вызови метод с блоком, который печатает каждое число.</p>',
        starter: `# TODO: метод, который по очереди отдаёт числа блоку (от from до 1)

# TODO: вызови метод с блоком do ... end и выведи каждое число`,
        rules: [
          { desc: 'Метод объявлен через def и закрыт end-ом', all: ['\\bdef\\s+\\w+', '\\bend\\b'] },
          { desc: 'Блок вызывается из метода через yield', all: ['\\byield\\b'] },
          { desc: 'yield передаёт аргумент (или блок вызывается через .call)', any: ['\\byield\\s+\\w+', '\\byield\\s*\\(', '\\w+\\.call\\s*\\('] },
          { desc: 'Защита block_given? или приём блока через &имя', any: ['\\bblock_given\\?', '&\\s*\\w+'] },
          { desc: 'Метод вызывается с блоком-параметром |имя|', all: ['\\|\\s*\\w+\\s*\\|'] },
          { desc: 'Вывод через puts/print, пометок TODO нет', any: ['\\bputs\\b', '\\bprint\\b'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас: def countdown(from) ... while from > 0 ... yield from ... end ... end',
        'Вызов: countdown(3) do |n| puts n end — параметр блока получает то, что yield отдал.',
        'Первая строкой метода: return unless block_given? — защита от вызова без блока.'
      ],
      solution: `def countdown(from)
  return unless block_given?
  while from > 0
    yield from
    from -= 1
  end
end

countdown(3) do |n|
  puts "Осталось: #{n}"
end`
    },

    /* ---------- 13. Procs и lambda ---------- */
    {
      id: 'ruby-13',
      title: 'Procs и lambda',
      goal: 'Сохранять блоки в объекты Proc, различать proc и lambda по арности и return, вызывать через .call',
      xp: 45,
      theory: [
        { t: 'p', html: 'Блок — не объект: его не сохранить в переменную и не передать «про запас». <b>Proc</b> — тот же блок, но упакованный в объект: <code>pr = Proc.new { ... }</code> или короче — <code>pr = proc { ... }</code>. Запускается методом <code>call</code>: <code>pr.call(5)</code>. Теперь блок можно вернуть из метода, сложить в массив, передать другому методу.' },
        { t: 'code', code: `square = proc { |x| x * x }
puts square.call(5)   # 25` },
        { t: 'p', html: '<b>lambda</b> — Proc с характером: <code>l = lambda { |x| x }</code> или современная стрелка <code>l = -&gt;(x) { x }</code>. Внутри Ruby лямбда помечена флагом (проверяется методом <code>lambda?</code>), и от этого зависят два поведения — строгость аргументов и смысл return.' },
        { t: 'table', head: ['Запись', 'Поведение'], rows: [
          ['<code>proc { |x, y| }</code>', 'недостающие аргументы станут nil, лишние — отбросятся'],
          ['<code>lambda { |x, y| } / -&gt;(x, y) { }</code>', 'несовпадение арности — ArgumentError'],
          ['<code>pr.call(5)</code>', 'выполнить объект'],
          ['<code>pr.arity</code>', 'сколько параметров объявлено'],
          ['<code>pr.lambda?</code>', 'true только для лямбд']
        ] },
        { t: 'p', html: 'Разница return — главная ловушка собеседований: <code>return</code> внутри <b>proc</b> выходит из объемлющего МЕТОДА целиком, а внутри <b>lambda</b> — только из самой лямбды. Метод продолжается, как ни в чём не бывало.' },
        { t: 'code', code: `def with_lambda
  l = lambda { return 1 }
  result = l.call
  "лямбда вернула #{result}, метод жив"
end

def with_proc
  pr = proc { return 1 }
  pr.call              # return выбивает из метода!
  "эта строка мертва"
end

puts with_lambda   # лямбда вернула 1, метод жив
puts with_proc     # 1` },
        { t: 'warn', html: 'Арность: <code>-&gt;(x, y) { }.call(1)</code> поднимет ArgumentError — лямбда строга к числу аргументов. proc же молча подставит nil за недостающий параметр: ошибка всплывёт позже, в глубине вычислений, где её поиск труднее. Поэтому для «настоящих функций» выбирай стрелку, а proc оставляй для обёрток над блоками.' },
        { t: 'note', html: 'Блок, принятый методом через <code>&amp;blk</code> из уровня 12, — обычный Proc: <code>blk.class</code> → Proc. А в Rails лямбды повсюду: <code>scope :recent, -&gt; { order(created_at: :desc) }</code> — области видимости моделей, ленивые условия, колбэки. Итог темы: блок — синтаксис вызова, Proc — объект, lambda — режим объекта.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет этот код?</p><pre>def test
  pr = proc { return 1 }
  result = pr.call
  puts "после proc: #{result}"
  result
end

puts test</pre>`,
        options: [
          'только 1 — строка «после proc» не напечатается',
          '«после proc: 1», затем 1',
          'nil',
          'ошибка LocalJumpError'
        ],
        correct: 0,
        explain: 'return внутри proc выходит из ОБЪЕМЛЮЩЕГО метода: test завершается прямо на pr.call со значением 1, до puts дело не доходит, и puts test печатает только «1». Будь это lambda — return вышел бы лишь из лямбды, result стал бы 1, и мы увидели бы обе строки.',
        solution: 0
      },
      hints: [
        'return в proc — это не «выход из блока», а выход из метода, где proc вызван.',
        'Если бы это была lambda, метод дошёл бы до puts — но здесь proc.'
      ],
      solution: 0
    },

    /* ---------- 14. Классы и attr_accessor ---------- */
    {
      id: 'ruby-14',
      title: 'Классы и attr_accessor',
      goal: 'Систематизировать ООП: attr_reader / writer / accessor, методы экземпляра, to_s и self',
      xp: 50,
      theory: [
        { t: 'p', html: 'Классы ты уже собирал в уровнях 7 и 10 — теперь систематизируем доступ к состоянию. <code>attr_reader :name</code> генерирует геттер, <code>attr_writer :name</code> — сеттер <code>name=</code>, <code>attr_accessor</code> — оба сразу. Это не магия: Ruby просто пишет за тебя обычные методы, которые можно было бы объявить руками.' },
        { t: 'code', code: `class Point
  attr_accessor :x, :y   # и читаем, и пишем

  def initialize(x, y)
    @x, @y = x, y        # параллельное присваивание
  end

  def to_s
    "(#{@x}, #{@y})"
  end
end

p1 = Point.new(2, 3)
p1.x = 10          # сработал сеттер от attr_accessor
puts p1            # (10, 3) — вызван to_s` },
        { t: 'p', html: 'Параллельное присваивание <code>@x, @y = x, y</code> раскладывает значения по порядку — две переменные за одну строку. Методы экземпляра (объявленные без self в имени) живут у каждого объекта: у двух счётчиков — свои собственные @count, у двух точек — свои координаты.' },
        { t: 'p', html: 'Особые методы: <code>to_s</code> — «строковое представление», его вызывают puts и интерполяция; <code>inspect</code> — отладочный вид, его вызывает p. Определил to_s — объекты класса печатаются красиво везде. А <code>self</code> внутри метода — «сам объект»: <code>self.count</code> — явный вызов другого метода того же объекта.' },
        { t: 'table', head: ['Запись', 'Что делает'], rows: [
          ['<code>attr_reader :a</code>', 'только чтение'],
          ['<code>attr_writer :a</code>', 'только запись: obj.a = 5'],
          ['<code>attr_accessor :a</code>', 'чтение и запись'],
          ['<code>def to_s</code>', 'сработает при puts объекта'],
          ['<code>self.метод</code>', 'явный вызов метода текущего объекта'],
          ['<code>@x, @y = 1, 2</code>', 'параллельное присваивание']
        ] },
        { t: 'warn', html: 'attr_accessor «на всё подряд» — антипаттерн: так ты выставляешь внутренности объекта на растерзание. Хороший Rails-код прячет состояние за методами-командами (user.activate!), а не за голыми сеттерами. Правило: reader — когда действительно читают, writer/accessor — только когда состояние обязаны менять снаружи.' },
        { t: 'note', html: 'Дефолты в конструкторе: <code>def initialize(start = 0)</code> — Counter.new без аргументов даст счётчик с нуля. Проверить класс объекта: <code>c.is_a?(Counter)</code>, увидеть его методы: <code>c.methods</code>. Всё это обычные вызовы — даже «ключевые слова» ООП в Ruby объектно-методные.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери класс <code>Counter</code>: <code>attr_accessor :count</code>, <code>initialize</code> с полем-счётчиком, метод экземпляра <code>increment</code> (увеличивает счётчик) и <code>to_s</code>. Затем создай объект через <code>Counter.new(...)</code>, увеличь счётчик и выведи результат.</p>',
        starter: `# TODO: класс Counter — attr_accessor, initialize, метод increment и to_s

# TODO: создай объект, увеличь счётчик и выведи его`,
        rules: [
          { desc: 'Класс Counter объявлен и закрыт end-ом', all: ['class\\s+Counter\\b', '\\bend\\b'] },
          { desc: 'Объявлен attr_reader / writer / accessor', any: ['attr_(?:accessor|reader|writer)'] },
          { desc: 'initialize присваивает переменную экземпляра @...', all: ['def\\s+initialize\\b', '@\\w+\\s*='] },
          { desc: 'Есть метод экземпляра помимо initialize', any: ['def\\s+(?!initialize)\\w+'] },
          { desc: 'Метод или to_s использует @поле', all: ['@\\w+'] },
          { desc: 'Объект создан через Counter.new(...)', all: ['Counter\\.new'] },
          { desc: 'Результат выводится через puts/print, пометок TODO нет', any: ['\\bputs\\b', '\\bprint\\b'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас: class Counter ... attr_accessor :count ... def initialize(start = 0) ... end ... end',
        'increment: def increment(by = 1) ... @count += by ... end — дефолт позволяет вызывать без аргумента.',
        'to_s возвращает строку с интерполяцией: "Счётчик: #{@count}" — тогда puts c напечатает её.'
      ],
      solution: `class Counter
  attr_accessor :count

  def initialize(start = 0)
    @count = start
  end

  def increment(by = 1)
    @count += by
    self
  end

  def to_s
    "Счётчик: #{@count}"
  end
end

c = Counter.new(10)
c.increment
c.increment(5)
puts c         # Счётчик: 16 — сработал to_s
puts c.count   # 16`
    },

    /* ---------- 15. Наследование и модули ---------- */
    {
      id: 'ruby-15',
      title: 'Наследование и модули',
      goal: 'Наследовать классы через <, вызывать super и подключать модули-миксины через include',
      xp: 55,
      theory: [
        { t: 'p', html: 'Наследование — <code>class Dog &lt; Animal</code>: потомок получает все методы и переменные родителя. Родитель ровно один — множественного наследования в Ruby нет (и это к лучшему: не будет «ромба»). Переопределил метод — работает твой; нужен родительский — вызывай <code>super</code>.' },
        { t: 'code', code: `class Animal
  attr_reader :name

  def initialize(name)
    @name = name
  end

  def speak
    "..."
  end
end

class Dog < Animal
  def initialize(name, breed)
    super(name)          # initialize родителя
    @breed = breed
  end

  def speak
    "#{@name}: Гав!"
  end
end` },
        { t: 'p', html: 'Три лика super: <code>super(name)</code> — вызвать с конкретными аргументами; <code>super</code> без скобок — с теми же, что пришли в метод; <code>super()</code> — вообще без аргументов. Перепутаешь — родитель получит не те параметры и уронит ArgumentError.' },
        { t: 'p', html: 'Второе наследование — модули. Класс включает сколько угодно модулей через <code>include</code>: методы модуля становятся методами экземпляра. Это <b>миксины</b> — способ шарить поведение между неродственными классами: у Dog и Robot нет общего предка, но оба могут включить один модуль.' },
        { t: 'code', code: `module Greetable
  def greet
    "Привет, я #{self.class.name.downcase}!"
  end
end

class Cat < Animal
  include Greetable
end

puts Cat.new("Мурка").greet   # Привет, я cat!` },
        { t: 'p', html: 'Стандартные миксины мощные: <code>include Comparable</code> плюс метод <code>&lt;=&gt;</code> («космический корабль»: возвращает -1, 0 или 1) — и класс получает <code>&lt;</code>, <code>&gt;=</code>, <code>between?</code> и сортировку sort бесплатно. <code>include Enumerable</code> плюс свой <code>each</code> — и у твоего класса появляются map, select и reduce.' },
        { t: 'table', head: ['Запись', 'Что делает'], rows: [
          ['<code>class Dog < Animal</code>', 'наследование, один родитель'],
          ['<code>super</code>', 'метод родителя с теми же аргументами'],
          ['<code>module M ... end</code>', 'пакет методов'],
          ['<code>include M</code>', 'методы M — методам экземпляра'],
          ['<code>include Comparable + <=></code>', 'весь набор сравнений'],
          ['<code>obj.is_a?(Animal)</code>', 'проверка принадлежности классу']
        ] },
        { t: 'warn', html: 'include даёт методы экземпляра, а <code>extend</code> — методы класса. И не строй глубокие иерархии ради «повторного использования»: если различие — «умеет X», это модуль, а не ветка дерева. Ruby-код чаще выглядит как короткие классы плюс миксины, чем как башня Animal → Dog → Puppy → PuppyV2.' },
        { t: 'note', html: 'Rails: все модели наследуют ApplicationRecord (общая точка настроек), а повторяющиеся кусочки вынесены в concerns — те же модули. Проверки <code>d.is_a?(Animal)</code> и <code>d.respond_to?(:speak)</code> — инструмент рефакторинга: смотри, что объект умеет, а не как он назван.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери связку: класс-родитель с <code>initialize</code>, класс-потомок через <code>&lt;</code>, который в своём <code>initialize</code> вызывает <code>super</code>; модуль с методом и его подключение через <code>include</code>. Создай объект потомка и вызови хотя бы один его метод (или метод из модуля) через puts.</p>',
        starter: `# TODO: класс-родитель с initialize

# TODO: класс-потомок через < с super и модуль через include

# TODO: создай объект потомка и выведи вызов метода`,
        rules: [
          { desc: 'Модуль объявлен (module Имя ... end)', all: ['\\bmodule\\s+\\w+', '\\bend\\b'] },
          { desc: 'Наследование через < (class Потомок < Родитель)', all: ['class\\s+\\w+\\s*<\\s*\\w+'] },
          { desc: 'Модуль подключён через include Имя', all: ['\\binclude\\s+\\w+'] },
          { desc: 'Потомок вызывает super в initialize', all: ['\\bsuper\\b'] },
          { desc: 'Есть конструктор initialize', all: ['def\\s+initialize\\b'] },
          { desc: 'Метод объекта вызывается после создания', any: ['\\.describe\\b', '\\.greet\\b', '\\.speak\\b', 'new[\\s\\S]*\\w+\\.\\w+'] },
          { desc: 'Вывод через puts/print, пометок TODO нет', any: ['\\bputs\\b', '\\bprint\\b'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Родитель: class Animal ... def initialize(name) ... @name = name ... end ... end',
        'Потомок: class Dog < Animal ... def initialize(name, breed) ... super(name) ... end ... end',
        'Модуль: module Greetable ... def greet ... end ... end — и внутри класса: include Greetable'
      ],
      solution: `module Describable
  def describe
    "#{self.class.name}: #{@name}"
  end
end

class Animal
  attr_reader :name

  def initialize(name)
    @name = name
  end
end

class Dog < Animal
  include Describable

  def initialize(name, breed)
    super(name)
    @breed = breed
  end

  def speak
    "#{@name}: Гав!"
  end
end

d = Dog.new("Рекс", "дворняга")
puts d.speak
puts d.describe`
    },

    /* ---------- 16. Исключения ---------- */
    {
      id: 'ruby-16',
      title: 'Исключения: begin, rescue, raise',
      goal: 'Ловить ошибки через begin/rescue/ensure, поднимать их через raise и объявлять свои классы ошибок',
      xp: 55,
      theory: [
        { t: 'p', html: 'Ошибки в Ruby — тоже объекты. Иерархия начинается с Exception, но на практике ловят наследников <b>StandardError</b>: NoMethodError (метода нет), ZeroDivisionError, TypeError, ArgumentError, KeyError. Голый <code>rescue</code> без класса ловит именно StandardError и всех его потомков.' },
        { t: 'p', html: '<code>raise</code> поднимает ошибку: <code>raise "текст"</code> создаст RuntimeError — работает, но грубо; правильнее <code>raise Класс, "текст"</code>. Валидация входных данных через raise — идиома: падай рано и громко, чтобы мусор не расползался по программе.' },
        { t: 'code', code: `def check_age(age)
  raise ArgumentError, "возраст не число" unless age.is_a?(Integer)
  raise ArgumentError, "возраст отрицательный" if age < 0
  "#{age} лет — принято"
end` },
        { t: 'p', html: 'Ловля — связка <code>begin / rescue / else / ensure</code>: <code>rescue Класс =&gt; e</code> ловит конкретный тип и кладёт объект ошибки в <code>e</code> (текст ошибки — <code>e.message</code>). Блок <code>else</code> выполнится, если ошибки не было, а <code>ensure</code> — всегда, даже при ошибке: закрыть файл, соединение, вернуть ресурс.' },
        { t: 'code', code: `begin
  puts check_age(30)
  puts check_age(-5)
rescue ArgumentError => e
  puts "Отклонено: #{e.message}"
ensure
  puts "Проверка завершена"
end` },
        { t: 'p', html: 'Своя ошибка — пустой класс-наследник: <code>class ValidationError &lt; StandardError; end</code> (точка с запятой позволяет однострочник). Поднимаешь её через raise — и ловишь конкретно её: чужие ошибки пройдут мимо твоего rescue, не мешая друг другу.' },
        { t: 'table', head: ['Запись', 'Что делает'], rows: [
          ['<code>begin ... end</code>', 'блок под контролем'],
          ['<code>rescue Класс => e</code>', 'поймать тип, объект — в e'],
          ['<code>else</code>', 'выполнится, если ошибки не было'],
          ['<code>ensure</code>', 'выполнится всегда'],
          ['<code>raise Класс, "текст"</code>', 'поднять ошибку'],
          ['<code>retry</code>', 'повторить begin ещё раз']
        ] },
        { t: 'warn', html: 'retry в rescue перезапускает весь begin: без счётчика попыток — вечный цикл, будь осторожен. И не глушись: голый rescue с пустым телом прячет реальные баги — «тихие» падения дороже громких. Минимум гигиены: конкретные классы ошибок и вывод e.message в лог.' },
        { t: 'note', html: 'В Rails-контроллерах ошибки ловят централизованно: <code>rescue_from ActiveRecord::RecordNotFound, with: :redirect_home</code> — одна строка на весь контроллер. А идиома с ensure живёт в файлах: <code>f = File.open("log.txt", "w"); begin; f.puts "строка"; ensure; f.close; end</code> — либо сразу блочная форма File.open { |f| ... }, где закрытие гарантировано Ruby.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Обработай ошибки по-взрослому: объяви свой класс ошибки (наследник <code>StandardError</code>), метод или строка кода с <code>raise</code> (подними свою или стандартную ошибку), затем <code>begin</code>-блок с <code>rescue</code> конкретного класса (объект ошибки — в переменную через <code>=&gt;</code>), <code>ensure</code>-блоком и чтением <code>e.message</code>.</p>',
        starter: `# TODO: свой класс ошибки — наследник StandardError

# TODO: raise при плохих данных

# TODO: begin / rescue / ensure с e.message`,
        rules: [
          { desc: 'begin-блок открыт и закрыт end-ом', all: ['\\bbegin\\b', '\\bend\\b'] },
          { desc: 'rescue ловит конкретный класс ошибки', all: ['\\brescue\\s+[A-Z]\\w*'] },
          { desc: 'Своя ошибка: класс наследует StandardError', all: ['class\\s+\\w+\\s*<\\s*StandardError'] },
          { desc: 'raise поднимает ошибку с классом', all: ['\\braise\\b'], any: ['\\braise\\s+[A-Z]\\w*', '\\braise\\s+"'] },
          { desc: 'ensure-блок присутствует', all: ['\\bensure\\b'] },
          { desc: 'Текст ошибки читается через .message', any: ['\\.message\\b'] },
          { desc: 'Вывод через puts/print, пометок TODO нет', any: ['\\bputs\\b', '\\bprint\\b'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Свой класс одной строкой: class AgeError < StandardError; end',
        'Подъём: raise AgeError, "возраст должен быть положительным" if age <= 0',
        'Каркас: begin ... rescue AgeError => e ... puts e.message ... ensure ... end'
      ],
      solution: `class AgeError < StandardError; end

def check_age(age)
  raise AgeError, "возраст должен быть положительным" if age <= 0
  "#{age} — рабочий возраст"
end

begin
  puts check_age(30)
  puts check_age(-5)
rescue AgeError => e
  puts "Поймали: #{e.message}"
ensure
  puts "Проверка завершена"
end`
    },

    /* ---------- 17. Символы и строки ---------- */
    {
      id: 'ruby-17',
      title: 'Символы и строки',
      goal: 'Различать :sym и "str", писать %w[]-литералы, владеть строковыми методами и понимать freeze',
      xp: 50,
      theory: [
        { t: 'p', html: 'Символ <code>:ruby</code> — неизменяемое «имя», а не текст. Ключевое отличие: два одинаковых символа — ОДИН объект (тот же object_id), а две одинаковые строки — как правило, два разных объекта. Сравнение символов почти бесплатно, поэтому их делают ключами хэшей, именами методов, статусами.' },
        { t: 'code', code: `puts :ruby.object_id == :ruby.object_id    # true — один объект
puts "ruby".object_id == "ruby".object_id  # обычно false — два` },
        { t: 'p', html: 'Процентные литералы — короче кавычек: <code>%w[ruby rails css]</code> — это массив строк <code>["ruby", "rails", "css"]</code>, а <code>%i[a b]</code> — массив символов. Слова внутри разделяются пробелами, кавычки и запятые не нужны — удобно для списков слов, имён файлов, флагов.' },
        { t: 'p', html: 'Интерполяция <code>#{...}</code> работает только в двойных кавычках; в одинарных <code>#{x}</code> останется текстом. В двойных действуют и экранированные символы: <code>\\n</code> — перенос строки, <code>\\t</code> — табуляция, <code>\\\\</code> — сам обратный слэш.' },
        { t: 'table', head: ['Запись', 'Что это'], rows: [
          ['<code>:sym</code>', 'имя: ключи, статусы, методы'],
          ['<code>"str"</code>', 'текст для людей: вывод, склейка'],
          ['<code>%w[a b c]</code>', 'массив строк одним словом'],
          ['<code>%i[a b]</code>', 'массив символов'],
          ['<code>s << "!"</code>', 'дописать в строку (мутация)'],
          ['<code>s.freeze</code>', 'заморозить — менять нельзя']
        ] },
        { t: 'p', html: 'Методы строк, которые стоит добавить к словарю из уровня 5: <code>strip</code> — обрезать пробелы по краям, <code>gsub("а", "о")</code> — заменить ВСЕ вхождения (sub — только первое), <code>start_with?</code> / <code>end_with?</code> — проверки префиксов и суффиксов, <code>empty?</code> — пуста ли строка.' },
        { t: 'code', code: `raw = "  Rails  "
puts raw.strip                      # Rails
puts raw.strip.gsub("R", "r")       # rails
puts "photo.jpg".end_with?(".jpg")  # true` },
        { t: 'warn', html: '<code>freeze</code> замораживает строку: <code>s = "константа".freeze</code> — и попытка <code>s &lt;&lt; "!"</code> поднимет FrozenError. В Rails-проектах первой строкой файла ставят magic-комментарий <code># frozen_string_literal: true</code>: все строковые литералы файла замораживаются автоматически — экономия памяти и защита от случайных мутаций.' },
        { t: 'note', html: 'Правило выбора простое: символ — для имён (ключи хэшей, статусы, имена методов), строка — для данных, которые показывают и склеивают. В Rails это видно повсюду: <code>params[:id]</code> — символ, <code>"Привет, #{user.name}!"</code> — строка для человека.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Допиши шпаргалку по символам и строкам: тело символа после двоеточия, слова для <code>%w[...]</code>, интерполяцию переменной, строковые методы и «заморозку».</p>',
        code: `# 1) Символ — неизменяемое «имя» (двоеточие + слово)
status = :{{0}}

# 2) Массив строк без кавычек и запятых
langs = %w[{{1}}]

# 3) Интерполяция — только в двойных кавычках
puts "Учим ruby: {{2}}"
puts 'Без интерполяции: #{status}'

# 4) Методы строк
title = "rails для начинающих"
puts title.{{3}}     # Rails для начинающих
puts title.{{4}}     # 20 — длина строки

# 5) Заморозить строку (см. теорию)
s = "константа".{{5}}`,
        blanks: [
          { answer: 'done' },
          { answer: 'ruby rails' },
          { answer: '#{status}' },
          { answer: 'capitalize' },
          { answer: 'length', alt: ['size'] },
          { answer: 'freeze' }
        ]
      },
      hints: [
        'Символ: двоеточие плюс слово без пробелов — :done. В %w[] слова через пробел: ruby rails.',
        'Интерполяция внутри двойных кавычек — #{status}; метод с большой буквы — capitalize.',
        'Длину дают length или size, а «замораживает» строку метод freeze.'
      ],
      solution: ['done', 'ruby rails', '#{status}', 'capitalize', 'length', 'freeze']
    },

    /* ---------- 18. Проект: список дел ---------- */
    {
      id: 'ruby-18',
      title: '🚀 Проект: Список дел на классах',
      goal: 'Собрать трекер задач: класс Task, класс List с массивом, методы add / complete / stats через reduce',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект курса — трекер дел на двух классах. Класс <b>Task</b> — одна задача: описание и флаг выполнения. Класс <b>List</b> — коллекция: массив задач внутри и методы add / complete / stats. Это ровно каркас Rails-приложения: модель + коллекция + отчёт.' },
        { t: 'list', items: [
          'класс <b>Task</b>: initialize с описанием, <code>@done = false</code>, метод <code>done?</code>;',
          'класс <b>List</b>: initialize создаёт пустой массив <code>@tasks = []</code>;',
          '<b>add</b> — дописать новую Task в массив (<code>&lt;&lt;</code> или push);',
          '<b>complete</b> — найти задачу по названию и поставить <code>done = true</code>;',
          '<b>stats</b> — итог через <code>reduce</code>: сколько сделано из скольких;',
          'создай список, добавь 2–4 дела, закрой пару и выведи stats через puts.'
        ] },
        { t: 'code', code: `class Task
  attr_reader :title
  attr_accessor :done

  def initialize(title)
    @title = title
    @done = false
  end

  def done?
    @done
  end
end

class List
  def initialize
    @tasks = []
  end
  # add, complete, stats — за тобой
end` },
        { t: 'p', html: 'Поиск в complete — метод <code>find</code> из Enumerable: возвращает первый элемент, для которого блок дал true (или nil, если такого нет). Ставим флаг через сеттер от attr_accessor: <code>task.done = true if task</code> — защита от nil на всякий случай.' },
        { t: 'p', html: 'Статистика — reduce с накопителем-счётчиком: <code>@tasks.reduce(0) { |sum, t| t.done? ? sum + 1 : sum }</code>. Тернарник <code>? :</code> добавляет единицу для сделанных и ничего для остальных. Вернуть из stats удобно готовую строку: <code>"#{done_count} из #{@tasks.length} сделано"</code>.' },
        { t: 'warn', html: 'Два класса — два блока class ... end, не вкладывай один в другой. Не забудь attr-строки в Task: без <code>attr_reader :title</code> метод complete не сможет спросить t.title (NoMethodError), без <code>attr_accessor :done</code> — поставить флаг. Имена классов — CamelCase, методы — snake_case.' },
        { t: 'note', html: 'Куда расти: делегируй обход — <code>def each(&amp;blk); @tasks.each(&amp;blk); end</code>, добавь <code>include Enumerable</code> — и у списка появятся map, select и count бесплатно. Дальше — сроки, приоритеты, экспорт CSV. А в Rails это уже настоящая модель: <code>Task.where(done: false)</code>.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Список дел».</b> Собери класс <code>Task</code> (описание + флаг выполнения, атрибуты через attr-строки) и класс <code>List</code> с массивом задач в <code>@...</code>: метод <code>add</code> (добавить), <code>complete</code> (отметить выполненной) и <code>stats</code> с итогом через <code>reduce</code> (или <code>inject</code>). Создай список, добавь хотя бы два дела, отметь выполненное и выведи результат.</p>',
        starter: `# TODO: класс Task — описание и флаг выполнения

# TODO: класс List — массив задач, add, complete и stats через reduce`,
        rules: [
          { desc: 'Класс Task объявлен и закрыт end-ом', all: ['class\\s+Task\\b', '\\bend\\b'] },
          { desc: 'Класс List объявлен', all: ['class\\s+List\\b'] },
          { desc: 'Оба класса с initialize', all: ['class\\s+Task[\\s\\S]*?def\\s+initialize', 'class\\s+List[\\s\\S]*?def\\s+initialize'] },
          { desc: 'Задачи в массиве экземпляра @... и добавляются (<< или push)', all: ['@\\w+\\s*=\\s*\\[', '(?:<<|\\.push)'] },
          { desc: 'Метод add объявлен', all: ['def\\s+add\\b'] },
          { desc: 'Метод complete объявлен', all: ['def\\s+complete\\b'] },
          { desc: 'Статистика через reduce/inject', all: ['\\.(?:reduce|inject)\\b'] },
          { desc: 'Вывод через puts/print, пометок TODO нет', any: ['\\bputs\\b', '\\bprint\\b'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Task: attr_reader :title + attr_accessor :done, initialize ставит @done = false, метод done? возвращает @done.',
        'List: @tasks = [] в initialize; add: @tasks << Task.new(title); complete: task = @tasks.find { |t| t.title == title }.',
        'stats: @tasks.reduce(0) { |sum, t| t.done? ? sum + 1 : sum } — и верни строку "#{done_count} из #{@tasks.length} сделано".'
      ],
      solution: `class Task
  attr_reader :title
  attr_accessor :done

  def initialize(title)
    @title = title
    @done = false
  end

  def done?
    @done
  end
end

class List
  def initialize
    @tasks = []
  end

  def add(title)
    @tasks << Task.new(title)
    self
  end

  def complete(title)
    task = @tasks.find { |t| t.title == title }
    task.done = true if task
  end

  def stats
    done_count = @tasks.reduce(0) { |sum, t| t.done? ? sum + 1 : sum }
    "#{done_count} из #{@tasks.length} сделано"
  end
end

list = List.new
list.add("Купить кофе")
list.add("Написать тесты")
list.add("Прочитать главу")
list.complete("Купить кофе")
list.complete("Прочитать главу")

puts list.stats`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас и запуск',
      code: `puts "Привет!"
# запуск: ruby main.rb
# интерактивная консоль: irb
# end закрывает блоки; точка с запятой не нужна`
    },
    {
      title: 'Переменные и интерполяция',
      code: `name = "Аня"     # snake_case
age = 20         # Integer
height = 1.68    # Float
active = true    # TrueClass
nothing = nil    # NilClass
age.class        # Integer
"Мне #{age}"     # интерполяция
'Мне #{age}'     # БЕЗ интерполяции!`
    },
    {
      title: 'Условия',
      code: `if temp >= 25
  puts "Жарко"
elsif temp >= 10
  puts "Нормально"
else
  puts "Холодно"
end

unless raining
  puts "Зонт не нужен"
end
puts "Идём" if temp > 10   # модификатор
# ложь = только false и nil (0 — истина!)`
    },
    {
      title: 'Циклы и итераторы',
      code: `3.times { |i| puts i }     # 0, 1, 2
3.times do |i|
  puts "Шаг #{i}"
end
[2, 5].each { |n| puts n }
while k > 1
  k = k / 2
end
1.upto(5) { |i| puts i }
break    # выйти
next     # пропустить шаг`
    },
    {
      title: 'Массивы и строки',
      code: `a = [1, 2, 3]
a << 4            # дописать
a.push(5)         # то же
a.length          # 5
a.first / a.last
a.join(", ")      # "1, 2, 3, 4, 5"
s = "код"
s.upcase / s.downcase / s.capitalize
s.reverse / s.include?("о")
"а, б".split(", ")  # ["а", "б"]`
    },
    {
      title: 'Хэши и символы',
      code: `h = { coffee: 150, tea: 90 }  # ключи-символы
h[:coffee]                    # 150
h[:juice] = 120               # добавить
h.key?(:tea)                  # true
h.keys / h.values / h.length
h.each { |k, v| puts "#{k}: #{v}" }
:sym   # символ — неизменяемое имя, ключи лучше строк`
    },
    {
      title: 'Методы',
      code: `def add(a, b)
  a + b             # неявный return
end

def sign(n)
  return "плюс" if n > 0
  "ноль или минус"
end

def adult?(age)     # метод-вопрос
  age >= 18
end
add(2, 3)           # вызов; скобки можно опустить`
    },
    {
      title: 'Классы',
      code: `class Book
  attr_reader :title, :author

  def initialize(title, author)
    @title = title
    @author = author
  end

  def describe
    "#{@title} — #{@author}"
  end
end

book = Book.new("Война и мир", "Толстой")
book.title      # геттер от attr_reader
book.describe`
    },
    {
      title: 'Блоки, yield и лямбды',
      code: `def around
  return unless block_given?
  yield 1
  yield 2
end
around { |n| puts n }   # yield вызывает блок

pr = proc { |x| x }     # Proc: арность мягкая,
lam = ->(x) { x }       # lambda/стрелка: строгая;
pr.call(2)              # return у proc — из метода,
lam.call(2)             # у lambda — из лямбды
[1, 2].map(&:to_s)      # символ-метод как блок`
    },
    {
      title: 'ООП: наследование, модули, исключения',
      code: `class Dog < Animal        # наследование, один родитель
  def initialize(name, breed)
    super(name)           # initialize родителя
    @breed = breed
  end
end

module Greetable          # модуль-миксин
  def greet
    "Привет!"
  end
end
include Greetable         # методы модуля — классу

begin                     # контроль ошибок
  raise ArgumentError, "нет"
rescue ArgumentError => e
  puts e.message          # текст ошибки
ensure
  puts "выполняюсь всегда"
end`
    }
  ]
};
