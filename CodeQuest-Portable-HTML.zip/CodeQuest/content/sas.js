'use strict';
/* ============ CodeQuest — курс SAS ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.sas = {
  id: 'sas',
  title: 'SAS',
  emoji: '📈',
  color: '#2f7fbf',
  lang: 'sas',
  tagline: 'DATA-шаг и аналитика: 10 уровней',
  description: 'Язык статистического пакета SAS — стандарт фармы, банков и госстатистики 40 лет. DATA-шаг — уникальная модель построчной обработки. За 10 уровней: DATA и PROC, переменные и formats, SET и merge, условия, циклы do, функции, массивы, макросы и финальный отчёт.',

  levels: [

    {
      id: 'sas-1',
      title: 'DATA-шаг: строки в столбик',
      goal: 'Понять модель DATA-шага: неявный цикл по строкам',
      xp: 30,
      theory: [
        { t: 'p', html: 'Программа SAS состоит из шагов. <b>DATA-шаг</b> создаёт таблицы: <code>data выходной; set входной; … run;</code>. Секрет: DATA-шаг — НЕЯВНЫЙ цикл по строкам — код внутри выполняется для каждой строки входной таблицы. Это «конвейер строк».' },
        { t: 'code', code: `data work.clients;
    set work.raw;
    bonus = salary * 0.1;
run;

proc print data=work.clients;
run;` },
        { t: 'p', html: 'Каждый шаг завершается <code>run;</code>. Точка с запятой завершает КАЖДЫЙ оператор — забытая точка с запятой — ошибка №1 новичков SAS. Комментарии — <code>* … ;</code> и <code>/* … */</code>.' },
        { t: 'list', items: [
          '<b>data имя;</b> — создать таблицу;',
          '<b>set имя;</b> — читать строки входной;',
          '<b>run;</b> — выполнить шаг;',
          'новая переменная = просто формула в шаге.'
        ] },
        { t: 'note', html: 'PROC-шаги (proc print, proc means) — готовые процедуры: печать, статистика, регрессия. Данные течёт: DATA обрабатывает построчно, PROC агрегирует.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери DATA-шаг: из таблицы sales создай work.report с новой колонкой profit = revenue - cost.</p>',
        starter: `data work.report;
    TODO
run;`,
        rules: [
          { desc: 'set исходной таблицы', all: ['set\\s+work\\.sales;'] },
          { desc: 'Формула profit', all: ['profit\\s*=\\s*revenue\\s*-\\s*cost;'] }
        ],
        note: 'set work.sales; / profit = revenue - cost;'
      },
      hints: [
        'Чтение — set work.sales;',
        'Формула — обычное присваивание с ;'
      ],
      solution: `data work.report;
    set work.sales;
    profit = revenue - cost;
run;`
    },

    {
      id: 'sas-2',
      title: 'Переменные и длины',
      goal: 'Объявлять переменные, задавать длины и форматы',
      xp: 35,
      theory: [
        { t: 'p', html: 'Типы SAS: числа и символы ($). Объявление — <code>length name $ 20;</code> до первого присваивания. Форматы показа: <code>format price 8.2</code> (2 знака после запятой), даты — <code>date9.</code> (05FEB2024). Названия переменных — до 32 символов, без пробелов.' },
        { t: 'code', code: `data work.empl;
    length name $ 20 dept $ 10;
    set work.raw;

    format hire_date date9. salary 12.2;
    years = year(today()) - year(hire_date);
run;` },
        { t: 'p', html: 'Даты в SAS — числа дней с 01.01.1960! Поэтому с ними работает арифметика: разность дат — дни, функции year(), month(), intck(&apos;month&apos;, d1, d2) — интервалы между датами.' },
        { t: 'list', items: [
          '<b>length x $ 20</b> — символьная длина;',
          '<b>format</b> — вид показа, не значение;',
          '<b>today()</b> — текущая дата;',
          '<b>intck(&apos;year&apos;, d1, d2)</b> — полных интервалов между датами.'
        ] },
        { t: 'note', html: 'Эпоха 01.01.1960 — историческая шутка SAS, зато date-арифметика мгновенна: 200 лет дат — это всего 73000, число легко хранить в 4 байтах.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь объявления длины и формата даты.</p>',
        code: `data work.staff;
    {{0}} name $ 25;
    set work.raw;
    {{1}} start_date date9.;
    age = intck('year', birth, today());
run;`,
        blanks: [
          { answer: 'length' },
          { answer: 'format' }
        ],
        ci: false
      },
      hints: [
        'Объявление длины — length.',
        'Вид показа — format.'
      ],
      solution: ['length', 'format']
    },

    {
      id: 'sas-3',
      title: 'if/then/else и where',
      goal: 'Фильтровать строки: подмножества и удаление',
      xp: 40,
      theory: [
        { t: 'p', html: 'Условия в DATA-шаге: <code>if условие then действие; else действие;</code>. Фильтрация строк: <code>if условие;</code> (subsetting if) — оставить ТОЛЬКО подходящие, <code>if условие then delete;</code> — удалить неподходящие. WHERE — фильтр на этапе чтения (быстрее).' },
        { t: 'code', code: `data work.big;
    set work.all;
    where revenue > 1000;   * фильтр на входе;

    if region = "EU" then tier = 1;
    else if region = "US" then tier = 2;
    else tier = 3;

    if profit < 0 then delete;   * выбросить убыточные;
run;` },
        { t: 'p', html: 'Логика: and/or/not, сравнения =, ^= (не равно), &lt;, &gt;=, in: <code>if region in ("EU", "US")</code>. Порядок важен: subsetting if в конце шага уже не спасёт переменные, вычисленные раньше.' },
        { t: 'list', items: [
          '<b>if cond;</b> — оставить только эти строки;',
          '<b>where</b> — фильтр до попадания в PDV;',
          '<b>in (список)</b> — принадлежность набору;',
          '<b>^=</b> — не равно.'
        ] },
        { t: 'note', html: 'PDV (Program Data Vector) — внутренний буфер строки SAS: понимание «строка проходит через шаг целиком» — ключ к тому, как SAS думает о данных.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Сколько строк попадёт в выходную таблицу?</p>',
        code: `data out;
    set src;
    where age >= 18;
    if city = "Москва";
run;`,
        options: [
          `Все строки src`,
          `Совершеннолетние из Москвы`,
          `Только москвичи любого возраста`,
          `Совершеннолетние всех городов`
        ],
        correct: 1,
        explain: 'where сначала отфильтрует возраст, затем subsetting-if оставит только Москву — пересечение условий: совершеннолетние москвичи.'
      },
      hints: [
        'Фильтры применяются последовательно.',
        'where — раньше, if — позже, результат — пересечение.'
      ],
      solution: `Совершеннолетние из Москвы`
    },

    {
      id: 'sas-4',
      title: 'retain и sum',
      goal: 'Накапливать значения между строками',
      xp: 45,
      theory: [
        { t: 'p', html: 'Обычные переменные сбрасываются на каждой строке. <code>retain total 0;</code> — сохранять значение между строками! Короткая форма накопления: <code>total + x;</code> — само делает retain и прибавление.' },
        { t: 'code', code: `data work.summary;
    set work.sales;
    total + revenue;        * бегущая сумма;
    count + 1;              * счётчик строк;
    drop revenue;           * не выводить колонку;
run;` },
        { t: 'p', html: '<code>total + revenue;</code> — особый синтаксис SAS: переменная total сохраняется между строками и увеличивается. Это и есть running total. first./last. автоматические переменные для групп — работают с sorted данными:' },
        { t: 'code', code: `proc sort data=work.sales; by region; run;

data work.byregion;
    set work.sales;
    by region;
    if first.region then group_total = 0;
    group_total + revenue;
    if last.region then output;   * итог по группе;
run;` },
        { t: 'note', html: 'first./last. — флаги смены группы: фирменный приём SAS «обработка по группам в DATA-шаге». Требует сортировки by — отсюда proc sort перед шагом.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери накопление: retain-сумма выручки через короткий синтаксис и счётчик строк.</p>',
        starter: `data work.acc;
    set work.sales;
    TODO
run;`,
        rules: [
          { desc: 'Бегущая сумма', all: ['total\\s*\\+\\s*revenue;'] },
          { desc: 'Счётчик строк', all: ['count\\s*\\+\\s*1;'] }
        ],
        note: 'total + revenue; / count + 1;'
      },
      hints: [
        'Особый синтаксис: total + revenue; сам делает retain.',
        'Счётчик — count + 1;'
      ],
      solution: `data work.acc;
    set work.sales;
    total + revenue;
    count + 1;
run;`
    },

    {
      id: 'sas-5',
      title: 'merge и объединения',
      goal: 'Соединять таблицы: merge по ключу',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>merge табл1 табл2; by ключ;</code> — слияние по ключу (обе таблицы должны быть отсортированы по ключу!). Контроль совпадений — переменные in=: <code>if a; if b;</code> — типы соединений вручную: пересечение, левое, полное.' },
        { t: 'code', code: `proc sort data=work.clients; by id; run;
proc sort data=work.orders;  by id; run;

data work.full;
    merge work.clients(in=a) work.orders(in=b);
    by id;
    if a and b;     * только совпадающие (inner);
run;

data work.left;
    merge work.clients(in=a) work.orders(in=b);
    by id;
    if a;           * все клиенты (left join);
run;` },
        { t: 'p', html: 'Флаги in= — булевы «строка присутствует в этой таблице». Комбинация if a and b / if a / if a or b даёт inner/left/full join — SAS даёт полный контроль построчного слияния без SQL-синтаксиса.' },
        { t: 'note', html: 'Забытая сортировка перед merge by — классическая ошибка: SAS выдаст warning, но соединит неправильно. Правило: sort → merge → by, всегда.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь шаги слияния по ключу id.</p>',
        code: `proc {{0}} data=work.clients; by id; run;

data work.joined;
    {{1}} work.clients(in=a) work.orders(in=b);
    {{2}} id;
    if a and b;
run;`,
        blanks: [
          { answer: 'sort' },
          { answer: 'merge' },
          { answer: 'by' }
        ],
        ci: false
      },
      hints: [
        'Сначала сортировка — proc sort.',
        'Слияние — merge ... by id;'
      ],
      solution: ['sort', 'merge', 'by']
    },

    {
      id: 'sas-6',
      title: 'PROC MEANS и PROC FREQ',
      goal: 'Статистика готовыми процедурами',
      xp: 50,
      theory: [
        { t: 'p', html: '<code>proc means</code> — числовая статистика: mean, min, max, std, n по группам class/by. <code>proc freq</code> — частоты категорий и таблицы сопряжённости. <code>proc sort</code> — сортировка, <code>proc print</code> — печать. Сотни PROC-ов покрывают всю аналитику.' },
        { t: 'code', code: `proc means data=work.sales mean min max std;
    class region;
    var revenue;
run;

proc freq data=work.sales;
    tables region*segment / chisq;
run;

proc sort data=work.sales out=sorted;
    by descending revenue;
run;` },
        { t: 'p', html: 'class — группировка без сортировки (в отличие от by). var — анализируемые числовые переменные. tables a*b — перекрёстные частоты, опция chisq — хи-квадрат. descending — обратная сортировка.' },
        { t: 'list', items: [
          '<b>proc means</b>: статистика по class-группам;',
          '<b>proc freq</b>: частоты, кросс-таблицы, тесты;',
          '<b>proc sort</b>: упорядочивание, descending;',
          'out= — результат в новую таблицу.'
        ] },
        { t: 'note', html: 'PROC выводит в отчёт; чтобы сохранить результат — ODS OUTPUT или out=/output out=. Связка DATA (подготовка) → PROC (анализ) — ритм всей SAS-разработки.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери proc means: среднее по revenue с группировкой class region.</p>',
        starter: `TODO`,
        rules: [
          { desc: 'proc means объявлен', all: ['proc\\s+means\\s+data=\\w+[\\w.]*'] },
          { desc: 'Группировка class region', all: ['class\\s+region;'] },
          { desc: 'Переменная var revenue', all: ['var\\s+revenue;'] },
          { desc: 'run; завершает', all: ['run;'] }
        ],
        note: 'proc means data=... mean; / class region; / var revenue; / run;'
      },
      hints: [
        'Каркас: proc means ... ; class ...; var ...; run;',
        'Среднее — ключевое слово mean в скобках proc.'
      ],
      solution: `proc means data=work.sales mean;
    class region;
    var revenue;
run;`
    },

    {
      id: 'sas-7',
      title: 'Функции и массивы',
      goal: 'Строковые/числовые функции и массивы SAS',
      xp: 50,
      theory: [
        { t: 'p', html: 'Функции: строки — <code>upcase, substr, catx, strip, scan</code>, числа — <code>round, int, abs</code>, даты — <code>intnx, intck</code>. Массив: <code>array nums{*} v1-v5;</code> — псевдоним набора колонок для обработки в цикле do.' },
        { t: 'code', code: `data work.clean;
    set work.raw;
    fullname = catx(" ", first_name, last_name);
    price = round(price, 0.01);
    word2 = scan(address, 2);

    array vals{*} q1-q10;
    do i = 1 to dim(vals);
        if vals{i} = . then vals{i} = 0;
    end;
    drop i;
run;` },
        { t: 'p', html: 'Массив НЕ создаёт данных — это ярлык на существующие колонки (q1-q10 — десять штук). dim() — размер. Внутри do-цикла обрабатываются все колонки разом — типовой приём очистки анкет: заменяем пропуски (.) нулями.' },
        { t: 'note', html: 'Пропущенное числовое значение в SAS — точка <code>.</code>! Проверка «нет данных» — if x = . Или missing(x). Уникальная особенность языка, которую надо принять с первых дней.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь элементы работы с массивом.</p>',
        code: `array scores{{0}} s1-s8;
do i = 1 to {{1}}(scores);
    if scores{i} = . then scores{i} = 0;
end;`,
        blanks: [
          { answer: '{*}' },
          { answer: 'dim' }
        ],
        ci: false
      },
      hints: [
        'Автоматический размер — {*}.',
        'Число элементов — dim(массив).'
      ],
      solution: ['{*}', 'dim']
    },

    {
      id: 'sas-8',
      title: 'Циклы do',
      goal: 'Явные циклы: do i, do while, do until',
      xp: 55,
      theory: [
        { t: 'p', html: 'Явный цикл: <code>do i = 1 to 10 by 2; … end;</code>. С условиями: <code>do while (условие);</code> и <code>do until (условие);</code>. В DATA-шаге цикл выполняется ВНУТРИ одной строки — генерация данных:' },
        { t: 'code', code: `data work.series;
    do i = 1 to 10;
        value = i ** 2;
        output;          * каждая итерация = строка!;
    end;
run;

data work.grow;
    amount = 1000;
    do year = 1 to 10 until(amount > 2000);
        amount = amount * 1.08;
        output;
    end;
run;` },
        { t: 'p', html: '<code>output;</code> — записать текущую строку в таблицу: без него в таблицу попадает только ПОСЛЕДНЯЯ итерация. Это главный трюк генерации: цикл внутри строки + output = столько строк, сколько итераций.' },
        { t: 'list', items: [
          '<b>do i = a to b by c;</b> — счётный;',
          '<b>do while/until (cond);</b> — условный;',
          '<b>output;</b> — строка в таблицу немедленно;',
          '<b>leave</b> — выход из цикла (break).'
        ] },
        { t: 'note', html: 'do until проверяет условие ПОСЛЕ тела (тело исполнится хотя бы раз), do while — до. Смешение — источник «лишних» строк в данных.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Сколько строк попадёт в таблицу? Одно число.</p>',
        code: `data out;
    do i = 1 to 6 by 2;
        output;
    end;
run;`,
        solution: `3`,
        ci: false
      },
      hints: [
        'i принимает 1, 3, 5.',
        'Каждая итерация с output — одна строка.'
      ],
      solution: `3`
    },

    {
      id: 'sas-9',
      title: 'Макросы %macro',
      goal: 'Генерировать код макропеременными и макросами',
      xp: 55,
      theory: [
        { t: 'p', html: 'Макроязык SAS — препроцессор, генерирующий код. Макропеременные: <code>%let name=значение;</code> подстановка <code>&amp;name</code>. Макрос: <code>%macro имя(параметры); … %mend;</code> вызов <code>%имя(арг)</code>. Циклы %do — генерация повторяющихся блоков.' },
        { t: 'code', code: `%let year = 2024;

data work.y&year;
    set work.raw;
    where report_year = &year;
run;

%macro report(tbl, grp);
    proc means data=&tbl mean;
        class &grp;
    run;
%mend;

%report(work.sales, region)
%report(work.hr, dept)` },
        { t: 'p', html: 'Макрос %report сгенерировал ДВА proc means из одного определения — по вызову на каждый. Это мета-программирование: макросы пишут код SAS, который потом исполняется. Логика: &amp;tbl и &amp;grp — текстовые подстановки до компиляции.' },
        { t: 'note', html: 'Двойной амперсанд &&&& — косвенная ссылка: &&name&i обращается к name1, name2… Фарма-программисты живут на макросах: стандартные репорты параметризуются и тиражируются.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери макрос report с параметром tbl, печатающий proc print данных &tbl.</p>',
        starter: `TODO`,
        rules: [
          { desc: '%macro с параметром', all: ['%macro\\s+report\\s*\\(\\s*tbl\\s*\\);'] },
          { desc: 'Подстановка &tbl', all: ['&tbl;'] },
          { desc: '%mend закрывает', all: ['%mend;'] },
          { desc: 'Вызов макроса', all: ['%report\\s*\\(\\s*work\\.sales\\s*\\)'] }
        ],
        note: '%macro report(tbl); / proc print data=&tbl; run; / %mend; / %report(work.sales)'
      },
      hints: [
        'Каркас: %macro имя(парам); … %mend;',
        'Внутри — обычный код с &парам.'
      ],
      solution: `%macro report(tbl);
    proc print data=&tbl;
    run;
%mend;

%report(work.sales)`
    },

    {
      id: 'sas-10',
      title: 'Проект: регуляторный отчёт',
      goal: 'Собрать полный пайплайн: подготовка, агрегаты, макрорасширение',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финал — типовой фарма/банк-отчёт: отфильтровать данные, посчитать сводку по группам, отформатировать, параметризовать макросом. Ровно так выглядят программы валидации клинических данных и банковские регуляторные репорты.' },
        { t: 'code', code: `%macro summary(indata, groupcol, outdata);
    data work.clean;
        set &indata;
        where revenue > 0;
        profit_margin = round(profit / revenue * 100, 0.1);
    run;

    proc sort data=work.clean; by &groupcol; run;

    proc means data=work.clean mean std min max;
        class &groupcol;
        var profit_margin;
        output out=&outdata mean=avg_margin;
    run;
%mend;

%summary(work.sales, region, work.region_summary)
%summary(work.sales, segment, work.seg_summary)` },
        { t: 'list', items: [
          '<b>DATA-шаг</b> — фильтр + расчётная колонка;',
          '<b>proc sort</b> — упорядочить для class;',
          '<b>proc means</b> — статистика по группам;',
          '<b>output out=</b> — результаты в таблицу;',
          '<b>%macro с 3 параметрами</b> — тиражируемость.'
        ] },
        { t: 'note', html: 'Добавь title "&groupcol Summary"; в proc — заголовки в отчёте подставятся макропеременной. Этот шаблон — 80% реального SAS-кодинга: данные через DATA, анализ через PROC, масштаб через %macro. Отсюда прямая дорога в фарму, банки и CRO-компании с их legendary зарплатами SAS-программистов.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь ключевые элементы пайплайна.</p>',
        code: `data work.clean;
    set &indata;
    {{0}} revenue > 0;
run;

proc {{1}} data=work.clean mean;
    class &groupcol;
    {{2}} profit_margin;
run;`,
        blanks: [
          { answer: 'where' },
          { answer: 'means' },
          { answer: 'var' }
        ],
        ci: false
      },
      hints: [
        'Фильтр строк — where.',
        'Статистика — proc means; переменная — var.'
      ],
      solution: ['where', 'means', 'var']
    }
  ]
};
