'use strict';
/* ============ CodeQuest — курс Scala ============
   Scala не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.scala = {
  id: 'scala',
  title: 'Scala',
  emoji: '🪜',
  color: '#c22d40',
  lang: 'scala',
  tagline: 'Scala для больших данных: от val до sealed-иерархий',
  description: 'Язык Мартина Одерски (EPFL, 2004): Scala расшифровывается как «scalable language» — масштабируемый язык. Он совмещает ООП и функциональное программирование и работает на JVM; на нём написаны Spark, Kafka и Akka. За 16 уровней пройдёшь путь от первого println до sealed-иерархий, Option как коллекции, композиции функций и проекта «Процессор заказов» в стиле больших данных.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'scala-1',
      title: 'Первая программа',
      goal: 'Собрать каркас программы: object Main extends App и вывод через println',
      xp: 30,
      theory: [
        { t: 'p', html: 'Scala — язык, созданный Мартином Одерски в Швейцарской высшей технической школе Лозанны (EPFL) в 2004 году. Имя расшифровывается как «scalable language» — масштабируемый язык: на нём пишут и маленькие скрипты, и огромные системы. Scala компилируется в тот же байткод, что и Java, и живёт на JVM, поэтому свободно использует все Java-библиотеки. На Scala написаны Spark (большие данные), Kafka (потоки сообщений), Akka; долгие годы Twitter и LinkedIn строили на ней свои бэкенды.' },
        { t: 'h', html: 'Два способа начать' },
        { t: 'p', html: 'В Scala 3 точку входа объявляют аннотацией: <code>@main def run(): Unit = println("…")</code>. Классический стиль — объект, наследующий <code>App</code>: весь код его тела выполняется при запуске. В этом курсе используем классический каркас <code>object Main extends App</code> — он встречается в огромном количестве учебников и старых проектов.' },
        { t: 'code', code: `object Main extends App {
  println("Привет, CodeQuest!")
  println("Это моя первая программа на Scala.")
}` },
        { t: 'p', html: 'Слово <code>object</code> создаёт одиночный объект — синглтон: экземпляр существует ровно один, создавать его не нужно. <code>extends App</code> означает «наследует поведение приложения» — тело объекта становится телом программы. <code>println</code> печатает строку и переводит курсор на новую. Точка с запятой в конце строки не нужна: компилятор сам понимает, где заканчивается выражение.' },
        { t: 'h', html: 'Как запустить' },
        { t: 'p', html: 'Нужен установленный Scala — он тянет за собой JVM. Файл <code>Main.scala</code> запускается одной командой <code>scala Main.scala</code>: компиляция и старт происходят за один шаг. Для больших проектов используют сборщик <code>sbt</code>, но для учёбы достаточно прямого запуска файла.' },
        { t: 'warn', html: 'Регистр букв важен: <code>Main</code> и <code>App</code> — с большой буквы, <code>println</code> пишется слитно. Скрипт не запускается в приложении — проверка структурная, но пиши настоящий код, как для <code>scala Main.scala</code>.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первую программу: каркас <code>object Main extends App { … }</code> уже стоит. Выведи через <code>println</code> точную фразу «Привет, CodeQuest!» (в двойных кавычках) и ещё одну любую строку на свой вкус.</p>',
        starter: `object Main extends App {
  // TODO: выведи приветствие
}`,
        rules: [
          { desc: 'Каркас: object Main extends App', all: ['object\\s+Main\\s+extends\\s+App'] },
          { desc: 'Тело объекта в фигурных скобках', all: ['\\{[\\s\\S]*\\}'] },
          { desc: 'Есть вывод через println или print', any: ['println\\s*\\(', 'print\\s*\\('] },
          { desc: 'В кавычках — фраза "Привет, CodeQuest!"', all: ['"Привет, CodeQuest!"'] },
          { desc: 'Код непустой и без пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас object Main extends App { ... } уже стоит — пиши внутри скобок.',
        'println("Привет, CodeQuest!") — кавычки двойные, запятая и восклицательный знак на месте.',
        'Можно вывести и вторую строку — любой текст на свой вкус.'
      ],
      solution: `object Main extends App {
  println("Привет, CodeQuest!")
  println("Это моя первая программа на Scala.")
}`
    },

    /* ---------- 2. val, var и типы ---------- */
    {
      id: 'scala-2',
      title: 'val, var и типы',
      goal: 'Различать val и var, полагаться на выведение типов и подставлять значения в строки через s"…"',
      xp: 30,
      theory: [
        { t: 'p', html: '<code>val</code> — неизменяемое значение: присвоил один раз — навсегда. <code>var</code> — изменяемая переменная. В идиоматичном Scala по умолчанию берут val: неизменяемость — не ограничение, а суперсила. Значения, которые нельзя случайно изменить, проще читать и безопаснее передавать между потоками.' },
        { t: 'code', code: `val name = "Аня"       // не изменится
var age = 20           // можно менять
age = 21               // ок: это var` },
        { t: 'p', html: 'Типы можно не писать: компилятор выводит их из значения — это называется <b>выведением типов</b>. <code>val name = "Аня"</code> — и name уже String. Тип можно указать и явно, через двоеточие: <code>val age: Int = 20</code>. Явная аннотация полезна для публичных функций и документации.' },
        { t: 'table', head: ['Тип', 'Хранит', 'Примеры'], rows: [
          ['Int', 'целые числа', '42, -7, 0'],
          ['Double', 'дробные числа', '3.14, -0.5, 2.0'],
          ['String', 'текст в кавычках', '"привет"'],
          ['Boolean', 'истина/ложь', 'true, false'],
          ['Unit', 'ничего (аналог void)', '()']
        ] },
        { t: 'p', html: 'Строки умеют интерполяцию: поставь <code>s</code> перед кавычками — и внутри строки работают переменные: <code>s"Привет, $name"</code>. Выражения — в фигурных скобках: <code>s"через год: ${age + 1}"</code>. Без буквы s подстановки не будет — напечатается буквально $name.' },
        { t: 'warn', html: 'Попробуй присвоить новое значение val — компилятор откажет: «reassignment to val». Это не баг, а защита: если значение правда должно меняться, честно объявляй var.' },
        { t: 'note', html: 'Имена — camelCase: <code>maxScore</code>, <code>userName</code>. Классы и типы — с большой буквы. Правило выбора простое: val по умолчанию, var только когда значение действительно должно меняться.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни программу: имя должно быть неизменяемым, возраст — изменяемым (строка <code>age = 21</code> подсказывает, какой нужен). В выводе подставь обе переменные внутрь строки-интерполяции <code>s"…"</code>.</p>',
        code: `object Main extends App {
  {{0}} name = "Аня"
  {{1}} age = 20
  age = 21
  println(s"{{2}}, тебе уже {{3}}")
}`,
        blanks: [
          { answer: 'val' },
          { answer: 'var' },
          { answer: '$name', alt: ['${name}'] },
          { answer: '$age', alt: ['${age}'] }
        ]
      },
      hints: [
        'Неизменяемое значение — val, изменяемая переменная — var.',
        'Внутри s"…" переменные подставляются после знака доллара.',
        'Строка age = 21 меняет значение — значит, age объявлена через var.'
      ],
      solution: ['val', 'var', '$name', '$age']
    },

    /* ---------- 3. if — выражение ---------- */
    {
      id: 'scala-3',
      title: 'if — это выражение',
      goal: 'Использовать if как выражение, которое возвращает значение, и не путать = с ==',
      xp: 35,
      theory: [
        { t: 'p', html: 'if в Scala — не инструкция, а <b>выражение</b>: оно возвращает значение. Результат можно присвоить переменной, напечатать, передать дальше. Это одно из главных отличий Scala от Java и C++.' },
        { t: 'code', code: `val temp = 12
val verdict = if (temp >= 20) "тепло" else "холодно"
println(verdict)   // холодно` },
        { t: 'p', html: 'Поэтому в Scala нет тернарного оператора <code>?:</code> из Java — if/else сам его заменяет, и читается лучше. Ветки должны давать значения совместимых типов: здесь обе — String.' },
        { t: 'p', html: 'Если <code>else</code> забыть, выражение вернёт <code>Unit</code> («ничего»), и общий тип результата размажется в Any — компилятор такое допустит, но пользы от этого мало. Правило: используешь if как выражение — всегда пиши else.' },
        { t: 'code', code: `val n = -5
val label = if (n > 0) "плюс" else if (n < 0) "минус" else "ноль"
println(label)     // минус` },
        { t: 'p', html: 'Внутри условия — знакомая логика: <code>==</code>, <code>!=</code>, <code>&gt;</code>, <code>&lt;</code>, <code>&gt;=</code>, <code>&lt;=</code>, <code>&amp;&amp;</code> (и), <code>||</code> (или), <code>!</code> (не). Скобки вокруг условия обязательны, фигурные скобки нужны, когда в ветке несколько строк. Цепочка else if проверяется сверху вниз — срабатывает первая истинная ветка.' },
        { t: 'warn', html: '<code>=</code> присваивает, <code>==</code> сравнивает. Приятный сюрприз: в Scala <code>==</code> у объектов сравнивает по содержимому (как equals в Java) — «Аня» == "Аня" истинно, ловушка сравнения ссылок тебя не подстерегает.' },
        { t: 'note', html: 'if-выражения можно вкладывать друг в друга и собирать в цепочки. А ещё выражения возвращают значения из функций — скоро увидишь, что и функции в Scala пишутся как одно большое выражение.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет эта программа (обе строки)?</p><pre>val temp = 12
val verdict = if (temp &gt;= 20) "тепло" else "холодно"
println(verdict)
println(if (temp &gt;= 20) 1 else 0)</pre>`,
        options: ['холодно и 0', 'тепло и 1', 'холодно и 1', 'Ошибка: if нельзя присваивать'],
        correct: 0,
        explain: 'temp = 12, условие 12 >= 20 ложно — берётся ветка else: «холодно». Второй if тоже ложен и возвращает 0. if — выражение, его результат можно и присваивать, и печатать.',
        solution: 0
      },
      hints: [
        '12 >= 20 — правда или ложь? Ответ определяет обе строки.',
        'if возвращает значение той ветки, которая сработала.'
      ],
      solution: 0
    },

    /* ---------- 4. Циклы ---------- */
    {
      id: 'scala-4',
      title: 'Циклы: for и while',
      goal: 'Перебирать диапазоны через for (i <- …) с to/until/by и крутить while с var-счётчиком',
      xp: 35,
      theory: [
        { t: 'p', html: 'Цикл for в Scala перебирает диапазоны: <code>for (i &lt;- 1 to 5)</code> — i пробежит 1, 2, 3, 4, 5 включительно. Стрелка <code>&lt;-</code> читается «из»: i получает каждое значение диапазона по очереди.' },
        { t: 'code', code: `object Main extends App {
  for (i <- 1 to 3) {
    println(s"шаг $i")
  }
}` },
        { t: 'p', html: 'Слова-регуляторы: <code>to</code> — включительно, <code>until</code> — исключительно: <code>1 until 5</code> — это 1, 2, 3, 4. Шаг задаёт <code>by</code>: <code>1 to 10 by 2</code> — 1, 3, 5, 7, 9. Перебирать можно и коллекции: <code>for (x &lt;- List("а", "б"))</code>.' },
        { t: 'h', html: 'while — классика' },
        { t: 'code', code: `var n = 40
while (n >= 10) {
  n = n / 2
}
println(n)` },
        { t: 'p', html: 'while крутится, пока условие истинно. Счётчик для while — обязательно <code>var</code>: его придётся менять руками внутри тела. Деление целых отбрасывает дробную часть: 40 / 2 = 20, 20 / 2 = 10, 10 / 2 = 5. Забудешь менять переменную — цикл станет вечным.' },
        { t: 'list', items: [
          '<b>break</b> в Scala нет из коробки — циклы строят через условия и флаги;',
          '<b>for с yield</b> собирает новую коллекцию (for-comprehension) — увидишь в уровне про идиомы;',
          '<b>foreach</b> — метод коллекции: <code>nums.foreach(println)</code>.',
          '<b>Целочисленное деление</b> отрезает остаток: 7 / 2 = 3.'
        ] },
        { t: 'warn', html: 'Код не запускается в приложении — циклы придётся прокручивать в голове. Записывай значения на бумаге: сумма после каждого круга, текущее n. Задание уровня — предскажи вывод построчно.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай программу и напиши, что она выведет в консоль — по одной строке на каждый вывод, в порядке появления.</p>',
        code: `object Main extends App {
  var sum = 0
  for (i <- 1 to 5 by 2) {
    sum += i
  }
  println(s"sum=$sum")

  var n = 40
  while (n >= 10) {
    n = n / 2
  }
  println(s"n=$n")
}`,
        answer: `sum=9
n=5`
      },
      hints: [
        '1 to 5 by 2 — это 1, 3, 5. Сложи их руками.',
        'В while дели n пополам, пока условие n >= 10 истинно. Остановись, когда оно станет ложным.',
        'Целочисленное деление отбрасывает остаток: 10 / 2 = 5.'
      ],
      solution: `sum=9
n=5`
    },

    /* ---------- 5. Коллекции ---------- */
    {
      id: 'scala-5',
      title: 'Коллекции: List, Vector, Map',
      goal: 'Создавать List и Vector, читать head/length, перебирать элементы и различать индексы в круглых скобках',
      xp: 40,
      theory: [
        { t: 'p', html: '<code>List</code> — основной список Scala: неизменяемый связный список. Создаётся литералом <code>List("а", "б", "в")</code>. Изменить его нельзя — можно получить новый список, но об этом чуть позже.' },
        { t: 'code', code: `val fruits = List("яблоко", "банан", "киви")

println(fruits.length)   // 3
println(fruits.head)     // яблоко — первый
println(fruits.tail)     // List(банан, киви) — всё, кроме первого` },
        { t: 'p', html: '<code>head</code> — первый элемент, <code>tail</code> — всё остальное, <code>length</code> — длина (у Map — <code>size</code>). Обращение по индексу: <code>fruits(0)</code> — в Scala индекс берут <b>круглыми</b> скобками, не квадратными!' },
        { t: 'h', html: 'Неизменяемость и Vector' },
        { t: 'p', html: 'Методы не меняют коллекцию, а возвращают новую: <code>"х" :: fruits</code> — новый список с «х» в начале, <code>fruits :+ "груша"</code> — с «грушей» в конце. <code>Vector</code> — родственный List неизменяемый список, но с быстрым доступом по индексу в любом месте.' },
        { t: 'code', code: `val nums = Vector(10, 20, 30)
println(nums(1))         // 20
println(nums.length)     // 3` },
        { t: 'p', html: '<code>Map</code> — словарь пар ключ → значение: <code>Map("Аня" -&gt; 20, "Борис" -&gt; 25)</code>. Чтение по ключу: <code>ages("Аня")</code>. Стрелка <code>-&gt;</code> создаёт пару. Обращение к отсутствующему ключу бросит исключение — безопаснее <code>ages.get("Оля")</code>, вернётся Option (тема уровня 8).' },
        { t: 'warn', html: 'Квадратные скобки в Scala — для типов: <code>List[Int]</code>, а не для индексов. <code>fruits[0]</code> не скомпилируется — нужно <code>fruits(0)</code>. И List неизменяем: <code>fruits :+ "х"</code> само по себе ничего не меняет — результат надо сохранить в val.' },
        { t: 'note', html: 'Пустой список — <code>List()</code> или <code>Nil</code>. Проверки: <code>fruits.isEmpty</code>, <code>fruits.contains("банан")</code>. Для больших списков с частым доступом по индексу бери Vector — у List он медленный в середине.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери программу со списком: объяви <code>val</code> со списком <code>List</code> из 3–4 строк, выведи его длину через <code>.length</code> и первый элемент через <code>.head</code>, затем перебери список и выведи каждый элемент (через <code>foreach</code> или <code>for</code>).</p>',
        starter: `object Main extends App {
  // TODO: список, длина, первый элемент, перебор
}`,
        rules: [
          { desc: 'Объявлена коллекция: List, Vector или Map', any: ['(List|Vector|Map)\\s*\\('] },
          { desc: 'Коллекция хранится в val', all: ['val\\s+\\w+'] },
          { desc: 'Размер взят через .length или .size', any: ['\\.length', '\\.size'] },
          { desc: 'Первый элемент получен через .head или по индексу (0)', any: ['\\.head', '\\(\\s*0\\s*\\)'] },
          { desc: 'Коллекция перебирается: foreach или for (x <- …)', any: ['\\.foreach', '\\bfor\\s*\\(\\s*\\w+\\s*<-'] },
          { desc: 'Есть вывод println, пометок TODO нет', all: ['\\S'], any: ['println\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Список: val fruits = List("яблоко", "банан", "киви").',
        'Длина — fruits.length, первый элемент — fruits.head.',
        'Перебор: fruits.foreach(f => println(f)) или for (f <- fruits) println(f).'
      ],
      solution: `object Main extends App {
  val fruits = List("яблоко", "банан", "киви")

  println(fruits.length)
  println(fruits.head)

  fruits.foreach(f => println(f))
}`
    },

    /* ---------- 6. Функции и лямбды ---------- */
    {
      id: 'scala-6',
      title: 'Функции и лямбды',
      goal: 'Писать def-функции, возвращающие последнее выражение, и использовать лямбды x => x * 2',
      xp: 45,
      theory: [
        { t: 'p', html: 'Функция объявляется словом <code>def</code>: <code>def имя(параметры): ТипРезультата = тело</code>. Тип результата можно не писать — выведется сам. Параметры всегда со своими типами: <code>def add(a: Int, b: Int) = a + b</code>.' },
        { t: 'code', code: `def add(a: Int, b: Int): Int = a + b

println(add(2, 3))   // 5` },
        { t: 'p', html: 'Никаких <code>return</code>: возвращается значение <b>последнего выражения</b> тела. Если тело — одно выражение, можно писать его прямо после знака равенства: <code>def double(x: Int) = x * 2</code>. Функция в Scala — это выражение, а не последовательность инструкций.' },
        { t: 'code', code: `def celebrate(name: String) = {
  val shout = name.toUpperCase
  s"Ура, $shout!"
}

println(celebrate("Аня"))   // Ура, АНЯ!` },
        { t: 'h', html: 'Лямбды — функции без имени' },
        { t: 'p', html: 'Лямбда — функция-значение: <code>(n: Int) =&gt; n * 3</code>, а если тип выведется — короче: <code>n =&gt; n * 3</code>. Ещё короче, с подчёркиванием вместо параметра: <code>_ * 3</code>. Лямбды передают в методы коллекций: <code>nums.map(_ * 2)</code>, <code>nums.foreach(println)</code>.' },
        { t: 'code', code: `val triple = (n: Int) => n * 3
println(triple(7))    // 21

val nums = List(1, 2, 3)
println(nums.map(_ * 10))   // List(10, 20, 30)` },
        { t: 'warn', html: '<code>return</code> в Scala почти не используют — в лямбде он вообще означает выход не из лямбды, а из объемлющего метода. Правило простое: последнее выражение тела — результат функции.' },
        { t: 'note', html: 'У методов и функций разная природа: метод — часть объекта, функция — полноценное значение, которое можно передавать. На старте разница не важна: и то, и другое вызывается скобками.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет эта программа (обе строки)?</p><pre>def celebrate(name: String) = {
  val shout = name.toUpperCase
  s"Ура, $shout!"
}

val triple = (n: Int) =&gt; n * 3
println(celebrate("Аня"))
println(triple(7))</pre>`,
        options: ['Ура, АНЯ! и 21', 'Ура, Аня! и 7', 'Ура, АНЯ! и 7', 'Ошибка: в функции нужен return'],
        correct: 0,
        explain: 'Последнее выражение функции возвращается автоматически: s"Ура, $shout!" даёт «Ура, АНЯ!» — toUpperCase перевёл буквы в верхний регистр. Лямбда n => n * 3 от 7 даёт 21. return в Scala не нужен.',
        solution: 0
      },
      hints: [
        'toUpperCase делает все буквы заглавными.',
        'Результат функции — последнее выражение тела; лямбда умножает на 3.'
      ],
      solution: 0
    },

    /* ---------- 7. case class и match ---------- */
    {
      id: 'scala-7',
      title: 'case class и match',
      goal: 'Объявлять case class с полями, создавать объекты без new и разбирать их через match/case',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>case class</code> — класс-карточка данных: компилятор сам делает поля публичными val, добавляет equals, hashCode и красивый toString, а ещё фабрику <code>apply</code> — создавать объекты можно без <code>new</code>.' },
        { t: 'code', code: `case class Book(title: String, pages: Int)

val b = Book("Мартин Иден", 400)   // без new!
println(b.title)     // Мартин Иден
println(b.pages)     // 400
println(b)           // Book(Мартин Иден,400)` },
        { t: 'p', html: 'Главная сила case class — <b>сопоставление с образцом</b>. <code>match</code> перебирает шаблоны <code>case</code> сверху вниз и возвращает значение первой подходящей ветки. Для case class работает распаковка: <code>case Book(_, p)</code> — взять поле pages в переменную p.' },
        { t: 'code', code: `def size(b: Book): String = b match {
  case Book(_, p) if p > 300  => "Толстая"
  case Book(_, p) if p <= 300 => "Тонкая"
  case _                      => "Неизвестно"
}` },
        { t: 'p', html: 'Читается так: «если книга с любым названием (подчёркивание _ отбрасывает поле) и больше 300 страниц — Толстая». <code>if</code> после шаблона — охранник (guard), дополнительное условие. <code>case _</code> — ветка «всё остальное», аналог default. Match — тоже выражение: его результат присваивают или возвращают.' },
        { t: 'p', html: 'Компилятор следит за полнотой: если какой-то вариант не обработан, он предупредит. Это ещё одна проверка «до запуска» — типы и шаблоны ловят ошибки вместо позднего падения в рантайме.' },
        { t: 'warn', html: 'case class обычно объявляют на верхнем уровне файла или внутри объекта, а не внутри цикла или функции. И не путай: <code>case</code> в match — это ветка шаблона, <code>case class</code> — тип данных. Слова похожи, роли разные.' },
        { t: 'note', html: 'Если поле нужно, дай ему имя в шаблоне: <code>case Book(t, p) =&gt; s"$t: $p страниц"</code>. Поля распаковываются по порядку объявления. Подчёркивание <code>_</code> всегда значит «мне это не важно».' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери реестр книг: объяви <code>case class Book(title: String, pages: Int)</code>, создай две книги через <code>val</code>, напиши функцию <code>size</code>, которая через <code>match</code> возвращает «Толстая» (больше 300 страниц) или «Тонкая», и выведи результат для обеих книг.</p>',
        starter: `object Main extends App {
  // TODO: case class Book, две книги, match в функции size
}`,
        rules: [
          { desc: 'case class Book объявлена с полями title: String и pages: Int', all: ['case\\s+class\\s+Book\\s*\\(', 'title\\s*:\\s*String', 'pages\\s*:\\s*Int'] },
          { desc: 'Созданы объекты Book: val … = Book(…)', all: ['val\\s+\\w+\\s*=\\s*Book\\s*\\('] },
          { desc: 'Есть сопоставление match', all: ['\\bmatch\\b'] },
          { desc: 'Есть ветки case с шаблоном', any: ['case\\s+Book\\s*\\(', 'case\\s+_\\s+if\\b', 'case\\s+\\w+\\s+if\\b', 'case\\s+_\\s*=>'] },
          { desc: 'Результат выводится через println', any: ['println\\s*\\('] },
          { desc: 'Код непустой и без пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Объявление: case class Book(title: String, pages: Int) — внутри Main, над книгами.',
        'Функция: def size(b: Book): String = b match { case Book(_, p) if p > 300 => "Толстая" ... }.',
        'Не забудь ветку case _ => — «всё остальное».'
      ],
      solution: `object Main extends App {
  case class Book(title: String, pages: Int)

  val b1 = Book("Война и мир", 1200)
  val b2 = Book("Сказки", 40)

  def size(b: Book): String = b match {
    case Book(_, p) if p > 300  => "Толстая"
    case Book(_, p) if p <= 300 => "Тонкая"
    case _                      => "Неизвестно"
  }

  println(size(b1))
  println(size(b2))
}`
    },

    /* ---------- 8. Option ---------- */
    {
      id: 'scala-8',
      title: 'Option вместо null',
      goal: 'Читать Map через get с Option, разбирать Some и None через getOrElse и match',
      xp: 45,
      theory: [
        { t: 'p', html: 'В Java <code>null</code> означает «ничего», и попытка вызвать метод у null роняет программу с NullPointerException — самой известной ошибкой в индустрии. Scala идёт другим путём: возможное отсутствие значения упаковывается в тип <code>Option</code>.' },
        { t: 'p', html: 'Option — коробочка, в которой лежит либо <code>Some(значение)</code>, либо <code>None</code> (пусто). Метод <code>get</code> у Map возвращает именно Option: ключ найден — Some, не найден — None. Тип честно сообщает в сигнатуре: «здесь значения может не быть».' },
        { t: 'code', code: `val phones = Map("Аня" -> "123", "Борис" -> "456")

println(phones.get("Аня"))    // Some(123)
println(phones.get("Оля"))    // None` },
        { t: 'h', html: 'Как доставать значение' },
        { t: 'p', html: '<code>getOrElse</code> — достать значение или подставить запасное: <code>phones.get("Оля").getOrElse("нет")</code>. Через match: <code>case Some(v) =&gt; …</code> и <code>case None =&gt; …</code> — компилятор заставит обработать оба варианта.' },
        { t: 'code', code: `val found = phones.get("Оля")
println(found.getOrElse("нет номера"))

found match {
  case Some(p) => println(s"Номер: $p")
  case None    => println("Номера нет")
}` },
        { t: 'p', html: 'У Option есть <code>map</code>, <code>foreach</code> и вся мощь коллекций: <code>Some(5).map(_ * 2)</code> даст Some(10). Option — коллекция из нуля или одного элемента, поэтому с ней работают те же приёмы, что и со списками.' },
        { t: 'warn', html: 'null в Scala существует — для совместимости с Java, но идиоматичный код его не использует. И осторожно с <code>.get</code> у самого Option: он достаёт значение «вслепую» и для None бросит исключение. Сначала getOrElse или match.' },
        { t: 'note', html: 'Забудешь ветку None в match — получишь предупреждение «match may not be exhaustive». Опять типы поймали ошибку до запуска: Option превращает «случайный ноль» в видимую задачу для компилятора.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет эта программа (обе строки)?</p><pre>val phones = Map("Аня" -&gt; "123", "Борис" -&gt; "456")
val found = phones.get("Оля")
println(found)
println(found.getOrElse("нет номера"))</pre>`,
        options: ['None и нет номера', 'null и нет номера', 'None и Оля', 'Ошибка: ключа «Оля» нет в Map'],
        correct: 0,
        explain: 'get по отсутствующему ключу возвращает None (не null!). getOrElse достаёт значение из Some, а у None подставляет запасное: «нет номера». Программа не падает — отсутствие значения это обычный Option.',
        solution: 0
      },
      hints: [
        'Map.get никогда не бросает исключение — он возвращает Option.',
        'getOrElse: у Some отдаёт значение, у None — аргумент по умолчанию.'
      ],
      solution: 0
    },

    /* ---------- 9. Идиомы: map, filter, fold ---------- */
    {
      id: 'scala-9',
      title: 'Идиомы: map, filter, fold',
      goal: 'Трансформировать коллекции через map и filter, сворачивать в число через fold — без var и циклов',
      xp: 50,
      theory: [
        { t: 'p', html: 'Вместо ручных циклов в Scala коллекции трансформируют методами. <code>map</code> применяет лямбду к каждому элементу и собирает новую коллекцию: <code>nums.map(_ * 2)</code> — удвоенные числа.' },
        { t: 'code', code: `val nums = List(1, 2, 3, 4, 5)
println(nums.map(_ * 2))      // List(2, 4, 6, 8, 10)` },
        { t: 'p', html: '<code>filter</code> оставляет элементы, для которых лямбда вернула true: <code>nums.filter(_ % 2 == 0)</code> — только чётные. Методы выстраиваются в цепочки — данные текут через конвейер слева направо, как в пайпе терминала.' },
        { t: 'code', code: `println(nums.filter(_ % 2 == 0))          // List(2, 4)
println(nums.map(_ * 3).filter(_ > 5))    // List(6, 9, 12, 15)` },
        { t: 'p', html: '<code>fold</code> сворачивает коллекцию в одно значение: <code>nums.fold(0)(_ + _)</code> — сумма. Первый аргумент — начальное значение аккумулятора, второй — лямбда (аккумулятор, элемент). Готовые свёртки: <code>sum</code>, <code>max</code>, <code>min</code>, <code>count</code>.' },
        { t: 'code', code: `println(nums.fold(0)(_ + _))   // 15
println(nums.sum)              // 15` },
        { t: 'h', html: 'Иммутабельность — стиль' },
        { t: 'p', html: 'Исходный список <code>nums</code> не изменился ни разу: map и filter вернули новые коллекции. Так пишут идиоматичный Scala: неизменяемые val, цепочки трансформаций, никаких var-счётчиков. Код читается как описание потока данных: «взять, отфильтровать, сложить».' },
        { t: 'warn', html: 'Подчёркивание <code>_</code> — краткая запись лямбды, и каждый <code>_</code> — свой параметр: <code>(_ + _)</code> — это (a, b) =&gt; a + b. Но <code>_ * 2</code> и <code>_ * _</code> — разные вещи: во втором случае у лямбды два параметра. В предсказании вывода прогоняй каждый метод руками.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай программу и напиши, что она выведет в консоль — по одной строке на каждый вывод, в порядке появления.</p>',
        code: `object Main extends App {
  val nums = List(1, 2, 3, 4, 5)

  val evens = nums.filter(_ % 2 == 0)
  println(evens)

  val tripled = nums.map(_ * 3)
  println(tripled)

  val total = nums.fold(0)(_ + _)
  println(total)
}`,
        answer: `List(2, 4)
List(3, 6, 9, 12, 15)
15`
      },
      hints: [
        'filter оставляет чётные: 2 и 4.',
        'map умножает каждый элемент на 3 — по порядку слева направо.',
        'fold складывает всё: 1 + 2 + 3 + 4 + 5.'
      ],
      solution: `List(2, 4)
List(3, 6, 9, 12, 15)
15`
    },

    /* ---------- 10. Проект: реестр заказов ---------- */
    {
      id: 'scala-10',
      title: 'Проект: реестр заказов',
      goal: 'Собрать финальную программу: case class Order, список заказов, подсчёт суммы через fold и печать каждой позиции',
      xp: 100,
      theory: [
        { t: 'p', html: 'Финальный проект — реестр заказов: case class с полями заказа, список заказов, функция подсчёта общей суммы и печать каждой позиции. Собираем всё из курса: case class, List, fold, foreach, интерполяция строк. Такая модель — типичная основа бизнес-приложения на Scala.' },
        { t: 'h', html: 'План' },
        { t: 'list', items: [
          '<code>case class Order(id: Int, customer: String, total: Double)</code> — заказ;',
          '<code>val orders = List(...)</code> — реестр из 2–3 заказов;',
          '<code>def grandTotal(list: List[Order]): Double</code> — сумма через fold;',
          '<code>foreach</code> — печать каждого заказа, <code>println</code> — итог.'
        ] },
        { t: 'p', html: 'К полям обращаются через точку: <code>o.customer</code>, <code>o.total</code>. Тип <code>List[Order]</code> в квадратных скобках — это тип-параметр (дженерик): «список заказов». Складывай аккуратно: начальное значение аккумулятора — 0.0, лямбда — <code>(acc, o) =&gt; acc + o.total</code>.' },
        { t: 'code', code: `object Main extends App {
  case class Order(id: Int, customer: String, total: Double)

  val orders = List(
    Order(1, "Аня", 1200.0),
    Order(2, "Борис", 340.5),
    Order(3, "Вера", 780.0)
  )

  def grandTotal(list: List[Order]): Double =
    list.fold(0.0)((acc, o) => acc + o.total)

  orders.foreach(o => println(s"Заказ #\${o.id} — \${o.customer}: \${o.total}"))
  println(s"Итого: \${grandTotal(orders)}")
}` },
        { t: 'p', html: '<code>fold</code> — самый идиоматичный способ суммирования: аккумулятор <code>acc</code> начинается с 0.0 и на каждом шаге получает <code>acc + o.total</code>. Итог для примера: 1200 + 340.5 + 780 = 2320.5. Обрати внимание: строки внутри <code>s"…"</code> собирают значения полей прямо при печати.' },
        { t: 'warn', html: 'Типы полей важны: <code>total</code> — Double, чтобы суммы с копейками считались. И не забывай букву <code>s</code> перед строкой с долларами — без неё интерполяции нет, и напечатается буквально $o.id.' },
        { t: 'note', html: 'После зачёта развивай реестр: самый дорогой заказ — <code>orders.maxBy(_.total)</code>, крупные заказы — <code>orders.filter(_.total &gt; 500)</code>, средний чек — fold плюс length. Реестр на case class — то, из чего состоят настоящие сервисы на Scala.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Реестр заказов».</b> Объяви <code>case class Order(id: Int, customer: String, total: Double)</code>. Создай список из 2–3 заказов. Напиши функцию, которая через <code>fold</code> (или цикл) считает общую сумму по полю <code>total</code>. Выведи каждый заказ (через <code>foreach</code> или <code>for</code>) и итоговую сумму.</p>',
        starter: `object Main extends App {
  // TODO: реестр заказов — case class, список, подсчёт суммы, вывод

}`,
        rules: [
          { desc: 'case class Order объявлена с полями id: Int, customer: String, total: Double', all: ['case\\s+class\\s+Order\\s*\\(', 'id\\s*:\\s*Int', 'customer\\s*:\\s*String', 'total\\s*:\\s*Double'] },
          { desc: 'Создан список заказов List / Vector', any: ['val\\s+\\w+\\s*(:[^=\\n]+)?=\\s*(List|Vector)\\s*\\('] },
          { desc: 'Есть функция подсчёта через def', all: ['\\bdef\\s+\\w+'] },
          { desc: 'Сумма считается через fold или цикл', any: ['\\.fold', '\\bforeach\\b', '\\bfor\\s*\\(', '\\bwhile\\b'] },
          { desc: 'Каждый заказ выводится через println внутри foreach / for', all: ['println\\s*\\('], any: ['\\.foreach', '\\bfor\\s*\\('] },
          { desc: 'Код непустой и без пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'case class Order(id: Int, customer: String, total: Double) — объявляй внутри Main.',
        'Список: val orders = List(Order(1, "Аня", 1200.0), ...).',
        'Сумма: list.fold(0.0)((acc, o) => acc + o.total); печать: orders.foreach(o => println(s"Заказ #${o.id}")).'
      ],
      solution: `object Main extends App {
  case class Order(id: Int, customer: String, total: Double)

  val orders = List(
    Order(1, "Аня", 1200.0),
    Order(2, "Борис", 340.5),
    Order(3, "Вера", 780.0)
  )

  def grandTotal(list: List[Order]): Double =
    list.fold(0.0)((acc, o) => acc + o.total)

  orders.foreach(o => println(s"Заказ #\${o.id} — \${o.customer}: \${o.total}"))
  println(s"Итого: \${grandTotal(orders)}")
}`
    },

    /* ---------- 11. case class и pattern matching глубоко ---------- */
    {
      id: 'scala-11',
      title: 'case class и pattern matching глубоко',
      goal: 'Строить sealed-иерархии, писать match с guard и @-связыванием и полагаться на проверку полноты от компилятора',
      xp: 50,
      theory: [
        { t: 'p', html: 'Уровень 7 показал match на одном case class. В настоящих системах типов обычно целые семейства: статус заказа — оплачен, отменён, возвращён; событие потока — клик, покупка, уход с сайта. Для таких семей в Scala есть модификатор <code>sealed</code>: <code>sealed trait OrderStatus</code> — «запечатанный» тип, все наследники которого объявлены в том же файле. Компилятор знает полный список вариантов и держит его под контролем.' },
        { t: 'code', code: `sealed trait OrderStatus
case object Pending  extends OrderStatus
case object Paid     extends OrderStatus
case object Refunded extends OrderStatus

def label(s: OrderStatus): String = s match {
  case Pending  => "ожидает оплаты"
  case Paid     => "оплачен"
  case Refunded => "возврат"
}` },
        { t: 'p', html: 'Схема «sealed trait + case class/case object + match» называется алгебраическим типом данных (АТД) — стандартный способ моделировать предметную область в Scala: так описывают события в Spark-пайплайнах и сообщения акторам в Akka. Бонус — проверка полноты: если в match забыт вариант, компилятор предупредит «match may not be exhaustive» ещё до запуска. Отдельные значения без полей объявляются как <code>case object</code>.' },
        { t: 'h', html: 'Guard — условие на ветке' },
        { t: 'p', html: 'После шаблона можно дописать <code>if</code> с дополнительным условием — охранник (guard): <code>case Circle(r) if r &gt; 10 =&gt; …</code>. Guard пользуется переменными, связанными в образце. Ветки проверяются сверху вниз, поэтому частные случаи ставят выше общих: сначала «крупный заказ», потом «любой заказ».' },
        { t: 'h', html: '@-связывание: и распаковать, и сохранить' },
        { t: 'p', html: 'Иногда нужно и разобрать значение на поля, и сохранить его целиком. Для этого есть связывание через <code>@</code>: <code>case p @ Some(number) =&gt; …</code> — число распаковано в переменную number, а весь Some доступен под именем p. Читается «p — это Some(number)».' },
        { t: 'code', code: `phones.get("Аня") match {
  case p @ Some(number) => s"Нашли: $number (внутри $p)"
  case None             => "Номера нет"
}` },
        { t: 'warn', html: 'Слева от <code>@</code> всегда имя с маленькой буквы, справа — образец; запись <code>_ @ Some(x)</code> бессмысленна. И не путай этот <code>@</code> с Java-аннотациями — здесь это часть шаблона в ветке case. Помни и про порядок: guard относится к конкретной ветке, а не ко всему match, поэтому общие ветки ставь ниже частных.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Построй запечатанную иерархию фигур: <code>sealed trait Shape</code>; наследники — <code>case class Circle(r: Double)</code>, <code>case class Rect(w: Double, h: Double)</code> и <code>case object Dot</code>, все со <code>extends Shape</code>. Напиши функцию <code>describe</code> через <code>match</code>: для большого круга (радиус больше 10) используй guard и @-связывание, обработай и остальные варианты. Выведи результаты через <code>println</code>.</p>',
        starter: `object Main extends App {
  // TODO: sealed trait Shape + case class Circle, Rect + case object Dot
  // TODO: describe через match с guard и @-связыванием
}`,
        rules: [
          { desc: 'Иерархия запечатана: sealed trait с именем', all: ['\\bsealed\\s+trait\\s+\\w+'] },
          { desc: 'Наследники объявлены через case class/case object с extends', any: ['case\\s+class\\s+\\w+\\s*\\([^)]*\\)\\s+extends\\s+\\w+', 'case\\s+object\\s+\\w+\\s+extends\\s+\\w+'] },
          { desc: 'Есть сопоставление match', all: ['\\bmatch\\b'] },
          { desc: 'Есть guard (case … if …)', any: ['case\\s+[^=\\n]{0,80}\\bif\\b'] },
          { desc: 'Есть @-связывание значения в образце', all: ['\\w+\\s*@\\s*[A-Z]'] },
          { desc: 'Результат выводится через println, пометок TODO нет', all: ['\\S'], any: ['println\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Схема: sealed trait Shape, затем case class Circle(r: Double) extends Shape, case class Rect(w: Double, h: Double) extends Shape и case object Dot extends Shape.',
        'Guard с @: case c @ Circle(r) if r > 10 => ... — @ сохраняет весь объект в c, if отсекает мелкие круги.',
        'Не забудь ветки для обычного Circle, Rect и Dot — компилятор любит полноту.'
      ],
      solution: `object Main extends App {
  sealed trait Shape
  case class Circle(r: Double) extends Shape
  case class Rect(w: Double, h: Double) extends Shape
  case object Dot extends Shape

  def describe(s: Shape): String = s match {
    case c @ Circle(r) if r > 10 => s"Большой круг радиуса \${c.r}"
    case Circle(r)               => s"Круг радиуса $r"
    case Rect(w, h) if w == h    => "Квадрат"
    case Rect(w, h)              => s"Прямоугольник \${w} на \${h}"
    case Dot                     => "Точка"
  }

  println(describe(Circle(12)))
  println(describe(Rect(3, 4)))
  println(describe(Dot))
}`
    },

    /* ---------- 12. Коллекции: map, flatMap, groupBy ---------- */
    {
      id: 'scala-12',
      title: 'Коллекции: map, flatMap, groupBy',
      goal: 'Трансформировать коллекции без циклов: map и flatMap, for-comprehension как сахар над flatMap и группировка через groupBy',
      xp: 50,
      theory: [
        { t: 'p', html: 'Правило уровня 9: map и filter не меняют исходный список — они возвращают новый. Иммутабельность по умолчанию — не красивость, а инженерное решение: неизменяемые коллекции можно смело передавать между потоками и узлами кластера, ничего не копируя и не синхронизируя. На этом строится вся модель больших данных в Spark: данные гоняются по кластеру как неизменяемые блоки.' },
        { t: 'code', code: `val nums = List(1, 2, 3, 4)
println(nums.map(_ * 2))                // List(2, 4, 6, 8)
println(nums.flatMap(n => List(n, n)))  // List(1, 1, 2, 2, 3, 3, 4, 4)` },
        { t: 'p', html: '<code>flatMap</code> — это map, после которого результаты «разглаживаются» в один список: лямбда возвращает коллекцию для каждого элемента, а flatMap склеивает их все вместе. Так делают дублирование, разворачивание строк на слова, выборку вариантов. Цепочки map/flatMap/filter читаются как конвейер: слева направо, шаг за шагом.' },
        { t: 'h', html: 'for-comprehension — обёртка над flatMap' },
        { t: 'p', html: 'Запись <code>for { n &lt;- nums; if n &gt; 2 } yield n * 10</code> — синтаксический сахар: компилятор разворачивает её в <code>nums.withFilter(n =&gt; n &gt; 2).map(n =&gt; n * 10)</code>. Несколько стрелок <code>&lt;-</code> превращаются во вложенные flatMap. Понимание этого соответствия — ключ к чтению чужого кода: за for всегда стоит цепочка комбинаторов.' },
        { t: 'p', html: '<code>groupBy</code> раскладывает элементы по корзинам: <code>nums.groupBy(_ % 2)</code> — Map, где ключ — результат функции, а значение — список элементов с таким ключом. Это «сгруппируй и посмотри» из отчётов: по статусу, по категории, по первой букве. Собранные группы дальше обрабатываются теми же map/filter/fold.' },
        { t: 'code', code: `val words = List("анна", "борис", "белла", "влад")
val byLetter = words.groupBy(_.head)
// Map: ключ — первая буква, значение — слова на неё
println(byLetter.keys.toList.sorted)   // List(a, b, v)` },
        { t: 'warn', html: 'В for-comprehension над коллекциями <code>yield</code> обязателен, если нужен результат-коллекция: без yield for работает ради побочных эффектов и возвращает Unit. И помни: цепочки не меняют исходный список — результат нужно сохранить в val или сразу вывести.' },
        { t: 'note', html: 'Имена map, flatMap, filter, groupBy, reduce — не случайность: это API Spark RDD и DataFrame. Привычка мыслить трансформациями над неизменяемыми коллекциями прямо переносится в большие данные: локально ты тренируешься на List, в кластере те же операции распараллелятся по узлам.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни конвейер: подставь метод для удвоения каждого элемента, метод для склейки списков из лямбды, метод группировки по остатку и слово, которое собирает результат в for-comprehension. Смотри на комментарии и на лямбды — они подсказывают ответ.</p>',
        code: `object Main extends App {
  val nums = List(1, 2, 3, 4)

  val doubled = nums.{{0}}(_ * 2)             // List(2, 4, 6, 8)
  val pairs   = nums.{{1}}(n => List(n, n))   // List(1, 1, 2, 2, 3, 3, 4, 4)
  val grouped = nums.{{2}}(_ % 2)             // Map: ключ — остаток, значение — числа

  val big     = for {
    n <- nums
    if n > 2
  } {{3}} n * 10                              // List(30, 40)

  println(doubled)
  println(pairs)
  println(grouped)
  println(big)
}`,
        blanks: [
          { answer: 'map' },
          { answer: 'flatMap' },
          { answer: 'groupBy' },
          { answer: 'yield' }
        ]
      },
      hints: [
        'map применяет простую функцию к каждому элементу; flatMap — когда лямбда возвращает список, который надо склеить в один.',
        'groupBy собирает Map: ключ — результат функции (_ % 2), значение — элементы с таким ключом.',
        'В for-comprehension результат-коллекцию собирает yield.'
      ],
      solution: ['map', 'flatMap', 'groupBy', 'yield']
    },

    /* ---------- 13. Option глубоко ---------- */
    {
      id: 'scala-13',
      title: 'Option глубоко: map, flatMap, getOrElse',
      goal: 'Работать с Option как с коллекцией из нуля или одного элемента и строить цепочки без null',
      xp: 50,
      theory: [
        { t: 'p', html: 'Уровень 8 познакомил с Option как ответом Map.get. Теперь — вся мощь. Option — это коллекция из нуля или одного элемента: <code>Some(значение)</code> — контейнер с одним элементом, <code>None</code> — пустой. А раз это коллекция, у неё работают map, flatMap, filter и друзья — без единой ручной распаковки.' },
        { t: 'code', code: `val num = Some(21)
println(num.map(_ * 2))    // Some(42)
println(None.map(_ * 2))   // None — функция даже не вызовется` },
        { t: 'p', html: 'Это меняет стиль: вместо «достань значение и проверь на null» пишешь «примени функцию, Option сам решит». <code>getOrElse</code> подставляет запасное значение в конце цепочки. Ничего не упадёт: None просто молча пропустит все трансформации и дойдёт до запасного значения.' },
        { t: 'code', code: `val phones = Map("Аня" -> "123", "Борис" -> "456")
val len = phones.get("Аня").map(_.length).getOrElse(0)
println(len)   // 3` },
        { t: 'p', html: '<code>flatMap</code> соединяет несколько шагов, каждый из которых может ничего не вернуть: <code>get(ключ).flatMap(номер =&gt; справочник.get(номер))</code> — если любой шаг вернул None, вся цепочка даст None. Это «порожистая река»: любая пустота обнуляет результат, но не программу. Такие цепочки заменяют лестницы if-проверок на null из Java-кода.' },
        { t: 'p', html: 'Почему null — зло: null может прийти откуда угодно и роняет код в случайном месте — NullPointerException называют самой известной ошибкой в индустрии; компилятор же не отличает «значение всегда есть» от «может не быть». Option делает отсутствие частью типа: сигнатура <code>def find(id: Int): Option[User]</code> честно предупреждает каждого вызывающего. В экосистеме больших данных так оборачивают граничные случаи на границах модулей — а внутри живут без null.' },
        { t: 'warn', html: 'Метод <code>.get</code> у самого Option — ловушка: для None он бросит исключение. Честные пути: getOrElse, match с Some/None, map/flatMap. И не создавай <code>Some(null)</code> — это обман самого себя: отсутствие должно быть None.' },
        { t: 'note', html: 'Option и List подчиняются одним приёмам: map/flatMap/filter/foreach. Однажды ты заметишь, что и for-comprehension работает по Option: <code>for (n &lt;- maybeNum) yield n * 2</code> скомпилируется в maybeNum.map(...). Один интерфейс — много контейнеров.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери безопасное деление: функция <code>safeDiv(a: Int, b: Int): Option[Int]</code> возвращает <code>None</code> при делении на ноль и <code>Some</code> в остальных случаях. Прогони её для пары чисел, используй <code>getOrElse</code> для запасного ответа и обработай один из результатов через <code>map</code>, <code>flatMap</code> или <code>match</code>. Выведи всё через <code>println</code>.</p>',
        starter: `object Main extends App {
  // TODO: safeDiv -> Option[Int], getOrElse, map/flatMap/match
}`,
        rules: [
          { desc: 'Функция возвращает Option: … : Option[…]', all: ['\\bdef\\s+\\w+\\s*\\([^)]*\\)\\s*:\\s*Option\\s*\\['] },
          { desc: 'Оба варианта Some и None на месте', all: ['\\bSome\\s*\\(', '\\bNone\\b'] },
          { desc: 'Запасное значение через getOrElse', all: ['\\.getOrElse\\s*\\('] },
          { desc: 'Option обработан как коллекция: map, flatMap или match', any: ['\\.map\\s*\\(', '\\.flatMap\\s*\\(', '\\bmatch\\b'] },
          { desc: 'Вывод через println, пометок TODO нет', all: ['\\S'], any: ['println\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Схема: if (b == 0) None else Some(a / b) — деление на ноль это не падение, а None.',
        'getOrElse("делить нельзя") даст ответ или запасную строку.',
        'map по Option: Some(5).map(_ * 2) — Some(10); None.map(...) — None.'
      ],
      solution: `object Main extends App {
  def safeDiv(a: Int, b: Int): Option[Int] =
    if (b == 0) None else Some(a / b)

  val r1 = safeDiv(10, 2)
  val r2 = safeDiv(7, 0)

  println(r1.getOrElse("делить нельзя"))
  println(r2.getOrElse("делить нельзя"))

  println(r1.map(_ * 2))

  r2 match {
    case Some(v) => println(s"Получилось: $v")
    case None    => println("На ноль не делим")
  }
}`
    },

    /* ---------- 14. Traits глубоко ---------- */
    {
      id: 'scala-14',
      title: 'Traits глубоко: линейизация и self-types',
      goal: 'Понять, как Scala разрешает конфликты методов при mixin (линейизация) и как self-types объявляют зависимости',
      xp: 45,
      theory: [
        { t: 'p', html: 'Трейт — контракт, у которого могут быть методы с реализацией: наследник получает их бесплатно, а миксовать трейтов можно сколько угодно: <code>class X extends T1 with T2 with T3</code>. Так поведение собирается из деталей. Интерфейсы Java с default-методами рядом не стояли: у трейтов есть поля, параметры типа и абстрактные члены.' },
        { t: 'code', code: `trait Greeter {
  def greet(name: String): String = s"Привет, $name!"
}

trait LoudGreeter extends Greeter {
  override def greet(name: String): String = super.greet(name).toUpperCase
}` },
        { t: 'p', html: 'А если два трейта объявляют один и тот же метод? В C++ это «ромбовидная проблема», в Scala у неё строгий ответ — <b>линейизация</b>. Для каждого класса компилятор строит линейный порядок всех его предков. Правило большого пальца: <b>правее — сильнее</b> — при конфликте побеждает трейт, стоящий правее в цепочке with, а <code>super</code> внутри трейта зовёт следующий по линейизации, а не «родителя».' },
        { t: 'code', code: `class Speaker extends Greeter with LoudGreeter

println(new Speaker().greet("Аня"))   // ПРИВЕТ, АНЯ!
// линейизация: Speaker -> LoudGreeter -> Greeter` },
        { t: 'h', html: 'Self-types: трейт с требованием' },
        { t: 'p', html: 'Иногда трейту нужен другой компонент, но наследовать его не хочется. Для этого есть self-type: <code>trait Servicing { this: Database =&gt; … }</code> — «меня можно смешать только в класс, который является Database». Компилятор проверит это при сборке класса. Так объявляют зависимости компонентов без наследования — известный архитектурный приём «cake pattern».' },
        { t: 'code', code: `trait Database { def query(sql: String): List[String] }

trait Servicing {
  this: Database =>            // требование: примешь меня только с Database
  def users: List[String] = query("SELECT name FROM users")
}` },
        { t: 'warn', html: 'Линейизация отвечает на вопрос «чей метод победил», но порядок with имеет значение: <code>extends A with B</code> и <code>extends B with A</code> могут дать разный результат. Self-type не создаёт поле — к объекту-требованию обращаются через <code>this</code>, и итоговый класс обязан им быть.' },
        { t: 'note', html: 'В больших данных трейты — способ нарастить поведение трансформаций: логирование, метрики, ретраи оборачивают базовый трейт и миксуются по потребности. Строгая линейизация делает это предсказуемым — без сюрпризов множественного наследования.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет эта программа?</p><pre>trait Greeter {
  def greet(name: String): String = s"Привет, $name!"
}

trait LoudGreeter extends Greeter {
  override def greet(name: String): String = super.greet(name).toUpperCase
}

class Speaker extends Greeter with LoudGreeter

println(new Speaker().greet("Аня"))</pre>`,
        options: ['ПРИВЕТ, АНЯ!', 'Привет, Аня!', 'Привет, Аня! и ПРИВЕТ, АНЯ!', 'Ошибка: конфликт двух методов greet'],
        correct: 0,
        explain: 'Линейизация Speaker: Speaker -> LoudGreeter -> Greeter. Право сильнее: побеждает override из LoudGreeter, а его super.greet зовёт версию Greeter и поднимает регистр. Конфликта нет — порядок with строго определён линейизацией.',
        solution: 0
      },
      hints: [
        'Кто правее в with — тот и сильнее: именно его метод и выполнится.',
        'super внутри трейта зовёт следующего по линейизации, то есть версию Greeter.'
      ],
      solution: 0
    },

    /* ---------- 15. Функции высшего порядка ---------- */
    {
      id: 'scala-15',
      title: 'Функции высшего порядка: композиция и каррирование',
      goal: 'Склеивать функции через andThen и compose, каррировать и применять функции частично',
      xp: 50,
      theory: [
        { t: 'p', html: 'Функции — значения: их можно передавать, хранить в val и склеивать друг с другом. <b>Композиция</b> строит новую функцию из двух: <code>f.andThen(g)</code> — «сначала f, потом g», <code>f.compose(g)</code> — «сначала g, потом f». Мнемоника простая: andThen читается слева направо, как текст.' },
        { t: 'code', code: `val double = (n: Int) => n * 2
val inc    = (n: Int) => n + 1

val f = double.andThen(inc)   // 5 -> 10 -> 11
val g = double.compose(inc)   // 5 -> 6  -> 12
println(f(5))   // 11
println(g(5))   // 12` },
        { t: 'h', html: 'Каррирование' },
        { t: 'p', html: '<b>Каррирование</b> — приём «аргументы по одному»: <code>def add(a: Int)(b: Int): Int</code> объявляет два списка параметров. Вызов <code>add(10)</code> вернёт готовую функцию <code>Int =&gt; Int</code> — это <b>частичное применение</b>: из общей функции сделали специализированную, прибив первый аргумент.' },
        { t: 'code', code: `def add(a: Int)(b: Int): Int = a + b
val add10 = add(10)          // Int => Int
println(add10(7))            // 17` },
        { t: 'p', html: 'Для обычных методов частичное применение пишут через подчёркивание: <code>mul(2, _: Int)</code> — место под второй аргумент зарезервировано. Так собирают конвейеры: базовая функция плюс настройки — готовый шаг пайплайна. А каррированные функции удобны для конфигурации: сначала параметры окружения, потом данные.' },
        { t: 'p', html: 'Это не академия: в Spark и других библиотеках большие данные обрабатываются именно передачей функций — <code>lines.map(_.trim).filter(_.nonEmpty)</code>. Композиция и частичное применение позволяют собрать пайплайн заранее, а применить к данным потом.' },
        { t: 'warn', html: 'Не перепутай порядок: <code>double.andThen(inc)</code> и <code>double.compose(inc)</code> дают разные функции — 11 и 12 на входе 5. И следи за скобками: <code>add(10)(7)</code> — два списка аргументов; <code>add(10, 7)</code> для каррированной функции не сработает.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни конвейер: подставь названия методов композиции (смотри на комментарии — что выполняется первым), имя второго параметра каррированной функции и подчёркивание для частичного применения.</p>',
        code: `object Main extends App {
  val double = (n: Int) => n * 2
  val inc    = (n: Int) => n + 1

  val f = double.{{0}}(inc)    // сначала double, затем inc
  val g = double.{{1}}(inc)    // сначала inc, затем double
  println(f(5))    // 11
  println(g(5))    // 12

  // каррирование: аргументы по одному, каждый в своих скобках
  def add(a: Int)({{2}}: Int): Int = a + b
  val add10 = add(10)          // частичное применение: осталась функция Int => Int
  println(add10(7))            // 17

  // подчёркивание резервирует место под будущий аргумент
  def mul(a: Int, b: Int): Int = a * b
  val twice = mul(2, {{3}}: Int)
  println(twice(21))           // 42
}`,
        blanks: [
          { answer: 'andThen' },
          { answer: 'compose' },
          { answer: 'b' },
          { answer: '_' }
        ]
      },
      hints: [
        'andThen — «а потом»: double.andThen(inc) сначала умножит; compose — наоборот, сначала аргумент его скобки.',
        'Каррированная функция: def add(a: Int)(b: Int) — второй аргумент в своих скобках.',
        'mul(2, _: Int) — подчёркивание вместо второго аргумента.'
      ],
      solution: ['andThen', 'compose', 'b', '_']
    },

    /* ---------- 16. Проект: процессор заказов ---------- */
    {
      id: 'scala-16',
      title: '🚀 Проект: процессор заказов',
      goal: 'Собрать финальную систему: sealed-иерархия статусов, case class Order, обработка через match, Option и агрегации по коллекциям',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект собирает курс в одну программу уровня «сервис обработки заказов»: запечатанная иерархия статусов, case class заказа, список заказов, обработка через match, безопасный поиск через Option и агрегации filter/fold/maxBy. Это скелет настоящего бэкенда на Scala — примерно так выглядят домены в Spark-джобах и Akka-сервисах.' },
        { t: 'h', html: 'Что строим' },
        { t: 'list', items: [
          '<code>sealed trait OrderStatus</code> и варианты <code>Pending</code>, <code>Paid</code>, <code>Refunded</code> — case object со extends;',
          '<code>case class Order(id: Int, customer: String, total: Double, status: OrderStatus)</code>;',
          'список заказов <code>val orders = List(...)</code> — минимум три позиции;',
          'функция текстовой метки статуса через <code>match</code> по всей иерархии;',
          'сумма оплаченных через <code>filter</code> + <code>fold</code>;',
          'самый крупный заказ, возвращающий <code>Option</code> (None на пустом списке).'
        ] },
        { t: 'p', html: 'Сумма оплаченных — конвейер: <code>list.filter(_.status == Paid).fold(0.0)((acc, o) =&gt; acc + o.total)</code>. Сначала отобрали нужные статусы, потом свернули в число. Поиск максимума лучше сразу писать честно: <code>if (list.isEmpty) None else Some(list.maxBy(_.total))</code> — пустой список не должен ронять систему.' },
        { t: 'code', code: `object Main extends App {
  sealed trait OrderStatus
  case object Pending  extends OrderStatus
  case object Paid     extends OrderStatus
  case object Refunded extends OrderStatus

  case class Order(id: Int, customer: String, total: Double, status: OrderStatus)

  val orders = List(
    Order(1, "Аня", 1200.0, Paid),
    Order(2, "Борис", 340.5, Pending),
    Order(3, "Вера", 780.0, Paid)
  )

  def label(s: OrderStatus): String = s match {
    case Pending  => "ожидает оплаты"
    case Paid     => "оплачен"
    case Refunded => "возврат"
  }

  def paidTotal(list: List[Order]): Double =
    list.filter(_.status == Paid).fold(0.0)((acc, o) => acc + o.total)

  def biggest(list: List[Order]): Option[Order] =
    if (list.isEmpty) None else Some(list.maxBy(_.total))

  orders.foreach { o =>
    println(s"Заказ #\${o.id} (\${o.customer}): \${o.total} — \${label(o.status)}")
  }
  println(s"Сумма оплаченных: \${paidTotal(orders)}")
  println(s"Самый крупный: \${biggest(orders).map(_.total).getOrElse(0.0)}")
}` },
        { t: 'warn', html: 'Программа должна быть законченной: каждый заказ печатается через foreach/for, суммы и максимум — через конвейеры filter/fold/maxBy, пустой список обрабатывается через Option. Статусы — именно case object со extends OrderStatus: это значения, а не классы с полями.' },
        { t: 'note', html: 'Развитие после зачёта: группировка по статусу через <code>orders.groupBy(_.status)</code>, средний чек оплаченных, функция возврата, возвращающая новый список заказов — иммутабельность в действии. Такой процессор — готовая основа для сервиса на Akka или Spark Structured Streaming.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Процессор заказов».</b> Объяви <code>sealed trait OrderStatus</code> и три его варианта (<code>case object Pending/Paid/Refunded extends OrderStatus</code>), а также <code>case class Order(id: Int, customer: String, total: Double, status: OrderStatus)</code>. Создай список из 3–4 заказов. Добавь обработку статуса через <code>match</code> (функция с текстовой меткой), сумму оплаченных заказов через <code>filter</code> + <code>fold</code> и поиск самого крупного заказа, возвращающий <code>Option</code>. Выведи каждый заказ и итоги через <code>println</code>.</p>',
        starter: `object Main extends App {
  // TODO: процессор заказов — sealed-иерархия, case class,
  // список заказов, match по статусу, Option, агрегации

}`,
        rules: [
          { desc: 'Запечатанная иерархия: sealed trait OrderStatus', all: ['\\bsealed\\s+trait\\s+OrderStatus'] },
          { desc: 'Варианты статуса: case object/case class extends OrderStatus', any: ['case\\s+object\\s+\\w+\\s+extends\\s+OrderStatus', 'case\\s+class\\s+\\w+\\s*\\([^)]*\\)\\s+extends\\s+OrderStatus'] },
          { desc: 'case class Order с полями id, customer, total, status', all: ['case\\s+class\\s+Order\\s*\\(', 'id\\s*:\\s*Int', 'customer\\s*:\\s*String', 'total\\s*:\\s*Double', 'status\\s*:\\s*OrderStatus'] },
          { desc: 'Список заказов создан (List/Vector/Seq)', any: ['val\\s+\\w+\\s*(:[^=\\n]+)?=\\s*(List|Vector|Seq)\\s*\\('] },
          { desc: 'Обработка через match', all: ['\\bmatch\\b'] },
          { desc: 'Option в деле: Some/None/getOrElse/map', any: ['\\bSome\\s*\\(', '\\bNone\\b', '\\.getOrElse\\s*\\(', '\\.map\\s*\\('] },
          { desc: 'Агрегации по коллекции (filter/fold/foreach/maxBy/…)', any: ['\\.(filter|fold|foreach|groupBy|maxBy|sum|map)\\b'] },
          { desc: 'Вывод через println, пометок TODO нет', all: ['\\S'], any: ['println\\s*\\('], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Начни с иерархии: sealed trait OrderStatus, затем три case object со extends OrderStatus.',
        'case class Order(id: Int, customer: String, total: Double, status: OrderStatus); список — val orders = List(Order(1, "Аня", 1200.0, Paid), ...).',
        'Сумма оплаченных: list.filter(_.status == Paid).fold(0.0)((acc, o) => acc + o.total); максимум — Some(list.maxBy(_.total)).'
      ],
      solution: `object Main extends App {
  sealed trait OrderStatus
  case object Pending  extends OrderStatus
  case object Paid     extends OrderStatus
  case object Refunded extends OrderStatus

  case class Order(id: Int, customer: String, total: Double, status: OrderStatus)

  val orders = List(
    Order(1, "Аня", 1200.0, Paid),
    Order(2, "Борис", 340.5, Pending),
    Order(3, "Вера", 780.0, Paid)
  )

  def label(s: OrderStatus): String = s match {
    case Pending  => "ожидает оплаты"
    case Paid     => "оплачен"
    case Refunded => "возврат"
  }

  def paidTotal(list: List[Order]): Double =
    list.filter(_.status == Paid).fold(0.0)((acc, o) => acc + o.total)

  def biggest(list: List[Order]): Option[Order] =
    if (list.isEmpty) None else Some(list.maxBy(_.total))

  orders.foreach { o =>
    println(s"Заказ #\${o.id} (\${o.customer}): \${o.total} — \${label(o.status)}")
  }
  println(s"Сумма оплаченных: \${paidTotal(orders)}")
  println(s"Самый крупный: \${biggest(orders).map(_.total).getOrElse(0.0)}")
}`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас программы',
      code: `// Классика (в этом курсе)
object Main extends App {
  println("Привет!")
}
// Scala 3
@main def run(): Unit = println("Привет!")
// запуск: scala Main.scala`
    },
    {
      title: 'val / var и типы',
      code: `val name = "Аня"        // неизменяемое — по умолчанию
var age = 20            // изменяемая переменная
age = 21
val pi: Double = 3.14   // тип можно указать явно
// Int, Double, String, Boolean, Unit
// тип выводится сам (type inference)`
    },
    {
      title: 'if — выражение',
      code: `val verdict = if (temp >= 20) "тепло" else "холодно"
// if возвращает значение → тернарника ?: в Scala нет
// используешь if как выражение — всегда с else
// операторы: == != > < >= <= && || !`
    },
    {
      title: 'Циклы',
      code: `for (i <- 1 to 5) println(i)      // 1..5 включительно
for (i <- 1 until 5) println(i)   // 1..4
for (i <- 1 to 10 by 2) println(i)

var n = 40
while (n >= 10) { n = n / 2 }`
    },
    {
      title: 'Коллекции',
      code: `val xs = List("а", "б", "в")   // неизменяемый список
xs.length; xs.head; xs.tail
xs(0)                          // индекс — круглые скобки!
"х" :: xs                      // новый список с «х» в начале
xs :+ "г"                      // новый список с «г» в конце
val m = Map("Аня" -> 20)
m("Аня"); m.get("Оля")         // Option`
    },
    {
      title: 'map / filter / fold',
      code: `nums.map(_ * 2)            // трансформация каждого
nums.filter(_ % 2 == 0)    // оставить по условию
nums.fold(0)(_ + _)        // свёртка в одно значение
nums.sum; nums.count(_ > 2)
orders.maxBy(_.total)      // максимум по полю
// цепочки: nums.filter(...).map(...)`
    },
    {
      title: 'Функции и лямбды',
      code: `def add(a: Int, b: Int): Int = a + b  // return не нужен
def double(x: Int) = x * 2            // тип выведется
val triple = (n: Int) => n * 3        // лямбда
nums.map(_ * 2)                       // короткая запись
// результат функции — последнее выражение тела`
    },
    {
      title: 'case class, match, Option',
      code: `case class Book(title: String, pages: Int)
val b = Book("Сказки", 40)        // без new

b match {
  case Book(_, p) if p > 300 => "Толстая"
  case _                     => "Тонкая"
}

val found = phones.get("Оля")     // Some(...) или None
found.getOrElse("нет")
found match {
  case Some(v) => println(v)
  case None    => println("пусто")
}
// null в идиоматичном Scala не используют`
    },
    {
      title: 'Sealed-иерархии и паттерн-матчинг',
      code: `sealed trait Payment                        // все варианты в одном файле
case object Cash             extends Payment
case class Card(num: String) extends Payment

def pay(p: Payment): String = p match {
  case c @ Card(num) if num.startsWith("4") => s"Visa \${c.num}"
  case Card(num)                            => s"Карта $num"
  case Cash                                 => "Наличные"
}
// guard: if после шаблона; @: имя на весь образец
// забытый вариант — предупреждение компилятора`
    },
    {
      title: 'Композиция и конвейеры данных',
      code: `nums.map(_ * 2).filter(_ > 4)        // конвейер
nums.flatMap(n => List(n, n))        // map + разгладить
nums.groupBy(_ % 2)                  // Map: ключ -> элементы

for { n <- nums; if n > 2 } yield n * 10   // = flatMap + withFilter + map

val f = double.andThen(inc)          // сначала double
val g = double.compose(inc)          // сначала inc
def add(a: Int)(b: Int) = a + b      // каррирование
val add10 = add(10)                  // частичное применение
val twice = mul(2, _: Int)           // подчёркивание — место под аргумент
// Option тоже коллекция: opt.map(...).getOrElse(0)`
    }
  ]
};
