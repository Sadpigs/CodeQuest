'use strict';
/* ============ CodeQuest — курс Shakespeare ============
   Эзотерический язык SPL (Hasselström & Åslund, 2001).
   Проверки: структура (regex), fill, predict, квизы.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.shakespeare = {
  id: 'shakespeare',
  title: 'Shakespeare',
  emoji: '🎭',
  color: '#3fa66f',
  lang: 'shakespeare',
  tagline: 'Программа как пьеса: персонажи-переменные и лесть',
  description: 'Эзотерический язык Карла Хассельстрёма и Йона Ослунда (2001): исходный код выглядит как шекспировская пьеса. Персонажи — переменные, комплименты и оскорбления — числа, сцены — метки переходов. Смешно снаружи, строго внутри: за 5 уровней поставишь собственную драму-калькулятор.',

  levels: [

    /* ---------- 1. Каркас пьесы ---------- */
    {
      id: 'shakespeare-1',
      title: 'Каркас пьесы',
      goal: 'Собрать каркас программы-пьесы: заголовок, персонажи, Act/Scene, ремарки [Enter]/[Exeunt] и реплика',
      xp: 30,
      theory: [
        { t: 'p', html: 'Shakespeare Programming Language (SPL) — эзотерический язык Карла Хассельстрёма и Йона Ослунда, 2001 год. Идея дерзкая: программа должна читаться как шекспировская пьеса. Код действительно выглядит как драма — с действующими лицами, актами и сценами, — но при этом является полноценной программой: существуют трансляторы, превращающие пьесы SPL в обычный C.' },
        { t: 'p', html: 'Концепт простой, как афиша. <b>Персонажи — переменные</b>: в каждом хранится число. <b>Реплики — операции</b>: персонажи записывают друг другу значения и приказывают печатать. <b>Сцены — метки переходов</b>, а театральные ремарки в квадратных скобках решают, кто «на сцене».' },
        { t: 'code', code: `The Infamous Hello World Program.

Romeo, a young man with a remarkable patience.
Juliet, a woman of remarkable grace.

                    Act I: The meeting.

                    Scene I: The courtyard.

[Enter Romeo and Juliet]

Juliet:
  You are as sweet as the sum of a flower and a king.

[Exeunt]` },
        { t: 'p', html: 'Разбор каркаса сверху вниз. Первая строка — <b>заголовок пьесы</b>, он заканчивается точкой. Дальше — список действующих лиц: каждая строка «Имя, описание.» объявляет переменную с говорящим именем. Имена традиционно пишутся с заглавной буквы: <code>Romeo</code> — это переменная, а <code>romeo</code> — просто слово.' },
        { t: 'p', html: 'Заголовки <code>Act I:</code> и <code>Scene I:</code> (римские цифры и двоеточие!) делят пьесу на акты и сцены — это блоки программы. Ремарка <code>[Enter Romeo and Juliet]</code> выводит персонажей на сцену: говорить можно только с тем, кто на ней стоит. Реплика начинается с имени и двоеточия. <code>[Exeunt]</code> — уходят все, <code>[Exit Romeo]</code> — ушёл один.' },
        { t: 'list', items: [
          '<b>заголовок пьесы</b> — первая строка, заканчивается точкой;',
          '<b>Имя, описание.</b> — объявление персонажа-переменной;',
          '<b>Act I: / Scene I:</b> — акты и сцены, римские цифры;',
          '<b>[Enter …] / [Exit …] / [Exeunt]</b> — кто на сцене и кто уходит;',
          '<b>Имя:</b> — начало реплики (имя с заглавной и двоеточие).'
        ] },
        { t: 'note', html: 'Значения персонажей появятся на следующем уровне — пока твоя задача поставить сам каркас: афишу, труппу и одну реплику. Проверка структурная, как в настоящем театре: смотрят на состав, а не на игру. В настоящем SPL реплики полны слов, но интерпретатор слышит в них только числа и команды.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Поставь каркас пьесы: заголовок с точкой на конце, два персонажа строками «Имя, описание.», заголовки <code>Act I:</code> и <code>Scene I:</code> с двоеточиями, ремарка <code>[Enter …]</code>, реплика в форме <code>Имя:</code> и финальная ремарка ухода <code>[Exeunt]</code>. Заглушки TODO замени настоящими словами.</p>',
        starter: `TODO название пьесы

Romeo, a young man.
Juliet, a woman.

Act I: TODO

Scene I: TODO

[Enter Romeo and Juliet]

Juliet:
  You are as sweet as TODO

[Exeunt]`,
        rules: [
          { desc: 'Заголовок пьесы — строка с точкой в конце (без запятых внутри)', all: ['^[^.,\\n]{5,}\\.\\s*$'] },
          { desc: 'Два персонажа объявлены строками «Имя, описание.»', all: ['^[A-Z][a-z]+\\s*,\\s*[a-z][^.]*\\.', '\\n[ \\t]*[A-Z][a-z]+\\s*,\\s*[a-z][^.]*\\.'] },
          { desc: 'Есть заголовки акта и сцены: Act I: и Scene I:', all: ['^[ \\t]*Act\\s+[IVX]+\\s*:', '^[ \\t]*Scene\\s+[IVX]+\\s*:'] },
          { desc: 'Персонажи выходят и уходят: [Enter …] и [Exeunt]/[Exit …]', all: ['\\[\\s*Enter\\s+[^\\]]+\\]', '\\[\\s*Ex(eunt|it)[^\\]]*\\]'] },
          { desc: 'Есть реплика: «Имя:» с двоеточием', all: ['^[A-Z][a-z]+\\s*:\\s*$'] },
          { desc: 'Нет заглушек TODO', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Заголовок пьесы — первая строка и заканчивается точкой: The Meeting Play.',
        'Акт и сцена: Act I: Встреча. / Scene I: Двор. — римская цифра и двоеточие.'
      ],
      solution: `The Infamous Hello World Program.

Romeo, a young man with a remarkable patience.
Juliet, a woman of remarkable grace.

                    Act I: The meeting.

                    Scene I: The courtyard.

[Enter Romeo and Juliet]

Juliet:
  You are as sweet as the sum of a flower and a king.

[Exeunt]`
    },

    /* ---------- 2. Значения ---------- */
    {
      id: 'shakespeare-2',
      title: 'Значения: существительные и прилагательные',
      goal: 'Записывать значения: существительное по словарю, прилагательное ±1, операции the sum of / the difference between',
      xp: 35,
      theory: [
        { t: 'p', html: 'Время наполнить персонажей числами. Числа записываются словами: <b>существительное</b> означает фиксированное значение из словаря интерпретатора, а каждое <b>прилагательное</b> перед ним меняет это значение на единицу — приятное прибавляет, обидное отнимает. Настоящий SPL знает больше сотни слов; для курса возьмём мини-словарь из четырёх слов — его хватит на все задания.' },
        { t: 'table', head: ['Слово', 'Значение'], rows: [
          ['<code>nothing</code>', '0'],
          ['<code>flower</code>', '2'],
          ['<code>sky</code>', '32 — это код пробела!'],
          ['<code>king</code>', '77']
        ] },
        { t: 'p', html: 'Примеры: <code>a flower</code> — это 2, <code>a lovely flower</code> — уже 3 (одно приятное прилагательное добавило единицу), а <code>a stupid king</code> — 76 (обидное прилагательное отняло единицу). Перед существительным в единственном числе обязателен неопределённый артикль: <code>a king</code>, <code>an uncle</code>.' },
        { t: 'p', html: 'Присваивание звучит как комплимент: <code>You are as brave as …</code> — «ты так храбр, как…». Значение выражения после второго <code>as</code> записывается <b>адресату</b> — тому, к кому обращается говорящий. Выражения строятся так: <code>the sum of X and Y</code> — сумма, <code>the difference between X and Y</code> — разность, <code>yourself</code> — текущее значение адресата.' },
        { t: 'code', code: `Romeo:
  You are as brave as the sum of a king and a flower.` },
        { t: 'p', html: 'Посчитаем реплику выше по мини-словарю: <code>a king</code> — 77, <code>a flower</code> — 2, значит <code>the sum of a king and a flower</code> — это 79. Джульетта получает 79. Хочешь вычесть — скажи <code>You are as bold as the difference between a king and a flower.</code> — и теперь у неё 75. Слово <code>yourself</code> подставляет текущее значение того, кому адресована реплика.' },
        { t: 'warn', html: '«You are as brave as …» — это присваивание, а не сравнение! Вопрос-сравнение звучит иначе: «Am I as good as you?». О нём — в уровне про ловушки. И не забывай артикль: «sum of king and flower» без <code>a</code> грамматически неверно — существительное должно быть с артиклем.' },
        { t: 'note', html: 'Мнемоника для запоминания словаря: <code>nothing</code> — пустота, ноль; <code>flower</code> — маленькое число 2; <code>sky</code> — код пробела 32 (пригодится на следующем уровне); <code>king</code> — большое 77. В настоящем интерпретаторе словарь больше сотни слов и значения другие — но правила игры ровно те же.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Допиши реплику Ромео: свяжи операции — сумма это <code>sum</code>, разность <code>difference</code> — и расставь артикль <code>a</code> перед существительными. По мини-словарю первая строка даст Джульетте 79, вторая — 75.</p>',
        code: `[Enter Romeo and Juliet]

Romeo:
  You are as brave as the {{0}} of {{1}} king and {{2}} flower.

  You are as bold as the {{3}} between a king and a flower.

[Exeunt]`,
        blanks: [
          { answer: 'sum' },
          { answer: 'a' },
          { answer: 'a' },
          { answer: 'difference' }
        ],
        ci: false
      },
      hints: [
        '«the sum of X and Y» — сумма, «the difference between X and Y» — разность.',
        'Перед существительным в единственном числе стоит артикль a.',
        'king = 77, flower = 2: сумма даст 79, разность — 75.'
      ],
      solution: ['sum', 'a', 'a', 'difference']
    },

    /* ---------- 3. Вывод и переходы ---------- */
    {
      id: 'shakespeare-3',
      title: 'Вывод и переходы',
      goal: 'Выводить значение числом и символом (Open your heart / Speak your mind) и переходить между сценами командой Let us return to',
      xp: 40,
      theory: [
        { t: 'p', html: 'Значения записаны — теперь их надо показать. Приказ <code>Open your heart.</code> («открой сердце») печатает <b>число</b> — текущее значение того, к кому обращаются. А <code>Speak your mind.</code> («выскажись») печатает то же значение как <b>символ</b> по коду из таблицы ASCII: значение 79 — это буква «O». Мнемоника: heart — число, mind — символ.' },
        { t: 'code', code: `Romeo:
  You are as brave as the sum of a king and a flower.
  Open your heart.
  Speak your mind.` },
        { t: 'p', html: 'Разберём: Джульетте записано 77 + 2 = 79. <code>Open your heart</code> печатает цифры «79», затем <code>Speak your mind</code> печатает символ с кодом 79 — букву «O». Всё вместе на экране: <code>79O</code>. Пробелы и переводы строки команды сами не добавляют — пьеса печатает ровно то, что ей приказали.' },
        { t: 'p', html: 'Ход пьесы можно переломить <b>переходом</b>. Команда <code>Let us return to scene II.</code> (или <code>We shall return to scene II.</code>) прыгает к началу указанной сцены и продолжает оттуда; всё, что записано после команды в текущей сцене, пропускается. Сцены без переходов исполняются просто по порядку, одна за другой.' },
        { t: 'code', code: `Scene I: Numbers.

[Enter Romeo and Juliet]

Romeo:
  You are as brave as the sum of a king and a flower.
  Speak your mind.
  Let us return to scene II.

  Speak your mind.

Scene II: Letters.

Romeo:
  You are as bold as the difference between a king and a flower.
  Speak your mind.

[Exeunt]` },
        { t: 'p', html: 'В примере выше переход перепрыгивает повторную печать: на экране появляются только «O» (код 79) и «K» (код 75) — то есть <code>OK</code>. Именно так из драмы вырастает управление программой: сцены — метки, переходы — goto, а диалог — арифметика.' },
        { t: 'warn', html: 'Переход ведёт только на существующую сцену: <code>Let us return to scene VII.</code> при двух сценах уронит интерпретатор. И помни правило сцены: реплику в новой сцене произносят те, кто на ней находится, — при необходимости добавь <code>[Enter …]</code>.' },
        { t: 'note', html: 'В настоящем SPL переходы бывают условными — после сравнения: «If so, we shall return to scene II.», а значения можно прятать в стек командами Remember и Recall. Тебе хватит прямых переходов — они уже превращают пьесу в программу с циклами.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочти фрагмент пьесы по правилам курса (king = 77, flower = 2) и напиши ровно то, что он выведет на экран, — одной строкой, без пробелов между выводами.</p>',
        code: `[Enter Romeo and Juliet]

Romeo:
  You are as brave as the sum of a king and a flower.
  Open your heart.
  Speak your mind.
  Let us return to scene II.

  Open your heart.

Scene II: The end.

Romeo:
  You are as bold as the difference between a king and a flower.
  Speak your mind.`,
        answer: '79OK',
        solution: '79OK'
      },
      hints: [
        'Джульетта получает 79: Open your heart печатает 79, Speak your mind — символ «O».',
        'Переход к сцене II пропускает второй Open your heart.',
        'Разность 77 − 2 = 75 — это код буквы «K».'
      ],
      solution: '79OK'
    },

    /* ---------- 4. Ловушки сцены ---------- */
    {
      id: 'shakespeare-4',
      title: 'Ловушки сцены',
      goal: 'Держать правило сцены: Enter/Exit/Exeunt, обращения к адресату и вопросы-сравнения вместо присваивания',
      xp: 40,
      theory: [
        { t: 'p', html: 'Театр строг к составу труппы. Главное правило сцены: реплику произносят только тому, кто <b>на сцене</b>. Обратился к тому, кто ушёл или ещё не выходил, — интерпретатор падает с ошибкой выполнения. Вернуть персонажа можно только ремаркой <code>[Enter Juliet]</code> — в той же или новой сцене.' },
        { t: 'code', code: `[Enter Romeo and Juliet]

Romeo:
  Speak your mind.

[Exit Juliet]

Romeo:
  Open your heart.   ← ошибка: Джульетты нет на сцене` },
        { t: 'p', html: 'Кто как уходит: <code>[Exit Romeo]</code> — ушёл один, <code>[Exeunt]</code> — уходят все, <code>[Exeunt Romeo and Juliet]</code> — уходят перечисленные. Состав сцены сохраняется, пока персонажи не ушли ремаркой, поэтому повторный <code>[Enter</code> того, кто уже на сцене, — тоже ошибка: он не может войти дважды.' },
        { t: 'p', html: 'Вторые грабли — форма обращения. Присваивание звучит во втором лице: <code>You are as brave as …</code> — значение получает <b>адресат</b>. А сравнения — это вопросы: <code>Am I as good as you?</code> («я так же хорош, как ты?») проверяет равенство значений говорящего и адресата, <code>Are you better than me?</code> спрашивает «ты больше меня?». Приятные сравнения (better, bigger, warmer) значат «больше», грустные (worse, smaller, colder) — «меньше».' },
        { t: 'code', code: `Romeo:
  Am I as good as you?
  If so, we shall return to scene II.` },
        { t: 'p', html: 'Вопрос-сравнение сам ничего не печатает и не меняет значения — он лишь задаёт условие для слов <code>If so, …</code> («если так») и <code>If not, …</code> («если нет»). Так делаются ветвления: сравнил — и прыгнул в нужную сцену.' },
        { t: 'warn', html: 'Регистр решает: <code>Romeo</code> — персонаж, <code>romeo</code> — неизвестно кто. Реплика всегда начинается с имени и двоеточия, а вопрос-сравнение заканчивается вопросительным знаком — иначе это не вопрос, и интерпретатор запутается.' },
        { t: 'note', html: 'Что ещё умеет настоящий SPL: объявление персонажей посреди пьесы, вход и выход из «вопросов» и стек Remember/Recall. Твоя мини-драма уже покрывает ядро языка — дальше только глубже.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Джульетта покинула сцену ремаркой <code>[Exit Juliet]</code>, но Ромео продолжает говорить: <code>Open your heart.</code> Что произойдёт?</p>',
        options: [
          'Джульетта автоматически вернётся на сцену, и её значение напечатается числом',
          'Ошибка времени выполнения: нельзя обращаться к персонажу, которого нет на сцене',
          'Выведется 0 — значение персонажа, которого нет на сцене',
          'Строка будет молча проигнорирована, программа завершится штатно'
        ],
        correct: 1,
        explain: 'Правило сцены железное: говорить можно только с тем, кто на ней находится. Обращение к ушедшему персонажу роняет интерпретатор с ошибкой выполнения. Вернуть Джульетту можно только ремаркой [Enter Juliet] — в той же или новой сцене.',
        solution: 1
      },
      hints: [
        'Состав сцены — не украшение, а условие исполнения реплик.',
        'Чтобы вернуть персонажа, нужна ремарка Enter — сама она не появится.'
      ],
      solution: 1
    },

    /* ---------- 5. Проект: пьеса-калькулятор ---------- */
    {
      id: 'shakespeare-5',
      title: '🚀 Проект: пьеса-калькулятор',
      goal: 'Поставить пьесу-калькулятор: два персонажа, вычисление суммы, вывод Speak your mind и две сцены',
      xp: 100,
      theory: [
        { t: 'p', html: 'Финал — «пьеса-калькулятор». Техзадание звучит как заказ театрального менеджера, но требования вполне программистские: два персонажа, вычисление суммы, вывод результата и две сцены. Всё это ты уже ставил по частям — теперь соберём в одну драму от афиши до занавеса.' },
        { t: 'list', items: [
          '<b>заголовок пьесы</b> — строка с точкой в конце;',
          '<b>два персонажа</b> — строки «Имя, описание.»;',
          '<b>акт и две сцены</b> — Act I:, Scene I: и Scene II:;',
          '<b>ремарки</b> — [Enter …] в начале и [Exeunt] или [Exit …] в конце;',
          '<b>реплики</b> — «Имя:», вычисление the sum of … и вывод Speak your mind.'
        ] },
        { t: 'code', code: `                    Act I: The sum.

                    Scene I: Preparing.

[Enter Romeo and Juliet]

Romeo:
  You are as brave as the sum of a king and a flower.
  Open your heart.` },
        { t: 'p', html: 'Сюжет предлагаю такой: в сцене I Джульетта получает сумму короля и цветка (77 + 2 = 79) и открывает сердце — на афише появляется «79». Затем пьеса доигрывается до сцены II, где Ромео командует <code>Speak your mind.</code> — Джульетта «произносит» букву O: код 79 — это именно она. Отдельная команда перехода не нужна: без goto сцены играются по порядку, а состав сцены сохраняется — Джульетта никуда не уходила.' },
        { t: 'note', html: 'После зачёта усложняй пьесу: условные переходы после сравнения «If so, …», второй акт, ввод значений с клавиатуры командой Listen to your heart — из маленькой драмы вырастет настоящий алгоритм, и это будет уже вполне работающий SPL.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Поставь «пьесу-калькулятор»: заголовок с точкой, два персонажа («Имя, описание.»), акт <code>Act I:</code> с двумя сценами <code>Scene I:</code> и <code>Scene II:</code>, ремарки <code>[Enter …]</code> и <code>[Exeunt]</code>/<code>[Exit …]</code>, реплика в форме <code>Имя:</code> с вычислением <code>the sum of …</code> и выводом <code>Speak your mind.</code> Заглушки TODO замени.</p>',
        starter: `TODO название пьесы

Romeo, a young man.
Juliet, a woman.

Act I: TODO

Scene I: TODO

[Enter Romeo and Juliet]

Romeo:
  You are as sweet as TODO

[Exeunt]`,
        rules: [
          { desc: 'Заголовок пьесы — строка с точкой в конце (без запятых внутри)', all: ['^[^.,\\n]{5,}\\.\\s*$'] },
          { desc: 'Два персонажа объявлены строками «Имя, описание.»', all: ['^[A-Z][a-z]+\\s*,\\s*[a-z][^.]*\\.', '\\n[ \\t]*[A-Z][a-z]+\\s*,\\s*[a-z][^.]*\\.'] },
          { desc: 'Есть акт Act I: и две сцены Scene I: и Scene II:', all: ['^[ \\t]*Act\\s+[IVX]+\\s*:', 'Scene\\s+[IVX]+\\s*:[\\s\\S]*Scene\\s+[IVX]+\\s*:'] },
          { desc: 'Персонажи выходят и уходят: [Enter …] и [Exeunt]/[Exit …]', all: ['\\[\\s*Enter\\s+[^\\]]+\\]', '\\[\\s*Ex(eunt|it)[^\\]]*\\]'] },
          { desc: 'Реплика «Имя:» с вычислением the sum of … и выводом Speak your mind', all: ['^[A-Z][a-z]+\\s*:\\s*$', 'sum of', 'Speak your mind'] },
          { desc: 'Нет заглушек TODO', all: ['\\S'], none: ['TODO'] }
        ]
      },
      hints: [
        'Две сцены — два заголовка: Scene I: … / Scene II: … (римские цифры и двоеточие).',
        'Вычисление: You are as brave as the sum of a king and a flower. Вывод: Speak your mind.'
      ],
      solution: `The Calculator Play.

Romeo, a young man who likes to count.
Juliet, a woman with a head for numbers.

                    Act I: The sum.

                    Scene I: Preparing the numbers.

[Enter Romeo and Juliet]

Romeo:
  You are as brave as the sum of a king and a flower.
  Open your heart.

                    Scene II: The result.

Romeo:
  Speak your mind.

[Exeunt]`
    }
  ],

  cheats: [
    { title: 'Каркас пьесы', code: `The Title Play.

Romeo, a young man.
Juliet, a woman.

Act I: The plot.

Scene I: The start.

[Enter Romeo and Juliet]

Romeo:
  Speak your mind.

[Exeunt]` },
    { title: 'Мини-словарь значений', list: [
      '<code>nothing</code> = 0, <code>flower</code> = 2',
      '<code>sky</code> = 32 (код пробела), <code>king</code> = 77',
      'приятное прилагательное = +1, обидное = −1',
      'артикль обязателен: a king, an uncle'
    ] },
    { title: 'Присваивание и выражения', list: [
      '<code>You are as brave as X.</code> — записать X адресату',
      '<code>the sum of X and Y</code> — сумма',
      '<code>the difference between X and Y</code> — разность',
      '<code>yourself</code> — текущее значение адресата'
    ] },
    { title: 'Вывод и переходы', list: [
      '<code>Open your heart.</code> — печать числа',
      '<code>Speak your mind.</code> — печать символа (код = значение)',
      '<code>Let us return to scene II.</code> — переход к сцене',
      'сцены без перехода играются по порядку'
    ] },
    { title: 'Сцена и обращения', list: [
      '<code>[Enter Romeo and Juliet]</code> — выйти на сцену',
      '<code>[Exit Romeo]</code> — ушёл один, <code>[Exeunt]</code> — все',
      'говорить можно только с тем, кто на сцене',
      '<code>You are …</code> — присваивание адресату, <code>Am I …?</code> — вопрос-сравнение'
    ] }
  ]
};
