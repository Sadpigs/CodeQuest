'use strict';
/* ============ CodeQuest — курс Smalltalk ============
   Smalltalk не запускается в приложении: задания проверяются
   структурным анализом (regex по коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.smalltalk = {
  id: 'smalltalk',
  title: 'Smalltalk',
  emoji: '🎈',
  color: '#7d9c1e',
  lang: 'smalltalk',
  tagline: 'Smalltalk: сообщения, блоки, классы — 10 уровней',
  description: 'Место, где родилось объектно-ориентированное программирование: Xerox PARC, 1972 год, Алан Кэй. В Smalltalk всё — объект, а любое действие — сообщение; здесь же придумали окна, мышь и первые IDE. За 10 уровней освоим сообщения, блоки с параметрами, классы, коллекции и словари и доведём банковский проект до проверок операций и истории транзакций.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'smalltalk-1',
      title: 'Первая программа',
      goal: 'Напечатать приветствие в Transcript: сообщение show:, строка в одинарных кавычках, каскад с cr',
      xp: 30,
      theory: [
        { t: 'p', html: 'Smalltalk создали в исследовательском центре Xerox PARC в 1972 году под руководством Алана Кэя — как язык для «Dynabook», мечты о персональном компьютере. Именно в Smalltalk-среде впервые появились перекрывающиеся окна, мышь и настоящая интегрированная среда разработки. Его идеи унаследовали Objective-C, Ruby и почти все современные IDE.' },
        { t: 'p', html: 'Работаем в Pharo — современном открытом Smalltalk. Скачай Pharo Launcher, создай образ, и ты внутри живой системы, где нет различия между программой и средой. Код исполняется в <b>Playground</b> (рабочей площадке): пишешь выражение, выделяешь и жмёшь Do it (Ctrl+D) — выполнить, или Print it (Ctrl+P) — выполнить и показать результат прямо под кодом.' },
        { t: 'code', code: `Transcript show: 'Привет, CodeQuest!'; cr.` },
        { t: 'p', html: 'Transcript — это объект-протокол, окно с выводом (открывается из меню Tools → Transcript). Сообщение <code>show:</code> просит его показать строку, а <code>cr</code> — перевести строку. Точка завершает выражение. Строки в Smalltalk — в ОДинарных кавычках.' },
        { t: 'p', html: 'Точка с запятой <code>;</code> — каскад: серия сообщений одному и тому же получателю без повторения его имени. <code>Transcript show: ' + "'текст'; cr.</code> читается «покажи текст и переведи строку — всё в Transcript»." },
        { t: 'list', items: [
          '<b>\'строка\'</b> — литерал в одинарных кавычках;',
          '<b>Transcript show:</b> — печать без перевода строки;',
          '<b>cr</b> — перевод строки;',
          '<b>.</b> — конец выражения, <b>;</b> — каскад.'
        ] },
        { t: 'warn', html: 'Двойные кавычки в Smalltalk — это КОММЕНТАРИИ: "вот такой". Никаких println и print-функций здесь нет: печать — всегда сообщение объекту Transcript. И помни про одинарные кавычки у строк — двойные съедят твой текст как комментарий.' },
        { t: 'note', html: 'Print it (Ctrl+P) в Playground напечатает результат последнего выражения рядом с кодом — так удобно исследовать, что возвращает любое сообщение. Вывод в Transcript и Print it — два разных инструмента: первый для программы, второй для тебя.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Выведи приветствие в Transcript: сообщение <code>show:</code> со строкой в одинарных кавычках и перевод строки <code>cr</code> через каскад. Выполнять будем в Playground, печатать — в окно Transcript.</p>',
        starter: `"TODO: покажи приветствие в протоколе Transcript"
"и не забудь перевод строки"`,
        rules: [
          { desc: 'Печать в Transcript (show: или showCr:)', any: ['Transcript\\s+show:', 'Transcript\\s+showCr:'] },
          { desc: 'Строка в одинарных кавычках', all: ["'[^']+'"] },
          { desc: 'Перевод строки: cr (или showCr:)', any: ['\\bcr\\b', 'showCr'] },
          { desc: 'Код непустой и без заглушек TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        "Каркас: Transcript show: 'текст'; cr. — точка завершает выражение.",
        'Точка с запятой — каскад: несколько сообщений одному Transcript подряд.',
        "Строки в Smalltalk — в одинарных кавычках: 'Привет!'."
      ],
      solution: `"Моя первая программа на Smalltalk"
Transcript show: 'Привет, CodeQuest!'; cr.`
    },

    /* ---------- 2. Переменные и типы ---------- */
    {
      id: 'smalltalk-2',
      title: 'Переменные и типы',
      goal: 'Объявлять переменные |x|, присваивать через := и различать базовые типы: Integer, Float, String, Boolean',
      xp: 30,
      theory: [
        { t: 'p', html: 'Переменные объявляются вертикальными чертами: <code>| name age |</code> — просто перечисление имён. Присваивание — <code>:=</code> (устаревший вариант — символ подчёркивания). Область видимости — до конца метода или выражения Playground.' },
        { t: 'code', code: `| name age |
name := 'Аня'.
age := 20.` },
        { t: 'p', html: 'Типов-примитивов в Smalltalk нет — числа и строки тоже объекты. Целые — Integer, дробные — Float, строки — String, истина/ложь — объекты true и false. Класс любого объекта узнаёт унарное сообщение <code>class</code>.' },
        { t: 'code', code: `20 class.      "SmallInteger"
1.75 class.    "Float"
'Аня' class.   "ByteString"
true class.    "True"` },
        { t: 'p', html: 'Сообщения бывают трёх видов: унарные — без аргументов (<code>class</code>, <code>printString</code>), бинарные — арифметика и сравнение (<code>3 + 4</code>), с ключевыми словами — каждое двоеточие добавляет аргумент (<code>to: do:</code>). Конкатенация строк — бинарная запятая: <code>\'Привет, \', \'мир!\'</code>.' },
        { t: 'code', code: `| greeting |
greeting := 'Привет, ' , 'мир!'.
Transcript show: greeting; cr.` },
        { t: 'warn', html: 'Деление целых в Smalltalk точное: 3/4 даст рациональную дробь Fraction (3/4), а не 0.75! Если нужен Float — пиши 3.0 / 4 или 3 / 4.0. И следи за регистром: true и false — с маленькой буквы, True с большой — уже имя класса.' },
        { t: 'note', html: 'Сообщение printString превращает любой объект в строку — оно понадобится, чтобы печатать числа через show:: Transcript show: 20 printString.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни объявление переменных: огради список имён вертикальными чертами, впиши строку <code>\'Аня\'</code>, дробное <code>1.75</code> и истину <code>true</code> с маленькой буквы.</p>',
        code: `{{0}} name year height isCoder {{1}}

name := {{2}}.        "строка"
year := 2024.         "целое — Integer"
height := {{3}}.      "дробное"
isCoder := {{4}}.     "истина"

Transcript show: name; show: ' '; show: height printString; cr.`,
        blanks: [
          { answer: '|' },
          { answer: '|' },
          { answer: "'Аня'" },
          { answer: '1.75' },
          { answer: 'true' }
        ],
        ci: false
      },
      hints: [
        'Список переменных берётся в вертикальные черты: | name year |.',
        "Строки — в одинарных кавычках: name := 'Аня'.",
        'Дробные — через точку: 1.75. Истина — true с маленькой буквы.'
      ],
      solution: ['|', '|', "'Аня'", '1.75', 'true']
    },

    /* ---------- 3. Условия и циклы-блоки ---------- */
    {
      id: 'smalltalk-3',
      title: 'Условия и циклы-блоки',
      goal: 'Читать блоки [ :i | ... ], условия ifTrue:/ifFalse: и циклы to:do: с timesRepeat: — и просчитать вывод руками',
      xp: 35,
      theory: [
        { t: 'p', html: 'Блок <code>[ :x | ... ]</code> — анонимная функция: параметры перечисляются после двоеточий, тело — после вертикальной черты. Блок — тоже объект; сообщение <code>value</code> его запускает. Через блоки Smalltalk делает всё, что другие языки делают операторами. Так устроены и условия — это СООБЩЕНИЯ к объектам true и false: <code>ifTrue:</code>, <code>ifFalse:</code> и вместе <code>ifTrue:ifFalse:</code>; аргумент — блок. Скобки вокруг условия не обязательны, но <code>(n &gt; 5) ifTrue: [ ... ]</code> читается яснее.' },
        { t: 'code', code: `| n |
n := 7.
n > 5
    ifTrue: [ Transcript show: 'много'; cr ]
    ifFalse: [ Transcript show: 'мало'; cr ].` },
        { t: 'p', html: 'Циклы тоже сообщения. <code>1 to: 5 do: [ :i | ... ]</code> — перебор от 1 до 5 включительно; параметр блока i получает очередное число. <code>timesRepeat:</code> просто повторяет блок N раз.' },
        { t: 'code', code: `1 to: 5 do: [ :i | Transcript show: i printString; cr ].

3 timesRepeat: [ Transcript show: 'ку ' ].
Transcript cr.` },
        { t: 'p', html: 'Свёртка — <code>inject:into:</code>: <code>(1 to: 5) inject: 0 into: [ :sum :each | sum + each ]</code> даёт 15. Первый аргумент — стартовое значение накопителя, второй — блок, получающий накопитель и очередной элемент. Это как reduce в других языках.' },
        { t: 'code', code: `(1 to: 5) inject: 0 into: [ :sum :each | sum + each ].  "15"` },
        { t: 'warn', html: 'Transcript show: ожидает СТРОКУ: show: 15 упадёт с ошибкой класса, пиши show: 15 printString. И не забывай := внутри блоков: sum := sum + i — иначе результат никуда не сохранится.' },
        { t: 'note', html: 'Словари Dictionary и наборы Set обходятся без гарантии порядка — в задачах «предскажи вывод» их избегаем: вывод по элементам коллекции надёжен только у упорядоченных массивов, строк и интервалов (1 to: 5).' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай код Playground и напиши, что появится в окне Transcript — по одной строке на каждый вывод.</p>',
        code: `| sum |
sum := 0.
1 to: 5 do: [ :i | sum := sum + i ].
Transcript show: sum printString; cr.

sum > 10
    ifTrue: [ Transcript show: 'много' ]
    ifFalse: [ Transcript show: 'мало' ].
Transcript cr.

3 timesRepeat: [ Transcript show: 'ку' ].
Transcript cr.`,
        answer: `15
много
кукуку`
      },
      hints: [
        'sum копит 1+2+3+4+5 — пройди цикл руками.',
        '15 больше 10 — выбирается ветка ifTrue:.',
        'timesRepeat: выполняет блок ровно N раз — три раза по «ку».'
      ],
      solution: `15
много
кукуку`
    },

    /* ---------- 4. Классы и методы ---------- */
    {
      id: 'smalltalk-4',
      title: 'Классы и методы',
      goal: 'Объявить класс через Object subclass: #Dog, определить метод сообщением &gt;&gt; с возвратом ^ и создать экземпляр',
      xp: 40,
      theory: [
        { t: 'p', html: 'В Pharo класс можно объявить прямо из Playground — классы здесь тоже объекты, и определение класса это сообщение. <code>Object subclass: #Dog</code> говорит классу Object: «создай подкласс с именем Dog». <code>#Dog</code> — символ, литерал имени класса (решётка обязательна). Поля экземпляра перечисляются строкой в <code>instanceVariableNames:</code>.' },
        { t: 'code', code: `Object subclass: #Dog
    instanceVariableNames: 'name'
    classVariableNames: ''
    package: 'CodeQuest'.` },
        { t: 'p', html: 'Методы добавляются сообщением <code>&gt;&gt;</code>: <code>Dog &gt;&gt; speak</code> компилирует метод speak в класс Dog. Тело пишется с новой строки с отступом, возврат значения — символ <code>^</code>. Метод без ^ возвращает сам объект-получателя (self).' },
        { t: 'code', code: `Dog >> speak
    ^ 'Гав!'

Dog >> name: aString
    name := aString` },
        { t: 'p', html: 'Три вида сообщений: <b>унарные</b> — без аргументов (d speak, acc balance), <b>бинарные</b> — арифметика и строки (3 + 4, name, other), <b>с ключевыми словами</b> — каждое двоеточие требует аргумент (d name: \'Шарик\', acc deposit: 100). Приоритет: унарные → бинарные → ключевые.' },
        { t: 'code', code: `| d |
d := Dog new.          "new — сообщение классу"
d name: 'Шарик'.
Transcript show: d speak; cr.` },
        { t: 'p', html: '<code>new</code> не только создаёт экземпляр, но и отправляет ему сообщение <code>initialize</code> — там удобно задать стартовые значения полей: <code>Dog &gt;&gt; initialize</code>, первой строкой <code>super initialize</code> — вызов родительской версии, затем присваивания полям, например <code>name := \'Безымянный\'</code>.' },
        { t: 'warn', html: 'Селектор без двоеточия — унарный метод (balance), селектор с двоеточием требует аргумент (deposit: 100). Порядок слов жёсткий: получатель первый — acc deposit: 100, а не deposit: acc 100. Имена классов — с большой буквы CamelCase, переменные и селекторы — с маленькой.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Опиши класс: <code>Object subclass: #Dog</code> с полем в <code>instanceVariableNames</code>, метод через <code>Dog &gt;&gt; speak</code> с возвратом <code>^</code>, затем создай экземпляр через <code>new</code> и выведи результат его сообщения в Transcript.</p>',
        starter: `"TODO: объяви класс Dog с переменной экземпляра"
"TODO: метод speak с возвратом строки"
"TODO: создай экземпляр и покажи его голос в Transcript"`,
        rules: [
          { desc: 'Класс объявлен через subclass: #Имя', all: ['subclass:\\s*#\\w+'] },
          { desc: 'Поля экземпляра перечислены в instanceVariableNames', all: ["instanceVariableNames:\\s*'[^']*'"] },
          { desc: 'Метод определён сообщением >>', any: ['\\w+\\s*>>\\s*\\w+'] },
          { desc: 'Метод возвращает значение через ^', all: ['\\^'] },
          { desc: 'new, вывод в Transcript и нет заглушек TODO', all: ['\\bnew\\b'], any: ['Transcript\\s+show:'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        "Каркас класса: Object subclass: #Dog, поля — строкой в instanceVariableNames: 'name'.",
        'Метод: Dog >> speak, тело — с новой строки, возврат через ^.',
        'Экземпляр: d := Dog new. Затем сообщение: d speak.'
      ],
      solution: `Object subclass: #Dog
    instanceVariableNames: 'name'
    classVariableNames: ''
    package: 'CodeQuest'.

Dog >> speak
    ^ 'Гав!'

| d |
d := Dog new.
Transcript show: d speak; cr.`
    },

    /* ---------- 5. Идиомы: коллекции и каскад ---------- */
    {
      id: 'smalltalk-5',
      title: 'Идиомы: коллекции и каскад',
      goal: 'Различать collect:, select:, detect: и каскад ; — фильтрация массива блоком',
      xp: 40,
      theory: [
        { t: 'p', html: 'Коллекции — сердце идиоматического Smalltalk. <code>do:</code> — перебор, <code>collect:</code> — преобразование каждого элемента (как map), <code>select:</code> — отбор подходящих (как filter), <code>reject:</code> — наоборот, отбрасывает подходящие, <code>detect:</code> — первый подходящий элемент, <code>inject:into:</code> — свёртка. Все принимают блок.' },
        { t: 'code', code: `#(10 15 20 25) collect: [ :n | n * 2 ].   "→ #(20 30 40 50)"
#(10 15 20 25) select: [ :n | n >= 20 ].  "→ #(20 25)"` },
        { t: 'p', html: '<code>#( )</code> — литерал массива. У интервала <code>(1 to: 6)</code> есть то же сообщение select:, но чтобы получить именно массив, вызывают <code>asArray</code>. Условие в блоке — обычное сообщение сравнения: <code>each odd</code> проверяет нечётность, <code>n &gt;= 20</code> — «не меньше двадцати».' },
        { t: 'code', code: `(1 to: 6) asArray select: [ :each | each odd ].
"→ #(1 3 5)"` },
        { t: 'p', html: 'Каскад <code>;</code> — цепочка сообщений одному получателю: имя пишется один раз, дальше идут сообщения через точку с запятой. Идеален для Transcript и для настройки одного объекта серией сообщений.' },
        { t: 'code', code: `Transcript
    show: 'Строка 1'; cr;
    show: 'Строка 2'; cr.` },
        { t: 'warn', html: 'Словари Dictionary и множества Set обходят элементы БЕЗ гарантии порядка — не строй вывод по порядку их ключей и не используй их в задачах «предскажи вывод». Упорядочены массивы, строки, интервалы и OrderedCollection.' },
        { t: 'note', html: 'Параметр блока традиционно называют each (или n, x). Блоки передаются как обычные аргументы сообщений — в этом и суть Smalltalk: управляющих конструкций почти нет, есть только сообщения и блоки.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что вернёт выражение?</p><pre>#(10 15 20 25) select: [ :n | n &gt;= 20 ]</pre>`,
        options: ['#(10 15)', '#(20 25)', '20', '#(10 15 20 25)'],
        correct: 1,
        explain: 'select: возвращает НОВУЮ коллекцию только из элементов, для которых блок вернул true: 10 и 15 не проходят проверку, остаются #(20 25). collect: применил бы блок к каждому и вернул бы #(false false true true), а detect: вернул бы первый подходящий элемент — 20.',
        solution: 1
      },
      hints: [
        'select: фильтрует: в результат попадают только «истинные» элементы.',
        'Проверь каждый элемент: проходит ли он проверку «не меньше 20»?',
        'collect: преобразует все элементы, select: — отбирает часть.'
      ],
      solution: 1
    },

    /* ---------- 6. 🚀 Проект: банковский счёт ---------- */
    {
      id: 'smalltalk-6',
      title: '🚀 Проект: банковский счёт',
      goal: 'Собрать класс BankAccount с полем balance и методами deposit:, withdraw:, balance — плюс сценарий операций',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальный проект — класс банковского счёта. Каркас знакомый: <code>Object subclass: #BankAccount</code> с одним полем balance в instanceVariableNames. Внутри методов имена полей читаются как обычные переменные — это и есть инкапсуляция: поле видно только методам своего класса.' },
        { t: 'code', code: `Object subclass: #BankAccount
    instanceVariableNames: 'balance'
    classVariableNames: ''
    package: 'CodeQuest'.` },
        { t: 'p', html: 'Метод <code>initialize</code> вызывается автоматически при <code>new</code> — задаём стартовый баланс. Операции — сообщения с ключевыми словами: <code>deposit:</code> кладёт сумму, <code>withdraw:</code> снимает, меняя поле balance. Геттер <code>balance</code> — унарный метод с возвратом через ^.' },
        { t: 'code', code: `BankAccount >> initialize
    balance := 0

BankAccount >> deposit: anAmount
    balance := balance + anAmount

BankAccount >> withdraw: anAmount
    balance := balance - anAmount

BankAccount >> balance
    ^ balance` },
        { t: 'p', html: 'Сценарий в Playground: создать счёт, выполнить операции, напечатать баланс. Число перед show: превращаем в строку через printString — или склеиваем запятой со строкой-пояснением.' },
        { t: 'code', code: `| acc |
acc := BankAccount new.
acc deposit: 100.
acc deposit: 50.
acc withdraw: 30.
Transcript show: 'Баланс: ' , acc balance printString; cr.` },
        { t: 'list', items: [
          '<b>subclass: + instanceVariableNames</b> — каркас класса с полем;',
          '<b>initialize</b> — стартовые значения, вызывается при new;',
          '<b>deposit:/withdraw:</b> — keyword-методы с аргументом;',
          '<b>balance</b> — унарный геттер через ^;',
          '<b>new + вызовы + Transcript</b> — сценарий проверки.'
        ] },
        { t: 'warn', html: 'Имена параметров — с маленькой буквы (anAmount — «ан»-префикс намекает на аргумент), классы — с большой. Хочешь усложнить — добавь в withdraw: проверку ifTrue:/ifFalse:, хватает ли денег; но базовая версия проекта — просто арифметика поля.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери класс <code>BankAccount</code>: поле в <code>instanceVariableNames</code>, методы <code>deposit:</code>, <code>withdraw:</code> (с аргументом) и <code>balance</code> (с возвратом <code>^</code>) в стиле <code>BankAccount &gt;&gt; deposit:</code>. Затем сценарий: <code>new</code>, вызовы с числовыми суммами и печать баланса в Transcript.</p>',
        starter: `"TODO: объяви класс BankAccount с полем баланса"
"TODO: методы deposit:, withdraw: и balance"
"TODO: создай счёт, сделай операции и покажи баланс"`,
        rules: [
          { desc: 'Класс BankAccount объявлен через subclass:', all: ['subclass:\\s*#BankAccount'] },
          { desc: 'Поле объявлено в instanceVariableNames', all: ["instanceVariableNames:\\s*'[^']+'"] },
          { desc: 'Методы deposit:, withdraw: и balance определены через >>', all: ['\\w+\\s*>>\\s*deposit:', '\\w+\\s*>>\\s*withdraw:', '\\w+\\s*>>\\s*balance'] },
          { desc: 'Есть возврат значения через ^', all: ['\\^'] },
          { desc: 'Вызваны deposit: и withdraw: с числовой суммой', all: ['deposit:\\s*\\d+', 'withdraw:\\s*\\d+'] },
          { desc: 'new, печать в Transcript и нет заглушек TODO', all: ['\\bnew\\b'], any: ['Transcript\\s+show:'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Метод в стиле: BankAccount >> deposit: anAmount, тело — balance := balance + anAmount.',
        'Геттер: BankAccount >> balance с новой строки, тело — ^ balance.',
        'Сценарий: acc := BankAccount new. acc deposit: 100. ... Transcript show: acc balance printString; cr.'
      ],
      solution: `Object subclass: #BankAccount
    instanceVariableNames: 'balance'
    classVariableNames: ''
    package: 'CodeQuest'.

BankAccount >> initialize
    balance := 0

BankAccount >> deposit: anAmount
    balance := balance + anAmount

BankAccount >> withdraw: anAmount
    balance := balance - anAmount

BankAccount >> balance
    ^ balance

| acc |
acc := BankAccount new.
acc deposit: 100.
acc deposit: 50.
acc withdraw: 30.
Transcript show: 'Баланс: ' , acc balance printString; cr.`
    },

    /* ---------- 7. Блоки с параметрами и коллекции ---------- */
    {
      id: 'smalltalk-7',
      title: 'Блоки с параметрами и коллекции',
      goal: 'Обрабатывать коллекции блоками: do: для перебора, collect: для преобразования, select: для фильтрации',
      xp: 45,
      theory: [
        { t: 'p', html: 'Блоки с параметрами — главный рабочий инструмент коллекций. <code>do:</code> выполняет блок для каждого элемента (печать, накопление), <code>collect:</code> возвращает НОВУЮ коллекцию из результатов блока (как map), <code>select:</code> — новую коллекцию только из подошедших элементов (как filter). Параметр блока перечисляется после двоеточия: <code>[ :p | ... ]</code>.' },
        { t: 'code', code: `| prices |
prices := #(120 80 150 90).
prices do: [ :p | Transcript show: p printString; cr ].
prices collect: [ :p | p * 2 ].     "→ #(240 160 300 180)"
prices select: [ :p | p >= 120 ].   "→ #(120 150)"` },
        { t: 'p', html: 'Разница ролей важна: <code>do:</code> возвращает саму коллекцию и используется ради побочных эффектов — печати или изменения внешних переменных. <code>collect:</code> и <code>select:</code> ничего не печатают — они строят новую коллекцию, которую присваивают переменной. Путаница этих ролей — самая частая ошибка новичка.' },
        { t: 'h', html: 'Литерал массива #( )' },
        { t: 'p', html: 'Массив-литерал пишется через решётку: <code>#(120 80 150)</code> — элементы через ПРОБЕЛ, без запятых. Внутри можно класть числа, символы и строки в одинарных кавычках: <code>#(&#39;Кофе&#39; &#39;Чай&#39;)</code>. Для вычисляемых коллекций есть фигурные скобки <code>{ 10 + 5. 2 * 3 }</code> — но это уже не литерал, а выражение.' },
        { t: 'list', items: [
          '<b>do:</b> — перебор ради эффекта;',
          '<b>collect:</b> — преобразовать каждый элемент;',
          '<b>select:</b> — оставить подходящие;',
          '<b>reject:</b> — выбросить подходящие; <b>detect:</b> — первый подходящий.'
        ] },
        { t: 'warn', html: 'Transcript show: принимает только строку — перед числом вызывай printString: <code>show: p printString</code>. И не путай <code>#(1 2 3)</code> с <code>{1. 2. 3}</code>: первые — литерал, вторые — вычисляемый массив; в константах используй решётку.' },
        { t: 'note', html: 'Сообщения к коллекциям цепляются друг за друга: <code>(prices select: [ :p | p >= 100 ]) collect: [ :p | p * 2 ]</code> — сначала отбор, потом преобразование. Так Smalltalk-код читается как конвейер — идея, которую потом унаследовали потоки и LINQ.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви массив чисел литералом <code>#( )</code>. Пройдись по нему с блоком-параметром через <code>do:</code> и печатай в Transcript (число — через printString). Затем собери новую коллекцию через <code>collect:</code> и отфильтруй через <code>select:</code> — оба результата покажи в Transcript.</p>',
        starter: `" TODO: объяви массив цен через решётку-литерал "
" TODO: пройдись по каждому элементу с блоком-параметром "
" TODO: преобразуй элементы в новую коллекцию "
" TODO: отфильтруй подходящие и покажи оба результата в Transcript "`,
        rules: [
          { desc: 'Блок с параметром [ :x | ... ]', all: ['\\[\\s*:\\w+\\s*\\|'] },
          { desc: 'Перебор do: с блоком', all: ['\\bdo:\\s*\\['] },
          { desc: 'Преобразование collect: с блоком', all: ['collect:\\s*\\['] },
          { desc: 'Фильтрация select: с блоком', all: ['select:\\s*\\['] },
          { desc: 'Вывод в Transcript и нет заглушек TODO', all: ['\\S'], any: ['Transcript\\s+show:'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Литерал: prices := #(120 80 150 90).',
        'Перебор: prices do: [ :p | Transcript show: p printString; cr ].',
        'Преобразование: prices collect: [ :p | p * 2 ]. Отбор: prices select: [ :p | p >= 120 ].'
      ],
      solution: `| prices expensive doubled |
prices := #(120 80 150 90).

"печать каждого элемента"
prices do: [ :p | Transcript show: 'Цена: ' , p printString; cr ].

doubled := prices collect: [ :p | p * 2 ].
Transcript show: doubled printString; cr.

expensive := prices select: [ :p | p >= 120 ].
Transcript show: expensive printString; cr.`
    },

    /* ---------- 8. Классы: subclass, instanceVariableNames ---------- */
    {
      id: 'smalltalk-8',
      title: 'Классы: subclass, instanceVariableNames',
      goal: 'Собрать объявление класса по частям: поля одной строкой, initialize при new, геттеры через ^ и вычисляющие методы',
      xp: 50,
      theory: [
        { t: 'p', html: 'Класс — чертёж объектов, поля экземпляра — его состояние. В объявлении класса поля перечисляются ОДНОЙ строкой в <code>instanceVariableNames:</code> — имена через пробел, вся строка в кавычках. Само объявление — сообщение классу-родителю: <code>Object subclass: #Rectangle</code>.' },
        { t: 'code', code: `Object subclass: #Rectangle
    instanceVariableNames: 'width height'
    classVariableNames: ''
    package: 'CodeQuest'.` },
        { t: 'p', html: 'Сообщение <code>initialize</code> объект получает автоматически при <code>new</code> — там задают стартовые значения полей. Без инициализации поле хранит nil, и первая же арифметика упадёт с ошибкой MessageNotUnderstood. В наследниках первым делом вызывают <code>super initialize</code>, чтобы не потерять родительскую инициализацию.' },
        { t: 'h', html: 'Геттеры и сеттеры' },
        { t: 'p', html: 'Поля видны только методам своего класса — снаружи к ним обращаются сообщениями. Геттер — унарный метод с именем поля и возвратом через <code>^</code>: <code>Rectangle &gt;&gt; width</code> с телом <code>^ width</code>. Сеттер — keyword-метод <code>width:</code> с присваиванием; в Pharo такие методы можно сгенерировать рефакторингом, но руками написать полезнее для понимания.' },
        { t: 'list', items: [
          '<b>subclass: #Имя</b> — объявление класса;',
          '<b>instanceVariableNames:</b> — поля одной строкой в кавычках;',
          '<b>initialize</b> — стартовые значения, вызывается при new;',
          '<b>геттеры через ^</b>, сеттеры — keyword-методами.'
        ] },
        { t: 'warn', html: 'Имена полей пишутся внутри строки в кавычках, а не в массиве — <code>&#39;width height&#39;</code>, не <code>#(width height)</code>. Класс — с большой буквы CamelCase, а вот селекторы и переменные — с маленькой; перепутаешь регистр — получишь второй класс или ошибку.' },
        { t: 'note', html: 'Выдели выражение в Playground и нажми Inspect it (Ctrl+I) — откроется инспектор объекта: слева поля, справа значения. Это живой отладчик классов: меняешь поле — объект меняется сразу.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни объявление класса: впиши список полей (одной строкой в кавычках), имя поля в initialize, символ возврата в геттере и имя поля в вычислении площади.</p>',
        code: `Object subclass: #Rectangle
    instanceVariableNames: {{0}}
    classVariableNames: ''
    package: 'CodeQuest'.

" инициализация при new "
Rectangle >> initialize
    {{1}} := 10.
    height := 5.

" геттер "
Rectangle >> width
    {{2}} width

" площадь "
Rectangle >> area
    ^ width * {{3}}`,
        blanks: [
          { answer: "'width height'", alt: ["'height width'"] },
          { answer: 'width' },
          { answer: '^' },
          { answer: 'height' }
        ],
        ci: false
      },
      hints: [
        "Поля перечисляются одной строкой в кавычках: 'width height'.",
        'В initialize поля получают стартовые значения: width := 10.',
        'Геттер возвращает значение через ^: Rectangle >> width, тело — ^ width.'
      ],
      solution: ["'width height'", 'width', '^', 'height']
    },

    /* ---------- 9. Словари Dictionary и ассоциации ---------- */
    {
      id: 'smalltalk-9',
      title: 'Словари Dictionary и ассоциации',
      goal: 'Работать со словарём: Dictionary new, запись at:put:, безопасное чтение и обход пар keysAndValuesDo: с блоком из двух параметров',
      xp: 50,
      theory: [
        { t: 'p', html: 'Словарь <code>Dictionary</code> хранит пары «ключ → значение»: ключом может быть любой объект — строка, символ, число. Создание — <code>Dictionary new</code>, добавление — сообщение <code>at:put:</code>, чтение — <code>at:</code>. В этом Smalltalk последователен: даже работа со словарём — это сообщения, а не синтаксис.' },
        { t: 'code', code: `| stock |
stock := Dictionary new.
stock at: 'coffee' put: 12.
stock at: 'tea' put: 30.
Transcript show: (stock at: 'coffee') printString; cr.` },
        { t: 'p', html: 'Повторный <code>at:put:</code> с тем же ключом перезаписывает значение — так обновляют данные. Чтение отсутствующего ключа по умолчанию бросает ошибку KeyNotFound; вариант <code>at:ifAbsent:</code> принимает блок и возвращает его результат, если ключа нет, — безопасное чтение с дефолтом. Размер словаря — сообщение <code>size</code>.' },
        { t: 'h', html: 'Обход пар: keysAndValuesDo:' },
        { t: 'p', html: 'Для перебора словаря используют <code>keysAndValuesDo:</code> — блок получает ДВА параметра: ключ и значение: <code>[ :key :value | ... ]</code>. Сообщения <code>keys</code> и <code>values</code> возвращают только ключи или только значения. Сами пары «ключ → значение» внутри представлены объектами-ассоциациями — их видно в инспекторе словаря.' },
        { t: 'warn', html: 'Порядок обхода Dictionary НЕ гарантирован — не строй вывод по порядку ключей и не используй словарь в задачах «предскажи вывод». Нужен устойчивый порядок — отсортируй ключи: <code>stock keys asSortedCollection do: [ :k | ... ]</code>.' },
        { t: 'note', html: 'Ключи-символы <code>#coffee</code> короче строк и сравниваются быстрее — их часто используют в качестве идентификаторов. А <code>at:ifAbsentPut:</code> лениво создаёт значение при первом обращении — удобно для счётчиков.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери учёт запасов: создай пустой <code>Dictionary</code>, положи минимум две пары через <code>at:put:</code>, обнови одну из них повторной записью. Обойди словарь через <code>keysAndValuesDo:</code> с блоком из двух параметров и печатай пары в Transcript, затем покажи значение одного ключа.</p>',
        starter: `" TODO: создай пустой словарь "
" TODO: положи значения по ключам и обнови одно из них "
" TODO: обойди пары ключ-значение блоком из двух параметров "
" TODO: покажи значение по ключу в Transcript "`,
        rules: [
          { desc: 'Словарь создан: Dictionary new', all: ['Dictionary\\s+new'] },
          { desc: 'Запись по ключу через at:put:', all: ['\\bat:\\s*[^\\n]*put:'] },
          { desc: 'Минимум две записи at:put:', all: ['(?:[\\s\\S]*at:\\s*[^\\n]*put:){2}'] },
          { desc: 'Обход пар keysAndValuesDo: с блоком из двух параметров', all: ['keysAndValuesDo:\\s*\\[\\s*:\\w+\\s*:\\w+\\s*\\|'] },
          { desc: 'Чтение значения по ключу в Transcript, заглушек TODO нет', all: ['\\S'], any: ['Transcript\\s+show:'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        "Создание: stock := Dictionary new. Запись: stock at: 'coffee' put: 12.",
        'Обход: stock keysAndValuesDo: [ :key :value | Transcript show: ...; cr ].',
        "Чтение: Transcript show: (stock at: 'coffee') printString; cr."
      ],
      solution: `| stock |
stock := Dictionary new.

stock at: 'coffee' put: 12.
stock at: 'tea' put: 30.
stock at: 'cocoa' put: 7.
stock at: 'tea' put: 28.   "обновили запас"

stock keysAndValuesDo: [ :key :value |
    Transcript show: key , ' -> ' , value printString; cr ].

Transcript show: (stock at: 'coffee') printString; cr.`
    },

    /* ---------- 10. 🚀 Проект: банк ---------- */
    {
      id: 'smalltalk-10',
      title: '🚀 Проект: банк',
      goal: 'Собрать класс Account с проверками и историей: deposit:/withdraw: с ifTrue:ifFalse:, OrderedCollection для операций и отчёт через collect:',
      xp: 110,
      theory: [
        { t: 'p', html: 'Итоговый проект — банк, выросший из счёта прошлых уровней: к операциям добавляются проверки и память. Счёт не примет лишнее списание, а все операции лягут в историю, из которой соберётся отчёт. Это уже маленькая, но настоящая модель предметной области.' },
        { t: 'h', html: 'Проверка средствами сообщений' },
        { t: 'p', html: 'Списание делается через <code>ifTrue:ifFalse:</code> — сообщение объекту-результату сравнения: <code>anAmount &lt;= balance</code> даёт true или false, и одна из веток-блоков выполняется. В ветке <code>ifTrue:</code> баланс уменьшается, в <code>ifFalse:</code> печатается отказ. Никакого оператора if языка здесь нет — только сообщения и блоки.' },
        { t: 'code', code: `Account >> withdraw: anAmount
    anAmount <= balance
        ifTrue: [ balance := balance - anAmount.
                  history add: anAmount negated ]
        ifFalse: [ Transcript show: 'Недостаточно средств'; cr ]` },
        { t: 'p', html: 'История операций — <code>OrderedCollection new</code> в initialize: упорядоченная коллекция с сообщением <code>add:</code>. Пополнение кладёт сумму, снятие — <code>anAmount negated</code>, то есть отрицательное значение: по истории видно и направление, и величину каждой операции. Отчёт собирается <code>collect:</code> — история превращается в массив строк для печати.' },
        { t: 'list', items: [
          '<b>класс Account</b> с полями balance и history;',
          '<b>initialize</b> — стартовые значения при new;',
          '<b>deposit:/withdraw:</b> — операции, withdraw с ifTrue:ifFalse:;',
          '<b>collect: по истории</b> — отчёт для Transcript.'
        ] },
        { t: 'warn', html: 'Поле history должно быть объявлено в instanceVariableNames и создано в initialize — иначе первый же add: уйдёт в nil и упадёт. Ветка ifFalse: НЕ должна менять баланс: отклонённая операция не оставляет следов в состоянии счёта.' },
        { t: 'note', html: 'Куда развивать: метод transactionsDo: с печатью каждой операции через do:, или подсчёт оборота через <code>inject:into:</code> по истории. Структура класса уже позволяет всё это без изменения состояния.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Банк».</b> Объяви класс <code>Account</code> с полями баланса и истории в <code>instanceVariableNames</code>, метод <code>initialize</code> со стартовыми значениями. Метод <code>deposit:</code> увеличивает баланс; <code>withdraw:</code> списывает ТОЛЬКО если хватает денег — вычитание внутри ветки <code>ifTrue:</code>, иначе <code>ifFalse:</code> с сообщением об отказе. Затем сценарий: <code>new</code>, несколько операций и отчёт — история, преобразованная через <code>collect:</code>, печатается в Transcript.</p>',
        starter: `" TODO: объяви класс Account с полями баланса и истории "
" TODO: initialize со стартовыми значениями "
" TODO: deposit: — пополнение "
" TODO: withdraw: — списание с проверкой средств "
" TODO: сценарий — операции и отчёт по истории "`,
        rules: [
          { desc: 'Класс Account с полями объявлен через subclass:', all: ['subclass:\\s*#Account', "instanceVariableNames:\\s*'[^']+'"] },
          { desc: 'Метод initialize задаёт стартовые значения', all: ['\\w+\\s*>>\\s*initialize'] },
          { desc: 'deposit: увеличивает баланс', all: ['\\w+\\s*>>\\s*deposit:', 'balance\\s*:=\\s*balance\\s*\\+'] },
          { desc: 'withdraw: проверяет средства: вычитание в ifTrue:, отказ в ifFalse:', all: ['\\w+\\s*>>\\s*withdraw:', 'ifTrue:\\s*\\[[^\\]]*balance\\s*:=\\s*balance\\s*-\\s*', '\\bifFalse:'] },
          { desc: 'История преобразуется через collect:', all: ['collect:\\s*\\['] },
          { desc: 'Сценарий: new, печать в Transcript и нет заглушек TODO', all: ['\\bnew\\b'], any: ['Transcript\\s+show:'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        "Каркас: Object subclass: #Account, поля — 'balance history'.",
        'withdraw: — сравнение anAmount <= balance, затем ifTrue: [...] ifFalse: [...].',
        'Отчёт: Transcript show: (acc history collect: [ :t | t printString ]) printString; cr.'
      ],
      solution: `Object subclass: #Account
    instanceVariableNames: 'balance history'
    classVariableNames: ''
    package: 'CodeQuest'.

Account >> initialize
    balance := 0.
    history := OrderedCollection new

Account >> deposit: anAmount
    balance := balance + anAmount.
    history add: anAmount

Account >> withdraw: anAmount
    anAmount <= balance
        ifTrue: [ balance := balance - anAmount.
                  history add: anAmount negated ]
        ifFalse: [ Transcript show: 'Недостаточно средств'; cr ]

Account >> balance
    ^ balance

Account >> history
    ^ history

| acc |
acc := Account new.
acc deposit: 100.
acc deposit: 50.
acc withdraw: 120.
acc withdraw: 500.
Transcript show: 'Баланс: ' , acc balance printString; cr.
Transcript show: 'Операции: ' , (acc history collect: [ :t | t printString ]) printString; cr.`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Playground и Transcript',
      code: `Transcript show: 'Привет!'; cr.
; Ctrl+D — выполнить (Do it)
; Ctrl+P — выполнить и показать результат (Print it)
; Transcript открывается: Tools → Transcript
; .  — конец выражения;  ;  — каскад
"двойные кавычки — это комментарий"`
    },
    {
      title: 'Переменные и типы',
      code: `| name age |
name := 'Аня'.        "строка в одинарных кавычках"
age := 20.            "Integer"
height := 1.75.       "Float"
flag := true.         "маленькими буквами!"
name , ' + ' , 'Кэй'. "конкатенация — запятая"
20 class.             "узнать класс объекта"
20 printString        "объект → строка"`
    },
    {
      title: 'Блоки, условия, циклы',
      code: `[ :x | x * 2 ]                      "блок-функция"
(1 to: 5) do: [ :i | ... ].         "цикл по интервалу"
3 timesRepeat: [ ... ].             "повторить N раз"
n > 5 ifTrue: [ ... ] ifFalse: [ ... ].
(1 to: 5) inject: 0 into: [ :s :e | s + e ].  "→ 15"
; ветки условий — обязательно блоки [ ]`
    },
    {
      title: 'Классы и методы',
      code: `Object subclass: #Dog
    instanceVariableNames: 'name'
    classVariableNames: ''
    package: 'CodeQuest'.

Dog >> speak
    ^ 'Гав!'

Dog >> initialize       "вызывается при new"
    super initialize.

| d |
d := Dog new.`
    },
    {
      title: 'Сообщения: три вида',
      list: [
        'унарные — без аргументов: d speak, acc balance',
        'бинарные — 3 + 4, \'a\' , \'b\'',
        'с ключевыми словами — каждое : добавляет аргумент: acc deposit: 100',
        'приоритет: унарные → бинарные → ключевые',
        'получатель всегда первый: acc deposit: 100',
        'каскад ; — серия сообщений одному объекту'
      ]
    },
    {
      title: 'Коллекции',
      code: `#(10 15 20 25) do: [ :n | ... ].       "перебор"
#(10 15 20 25) collect: [ :n | n * 2 ]. "преобразовать"
#(10 15 20 25) select: [ :n | n >= 20 ]. "отобрать → #(20 25)"
#(10 15 20 25) reject: [ :n | n < 15 ].  "отбросить"
#(10 15 20 25) detect: [ :n | n > 10 ].  "первый → 15"
; Dictionary/Set — порядок обхода НЕ гарантирован`
    },
    {
      title: 'Блоки и коллекции в деле',
      code: `| prices |
prices := #(120 80 150 90).
prices do: [ :p | Transcript show: p printString; cr ].
prices collect: [ :p | p * 2 ].     "новая коллекция"
prices select: [ :p | p >= 120 ].   "фильтр"
prices reject: [ :p | p < 100 ].    "выбросить"
prices detect: [ :p | p > 100 ].    "первый подходящий"
(prices select: [ :p | p >= 100 ]) collect: [ :p | p * 2 ]`
    },
    {
      title: 'Dictionary и банк целиком',
      code: `stock := Dictionary new.
stock at: 'tea' put: 30.          "запись/перезапись"
stock at: 'tea' ifAbsent: [ 0 ].  "безопасное чтение"
stock keysAndValuesDo: [ :k :v | ... ].
stock size.  stock keys.

Account >> withdraw: anAmount
    anAmount <= balance
        ifTrue: [ balance := balance - anAmount ]
        ifFalse: [ Transcript show: 'Отказ'; cr ]`
    }
  ]
};
