'use strict';
/* ============ CodeQuest — курс Solidity ============
   Solidity не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.solidity = {
  id: 'solidity',
  title: 'Solidity',
  emoji: '📜',
  color: '#aa6746',
  lang: 'solidity',
  tagline: 'Solidity: от каркаса до краудфандинга — 10 уровней',
  description: 'Язык смарт-контрактов Ethereum (2014, Gavin Wood): на нём построены DeFi, NFT и DAO. Здесь код — это деньги, а ошибки стоят реальных эфиров. За 10 уровней дойдём от первого контракта до модификаторов и конструктора, маппингов адресов, событий с indexed и проекта «Краудфандинг-контракт».',

  levels: [

    /* ---------- 1. Первый контракт ---------- */
    {
      id: 'solidity-1',
      title: 'Первый контракт',
      goal: 'Собрать каркас смарт-контракта: SPDX-комментарий, pragma, contract и публичную строковую переменную',
      xp: 30,
      theory: [
        { t: 'p', html: 'Solidity — язык смарт-контрактов Ethereum. Его задумал Gavin Wood в 2014 году, а развил и довёл до релиза Кристиан Райтвизнер с командой. Контракт — это программа, которая живёт прямо в блокчейне: у неё собственный адрес, её код нельзя просто так поменять, а каждый вызов стоит денег (газа). На Solidity построены DeFi-протоколы, NFT-маркетплейсы и DAO.' },
        { t: 'h', html: 'Каркас контракта' },
        { t: 'code', code: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Hello {
    string public greeting = "Hello, CodeQuest!";
}` },
        { t: 'p', html: 'Первая строка — лицензионный комментарий SPDX: его ждёт каждый серьёзный компилятор и аудит. <code>pragma solidity ^0.8.0;</code> фиксирует версии компилятора: «0.8 и выше, но ниже 0.9» — знак вставки исключает мажорное обновление. <code>contract Hello { ... }</code> — как class: объединяет переменные состояния и функции. После объявлений — точка с запятой, как в C-подобных языках.' },
        { t: 'p', html: '<code>string public greeting</code> — публичная строка состояния: слово <code>public</code> заставляет компилятор автоматически создать getter, и значение можно прочитать из любого приложения. Комментарии — <code>//</code> до конца строки и блочные <code>/* ... */</code>.' },
        { t: 'list', items: [
          '<b>SPDX-комментарий</b> — лицензия файла, пишется первой строкой;',
          '<b>pragma solidity ^0.8.0;</b> — диапазон версий компилятора;',
          '<b>contract Имя { }</b> — сам контракт;',
          '<b>string public x = "...";</b> — переменная состояния с бесплатным getter.'
        ] },
        { t: 'p', html: 'Писать и проверять удобнее всего в онлайн-IDE Remix: открываешь remix.ide, создаёшь файл, компилируешь кнопкой и деплоишь в тестовую сеть — контракт оживает за секунды. Для сборки в терминале есть компилятор <code>solc</code>. Переменные состояния хранятся в блокчейне вечно — за каждую запись платят газ.' },
        { t: 'warn', html: 'Здесь код = деньги: контракт после деплоя неизменяем, и ошибка становится неоткатываемой. В 2016 году через баг в контракте DAO из него вывели эфиры на десятки миллионов долларов. Поэтому в Solidity строгие типы, явные проверки и привычка перепроверять каждую функцию.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери свой первый контракт: комментарий SPDX с лицензией MIT, <code>pragma</code> с версией 0.8, контракт <code>Hello</code> и публичную строковую переменную со значением <code>"Hello, CodeQuest!"</code>. Не забудь точку с запятой после объявления переменной.</p>',
        starter: `// SPDX-License-Identifier: MIT
// TODO: объяви pragma, контракт Hello и публичную строку`,
        rules: [
          { desc: 'Есть pragma с версией компилятора', all: ['pragma\\s+solidity\\s*[^;\\n]*\\d'] },
          { desc: 'Объявлен контракт (contract Имя { ... })', all: ['\\bcontract\\s+\\w+\\s*\\{'] },
          { desc: 'Есть публичная строковая переменная', any: ['string\\s+public\\s+\\w+', 'public\\s+string\\s+\\w+'] },
          { desc: 'Строке присвоено значение "Hello, CodeQuest!"', all: ['"Hello, CodeQuest!"'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас: // SPDX-License-Identifier: MIT, затем pragma solidity ^0.8.0; затем contract Hello { ... }.',
        'Переменная: string public greeting = "Hello, CodeQuest!"; — внутри контракта.',
        'Не забудь точку с запятой после pragma и после объявления переменной.'
      ],
      solution: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Hello {
    string public greeting = "Hello, CodeQuest!";
}`
    },

    /* ---------- 2. Типы данных ---------- */
    {
      id: 'solidity-2',
      title: 'Типы данных',
      goal: 'Различать uint256, address, bool и mapping — базовые типы состояния контракта',
      xp: 30,
      theory: [
        { t: 'p', html: 'Состояние контракта — это переменные, объявленные прямо внутри <code>contract</code> вне функций. Они живут в хранилище блокчейна: записал — и значение останется навсегда, за каждую запись платишь газом. Отсюда и главные типы Solidity: компактные, фиксированной длины.' },
        { t: 'table', head: ['Тип', 'Хранит', 'Пример'], rows: [
          ['<code>uint256</code>', 'беззнаковое целое 0 … 2^256−1 (uint — псевдоним)', '<code>uint256 total = 100;</code>'],
          ['<code>address</code>', 'адрес кошелька или контракта, 20 байт', '<code>address owner;</code>'],
          ['<code>bool</code>', 'истина/ложь', '<code>bool active = true;</code>'],
          ['<code>string</code>', 'текст переменной длины', '<code>string name = "Аня";</code>'],
          ['<code>mapping(K =&gt; V)</code>', 'словарь «ключ → значение»', '<code>mapping(address =&gt; uint256)</code>']
        ] },
        { t: 'code', code: `contract Bank {
    uint256 public total = 0;      // uint = uint256
    address public owner;
    bool public active = true;
    mapping(address => uint256) public balances;
}` },
        { t: 'p', html: '<code>mapping</code> — словарь: объявляется как <code>mapping(типКлюча =&gt; типЗначения) имя</code>. Чтение и запись — через квадратные скобки: <code>balances[addr] = 500</code>. Любопытная особенность: все возможные ключи «уже существуют» — чтение отсутствующего возвращает ноль, поэтому маппинг не умеет считать размер и не перебирается циклом.' },
        { t: 'p', html: 'Публичные переменные дают бесплатный getter — <code>bank.total()</code> вернёт значение без написания функции. Модификатор <code>private</code> прячет переменную от других контрактов, но помни: всё, что лежит в блокчейне, читаемо на уровне данных — «приватность» здесь только на уровне вызовов.' },
        { t: 'warn', html: 'С версии 0.8 переполнение uint больше не «заворачивает» число: любая арифметика за границами диапазона автоматически откатывает транзакцию. И в Solidity нет дробных чисел — деньги считают в wei, минимальной доле эфира (1 эфир = 10^18 wei), поэтому везде uint256.' },
        { t: 'note', html: 'Есть и знаковый <code>int256</code>, и компактные размеры от <code>uint8</code> до <code>uint128</code> — они экономят газ на хранении, но новичку хватит uint256. Компактность имеет значение: каждая ячейка хранилища стоит реальных денег при деплое.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни контракт банка: подставь типы — total беззнаковое целое на 256 бит, owner — тип адреса, active — логический флаг, а balances — словарь «адрес → сумма». В последнем объявлении впиши имя типа, открывающее конструкцию со стрелкой.</p>',
        code: `contract Bank {
    {{0}} public total = 100;   // беззнаковое целое на 256 бит
    {{1}} public owner = 0xAb5801a7D398351b8bE11C439e05C5B3259aeC9B; // 20-байтный адрес
    {{2}} public active = true; // логический флаг
    {{3}}(address => uint256) public balances; // словарь адрес → сумма
}`,
        blanks: [
          { answer: 'uint256', alt: ['uint'] },
          { answer: 'address' },
          { answer: 'bool' },
          { answer: 'mapping' }
        ],
        ci: false
      },
      hints: [
        'Беззнаковое 256-битное целое — uint256 (короче просто uint, тоже верно).',
        'Адрес кошелька — тип address, флаг — bool.',
        'Словарь начинается словом mapping: mapping(address => uint256).'
      ],
      solution: ['uint256', 'address', 'bool', 'mapping']
    },

    /* ---------- 3. require, view и pure ---------- */
    {
      id: 'solidity-3',
      title: 'require, view и pure',
      goal: 'Ставить require-проверки с сообщениями, различать view и pure — и предсказать поведение функции',
      xp: 35,
      theory: [
        { t: 'p', html: '<code>require(условие, "сообщение")</code> — страж функции. Условие истинно — код идёт дальше; ложно — транзакция <b>откатывается</b> (revert): все изменения состояния отменяются, неизрасходованный газ возвращается, а сообщение уходит пользователю кошелька. Это стандартный способ «впустить нельзя — откажи».' },
        { t: 'code', code: `function withdraw(uint256 amount) public {
    require(amount > 0, "сумма должна быть положительной");
    require(amount <= balance, "недостаточно средств");
    // ... дальше безопасно
}` },
        { t: 'p', html: 'Специальные видимости функций: <code>view</code> — функция <b>только читает</b> состояние блокчейна; <code>pure</code> — не читает и не пишет вовсе, чистое вычисление из аргументов. Вызовы view и pure снаружи (с кошелька, без транзакции) бесплатны — они ничего не меняют.' },
        { t: 'code', code: `uint256 public total = 100;

function getTotal() public view returns (uint256) {
    return total;            // читает состояние — view
}

function square(uint256 x) public pure returns (uint256) {
    return x * x;            // только аргументы — pure
}` },
        { t: 'p', html: 'Строки в параметрах и возвратах помечаются <code>memory</code> — так указывается, где живут данные: <code>storage</code> — в блокчейне навсегда, <code>memory</code> — временно, на время вызова. Для параметров-строк пиши <code>string memory text</code>, для возврата — <code>returns (string memory)</code>.' },
        { t: 'p', html: 'Функция объявляется так: <code>function имя(параметры) видимость [view|pure] returns (тип) { ... }</code>. Возврат — через <code>return</code>. А сам вызов функции, на котором стоит require, либо дойдёт до return и вернёт значение, либо упадёт с сообщением require — третьего не дано.' },
        { t: 'note', html: 'Ручной аналог require — конструкция <code>if (!ok) { revert("причина"); }</code>. Разница в стиле: require — для проверки входных данных и внешних условий, revert — для сложных ветвлений. Сообщение ошибки пиши по-человечески: его увидит пользователь.' },
        { t: 'warn', html: 'Ставь require в начале функции, до любых изменений состояния: откат отменит всё, но зачем тратить газ на бессмысленные записи? И помни — сообщение в кавычках это часть API твоего контракта, по нему пользователи будут разбираться, почему их транзакция не прошла.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Контракт ниже, и функцию <code>double</code> вызывают дважды. В первой строке ответа напиши, что вернёт вызов <code>double(7)</code>. Во второй строке — что произойдёт при вызове <code>double(60)</code>: транзакция откатится с сообщением require, напиши ровно <code>revert: слишком большое число</code>.</p>',
        code: `pragma solidity ^0.8.0;

contract Safe {
    function double(uint256 x) public pure returns (uint256) {
        require(x <= 50, "слишком большое число");
        return x * 2;
    }
}`,
        answer: `14
revert: слишком большое число`
      },
      hints: [
        'double(7): проверка 7 <= 50 проходит — сработает return 7 * 2.',
        'double(60): проверка 60 <= 50 ложна — require откатит транзакцию.',
        'Сообщение ошибки после revert — то, что написано вторым аргументом require.'
      ],
      solution: `14
revert: слишком большое число`
    },

    /* ---------- 4. Функции и события ---------- */
    {
      id: 'solidity-4',
      title: 'Функции и события',
      goal: 'Писать функции с видимостью public и view, возвратом returns, объявлять события event и срабатывать их через emit',
      xp: 40,
      theory: [
        { t: 'p', html: 'Полное объявление функции: <code>function имя(параметры) видимость [view|pure] returns (типы)</code>. Видимость определяет, кто может вызвать: <code>public</code> — все, <code>private</code> — только сам контракт, есть ещё <code>internal</code> (наследники) и <code>external</code> (только извне). Для функций, меняющих состояние, видимость — просто <code>public</code>.' },
        { t: 'code', code: `contract Box {
    uint256 private value = 0;

    function set(uint256 x) public {
        value = x;               // меняет состояние
    }

    function get() public view returns (uint256) {
        return value;            // читает состояние
    }
}` },
        { t: 'p', html: '<b>События</b> — способ контракта «сказать миру»: запись в специальный журнал блокчейна, который внешние приложения и Remix слушают и показывают. Объявление — <code>event Имя(типы параметров)</code>, срабатывание — <code>emit Имя(значения)</code>. События дешевле хранения: они не занимают память состояния.' },
        { t: 'code', code: `contract Greeter {
    event Greet(address who, string text);

    function say(string memory text) public {
        emit Greet(msg.sender, text);
    }
}` },
        { t: 'p', html: 'Слово <code>indexed</code> у параметра события делает его фильтруемым: <code>event Transfer(address indexed from, address indexed to, uint256 amount)</code> — так биржи отслеживают переводы конкретных адресов. Внутри функций доступен глобальный объект <code>msg</code>: <code>msg.sender</code> — кто вызвал, <code>msg.value</code> — сколько эфира приложил к вызову.' },
        { t: 'list', items: [
          '<b>function f(...) public { }</b> — меняет состояние;',
          '<b>public view returns (T)</b> — читает и возвращает;',
          '<b>public pure returns (T)</b> — чистое вычисление;',
          '<b>event + emit</b> — запись в журнал блокчейна.'
        ] },
        { t: 'warn', html: 'У строковых параметров — обязательно <code>memory</code>: <code>function say(string memory text)</code>. Забудешь — компилятор выдаст ошибку и подскажет место. Возврат строки тоже с memory: <code>returns (string memory)</code>. Это самая частая ошибка компиляции у новичков.' },
        { t: 'note', html: 'Возвращать можно несколько значений: <code>returns (uint256, bool)</code> и <code>return (x, true)</code> — вызывающий примет их кортежем. Именованные возвраты <code>returns (uint256 total)</code> позволяют вернуть значение простым присваиванием total = ... без return.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери контракт-журналист: объяви <code>event</code> минимум с одним параметром, публичную функцию, которая что-то сохраняет и срабатывает событие через <code>emit</code>, и публичную <code>view</code>-функцию с <code>returns</code>, возвращающую сохранённое. У строкового параметра не забудь <code>memory</code>.</p>',
        starter: `// TODO: объяви событие, функцию, которая срабатывает его,
// и читающую функцию с возвратом значения`,
        rules: [
          { desc: 'Объявлено событие event', all: ['\\bevent\\s+\\w+'] },
          { desc: 'Событие срабатывается через emit', all: ['\\bemit\\s+\\w+'] },
          { desc: 'Есть view-функция с returns', all: ['\\bview\\b', '\\breturns\\s*\\('] },
          { desc: 'Есть публичная функция (function ... public)', all: ['\\bfunction\\s+\\w+\\s*\\([^)]*\\)\\s*public'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Событие: event Greet(address who, string text); — объявляется вне функций.',
        'Функция с emit: function say(string memory text) public { ... emit Greet(msg.sender, text); }',
        'Читающая функция: function getText() public view returns (string memory) { return text; }'
      ],
      solution: `pragma solidity ^0.8.0;

contract Greeter {
    string private text = "пока пусто";

    event Greet(address who, string text);

    function say(string memory message) public {
        text = message;
        emit Greet(msg.sender, message);
    }

    function getText() public view returns (string memory) {
        return text;
    }
}`
    },

    /* ---------- 5. Идиомы безопасности ---------- */
    {
      id: 'solidity-5',
      title: 'Идиомы безопасности',
      goal: 'Понять msg.sender, modifier и payable — три столпа владения, проверок и оплаты в Solidity',
      xp: 40,
      theory: [
        { t: 'p', html: '<code>msg.sender</code> — адрес того, кто вызвал функцию прямо сейчас. Это краеугольный камень контроля доступа: контракты запоминают владельца и сверяют каждый важный вызов с ним. Стандартная схема — зафиксировать владельца в конструкторе при деплое и проверять потом.' },
        { t: 'code', code: `contract Vault {
    address public owner;

    constructor() {
        owner = msg.sender;   // деплоящий = владелец
    }
}` },
        { t: 'p', html: '<b>modifier</b> — переиспользуемая обёртка над функцией. Объявляется словом <code>modifier</code>, внутри — проверки, а <code>_;</code> — место, куда вставляется тело функции. Список модификаторов пишется после видимости: <code>function secret() public view onlyOwner</code>. Так выглядит канонический «только владелец»:' },
        { t: 'code', code: `modifier onlyOwner() {
    require(msg.sender == owner, "не владелец");
    _;
}

function secret() public view onlyOwner returns (uint256) {
    return 42;   // выполнится только после проверки
}` },
        { t: 'p', html: '<b>payable</b> — пометка функции, разрешающая принимать эфир вместе с вызовом. Сумма перевода лежит в <code>msg.value</code>. Без payable отправка эфира к функции откатится — язык защищает от случайного приёма денег. Это основа всех краудфандингов и депозитов.' },
        { t: 'code', code: `function deposit() public payable {
    balance += msg.value;   // пришедший эфир учтён
}` },
        { t: 'warn', html: 'Порядок в функции — «проверки → изменения состояния → внешние вызовы»: так снижают риск reentrancy-атак, когда внешний контракт при переводе повторно вызывает твою функцию. И никогда не используй <code>tx.origin</code> для проверок вместо <code>msg.sender</code> — классическая фишинговая дыра.' },
        { t: 'note', html: 'Конструктор — функция с именем <code>constructor</code>: выполняется один раз при деплое и больше никогда. Там фиксируют владельца, начальные настройки, адреса внешних контрактов. Изменить после деплоя нельзя — как и весь контракт.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Кто получит результат вызова <code>withdrawAll()</code> в этом контракте?</p><pre>contract Vault {
    address public owner;
    uint256 public total;

    constructor() {
        owner = msg.sender;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "не владелец");
        _;
    }

    function withdrawAll() public view onlyOwner returns (uint256) {
        return total;
    }
}</pre>`,
        options: [
          'Только тот, чей адрес совпадает с owner',
          'Любой пользователь сети',
          'Никто: функция payable',
          'Только сам контракт Vault'
        ],
        correct: 0,
        explain: 'Модификатор onlyOwner выполняется до тела функции: require сверяет msg.sender с owner, и при несовпадении транзакция откатывается. Если совпало — срабатывает _; и выполняется тело. Это канонический паттерн доступа «только владелец».',
        solution: 0
      },
      hints: [
        'Что делает require(msg.sender == owner, ...) до строки _;?',
        'modifier вставляет свою проверку перед каждым вызовом помеченной функции.'
      ],
      solution: 0
    },

    /* ---------- 6. 🚀 Проект: копилка ---------- */
    {
      id: 'solidity-6',
      title: '🚀 Проект: копилка',
      goal: 'Собрать контракт PiggyBank: депозиты через payable, учёт баланса и вывод средств только владельцем',
      xp: 100,
      theory: [
        { t: 'p', html: 'Финальный проект — смарт-контракт копилки: любой может положить эфир, а забрать его может только владелец. Это «hello world» DeFi: депозит, баланс, вывод. Три функции — и вся суть платёжных контрактов перед глазами.' },
        { t: 'h', html: 'Что строим' },
        { t: 'list', items: [
          'переменные состояния: <code>owner</code> (address) и <code>balance</code> (uint256);',
          'конструктор, фиксирующий <code>owner = msg.sender</code>;',
          '<code>deposit() public payable</code> — принимает эфир и увеличивает баланс на <code>msg.value</code>;',
          '<code>withdraw(amount)</code> — проверяет владельца и сумму, уменьшает баланс.'
        ] },
        { t: 'code', code: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract PiggyBank {
    address public owner;
    uint256 public balance;

    constructor() {
        owner = msg.sender;
    }

    function deposit() public payable {
        balance += msg.value;
    }
}` },
        { t: 'p', html: 'В withdraw — двойной страж: сначала владелец (<code>msg.sender == owner</code>), потом сумма (<code>amount &lt;= balance</code>). Каждый require — с человеческим сообщением: это текст, который увидит в кошельке отклонённый пользователь. И только после проверок — <code>balance -= amount</code>.' },
        { t: 'warn', html: 'Убери любую из проверок — и контракт станет дырой: без проверки владельца эфир заберёт кто угодно, без проверки суммы — баланс уйдёт в минус. «Код = деньги» здесь буквальный: каждая строчка withdraw охраняет чужие средства.' },
        { t: 'note', html: 'После зачёта развивай копилку по-взрослому: события <code>event Deposit(address who, uint256 amount)</code> и Withdraw, словарь <code>mapping(address =&gt; uint256)</code> для личных балансов нескольких людей, модификатор onlyOwner из уровня про идиомы. Направление верное: состояние хранится, функции проверяют, события сообщают.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Копилка».</b> Собери контракт PiggyBank: переменные <code>owner</code> (address) и <code>balance</code> (uint256), конструктор с фиксацией владельца через <code>msg.sender</code>. Функция <code>deposit</code> должна быть <code>payable</code> и прибавлять <code>msg.value</code> к балансу. Функция <code>withdraw(amount)</code> — с require-проверками владельца (<code>msg.sender</code>) и суммы, уменьшающая баланс. Не забудь SPDX и pragma.</p>',
        starter: `// SPDX-License-Identifier: MIT
// TODO: объяви контракт-копилку с владельцем, балансом,
// приёмом денег и выводом средств с проверками`,
        rules: [
          { desc: 'Каркас: pragma и контракт объявлены', all: ['pragma\\s+solidity', '\\bcontract\\s+\\w+\\s*\\{'] },
          { desc: 'Есть owner (address) и баланс (uint256)', all: ['address\\s+(public\\s+)?owner', 'uint256\\s+(public\\s+)?balance'] },
          { desc: 'deposit объявлен payable и читает msg.value', all: ['\\bfunction\\s+deposit', '\\bpayable\\b', 'msg\\.value'] },
          { desc: 'withdraw проверяет require-ом владельца msg.sender', all: ['\\bfunction\\s+withdraw', '\\brequire\\s*\\(', 'msg\\.sender'] },
          { desc: 'Баланс растёт при депозите и уменьшается при выводе', all: ['balance\\s*(\\+=|=\\s*balance\\s*\\+)', 'balance\\s*(-=|=\\s*balance\\s*-)'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Состояние: address public owner; uint256 public balance; в конструкторе owner = msg.sender.',
        'Депозит: function deposit() public payable { balance += msg.value; }',
        'Вывод: function withdraw(uint256 amount) public с require(msg.sender == owner, ...) и require(amount <= balance, ...), затем balance -= amount.'
      ],
      solution: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract PiggyBank {
    address public owner;
    uint256 public balance;

    constructor() {
        owner = msg.sender;
    }

    function deposit() public payable {
        balance += msg.value;
    }

    function withdraw(uint256 amount) public {
        require(msg.sender == owner, "только владелец");
        require(amount <= balance, "недостаточно средств");
        balance -= amount;
    }
}`
    },

    /* ---------- 7. Модификаторы и constructor ---------- */
    {
      id: 'solidity-7',
      title: 'Модификаторы и constructor',
      goal: 'Настроить контракт при деплое через constructor с require и защитить функции переиспользуемым модификатором onlyOwner',
      xp: 45,
      theory: [
        { t: 'p', html: 'Конструктор — особая функция с именем <code>constructor</code>: она выполняется ровно один раз, при деплое контракта, и больше никогда. Через параметры конструктора контракт получает настройки при создании — цель сбора, стартовый запас, адрес казначея. Это единственный шанс задать начальное состояние «по-человечески», без отдельных функций-настроек.' },
        { t: 'code', code: `contract Vault {
    address public owner;
    uint256 public total;

    constructor(uint256 initial) {
        require(initial > 0, "начальная сумма должна быть положительной");
        owner = msg.sender;
        total = initial;
    }
}` },
        { t: 'p', html: '<code>require</code> в конструкторе защищает от кривого деплоя: неверные стартовые данные откатят создание контракта целиком, и мусор не попадёт в блокчейн навсегда. Паттерн <code>owner = msg.sender</code> фиксирует владельцем того, кто заплатил газ за деплой. После конструктора менять владельца можно только специальными функциями — если ты их вообще напишешь.' },
        { t: 'h', html: 'modifier: переиспользуемая проверка' },
        { t: 'p', html: 'Модификатор — обёртка над функцией: его код выполняется до и/или после тела. Строка <code>_;</code> — место, куда вставляется тело функции; проверки до <code>_;</code> — входной фильтр, код после — выходной. Модификатор навешивается в сигнатуре: <code>function refill(uint256 amount) public onlyOwner</code> — и одна проверка защищает сколько угодно функций.' },
        { t: 'code', code: `modifier onlyOwner() {
    require(msg.sender == owner, "не владелец");
    _;
}` },
        { t: 'list', items: [
          '<b>constructor</b> — один раз при деплое, параметры-настройки;',
          '<b>require в конструкторе</b> — защита от кривого деплоя;',
          '<b>modifier + _;</b> — переиспользуемый страж;',
          '<b>имя модификатора в сигнатуре</b> — его применение.'
        ] },
        { t: 'warn', html: 'Модификатор без <code>_;</code> закрывает функцию навсегда: тело никогда не выполнится. Иногда так делают сознательно (функция-заглушка на время паузы), но случайный пропуск подчёркивания — классический баг: контракт жив, а ключевая функция мертва.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери хранилище с контролем доступа: контракт, в конструкторе — <code>require</code>-проверка стартового значения и фиксация <code>owner = msg.sender</code>. Объяви модификатор <code>onlyOwner</code> с <code>require</code> и строкой <code>_;</code>, затем публичную функцию, защищённую этим модификатором (имя в сигнатуре).</p>',
        starter: `// SPDX-License-Identifier: MIT
// TODO: контракт с владельцем и конструктором-проверкой
// TODO: модификатор-страж: require и место для тела функции
// TODO: функция, защищённая модификатором`,
        rules: [
          { desc: 'Есть конструктор constructor', all: ['\\bconstructor\\s*\\('] },
          { desc: 'В конструкторе require-проверка', all: ['\\bconstructor\\s*\\([^)]*\\)\\s*\\{[^}]*\\brequire\\s*\\('] },
          { desc: 'Объявлен модификатор onlyOwner', all: ['\\bmodifier\\s+onlyOwner'] },
          { desc: 'В модификаторе есть _; (точка входа тела функции)', all: ['_;'] },
          { desc: 'Функция защищена модификатором (имя в сигнатуре)', all: ['\\bfunction\\s+\\w+\\s*\\([^)]*\\)[^{]*\\bonlyOwner\\b'] },
          { desc: 'Каркас контракта и нет заглушек TODO', all: ['\\S'], any: ['pragma\\s+solidity', '\\bcontract\\s+\\w+\\s*\\{'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Конструктор: constructor(uint256 initial) { require(initial > 0, "..."); owner = msg.sender; }',
        'Модификатор: modifier onlyOwner() { require(msg.sender == owner, "не владелец"); _; }',
        'Применение: function refill(uint256 amount) public onlyOwner { total += amount; }'
      ],
      solution: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Vault {
    address public owner;
    uint256 public total;

    constructor(uint256 initial) {
        require(initial > 0, "начальная сумма должна быть положительной");
        owner = msg.sender;
        total = initial;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "не владелец");
        _;
    }

    function refill(uint256 amount) public onlyOwner {
        total += amount;
    }
}`
    },

    /* ---------- 8. Маппинги и адреса ---------- */
    {
      id: 'solidity-8',
      title: 'Маппинги и адреса',
      goal: 'Вести персональный учёт: mapping(address => uint256) public, запись по msg.sender и view-функция личного баланса',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>mapping</code> — словарь в хранилище контракта: <code>mapping(типКлюча => типЗначения)</code>. Для учёта по кошелькам ключ — <code>address</code>, значение — <code>uint256</code>. Все возможные ключи «существуют» заранее: чтение отсутствующего адреса вернёт ноль, поэтому маппинг не умеет считать размер и не перебирается циклом.' },
        { t: 'code', code: `mapping(address => uint256) public balances;` },
        { t: 'p', html: '<code>msg.sender</code> — адрес того, кто вызвал функцию прямо сейчас: кошелёк пользователя или другой контракт. Комбинация «маппинг + msg.sender» — основа персонального учёта: каждый вклад, токен или голос пишется по адресу вызывающего. Один контракт — миллионы личных записей без единой строки «регистрации».' },
        { t: 'h', html: 'Публичный mapping — бесплатный getter' },
        { t: 'p', html: 'Модификатор <code>public</code> у маппинга создаёт getter с параметром-ключом: <code>balances(0x…)</code> вернёт баланс адреса. Этим пользуются эксплореры, фронтенды и другие контракты — читать состояние можно бесплатно, без транзакции. Писать же может только сам контракт — через свои функции.' },
        { t: 'list', items: [
          '<b>mapping(address => uint256)</b> — словарь адрес → число;',
          '<b>balances[msg.sender] += amount</b> — запись по вызывающему;',
          '<b>delete balances[addr]</b> — обнуление записи;',
          '<b>address(0)</b> — «нулевой адрес», маркер отсутствия владельца.'
        ] },
        { t: 'warn', html: 'Маппинг нельзя обойти циклом и у него нет length — если нужен список адресов, ведите его параллельно отдельным массивом или счётчиком. И помни: ноль у отсутствующего ключа неотличим от честного нулевого баланса — если различие важно, храните ещё и признак существования.' },
        { t: 'note', html: 'Маппинги вкладываются: <code>mapping(address => mapping(address => uint256))</code> — так в стандарте ERC20 хранятся разрешения approve: владелец → spender → сумма. Внешне это выглядит как двухступенчатое чтение: allowances[a][b].' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери реестр вкладов: публичный маппинг <code>mapping(address => uint256)</code> с именем <code>balances</code>. Функция <code>deposit(uint256 amount)</code> с <code>require</code>-проверкой пишет по адресу вызывающего: <code>balances[msg.sender] += amount</code>, и ведёт общий счётчик сумм. Добавь view-функцию, возвращающую личный баланс через <code>returns</code>.</p>',
        starter: `// SPDX-License-Identifier: MIT
// TODO: контракт-реестр: словарь «адрес → сумма» с публичным геттером
// TODO: функция пополнения пишет по адресу вызывающего
// TODO: require-проверка, общий счётчик и view-функция личного баланса`,
        rules: [
          { desc: 'Объявлен mapping (словарь)', all: ['\\bmapping\\s*\\('] },
          { desc: 'mapping(address => uint256) public — публичный getter', all: ['mapping\\s*\\(\\s*address\\s*=>\\s*uint256\\s*\\)\\s*public'] },
          { desc: 'Запись по адресу вызывающего: balances[msg.sender]', all: ['\\w+\\s*\\[\\s*msg\\.sender\\s*\\]'] },
          { desc: 'По msg.sender именно запись (+= или =)', all: ['\\w+\\s*\\[\\s*msg\\.sender\\s*\\]\\s*(\\+=|=[^=])'] },
          { desc: 'Есть require-проверка', all: ['\\brequire\\s*\\('] },
          { desc: 'view-функция, каркас контракта и нет заглушек TODO', all: ['\\S', '\\bview\\b', '\\bcontract\\s+\\w+\\s*\\{'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Словарь: mapping(address => uint256) public balances;',
        'Запись: balances[msg.sender] += amount; — плюс общий счётчик totalDeposited += amount.',
        'Личный баланс: function myBalance() public view returns (uint256) { return balances[msg.sender]; }'
      ],
      solution: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Ledger {
    mapping(address => uint256) public balances;
    uint256 public totalDeposited;

    function deposit(uint256 amount) public {
        require(amount > 0, "сумма должна быть положительной");
        balances[msg.sender] += amount;
        totalDeposited += amount;
    }

    function myBalance() public view returns (uint256) {
        return balances[msg.sender];
    }
}`
    },

    /* ---------- 9. События и emit ---------- */
    {
      id: 'solidity-9',
      title: 'События и emit',
      goal: 'Журналировать операции: события с indexed-параметрами, emit после изменения состояния и фильтрация логов',
      xp: 50,
      theory: [
        { t: 'p', html: 'Событие — запись контракта в специальный журнал блокчейна: дешевле хранения, а приложения и эксплореры слушают его в реальном времени. Объявление — <code>event Имя(параметры)</code>, срабатывание — <code>emit Имя(значения)</code>. Параметр с пометкой <code>indexed</code> попадает в темы лога — по нему потом фильтруют.' },
        { t: 'code', code: `event TicketBought(address indexed buyer, uint256 amount);

function buy(uint256 count) public {
    tickets[msg.sender] += count;
    emit TicketBought(msg.sender, count);
}` },
        { t: 'p', html: 'Конвенция порядка: сначала изменения состояния, потом <code>emit</code> — если require ниже откатит транзакцию, события тоже отменятся: весь лог транзакции откатывается вместе с состоянием. Поэтому событие ставят последним действием функции: оно фиксирует состоявшийся факт. Emit без require ничего не проверяет — проверки остаются на require.' },
        { t: 'h', html: 'indexed и фильтры' },
        { t: 'p', html: 'Проиндексировать можно до трёх параметров события — чаще всего это адреса: <code>address indexed buyer</code>. Фронтенд подписывается на событие и фильтрует по теме: «все покупки этого кошелька», «все переводы в этот контракт». Именно через indexed-события биржи и эксплореры отслеживают движения токенов.' },
        { t: 'list', items: [
          '<b>event Имя(address indexed who, uint256 amount);</b> — объявление;',
          '<b>emit Имя(msg.sender, 5);</b> — срабатывание;',
          '<b>indexed</b> — до 3 параметров в темы для фильтров;',
          '<b>события не занимают хранилище</b> — дешёвый журнал.'
        ] },
        { t: 'warn', html: 'События НЕ читаются из других контрактов — они только для внешнего мира; если логика контракта зависит от истории, храните её в состоянии или маппинге. И emit не проверяет условия: все require — до него.' },
        { t: 'note', html: 'ERC20/ERC721 живут на событиях: Transfer и Approval слушает вся экосистема — от кошельков до аналитики. Открой любой токен в эксплорере — вкладка Events это чистый лог emit-ов.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери контракт-магазин билетов: два события с <code>indexed</code>-адресом и числовым параметром (покупка и возврат), функция покупки, которая меняет состояние и срабатывает событие через <code>emit</code>, и функция возврата со вторым <code>emit</code>. Проверки — через <code>require</code>.</p>',
        starter: `// SPDX-License-Identifier: MIT
// TODO: контракт с журналом: пара событий с индексируемым адресом
// TODO: покупка — меняет состояние и пишет событие
// TODO: возврат — второе событие`,
        rules: [
          { desc: 'Событие объявлено с indexed-параметром', all: ['\\bevent\\s+\\w+\\s*\\([^)]*\\bindexed\\b[^)]*\\)'] },
          { desc: 'Два события: адрес и число в параметрах', all: ['\\bevent\\s+\\w+\\s*\\([^)]*address[^)]*uint', '(?:[\\s\\S]*\\bevent\\s+\\w+\\s*\\(){2}'] },
          { desc: 'Минимум два emit', all: ['(?:[\\s\\S]*\\bemit\\s+\\w+\\s*\\(){2}'] },
          { desc: 'emit внутри public-функции (меняет состояние)', all: ['\\bfunction\\s+[^{]*public[^{]*\\{[^}]*emit\\s+\\w+'] },
          { desc: 'Каркас контракта и нет заглушек TODO', all: ['\\S'], any: ['\\bcontract\\s+\\w+\\s*\\{'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Объявление: event TicketBought(address indexed buyer, uint256 amount);',
        'Покупка: tickets[msg.sender] += count; затем emit TicketBought(msg.sender, count);',
        'Возврат: обнули tickets[msg.sender] и emit Refunded(msg.sender, held).'
      ],
      solution: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract TicketShop {
    event TicketBought(address indexed buyer, uint256 amount);
    event Refunded(address indexed buyer, uint256 amount);

    mapping(address => uint256) public tickets;

    function buy(uint256 count) public {
        require(count > 0, "нужно хотя бы один билет");
        tickets[msg.sender] += count;
        emit TicketBought(msg.sender, count);
    }

    function refund() public {
        uint256 held = tickets[msg.sender];
        require(held > 0, "билетов нет");
        tickets[msg.sender] = 0;
        emit Refunded(msg.sender, held);
    }
}`
    },

    /* ---------- 10. 🚀 Проект: краудфандинг-контракт ---------- */
    {
      id: 'solidity-10',
      title: '🚀 Проект: краудфандинг-контракт',
      goal: 'Собрать контракт сбора средств: маппинг вкладчиков, contribute() payable с require и emit, onlyOwner для вывода и view-отчёт',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — краудфандинг: любой кладёт эфир на общую цель, владелец забирает собранное только после её достижения. В одном контракте сходится весь курс: конструктор с настройкой, маппинг вкладчиков, события, модификатор владельца и view-отчёт. Так устроены настоящие ICO-контракты в упрощённом виде.' },
        { t: 'h', html: 'Составляющие' },
        { t: 'list', items: [
          '<code>owner, goal, raised</code> — владелец, цель, собранное;',
          '<code>mapping(address => uint256) contributions</code> — вклады по адресам;',
          '<code>event Contributed(address indexed backer, uint256 amount)</code> — журнал взносов;',
          '<code>contribute() public payable</code> — взнос с require и emit;',
          '<code>onlyOwner</code> + <code>withdrawFunds()</code> — вывод владельцем после цели.'
        ] },
        { t: 'p', html: 'Функция <code>contribute</code> помечена <code>payable</code>: эфир приходит вместе с вызовом и лежит в <code>msg.value</code>. Проверяем, что взнос ненулевой, записываем адрес в маппинг вкладчиков, увеличиваем общий счётчик и срабатываем событие — по нему строится история сбора. Вклад сам «подписывает» себя адресом отправителя.' },
        { t: 'code', code: `function contribute() public payable {
    require(msg.value > 0, "нужен взнос больше нуля");
    contributions[msg.sender] += msg.value;
    raised += msg.value;
    emit Contributed(msg.sender, msg.value);
}` },
        { t: 'p', html: 'Вывод — <code>withdrawFunds()</code> с модификатором <code>onlyOwner</code>: сначала страж требует, чтобы вызывающий был владельцем, затем <code>require</code> проверяет достижимость цели. Сама функция меняет состояние, но ничего не возвращает — читать собранное для отчётов будет отдельная view-функция. В боевом контракте здесь стоял бы ещё и перевод эфира владельцу через <code>call{value: …}</code> — в проекте оставляем учёт баланса.' },
        { t: 'warn', html: 'Порядок внутри contribute — как учили: require до изменений состояния, emit после. Не забудь про constructor с проверкой цели: краудфандинг с нулевой целью деплоить нельзя — require откатит деплой.' },
        { t: 'note', html: 'Развитие проекта: функция refund() при провале цели по дедлайну (время сравнивается через <code>block.timestamp</code>), лимиты на взнос, событие GoalReached при достижении суммы. Каждое расширение — те же require, mapping и emit в новых комбинациях.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Краудфандинг-контракт».</b> Собери контракт: <code>owner</code> и цель сбора, конструктор с <code>require</code>-проверкой цели и фиксацией владельца через <code>msg.sender</code>. Публичный маппинг вкладчиков <code>mapping(address => uint256)</code> с именем <code>contributions</code>. Событие с <code>indexed</code>-адресом. Функция <code>contribute()</code> — <code>payable</code>, с <code>require</code> по <code>msg.value</code>, записью по адресу вызывающего и <code>emit</code>. Модификатор <code>onlyOwner</code> и функция вывода, защищённая им. И view-функция с <code>returns</code>, возвращающая собранное.</p>',
        starter: `// SPDX-License-Identifier: MIT
// TODO: краудфандинг: владелец, цель и словарь вкладчиков
// TODO: конструктор с проверкой цели
// TODO: взнос payable с require и событием
// TODO: страж владельца и вывод средств
// TODO: view-функция собранного`,
        rules: [
          { desc: 'Каркас: pragma и контракт', all: ['pragma\\s+solidity', '\\bcontract\\s+\\w+\\s*\\{'] },
          { desc: 'Словарь вкладчиков: mapping(address => uint256) public contributions', all: ['mapping\\s*\\(\\s*address\\s*=>\\s*uint256\\s*\\)\\s*public\\s+contributions'] },
          { desc: 'Конструктор фиксирует владельца через msg.sender', all: ['\\bconstructor\\b', 'owner\\s*=\\s*msg\\.sender'] },
          { desc: 'contribute: payable, require по msg.value, запись по адресу', all: ['\\bfunction\\s+contribute\\s*\\(\\s*\\)\\s*public\\s+payable', '\\brequire\\s*\\([^)]*msg\\.value', 'contributions\\s*\\[\\s*msg\\.sender\\s*\\]'] },
          { desc: 'Событие с indexed-адресом срабатывает через emit', all: ['\\bevent\\s+\\w+\\s*\\([^)]*\\bindexed\\b[^)]*\\)', '\\bemit\\s+\\w+\\s*\\('] },
          { desc: 'onlyOwner: модификатор с _; и функция под ним', all: ['\\bmodifier\\s+onlyOwner', '_;', '\\bfunction\\s+\\w+\\s*\\([^)]*\\)[^{]*\\bonlyOwner\\b'] },
          { desc: 'view-функция с returns, заглушек TODO нет', all: ['\\bview\\b', '\\breturns\\s*\\(', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Состояние: address public owner; uint256 public goal; uint256 public raised; mapping(address => uint256) public contributions;',
        'Взнос: function contribute() public payable { require(msg.value > 0, "..."); contributions[msg.sender] += msg.value; raised += msg.value; emit Contributed(msg.sender, msg.value); }',
        'Вывод и отчёт: modifier onlyOwner + function withdrawFunds() public onlyOwner; function raisedTotal() public view returns (uint256).'
      ],
      solution: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Crowdfund {
    address public owner;
    uint256 public goal;
    uint256 public raised;
    mapping(address => uint256) public contributions;

    event Contributed(address indexed backer, uint256 amount);

    constructor(uint256 fundingGoal) {
        require(fundingGoal > 0, "цель должна быть положительной");
        owner = msg.sender;
        goal = fundingGoal;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "не владелец");
        _;
    }

    function contribute() public payable {
        require(msg.value > 0, "нужен взнос больше нуля");
        contributions[msg.sender] += msg.value;
        raised += msg.value;
        emit Contributed(msg.sender, msg.value);
    }

    function withdrawFunds() public onlyOwner {
        require(raised >= goal, "цель ещё не достигнута");
        raised = 0;
    }

    function raisedTotal() public view returns (uint256) {
        return raised;
    }
}`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас контракта',
      code: `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Hello {
    string public greeting = "Привет!";
}
// IDE: remix.ide | компилятор: solc`
    },
    {
      title: 'Типы состояния',
      list: [
        '<code>uint256</code> — беззнаковое целое (uint — псевдоним)',
        '<code>int256</code> — знаковое целое',
        '<code>address</code> — адрес кошелька/контракта, 20 байт',
        '<code>bool</code> — true/false',
        '<code>string</code> — текст (в функциях — string memory)',
        '<code>mapping(K =&gt; V)</code> — словарь; нет ключа → ноль'
      ]
    },
    {
      title: 'require / view / pure',
      code: `require(x > 0, "должно быть положительным");
// ложно → revert: откат изменений, возврат газа

function get() public view returns (uint256) {
    return total;      // читает состояние
}
function square(uint256 x) public pure returns (uint256) {
    return x * x;      // только аргументы
}
// view/pure вызовы снаружи бесплатны`
    },
    {
      title: 'Функции и события',
      code: `function set(uint256 x) public { value = x; }

event Transfer(address indexed from, uint256 amount);
emit Transfer(msg.sender, 100);

function get() public view returns (uint256) {
    return value;
}
// строки: string memory — и в параметрах, и в returns`
    },
    {
      title: 'Владение и оплата',
      code: `constructor() { owner = msg.sender; }

modifier onlyOwner() {
    require(msg.sender == owner, "не владелец");
    _;
}
function secret() public view onlyOwner returns (uint256) { ... }

function deposit() public payable {
    balance += msg.value;   // принятый эфир
}`
    },
    {
      title: 'Частые ошибки',
      list: [
        'забыт string memory у строкового параметра или возврата',
        'tx.origin вместо msg.sender в проверках — дыра',
        'нет require на владельца — любой выведет деньги',
        'точка с запятой после pragma и объявлений переменных',
        'external вызовы в конце: проверки → состояние → вызовы',
        'дробных чисел нет: эфир считают в wei (10^18)'
      ]
    },
    {
      title: 'Конструктор и модификаторы',
      code: `constructor(uint256 goal) {
    require(goal > 0, "цель должна быть положительной");
    owner = msg.sender;     // один раз при деплое
}

modifier onlyOwner() {
    require(msg.sender == owner, "не владелец");
    _;                      // сюда вставится тело функции
}
function withdraw() public onlyOwner { ... }
// модификатор без _; закрывает функцию навсегда`
    },
    {
      title: 'Маппинги и события',
      code: `mapping(address => uint256) public contributions;
contributions[msg.sender] += msg.value;   // запись по адресу
delete contributions[addr];               // обнулить
// публичный mapping → getter с параметром-ключом

event Contributed(address indexed backer, uint256 amount);
emit Contributed(msg.sender, msg.value);
// indexed — до 3 параметров, фильтр по ним в эксплорерах
// порядок: require → изменения состояния → emit`
    }
  ]
};
