'use strict';
/* ============ CodeQuest — курс Visual Basic .NET ============
   VB.NET не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.vb = {
  id: 'vb',
  title: 'Visual Basic .NET',
  emoji: '🪟',
  color: '#945db7',
  lang: 'vb',
  tagline: 'Простой и человечный .NET-язык за 10 уровней',
  description: 'Классика Microsoft (2001): эволюция старого доброго BASIC в современный .NET-язык. Родственник VBA-макросов Excel — канцелярская классика, на которой до сих пор держатся офисные и банковские системы. За 10 уровней — от Sub Main до проекта «Учёт товаров»: классы со свойствами, коллекции с ключами, On Error и Try/Catch.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'vb-1',
      title: 'Первая программа',
      goal: 'Собрать каркас программы на VB.NET: Module, Sub Main, Console.WriteLine и закрывающие End',
      xp: 30,
      theory: [
        { t: 'p', html: 'Visual Basic .NET (VB.NET) — язык Microsoft 2001 года: переосмысление классического BASIC 1964-го под платформу .NET. Если C# — строгий и компактный, то VB — разговорный: вместо символов слова, вместо <code>}</code> — <code>End Sub</code>, вместо <code>&amp;&amp;</code> — <code>And</code>. Он приходится родственником VBA — языку макросов Excel и Access, поэтому его называют канцелярской классикой: на нём десятилетиями писали офисные и банковские системы.' },
        { t: 'h', html: 'Каркас программы' },
        { t: 'code', code: `Module Program
    Sub Main()
        Console.WriteLine("Привет, CodeQuest!")
    End Sub
End Module` },
        { t: 'p', html: '<code>Module Program</code> — контейнер для кода: в модуле функции доступны без создания объекта. <code>Sub Main()</code> — точка входа: выполнение начинается именно с неё (Sub = подпрограмма без результата). <code>Console.WriteLine("...")</code> печатает строку и переводит строку — класс .NET <code>Console</code> доступен и из VB. Каждый блок закрывается своим <code>End</code>: <code>End Sub</code> закрывает Sub, <code>End Module</code> — модуль, а комментарий начинается апострофом <code>&#39;</code> до конца строки. Точек с запятой в VB нет вообще — конец строки и есть конец команды.' },
        { t: 'list', items: [
          '<b>Module ... End Module</b> — контейнер программы;',
          '<b>Sub Main() ... End Sub</b> — точка входа;',
          '<b>Console.WriteLine("текст")</b> — печать строки;',
          '<b>&#39; комментарий</b> — всё после апострофа игнорируется.'
        ] },
        { t: 'p', html: 'Запуск: нужен установленный .NET SDK. В терминале: <code>dotnet new console -lang VB</code> создаёт проект с файлом Program.vb, затем <code>dotnet run</code> компилирует и запускает. В Visual Studio и VS Code с расширением VB всё то же самое делается кнопками — среда сама держит каркас.' },
        { t: 'warn', html: 'VB нечувствителен к регистру: <code>module</code>, <code>MODULE</code> и <code>Module</code> для компилятора одно и то же. Но редактор сам приводит ключевые слова к каноническому виду — пиши как в примерах: Module, Sub, End, Console. Имя <code>Main</code> обязательно: с него стартует программа.' },
        { t: 'note', html: 'Классический VB6 (1998) — другой язык, он не про .NET. VB.NET умеет почти всё, что C#: классы, интерфейсы, LINQ, асинхронность — различие в основном в словах. Освоив каркас, ты получаешь полный доступ к библиотеке классов .NET — той же, что у C#.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери первую программу на VB.NET: модуль <code>Program</code>, внутри — <code>Sub Main</code>, а в нём вывод фразы <code>Привет, CodeQuest!</code> через <code>Console.WriteLine</code>. Не забудь закрыть оба блока своими <code>End</code>.</p>',
        starter: `Module Program
    Sub Main()
        ' TODO: выведи приветствие через печать в консоль
    End Sub
End Module`,
        rules: [
          { desc: 'Есть Module с именем', all: ['\\b[Mm]odule\\s+\\w+'] },
          { desc: 'Есть Sub Main — точка входа', all: ['\\b[Ss]ub\\s+[Mm]ain\\s*\\('] },
          { desc: 'Вывод через Console.WriteLine', all: ['Console\\.WriteLine\\s*\\('] },
          { desc: 'Блоки закрыты: End Sub и End Module', all: ['\\b[Ee]nd\\s+[Ss]ub\\b', '\\b[Ee]nd\\s+[Mm]odule\\b'] },
          { desc: 'Строка в двойных кавычках, нет пометок TODO', all: ['"[^"]+"', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Внутри Sub Main добавь строку: Console.WriteLine("Привет, CodeQuest!")',
        'Каркас уже готов — закрывающие End Sub и End Module на месте.',
        'Каждый Console.WriteLine печатает свою строку — можно добавить и вторую фразу.'
      ],
      solution: `Module Program
    Sub Main()
        Console.WriteLine("Привет, CodeQuest!")
        Console.WriteLine("Это моя первая программа на VB.NET.")
    End Sub
End Module`
    },

    /* ---------- 2. Переменные Dim ---------- */
    {
      id: 'vb-2',
      title: 'Переменные Dim',
      goal: 'Объявлять переменные через Dim ... As и различать типы Integer, Double, String, Boolean',
      xp: 30,
      theory: [
        { t: 'p', html: 'Переменная в VB объявляется формулой <code>Dim имя As Тип = значение</code>. Слово Dim — наследие древнего BASIC (от dimension, «размерность»), но сегодня это просто стандартное объявление. Тип пишется явно после <code>As</code> — VB statically типизирован, и после объявления тип не меняется.' },
        { t: 'code', code: `Module Program
    Sub Main()
        Dim name As String = "Аня"
        Dim age As Integer = 25
        Dim pi As Double = 3.14
        Dim alive As Boolean = True
        Console.WriteLine(name & " " & age)
    End Sub
End Module` },
        { t: 'table', head: ['Тип', 'Хранит', 'Пример'], rows: [
          ['<code>Integer</code>', 'целое 32 бита (он же Int32)', '<code>25</code>'],
          ['<code>Double</code>', 'дробное 64 бита', '<code>3.14</code>'],
          ['<code>String</code>', 'текст в двойных кавычках', '<code>"Аня"</code>'],
          ['<code>Boolean</code>', 'истина/ложь: True и False', '<code>True</code>']
        ] },
        { t: 'p', html: 'Склейка строк — амперсанд <code>&amp;</code>: <code>name &amp; " " &amp; age</code> соединит имя, пробел и возраст, автоматически превратив число в текст. Это надёжнее плюса: <code>+</code> для строк тоже работает, но с числами он складывает, и легко получить сюрприз. <code>&amp;</code> всегда конкатенация.' },
        { t: 'p', html: 'В новых проектах включено выведение типов: <code>Dim n = 42</code> даст Integer без слова As. Но канонический VB-стиль — с явным типом: читается как документация. Логические значения пишутся с большой буквы — <code>True</code> и <code>False</code> (хотя компилятор и тут нестрог к регистру).' },
        { t: 'warn', html: 'Одинарная кавычка в VB — начало комментария, поэтому «строки в одинарных кавычках» здесь не существует в принципе. Строка — только в двойных кавычках. И не забывай слово <code>Dim</code>: <code>name As String = "Аня"</code> без него не скомпилируется.' },
        { t: 'note', html: 'За Integer стоит .NET-тип Int32, за Double — System.Double; есть ещё Long (64 бита) и Decimal — 128-битный тип для денег, где важна точность копеек. Составные операторы тоже на месте: <code>age += 1</code>, <code>total -= 5</code>.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни карточку пользователя: подставь типы — имя строковое, возраст целое, пи дробное, флаг логический, — а для значения флага впиши логическую истину с большой буквы, как принято в VB.</p>',
        code: `Module Program
    Sub Main()
        Dim name As {{0}} = "Аня"
        Dim age As {{1}} = 25
        Dim pi As {{2}} = 3.14
        Dim alive As {{3}} = {{4}}
        Console.WriteLine(name & " " & age)
    End Sub
End Module`,
        blanks: [
          { answer: 'String' },
          { answer: 'Integer' },
          { answer: 'Double' },
          { answer: 'Boolean' },
          { answer: 'True', alt: ['true'] }
        ],
        ci: false
      },
      hints: [
        'Текст — String, целое — Integer, дробное — Double.',
        'Логический тип — Boolean, а его истина — True с большой буквы.',
        'Не забудь: после Dim идёт имя, потом As, потом тип.'
      ],
      solution: ['String', 'Integer', 'Double', 'Boolean', 'True']
    },

    /* ---------- 3. Условия и циклы ---------- */
    {
      id: 'vb-3',
      title: 'Условия и циклы',
      goal: 'Предсказать вывод программы с For i As Integer ... Next и ветвлением If / ElseIf / Else',
      xp: 35,
      theory: [
        { t: 'p', html: 'Ветвление VB — самое «разговорное» из всех языков: <code>If условие Then</code> открывает блок, продолжения — <code>ElseIf</code> (слитно!), <code>Else</code>, закрывает <code>End If</code>. Тело — строки между ними, никаких скобок вокруг условия.' },
        { t: 'code', code: `Dim n As Integer = 12
If n > 10 Then
    Console.WriteLine("большое")
ElseIf n > 5 Then
    Console.WriteLine("среднее")
Else
    Console.WriteLine("маленькое")
End If` },
        { t: 'p', html: 'Цикл со счётчиком: <code>For i As Integer = 1 To 10 ... Next</code> — переменная <code>i</code> объявляется прямо в заголовке и пробегает от 1 до 10 включительно. Шаг задаётся словом Step: <code>For i As Integer = 0 To 10 Step 2</code>. Счёт назад — <code>For i As Integer = 10 To 1 Step -1</code>. Закрывает цикл слово <code>Next</code>.' },
        { t: 'code', code: `Dim total As Integer = 0
For i As Integer = 1 To 10
    total += i
Next` },
        { t: 'p', html: 'Сравнения привычные: <code>=</code> равно, <code>&lt;&gt;</code> не равно (да, именно так), <code>&lt;</code>, <code>&gt;</code>, <code>&lt;=</code>, <code>&gt;=</code>. Логика — словами: <code>And</code>, <code>Or</code>, <code>Not</code>. Второй цикл VB — <code>While условие ... End While</code>, крутится, пока условие истинно.' },
        { t: 'p', html: 'Накопители объявляют через Dim с начальным значением: <code>Dim total As Integer = 0</code> — и дальше <code>total += i</code> на каждом шаге. При выводе строка склеивается с числом амперсандом: <code>Console.WriteLine("total = " &amp; total)</code> — пробел внутри кавычек ты ставишь сам.' },
        { t: 'warn', html: 'Не перепутай закрывающие слова: If закрывается <code>End If</code>, For — <code>Next</code>, While — <code>End While</code>. Границы To включаются обе: <code>1 To 10</code> — это десять шагов. Код задания не запускается в приложении — цикл крути в голове, шаг за шагом.' },
        { t: 'note', html: 'Есть и <code>Do While ... Loop</code> — цикл с проверкой в начале или в конце (Do ... Loop While). Для счётных задач каноничен For: сразу видно границы и шаг, а компилятор следит, чтобы счётчик не убежал.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай код и напиши, что он выведет в консоль — по одной строке на каждый вывод, в порядке появления.</p>',
        code: `Module Program
    Sub Main()
        Dim total As Integer = 0
        For i As Integer = 1 To 10
            total += i
        Next

        Dim n As Integer = 7
        If n > 10 Then
            Console.WriteLine("n большое")
        ElseIf n > 5 Then
            Console.WriteLine("n среднее")
        Else
            Console.WriteLine("n маленькое")
        End If

        Console.WriteLine("total = " & total)
    End Sub
End Module`,
        answer: `n среднее
total = 55`
      },
      hints: [
        'For копит 1 + 2 + ... + 10 — пройди цикл руками, шаг за шагом.',
        'Затем читай If сверху вниз: 7 больше 10? Нет. Больше 5? Да.',
        'Амперсанд склеивает строку и число: "total = " & 55.'
      ],
      solution: `n среднее
total = 55`
    },

    /* ---------- 4. Function и Sub ---------- */
    {
      id: 'vb-4',
      title: 'Function и Sub',
      goal: 'Объявлять Function с типом результата и Return, Sub-процедуры — и вызывать их из Main',
      xp: 40,
      theory: [
        { t: 'p', html: 'Функция с результатом объявляется так: <code>Function имя(параметры) As Тип ... End Function</code>. Параметры пишутся как <code>имя As Тип</code> через запятую. Возврат значения — через <code>Return выражение</code>: он и возвращает, и завершает функцию.' },
        { t: 'code', code: `Module Program
    Function Twice(x As Integer) As Integer
        Return x * 2
    End Function

    Sub Main()
        Console.WriteLine(Twice(21))   ' 42
    End Sub
End Module` },
        { t: 'p', html: 'Процедура без результата — <code>Sub</code>: <code>Sub Greet(name As String) ... End Sub</code>. Она делает работу и не возвращает ничего. Вызов — просто имя и аргументы: <code>Greet("Аня")</code>; старый стиль с <code>Call Greet("Аня")</code> тоже работает, но давно не обязателен.' },
        { t: 'code', code: `Sub Greet(name As String)
    Console.WriteLine("Привет, " & name & "!")
End Sub` },
        { t: 'p', html: 'Параметры по умолчанию передаются по значению (ByVal) — функция получает копию. Явно можно попросить ссылку: <code>ByRef</code>. Необязательные параметры — <code>Optional x As Integer = 0</code>: вызывающий может их пропустить. Это делает VB особенно удобным для больших библиотечных функций.' },
        { t: 'p', html: 'Старый VB-стиль позволял вернуть значение присваиванием имени функции: <code>Twice = x * 2</code> — последняя строка без Return. Работает и сегодня, но современный канон — Return: он очевиднее и может стоять в середине логики, а не только в конце.' },
        { t: 'warn', html: 'Тип результата <code>As Тип</code> у Function обязателен — забудешь, компилятор подчеркнёт объявление. И следи за парностью: каждая Function закрывается <code>End Function</code>, каждый Sub — <code>End Sub</code>. Перепутал — каскад ошибок по всему файлу.' },
        { t: 'note', html: 'Функции объявляются внутри Module — тогда их можно вызывать из Main без создания объектов, как в примере. Когда дорастёшь до классов, там появятся методы — та же синтаксическая форма, только внутри Class.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви функцию <code>Twice</code> (принимает <code>x As Integer</code>, возвращает <code>As Integer</code>, внутри — <code>Return x * 2</code>) и процедуру <code>Greet</code> (принимает строковый параметр и печатает приветствие через Console.WriteLine). Затем в <code>Main</code> вызови обе: Twice с числом, Greet со строкой.</p>',
        starter: `Module Program
    ' TODO: объяви функцию удвоения и процедуру приветствия

    Sub Main()
        ' вызови обе подпрограммы здесь
    End Sub
End Module`,
        rules: [
          { desc: 'Функция Twice объявлена с типом результата As Integer', all: ['\\b[Ff]unction\\s+Twice\\s*\\(', '\\b[Aa]s\\s+Integer\\b'] },
          { desc: 'Внутри функции есть Return со значением', all: ['\\b[Rr]eturn\\s+\\S'] },
          { desc: 'Процедура Greet принимает строковый параметр', all: ['\\b[Ss]ub\\s+Greet\\s*\\(', '\\b[Aa]s\\s+[Ss]tring\\b'] },
          { desc: 'Обе вызываются: Twice(число) и Greet("строка")', all: ['Twice\\s*\\(\\s*\\d', 'Greet\\s*\\(\\s*"'] },
          { desc: 'Закрывающие End Function / End Sub на месте, нет TODO', all: ['\\b[Ee]nd\\s+[Ff]unction\\b', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Функция: Function Twice(x As Integer) As Integer ... Return x * 2 ... End Function.',
        'Процедура: Sub Greet(name As String) ... Console.WriteLine("Привет, " & name & "!") ... End Sub.',
        'Вызовы в Main: Console.WriteLine(Twice(21)) и Greet("Аня").'
      ],
      solution: `Module Program
    Function Twice(x As Integer) As Integer
        Return x * 2
    End Function

    Sub Greet(name As String)
        Console.WriteLine("Привет, " & name & "!")
    End Sub

    Sub Main()
        Console.WriteLine(Twice(21))
        Greet("Аня")
    End Sub
End Module`
    },

    /* ---------- 5. Идиомы VB ---------- */
    {
      id: 'vb-5',
      title: 'Идиомы VB',
      goal: 'Освоить List(Of T) со скобочной индексацией, конкатенацию & и строковую интерполяцию $',
      xp: 40,
      theory: [
        { t: 'p', html: 'Главный список VB — <code>List(Of T)</code> из библиотеки .NET: динамический массив, который растёт сам. Объявление через <code>New</code>: <code>Dim names As New List(Of String)</code>. Добавление — <code>names.Add("Аня")</code>, количество — <code>names.Count</code>. Слово <code>Of</code> — VB-версия дженериков: List(Of Integer), List(Of Employee) и так далее.' },
        { t: 'code', code: `Dim names As New List(Of String)
names.Add("Аня")
names.Add("Борис")
Console.WriteLine(names.Count)   ' 2
Console.WriteLine(names(0))      ' Аня` },
        { t: 'p', html: 'Обрати внимание на индексацию: элементы берутся <b>круглыми скобками</b> — <code>names(0)</code>, а не names[0], как в C#. Индексация с нуля: первый элемент — 0, последний — <code>names(names.Count - 1)</code>. Скобки — это свойство Item по умолчанию, VB просто прячет его за короткой записью.' },
        { t: 'p', html: 'Склейка строк — амперсанд <code>&amp;</code>: <code>"итого: " &amp; sum</code>. Числа превращаются в текст автоматически. А с версии VB-14 появилась интерполяция: строка с долларом <code>$"Привет, {name}!"</code> — выражения в фигурных скобках вычисляются и вставляются прямо в текст.' },
        { t: 'code', code: `Dim name As String = "Аня"
Dim age As Integer = 25
Dim msg As String = $"{name}({age})"   ' Аня(25)
Console.WriteLine(name & ": " & age)   ' то же без $` },
        { t: 'p', html: 'Перебор списка — <code>For Each x In collection ... Next</code>: на каждом шаге x — очередной элемент, без индексов и счётчиков. Методы списка: <code>Add</code>, <code>Remove</code> (по значению), <code>RemoveAt</code> (по индексу), <code>Contains</code> (проверка наличия). Всё это — методы .NET-класса List, они одинаковы во всех .NET-языках.' },
        { t: 'warn', html: 'Обращение <code>names(5)</code> к списку из двух элементов выбросит исключение ArgumentOutOfRangeException — программа упадёт во время выполнения. Перед индексом проверяй <code>names.Count</code>. И не путай <code>Count</code> (сколько элементов) с Capacity (сколько зарезервировано памяти).' },
        { t: 'note', html: 'Родственник списка — словарь <code>Dictionary(Of String, Integer)</code>: пары «ключ → значение» с доступом по ключу в тех же круглых скобках. Для канцелярских задач — реестры, справочники, журналы — связка List + Dictionary закрывает девять задач из десяти.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет этот код?</p><pre>Dim names As New List(Of String)
names.Add("Аня")
names.Add("Борис")
Console.WriteLine(names.Count &amp; " — " &amp; names(0))</pre>`,
        options: [
          '2 — Аня',
          '2 — Борис',
          '1 — Аня',
          'Ошибка: индекс вне диапазона'
        ],
        correct: 0,
        explain: 'Два вызова Add дают Count = 2. Индексация с нуля: names(0) — это «Аня». Амперсанд склеивает всё в одну строку: 2 — Аня.',
        solution: 0
      },
      hints: [
        'Сколько раз вызвали Add — такой и Count.',
        'Индексы в VB начинаются с нуля: names(0) — первый элемент.'
      ],
      solution: 0
    },

    /* ---------- 6. 🚀 Проект: учёт сотрудников ---------- */
    {
      id: 'vb-6',
      title: '🚀 Проект: учёт сотрудников',
      goal: 'Собрать класс Employee, список List(Of Employee) и функцию подсчёта фонда зарплаты',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальная практика — канцелярская классика в лучшем смысле: учёт сотрудников. Соберём всё курса: класс с полями из уровня про Function и Sub, список объектов List(Of T) из уровня про идиомы, цикл For Each и функцию подсчёта. Такой каркас — основа реальных офисных систем, которые десятилетиями писали на VB.' },
        { t: 'h', html: 'Что строим' },
        { t: 'list', items: [
          'класс <code>Employee</code> с полями <code>Name As String</code> и <code>Salary As Integer</code>;',
          'список <code>Dim staff As New List(Of Employee)</code> с 2–3 сотрудниками;',
          'создание через инициализатор: <code>New Employee With {.Name = ..., .Salary = ...}</code>;',
          'функция <code>TotalPay(people As List(Of Employee)) As Integer</code> — фонд зарплаты;',
          'перебор списка <code>For Each ... Next</code> с выводом каждого сотрудника.'
        ] },
        { t: 'code', code: `Module Program
    Class Employee
        Public Name As String
        Public Salary As Integer
    End Class

    Sub Main()
        Dim staff As New List(Of Employee)
        staff.Add(New Employee With {.Name = "Аня", .Salary = 80000})
    End Sub
End Module` },
        { t: 'p', html: 'Класс объявляется внутри модуля: <code>Class Employee ... End Class</code>. Поля помечены <code>Public</code> — без этого они были бы приватными по умолчанию, и снаружи к ним не достучаться. Инициализатор <code>With {.Поле = значение}</code> создаёт объект и сразу заполняет поля — компактнее, чем присваивать каждое отдельно.' },
        { t: 'p', html: 'Функция подсчёта принимает список целиком: <code>Function TotalPay(people As List(Of Employee)) As Integer</code>. Внутри — знакомый аккумулятор: <code>Dim total As Integer = 0</code>, цикл <code>For Each e As Employee In people</code> с <code>total += e.Salary</code>, и в конце <code>Return total</code>. Обращение к полям — через точку: <code>e.Name</code>, <code>e.Salary</code>.' },
        { t: 'warn', html: 'Не перепутай: <code>.Name</code> с точкой — поле объекта, просто <code>Name</code> без точки не существует вне класса. И помни про типы: зарплата — Integer, поэтому <code>TotalPay</code> возвращает Integer. Поля без Public — приватные, самая тихая ошибка новичка в VB.' },
        { t: 'note', html: 'После зачёта развивай проект: добавь метод <code>Info() As String</code> внутри класса Employee, найди самого дорогого сотрудника сравнением в цикле, посчитай среднюю зарплату делением фонда на Count. Структура «класс + список + функция» масштабируется до настоящей зарплатной ведомости без изменения скелета.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Учёт сотрудников».</b> Объяви класс <code>Employee</code> с полями <code>Name As String</code> и <code>Salary As Integer</code> (помети их Public). Создай список сотрудников через <code>List(Of Employee)</code> и добавь 2–3 записи через <code>New Employee With {...}</code>. Напиши функцию <code>TotalPay</code>, принимающую <code>List(Of Employee)</code> и возвращающую <code>As Integer</code> сумму зарплат (цикл For Each + Return). В Main выведи каждого сотрудника и вызови TotalPay, напечатав фонд зарплаты.</p>',
        starter: `Module Program
    ' TODO: объяви класс сотрудника с двумя полями
    ' и функцию подсчёта фонда зарплаты

    Sub Main()
        ' создай список сотрудников и выведи фонд зарплаты
    End Sub
End Module`,
        rules: [
          { desc: 'Класс объявлен: Class ... End Class', all: ['\\b[Cc]lass\\s+[A-Z]\\w*', '\\b[Ee]nd\\s+[Cc]lass\\b'] },
          { desc: 'Поля Name (String) и Salary (Integer) объявлены', all: ['[Nn]ame\\s+[Aa]s\\s+[Ss]tring', '[Ss]alary\\s+[Aa]s\\s+[Ii]nteger'] },
          { desc: 'Функция TotalPay с As Integer и Return', all: ['\\b[Ff]unction\\s+TotalPay[^\\r\\n]*\\b[Aa]s\\s+Integer\\b', '\\b[Rr]eturn\\s+\\S'] },
          { desc: 'Список List(Of ...) объявлен и создаётся через New', all: ['\\b[Aa]s\\s+New\\s+List\\s*\\(\\s*[Oo]f\\s+\\w+\\s*\\)'] },
          { desc: 'Перебор через For Each ... Next', all: ['\\b[Ff]or\\s+[Ee]ach\\b', '\\b[Nn]ext\\b'] },
          { desc: 'TotalPay вызывается, вывод через Console, нет TODO', all: ['TotalPay\\s*\\(', 'Console\\.WriteLine', '\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Класс: Class Employee ... Public Name As String ... Public Salary As Integer ... End Class.',
        'Список: Dim staff As New List(Of Employee), затем staff.Add(New Employee With {.Name = "Аня", .Salary = 80000}).',
        'Функция: Function TotalPay(people As List(Of Employee)) As Integer с For Each ... total += e.Salary ... Return total, а в Main — вывод Console.WriteLine("Фонд: " & TotalPay(staff)).'
      ],
      solution: `Module Program
    Class Employee
        Public Name As String
        Public Salary As Integer
    End Class

    Function TotalPay(people As List(Of Employee)) As Integer
        Dim total As Integer = 0
        For Each e As Employee In people
            total += e.Salary
        Next
        Return total
    End Function

    Sub Main()
        Dim staff As New List(Of Employee)
        staff.Add(New Employee With {.Name = "Аня", .Salary = 80000})
        staff.Add(New Employee With {.Name = "Борис", .Salary = 65000})
        staff.Add(New Employee With {.Name = "Вера", .Salary = 72000})

        For Each e As Employee In staff
            Console.WriteLine(e.Name & " — " & e.Salary)
        Next
        Console.WriteLine("Фонд зарплаты: " & TotalPay(staff))
    End Sub
End Module`
    },

    /* ---------- 7. Классы: Class … End Class, свойства Property ---------- */
    {
      id: 'vb-7',
      title: 'Классы: Class … End Class, свойства Property',
      goal: 'Спрятать данные класса: Private поле, Property с Get/Set и конструктор Sub New',
      xp: 50,
      theory: [
        { t: 'p', html: 'На проекте про сотрудников поля класса были открыты: Public Name, Public Salary — так проще для начала. В настоящем коде данные прячут: поле объявляют <code>Private</code>, а наружу выставляют свойство <code>Property</code> — прослойку между внешним кодом и данными. Класс с приватными полями и свойствами — это инкапсуляция, первый столп ООП.' },
        { t: 'code', code: `Class Account
    Private balance As Integer

    Public Property Balance As Integer
        Get
            Return balance
        End Get
        Set(value As Integer)
            balance = value
        End Set
    End Property
End Class` },
        { t: 'h', html: 'Как работает Property' },
        { t: 'p', html: 'Чтение <code>acc.Balance</code> вызывает блок <code>Get</code> — он и возвращает значение. Присваивание <code>acc.Balance = 100</code> вызывает блок <code>Set</code>, а приходящее значение лежит в параметре <code>value</code>. Внутри Get и Set можно делать что угодно: проверять данные, считать вычисляемые свойства, логировать обращения.' },
        { t: 'h', html: 'Конструктор Sub New' },
        { t: 'p', html: 'Начальное состояние классу задаёт конструктор — обычный <code>Sub New</code> внутри класса. Он вызывается автоматически при создании: <code>Dim acc As New Account(100)</code> передаст 100 параметру конструктора. Конструкторов может быть несколько — с разными наборами параметров.' },
        { t: 'warn', html: 'К приватному полю снаружи не достучаться: <code>acc.balance</code> не скомпилируется — только через свойство. Свойство без блока Get нельзя читать, без Set — нельзя менять: так делают свойства «только для чтения». И не путай: имя свойства и имя поля должны различаться.' },
        { t: 'note', html: 'Свойство только для чтения — это Property, где есть один Get: например, класс возвращает вычисленный итог, но менять его снаружи запрещено. В новом коде открытые поля почти не используют: Property стоит пару лишних строк, зато защищает данные.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери класс <code>Account</code>: приватное поле для баланса (<code>Private … As Integer</code>), конструктор <code>Sub New</code> с начальным значением и свойство <code>Property</code> с блоками <code>Get</code> и <code>Set</code>. В <code>Main</code> создай счёт через <code>New</code>, измени баланс через свойство и выведи его.</p>',
        starter: `Module Program
    ' TODO: класс счёта со скрытым полем и свойством
    ' 1. Объяви Class Account: приватное поле для баланса,
    '    конструктор Sub New и Property с Get и Set.
    ' 2. В Main создай счёт через New, пополни через свойство
    '    и выведи баланс.

    Sub Main()
    End Sub
End Module`,
        rules: [
          { desc: 'Класс объявлен: Class ... End Class', all: ['\\b[Cc]lass\\s+\\w+', '\\b[Ee]nd\\s+[Cc]lass\\b'] },
          { desc: 'Есть приватное поле: Private ... As ...', all: ['\\b[Pp]rivate\\s+\\w+\\s+[Aa]s\\s+\\w+'] },
          { desc: 'Свойство Property с Get и Set закрыто End Property', all: ['\\b[Pp]roperty\\s+\\w+\\s+[Aa]s\\s+\\w+', '\\b[Gg]et\\b', '\\b[Ss]et\\s*\\(', '\\b[Ee]nd\\s+[Pp]roperty\\b'] },
          { desc: 'Конструктор Sub New объявлен и закрыт', all: ['\\b[Ss]ub\\s+[Nn]ew\\s*\\(', '\\b[Ee]nd\\s+[Ss]ub\\b'] },
          { desc: 'Объект создан через New, свойство записывается', all: ['\\b[Nn]ew\\s+\\w+\\s*\\(', '\\.\\w+\\s*='] },
          { desc: 'Вывод через Console, заглушек TODO нет', any: ['Console\\.'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Поле: Private balance As Integer. Конструктор: Sub New(start As Integer) ... End Sub.',
        'Свойство: Public Property Balance As Integer с блоками Get ... End Get и Set(value As Integer) ... End Set, закрыто End Property.',
        'В Main: Dim acc As New Account(100), затем acc.Balance = acc.Balance + 50 и Console.WriteLine.'
      ],
      solution: `Module Program
    Class Account
        Private balance As Integer

        Sub New(start As Integer)
            balance = start
        End Sub

        Public Property Balance As Integer
            Get
                Return balance
            End Get
            Set(value As Integer)
                balance = value
            End Set
        End Property
    End Class

    Sub Main()
        Dim acc As New Account(100)
        acc.Balance = acc.Balance + 50
        Console.WriteLine("Баланс: " & acc.Balance)
    End Sub
End Module`
    },

    /* ---------- 8. Коллекции и For Each ---------- */
    {
      id: 'vb-8',
      title: 'Коллекции и For Each',
      goal: 'Использовать нетипизированную Collection со строковыми ключами и перебирать её через For Each',
      xp: 45,
      theory: [
        { t: 'p', html: 'Кроме типизированного List(Of T), в VB живёт старинная классика — <code>Collection</code>: нетипизированная коллекция из первых версий языка и VBA. Она хранит что угодно вперемешку, а её фишка — строковые <b>ключи</b>: каждый элемент можно положить с именем и доставать не по номеру, а по смыслу. Для справочников вроде «код → название» она до сих пор удобна.' },
        { t: 'code', code: `Dim stock As New Collection
stock.Add(5, "гайка")
stock.Add(12, "винт")

Console.WriteLine(stock("винт"))   ' 12
Console.WriteLine(stock.Count)     ' 2` },
        { t: 'h', html: 'Индексация с единицы' },
        { t: 'p', html: 'У Collection индексация начинается <b>с единицы</b>, а не с нуля — наследие старого BASIC, которое помнит весь офисный мир. <code>stock(1)</code> вернёт первый добавленный элемент, а <code>stock(0)</code> выбросит исключение. Главное отличие от List(Of T), где всё по-современному с нуля.' },
        { t: 'h', html: 'For Each по коллекции' },
        { t: 'p', html: 'Перебирается Collection тем же циклом <code>For Each … In … Next</code> — он работает с любой коллекцией, умеющей отдавать элементы. Элемент приходит как <code>Object</code>: типизированной Collection не бывает, поэтому компилятор не проверяет реальный тип — аккуратнее с приведениями. Методы на месте: <code>Add</code> (значение и необязательный ключ), <code>Remove</code> по ключу или индексу, <code>Count</code>.' },
        { t: 'warn', html: 'Дубликат ключа — ошибка: два <code>Add</code> с одним и тем же строковым ключом выбросят ArgumentException при выполнении. И не путай: у List(Of T) индексы с нуля, у Collection — с единицы; при переносе кода это стреляет чаще всего.' },
        { t: 'note', html: 'Для нового кода по умолчанию бери List(Of T): он типизирован и быстрее. Collection выручает, когда ключи-строки удобнее индексов, или когда чинишь унаследованный офисный код — таких систем ещё десятилетия.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери мини-склад на <code>Collection</code>: создай коллекцию, добавь 2–3 позиции методом <code>Add</code> со строковыми ключами, перебери её циклом <code>For Each … In … Next</code> с печатью каждой позиции и выведи количество через <code>Count</code>.</p>',
        starter: `Module Program
    Sub Main()
        ' TODO: склад на Collection с ключами
        ' 1. Заведи коллекцию и добавь 2-3 позиции: значение
        '    плюс строковый ключ у каждой.
        ' 2. Перебери склад циклом For Each и напечатай позиции.
        ' 3. Выведи количество позиций.
    End Sub
End Module`,
        rules: [
          { desc: 'Коллекция создана: Dim ... As New Collection', all: ['\\b[Aa]s\\s+[Nn]ew\\s+[Cc]ollection\\b'] },
          { desc: 'Метод Add вызван минимум дважды', all: ['\\.Add\\s*\\([^)]*\\)[\\s\\S]*\\.Add\\s*\\('] },
          { desc: 'Элементы добавлены со строковыми ключами', all: ['\\.Add\\s*\\([^)]*,\\s*"'] },
          { desc: 'Перебор через For Each ... In ... Next', all: ['\\b[Ff]or\\s+[Ee]ach\\b', '\\b[Ii]n\\s+\\w+', '\\b[Nn]ext\\b'] },
          { desc: 'Вывод через Console с Count, заглушек TODO нет', all: ['Console\\.WriteLine', '\\.Count\\b'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Коллекция: Dim stock As New Collection.',
        'С ключом: stock.Add(5, "гайка") — вторым аргументом строковый ключ.',
        'Перебор: For Each item As Object In stock ... Console.WriteLine(item) ... Next.'
      ],
      solution: `Module Program
    Sub Main()
        Dim stock As New Collection
        stock.Add(5, "гайка")
        stock.Add(12, "винт")
        stock.Add(3, "шуруп")

        For Each item As Object In stock
            Console.WriteLine("На складе: " & item)
        Next

        Console.WriteLine("Позиций: " & stock.Count)
        Console.WriteLine("Винтов: " & stock("винт"))
    End Sub
End Module`
    },

    /* ---------- 9. Обработка ошибок On Error и Try-стиль ---------- */
    {
      id: 'vb-9',
      title: 'Обработка ошибок On Error и Try-стиль',
      goal: 'Различать On Error GoTo и On Error Resume Next — и знать современную альтернативу Try/Catch',
      xp: 50,
      theory: [
        { t: 'p', html: 'В VB два поколения обработки ошибок, и в реальном коде встречаются оба. Старое поколение — семейство <code>On Error</code>: <code>On Error GoTo метка</code> при ошибке прыгает на обработчик, <code>On Error Resume Next</code> пропускает строку с ошибкой и продолжает. Новое — <code>Try … Catch … Finally</code>, общий для .NET механизм исключений.' },
        { t: 'h', html: 'On Error GoTo' },
        { t: 'code', code: `On Error GoTo Oops
Console.WriteLine("старт")
Dim n As Integer = CInt("abc")   ' исключение!
Console.WriteLine("не дойдём")
Exit Sub
Oops:
Console.WriteLine("поймали ошибку")` },
        { t: 'p', html: 'Как только строка с ошибкой выполняется, управление немедленно уходит на метку <code>Oops:</code> — строки после неё не трогаются. <code>Exit Sub</code> перед меткой обязателен: без него обработчик выполнялся бы и в штатном случае. Сведения об ошибке лежат в объекте <code>Err</code>: <code>Err.Number</code> и <code>Err.Description</code>.' },
        { t: 'p', html: '<code>Resume Next</code> — режим «ошибки не страшны»: строка, вызвавшая ошибку, пропускается, выполнение идёт со следующей. Присваивание при этом не происходит: переменная остаётся с нулём или прежним значением. Режим выключается <code>On Error GoTo 0</code> — дальше ошибки снова падают как обычно.' },
        { t: 'code', code: `On Error Resume Next
Dim b As Integer = CInt("abc")   ' ошибка «проглочена»
Console.WriteLine(b)             ' 0
On Error GoTo 0                  ' обычный режим` },
        { t: 'h', html: 'Try / Catch / Finally' },
        { t: 'p', html: 'Современный способ — блок <code>Try</code>: опасный код внутри, обработка в <code>Catch ex As Exception</code>, уборка в <code>Finally</code> (выполняется всегда). Он работает с исключениями .NET и не требует меток и Exit. В новом коде пиши Try/Catch, а On Error встретишь в унаследованных офисных макросах.' },
        { t: 'warn', html: 'Resume Next без проверки <code>Err.Number</code> — способ потерять баг: ошибка пройдёт незаметно, и программа продолжит с мусорными данными. А забытый <code>Exit Sub</code> перед меткой-обработчиком заставит обработчик выполняться после каждой успешной ветки.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет эта программа?</p><pre>Module Program
    Sub Main()
        On Error GoTo Oops
        Console.WriteLine("старт")
        Dim n As Integer = CInt("abc")
        Console.WriteLine("считаю дальше")
        Exit Sub
Oops:
        Console.WriteLine("поймали ошибку")
    End Sub
End Module</pre>`,
        options: [
          'старт, затем считаю дальше, затем поймали ошибку',
          'старт, затем поймали ошибку',
          'старт, затем считаю дальше',
          'только поймали ошибку'
        ],
        correct: 1,
        explain: 'CInt("abc") бросает исключение, и On Error GoTo немедленно прыгает на метку Oops — строка «считаю дальше» пропускается. Exit Sub перед меткой завершает Main в штатном случае, чтобы обработчик не выполнялся зря. А вот с On Error Resume Next программа напечатала бы и «считаю дальше»: строка с ошибкой просто пропускается, и n остался бы нулём.',
        solution: 1
      },
      hints: [
        'On Error GoTo переносит выполнение на метку сразу же, как только ошибка случилась.',
        'Exit Sub стоит ПЕРЕД меткой — он завершает Main в удачном сценарии.',
        'При Resume Next строка с ошибкой просто пропускается — сравни с GoTo.'
      ],
      solution: 1
    },

    /* ---------- 10. 🚀 Проект: учёт товаров ---------- */
    {
      id: 'vb-10',
      title: '🚀 Проект: учёт товаров',
      goal: 'Собрать учёт товаров: класс Product, коллекция с ключами, функции AddProduct и Total с отчётом',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — учёт товаров на складе: класс <code>Product</code> с именем и ценой, коллекция с ключами по названию, функция добавления и функция подсчёта. Это скелет настоящей складской программы: замени товары на детали, а склад на заказы — каркас останется тем же. Заодно соберём весь курс: классы, коллекции, функции и цикл For Each.' },
        { t: 'h', html: 'Класс и коллекция' },
        { t: 'code', code: `Class Product
    Public Name As String
    Public Price As Integer
End Class

Dim stock As New Collection` },
        { t: 'p', html: 'Коллекция хранит объекты, а ключом служит название товара: <code>stock.Add(prod, prod.Name)</code>. Достать товар по имени можно как <code>stock("Молоко")</code>, а перебрать всё — циклом <code>For Each p As Product In stock</code>. Классы в .NET — ссылочные типы: коллекция хранит не копии, а ссылки на те же объекты.' },
        { t: 'p', html: 'Функция добавления принимает коллекцию, имя и цену: создаёт <code>New Product</code>, заполняет поля, кладёт в коллекцию с ключом и возвращает созданный объект. Коллекцию возвращать не нужно — она ссылочный тип, изменения видны вызывающему коду. Функция подсчёта пробегает коллекцию в For Each, копит сумму цен и возвращает её.' },
        { t: 'code', code: `Function Total(items As Collection) As Integer
    Dim sum As Integer = 0
    For Each p As Product In items
        sum += p.Price
    Next
    Return sum
End Function` },
        { t: 'p', html: 'Отчёт печатается прямо в Main: сначала каждая позиция в цикле, затем итоговая строка с суммой. В настольном приложении итог показали бы через <code>MsgBox</code>, в консольном — через <code>Console.WriteLine</code>: суть отчёта не меняется. Разделив данные (класс), хранение (коллекция) и логику (функции), получаешь код, который легко читать и расширять.' },
        { t: 'warn', html: 'Два товара с одинаковым именем — это два <code>Add</code> с одним ключом: коллекция бросит ArgumentException. Поэтому ключом бери уникальное поле — артикул или код, а не название. И не забудь тип в For Each: <code>As Product</code> даёт доступ к полям без лишних преобразований.' },
        { t: 'note', html: 'Развить проект можно так: Property вместо открытых полей из уровня про классы, поиск самого дорогого товара сравнением в цикле, средняя цена делением суммы на Count. А ещё — обработка ввода через Try/Catch, чтобы некорректная цена не роняла программу.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Учёт товаров».</b> Объяви класс <code>Product</code> с полями <code>Name As String</code> и <code>Price As Integer</code>. Напиши функцию <code>AddProduct</code>: она принимает коллекцию, имя и цену, создаёт товар, добавляет его в коллекцию с ключом-именем и возвращает созданный объект. Напиши функцию <code>Total</code>, суммирующую цены через <code>For Each</code>. В <code>Main</code> создай коллекцию, наполни её 2–3 товарами и выведи каждую позицию и итоговую сумму через Console.WriteLine.</p>',
        starter: `Module Program
    ' TODO: учёт товаров: класс, коллекция с ключами, итог
    ' 1. Объяви Class Product: имя (String) и цена (Integer).
    ' 2. Функция добавления: создаёт товар, кладёт в коллекцию
    '    с ключом-именем и возвращает созданный объект.
    ' 3. Функция подсчёта: суммирует цены в цикле For Each.
    ' 4. В Main наполни склад и выведи позиции и итог.
    Sub Main()
    End Sub
End Module`,
        rules: [
          { desc: 'Класс Product объявлен и закрыт', all: ['\\b[Cc]lass\\s+Product\\b', '\\b[Ee]nd\\s+[Cc]lass\\b'] },
          { desc: 'Поля Name (String) и Price (Integer) объявлены', all: ['[Nn]ame\\s+[Aa]s\\s+[Ss]tring', '[Pp]rice\\s+[Aa]s\\s+[Ii]nteger'] },
          { desc: 'Коллекция создана через New Collection', all: ['\\b[Aa]s\\s+[Nn]ew\\s+[Cc]ollection\\b'] },
          { desc: 'AddProduct — Function, добавляющая товар с ключом', all: ['\\b[Ff]unction\\s+AddProduct[^\\r\\n]*\\b[Aa]s\\s+\\w+', '\\.Add\\s*\\([^)]*,\\s*\\w+'] },
          { desc: 'Total — Function As Integer с For Each и Return', all: ['\\b[Ff]unction\\s+Total[^\\r\\n]*\\b[Aa]s\\s+Integer\\b', '\\b[Ff]or\\s+[Ee]ach\\b', '\\b[Rr]eturn\\s+\\S'] },
          { desc: 'Отчёт через Console.WriteLine, заглушек TODO нет', all: ['Console\\.WriteLine'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Класс: Class Product ... Public Name As String ... Public Price As Integer ... End Class.',
        'Добавление: Function AddProduct(items As Collection, name As String, price As Integer) As Product — внутри New Product, заполнение полей, items.Add(p, name), Return p.',
        'Подсчёт: Function Total(items As Collection) As Integer с For Each p As Product In items ... sum += p.Price ... Return sum.'
      ],
      solution: `Module Program
    Class Product
        Public Name As String
        Public Price As Integer
    End Class

    Function AddProduct(items As Collection, name As String, price As Integer) As Product
        Dim p As New Product
        p.Name = name
        p.Price = price
        items.Add(p, name)
        Return p
    End Function

    Function Total(items As Collection) As Integer
        Dim sum As Integer = 0
        For Each p As Product In items
            sum += p.Price
        Next
        Return sum
    End Function

    Sub Main()
        Dim stock As New Collection
        AddProduct(stock, "Молоко", 89)
        AddProduct(stock, "Хлеб", 45)
        AddProduct(stock, "Сыр", 520)

        For Each p As Product In stock
            Console.WriteLine(p.Name & " — " & p.Price & " руб.")
        Next

        Console.WriteLine("Итого: " & Total(stock) & " руб.")
    End Sub
End Module`
    }
  ],

  /* ---------- Шпаргалки ---------- */
  cheats: [
    {
      title: 'Каркас программы',
      code: `Module Program
    Sub Main()
        Console.WriteLine("Привет!")
    End Sub
End Module
' комментарий — апостроф
' запуск: dotnet new console -lang VB → dotnet run`
    },
    {
      title: 'Переменные и типы',
      list: [
        '<code>Dim имя As Тип = значение</code> — каноническое объявление',
        '<code>Integer</code> — целое 32 бита; <code>Double</code> — дробное',
        '<code>String</code> — текст в двойных кавычках',
        '<code>Boolean</code> — True / False',
        '<code>Long</code> — 64 бита; <code>Decimal</code> — деньги без ошибок округления',
        'выведение типов: Dim n = 42 → Integer'
      ]
    },
    {
      title: 'Условия и циклы',
      code: `If n > 10 Then
    Console.WriteLine("большое")
ElseIf n > 5 Then
    Console.WriteLine("среднее")
Else
    Console.WriteLine("маленькое")
End If

For i As Integer = 1 To 10   ' обе границы включены
    total += i
Next                          ' шаг: Step 2 / Step -1

While count > 0
    count -= 1
End While
' операторы: =  <>  <  >  <=  >=  And  Or  Not`
    },
    {
      title: 'Function и Sub',
      code: `Function Twice(x As Integer) As Integer
    Return x * 2
End Function

Sub Greet(name As String)
    Console.WriteLine("Привет, " & name & "!")
End Sub

Console.WriteLine(Twice(21))
Greet("Аня")
' Optional x As Integer = 0 — необязательный параметр`
    },
    {
      title: 'List(Of T) и строки',
      code: `Dim names As New List(Of String)
names.Add("Аня")          ' добавить
names.Count               ' количество
names(0)                  ' первый — круглые скобки!
names(names.Count - 1)    ' последний
names.Contains("Аня")     ' есть ли такой
For Each n As String In names
    Console.WriteLine(n)
Next
Dim msg As String = $"Привет, {names(0)}!"  ' интерполяция
Dim s As String = "итого: " & 42            ' & склеивает`
    },
    {
      title: 'Частые ошибки',
      list: [
        'забыт Dim перед объявлением переменной',
        'End If / Next / End Sub перепутаны местами',
        'names[0] — неверно: индексация только names(0)',
        'поля класса без Public — приватные по умолчанию',
        'True и False принято с большой буквы',
        'одинарная кавычка — это комментарий, не строка',
        'If закрывается End If, а не End'
      ]
    },
    {
      title: 'Классы: Property и конструктор',
      code: `Class Account
    Private balance As Integer

    Sub New(start As Integer)   ' конструктор
        balance = start
    End Sub

    Public Property Balance As Integer
        Get
            Return balance
        End Get
        Set(value As Integer)
            balance = value
        End Set
    End Property
End Class

Dim acc As New Account(100)
acc.Balance += 50    ' сработал Set
' Private поле снаружи недоступно — только через Property`
    },
    {
      title: 'Collection и обработка ошибок',
      code: `Dim stock As New Collection
stock.Add(5, "гайка")    ' значение + строковый ключ
stock("гайка")           ' чтение по ключу
stock(1)                 ' по индексу — С ЕДИНИЦЫ!
stock.Count              ' количество
stock.Remove("гайка")    ' удалить по ключу

On Error GoTo Oops       ' прыжок на обработчик Oops:
On Error Resume Next     ' пропустить строку с ошибкой
On Error GoTo 0          ' выключить перехват
' Err.Number / Err.Description — что случилось

Try
    Dim n As Integer = CInt("abc")
Catch ex As Exception
    Console.WriteLine(ex.Message)
Finally
    Console.WriteLine("готово")
End Try`
    }
  ]
};
