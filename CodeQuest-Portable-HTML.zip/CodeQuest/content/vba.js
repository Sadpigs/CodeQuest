'use strict';
/* ============ CodeQuest — курс VBA (Excel) ============ */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.vba = {
  id: 'vba',
  title: 'VBA',
  emoji: '📊',
  color: '#217346',
  lang: 'vba',
  tagline: 'Автоматизация Excel и Office: 10 уровней',
  description: 'Язык макросов Microsoft Office: миллионы офисных сотрудников ежедневно экономят часы с его помощью. За 10 уровней: процедуры Sub и Function, переменные и типы, диапазоны Range, циклы по ячейкам, условия, массивы, UserForm-мышление и финальный проект-отчёт.',

  levels: [

    {
      id: 'vba-1',
      title: 'Первый макрос Sub',
      goal: 'Написать процедуру Sub и вывести сообщение',
      xp: 30,
      theory: [
        { t: 'p', html: 'VBA-код живёт в модулях редактора VBA (Alt+F11 из Excel). Единица кода — <b>процедура</b>: <code>Sub Имя() … End Sub</code>. Запуск — кнопкой F5 в редакторе или привязкой к кнопке на листе. Вывод — <code>MsgBox</code> (окно с сообщением) или запись в ячейку.' },
        { t: 'code', code: `Sub Приветствие()
    MsgBox "Привет, мир!"
End Sub` },
        { t: 'p', html: 'Каждый макрос начинается с Sub и заканчивается End Sub — VBA вербозный, скобки заменяются ключевыми словами. Комментарии начинаются с апострофа <code>’</code>. Регистр не важен, редактор сам выправит написание имён.' },
        { t: 'code', code: `' Это мой первый макрос
Sub Демо()
    MsgBox "Шаг 1"
    MsgBox "Шаг 2"
End Sub` },
        { t: 'note', html: 'Имена процедур могут быть и русскими — VBA это разрешает. Но в командах лучше придерживаться английского: MsgBox, Cells, Range — так код понимают коллеги во всём мире.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши макрос <code>Hello</code>, который показывает сообщение "Отчёт готов". Не забудь End Sub.</p>',
        starter: `Sub Hello()
    ' выведи сообщение
    TODO
End Sub`,
        rules: [
          { desc: 'Заглушка убрана', all: ['\\S'], none: ['TODO'] },
          { desc: 'Процедура Sub Hello объявлена', all: ['Sub\\s+Hello\\s*\\(\\s*\\)'] },
          { desc: 'Есть End Sub', all: ['End\\s+Sub'] },
          { desc: 'MsgBox с текстом отчёта', all: ['MsgBox\\s+"Отчёт готов"'] }
        ],
        note: 'Внутри Sub: MsgBox "текст"'
      },
      hints: [
        'MsgBox — команда вывода окна с сообщением.',
        'Текст — в двойных кавычках.'
      ],
      solution: `Sub Hello()
    MsgBox "Отчёт готов"
End Sub`
    },

    {
      id: 'vba-2',
      title: 'Переменные и типы',
      goal: 'Объявлять переменные с типами Dim и понимать Variant',
      xp: 35,
      theory: [
        { t: 'p', html: 'Переменные объявляются <code>Dim имя As Тип</code>. Главные типы: <code>Long</code> — целые, <code>Double</code> — дробные, <code>String</code> — текст, <code>Boolean</code> — истина/ложь, <code>Date</code> — даты, <code>Variant</code> — «что угодно» (тип по умолчанию).' },
        { t: 'code', code: `Sub Переменные()
    Dim count As Long
    Dim price As Double
    Dim product As String

    count = 12
    price = 249.9
    product = "Кофе"

    MsgBox product & ": " & count * price
End Sub` },
        { t: 'p', html: 'Склейка строк — оператор <code>&</code> (амперсанд), не плюс: плюс для строк тоже работает, но & безопаснее с числами — он автоматически превращает их в текст. Присваивание — просто знак <code>=</code>, объявлять до использования — правило хорошего тона (включи <code>Option Explicit</code> в начале модуля — и VBA будет требовать объявления).' },
        { t: 'list', items: [
          '<b>Long</b> — целые числа от −2 до 2 млрд;',
          '<b>Double</b> — дробные (цены, проценты);',
          '<b>String</b> — текст любой длины;',
          '<b>Variant</b> — любой тип; медленнее, но прощает всё.'
        ] },
        { t: 'warn', html: 'Без Option Explicit опечатка создаёт новую Variant-переменную молча: <code>tota1 = 5</code> вместо <code>total = 5</code> не вызовет ошибки, а просто сделает неверный расчёт. Option Explicit — первый шаг профессионального VBA.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь типы и оператор склейки: число товаров и имя.</p>',
        code: `Sub Демо()
    Dim qty {{0}} Long
    Dim name {{1}} String
    qty = 5
    name = "Ящики"
    MsgBox name {{2}} ": " & qty
End Sub`,
        blanks: [
          { answer: 'As' },
          { answer: 'As' },
          { answer: '&' }
        ],
        ci: false
      },
      hints: [
        'Объявление: Dim имя As Тип.',
        'Склейка строк и чисел — амперсанд.'
      ],
      solution: ['As', 'As', '&']
    },

    {
      id: 'vba-3',
      title: 'Range и Cells',
      goal: 'Читать и писать значения ячеек — сердце Excel-автоматизации',
      xp: 40,
      theory: [
        { t: 'p', html: 'Объект <code>Range</code> — доступ к ячейкам: <code>Range("A1")</code> — одна ячейка, <code>Range("A1:C3")</code> — блок. Чтение: <code>x = Range("B2").Value</code>. Запись: <code>Range("B2").Value = 42</code>. Альтернатива — <code>Cells(строка, столбец)</code>: <code>Cells(2, 3)</code> это C2 — удобно в циклах.' },
        { t: 'code', code: `Sub Заполнение()
    Range("A1").Value = "Товар"
    Range("B1").Value = 100

    Dim x As Double
    x = Range("B1").Value
    Range("C1").Value = x * 2
End Sub` },
        { t: 'p', html: 'Полезные свойства Range: <code>.Value</code> — значение, <code>.Address</code> — адрес, <code>.Rows.Count</code> — число строк диапазона, <code>.Font.Bold = True</code> — жирный шрифт, <code>.Interior.Color</code> — заливка. Всё, что видно в интерфейсе Excel, доступно из VBA.' },
        { t: 'code', code: `Sub Стиль()
    With Range("A1:B1")
        .Font.Bold = True
        .Interior.Color = RGB(220, 235, 255)
    End With
End Sub` },
        { t: 'note', html: 'Конструкция <code>With объект … End With</code> позволяет не повторять имя объекта в каждой строке — стандартный приём работы с Range.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Запиши в A1 число 50, а в B1 — удвоенное значение A1, прочитав его в переменную v.</p>',
        starter: `Sub Двойной()
    Dim v As Double
    TODO
End Sub`,
        rules: [
          { desc: 'Заглушка убрана', all: ['\\S'], none: ['TODO'] },
          { desc: 'Запись 50 в A1', all: ['Range\\("A1"\\)\\.Value\\s*=\\s*50'] },
          { desc: 'Чтение A1 в переменную', all: ['v\\s*=\\s*Range\\("A1"\\)\\.Value'] },
          { desc: 'Запись удвоенного в B1', all: ['Range\\("B1"\\)\\.Value\\s*=\\s*v\\s*\\*\\s*2'] }
        ],
        note: 'Порядок: записать, прочитать, умножить, записать.'
      },
      hints: [
        'Запись: Range("A1").Value = 50.',
        'Чтение наоборот: v = Range("A1").Value.'
      ],
      solution: `Sub Двойной()
    Dim v As Double
    Range("A1").Value = 50
    v = Range("A1").Value
    Range("B1").Value = v * 2
End Sub`
    },

    {
      id: 'vba-4',
      title: 'If и Select Case',
      goal: 'Ветвления: If/ElseIf и выбор через Select Case',
      xp: 40,
      theory: [
        { t: 'p', html: 'Ветвление — <code>If условие Then … ElseIf … Else … End If</code>. Операции сравнения: =, &lt;&gt;, &lt;, &gt;, &lt;=, &gt;=; логические — <code>And</code>, <code>Or</code>, <code>Not</code>. Многострочный If закрывается End If.' },
        { t: 'code', code: `Sub Оценка()
    Dim s As Long: s = Range("A1").Value

    If s >= 90 Then
        MsgBox "отлично"
    ElseIf s >= 70 Then
        MsgBox "хорошо"
    Else
        MsgBox "учись"
    End If
End Sub` },
        { t: 'p', html: 'Для выбора одного из многих значений есть <code>Select Case</code> — читается легче лестницы ElseIf:' },
        { t: 'code', code: `Select Case s
    Case Is >= 90: MsgBox "отлично"
    Case 70 To 89: MsgBox "хорошо"
    Case Else:     MsgBox "учись"
End Select` },
        { t: 'note', html: 'Двоеточие позволяет писать несколько операторов в одной строке (Case Is >= 90: MsgBox …). Диапазоны в Case — через To, сравнения — через Is.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Ячейка A1 содержит 75. Что покажет MsgBox?</p>',
        code: `Dim s As Long
s = Range("A1").Value
If s >= 90 Then
    MsgBox "A"
ElseIf s >= 70 Then
    MsgBox "B"
Else
    MsgBox "C"
End If`,
        options: [
          `A`,
          `B`,
          `C`,
          `ничего`
        ],
        correct: 1,
        explain: '75 не проходит первое условие (>=90), но проходит второе (>=70) — результат "B". ElseIf проверяется только когда предыдущие не сработали.'
      },
      hints: [
        'Ветви проверяются сверху вниз.',
        'Первое подошедшее условие завершает проверку.'
      ],
      solution: `B`
    },

    {
      id: 'vba-5',
      title: 'Циклы For и For Each',
      goal: 'Обходить диапазоны и коллекции циклами',
      xp: 45,
      theory: [
        { t: 'p', html: '<code>For i = 1 To N … Next i</code> — счётный цикл; шаг задаётся Step. <code>For Each x In коллекция … Next x</code> — обход коллекций: ячеек, листов, файлов. В Excel автоматизации 80% циклов — For Each по Range.' },
        { t: 'code', code: `Sub СуммаСтолбца()
    Dim i As Long, total As Double
    total = 0
    For i = 2 To 11
        total = total + Cells(i, 1).Value
    Next i
    MsgBox total
End Sub` },
        { t: 'code', code: `Sub ПокраситьЧётные()
    Dim c As Range
    For Each c In Range("A1:A10")
        If c.Value Mod 2 = 0 Then
            c.Interior.Color = vbYellow
        End If
    Next c
End Sub` },
        { t: 'warn', html: 'Для обхода тысяч ячеек цикл по Range медленный. Профессиональный приём — считать диапазон в массив одним движением: <code>arr = Range("A1:A10000").Value</code>, обработать массив, записать обратно. Разница во времени — в сотни раз.' },
        { t: 'note', html: 'Оператор <code>Mod</code> — остаток от деления: чётность проверяется как Value Mod 2 = 0. Выход из цикла досрочно — Exit For.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Собери цикл, суммирующий десять ячеек столбца A.</p>',
        code: `Sub Сумма()
    Dim i As Long, total As Double
    total = 0
    {{0}} i = 2 {{1}} 11
        total = total + {{2}}(i, 1).Value
    Next i
    MsgBox total
End Sub`,
        blanks: [
          { answer: 'For' },
          { answer: 'To' },
          { answer: 'Cells' }
        ],
        ci: false
      },
      hints: [
        'Счётный цикл: For i = 2 To 11.',
        'Обращение по координатам — Cells(строка, столбец).'
      ],
      solution: ['For', 'To', 'Cells']
    },

    {
      id: 'vba-6',
      title: 'While и Do',
      goal: 'Циклы с условием: Do While и Do Until',
      xp: 45,
      theory: [
        { t: 'p', html: 'Когда число повторений неизвестно заранее, используют <code>Do While условие … Loop</code> (пока верно) или <code>Do Until условie … Loop</code> (пока не станет верным). Условие проверяется перед каждой итерацией; вариант <code>Do … Loop While</code> проверяет после — тело исполнится хотя бы раз.' },
        { t: 'code', code: `Sub НайтиПустую()
    Dim r As Long: r = 1
    Do While Cells(r, 1).Value <> ""
        r = r + 1
    Loop
    MsgBox "Первая пустая строка: " & r
End Sub` },
        { t: 'p', html: 'Этот паттерн «иди вниз, пока данные» — классика обработки листов без заранее известной высоты таблицы. Важно, чтобы внутри цикла условие когда-нибудь изменилось, иначе цикл станет бесконечным (спасение — Ctrl+Break).' },
        { t: 'warn', html: 'Самая частая ошибка — забыть изменять переменную условия: <code>Do While r &lt; 10</code> без <code>r = r + 1</code> крутится вечно. Всегда проверяй, что шаг цикла приближает выход.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Сколько раз выполнится тело цикла? Напиши одно число.</p>',
        code: `Dim n As Long: n = 5
Dim k As Long: k = 0
Do While n > 0
    n = n - 2
    k = k + 1
Loop
MsgBox k`,
        solution: `3`,
        ci: false
      },
      hints: [
        'Проследи n: 5 → 3 → 1 → −1.',
        'Условие n > 0 истинно трижды.'
      ],
      solution: `3`
    },

    {
      id: 'vba-7',
      title: 'Функции Function',
      goal: 'Писать пользовательские функции, доступные в ячейках листа',
      xp: 50,
      theory: [
        { t: 'p', html: '<code>Function Имя(параметры) As Тип … End Function</code> возвращает значение через присваивание имени: <code>Имя = результат</code>. Секретная суперсила: такие функции появляются в Excel как пользовательские — их можно вводить в ячейки: <code>=Налог(A2)</code>.' },
        { t: 'code', code: `Function Налог(ByVal сумма As Double) As Double
    If сумма > 10000 Then
        Налог = сумма * 0.2
    Else
        Налог = сумма * 0.13
    End If
End Function

' В ячейке:  =Налог(B5)` },
        { t: 'p', html: 'Ключевое слово <code>ByVal</code> значит «передать копию значения» (по умолчанию VBA передаёт ByRef — ссылку на оригинал, и функция может изменить переменную вызывающего). Для функций-калькуляторов всегда пиши ByVal — безопаснее.' },
        { t: 'list', items: [
          'Function возвращает значение, Sub — действие;',
          'Результат — присваивание имени функции;',
          'ByVal — копия аргумента, ByRef — оригинал.'
        ] },
        { t: 'note', html: 'Файл с пользовательскими функциями сохраняют как .xlsm (с макросами). Иначе Excel вырежет код при сохранении — частая потеря работы у новичков.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Напиши функцию <code>Скидка</code>: при цене больше 1000 скидка 10% (цена × 0.1), иначе 5%. Возвращай через имя функции.</p>',
        starter: `Function Скидка(ByVal price As Double) As Double
    TODO
End Function`,
        rules: [
          { desc: 'Заглушка убрана', all: ['\\S'], none: ['TODO'] },
          { desc: 'Функция объявлена', all: ['Function\\s+Скидка\\s*\\(\\s*ByVal\\s+price\\s+As\\s+Double\\s*\\)\\s+As\\s+Double'] },
          { desc: 'Есть If с порогом 1000', all: ['If\\s+price\\s*>\\s*1000'] },
          { desc: 'Возврат через имя: Скидка = …', all: ['Скидка\\s*=\\s*price\\s*\\*\\s*0\\.1', 'Скидка\\s*=\\s*price\\s*\\*\\s*0\\.05'] }
        ],
        note: 'Две ветки: If … Else … End If, обе присваивают Скидка.'
      },
      hints: [
        'Функция возвращает значение, присваивая его собственному имени.',
        'Большая скидка 0.1, малая — 0.05.'
      ],
      solution: `Function Скидка(ByVal price As Double) As Double
    If price > 1000 Then
        Скидка = price * 0.1
    Else
        Скидка = price * 0.05
    End If
End Function`
    },

    {
      id: 'vba-8',
      title: 'Массивы',
      goal: 'Работать с массивами и диапазоном как с массивом',
      xp: 50,
      theory: [
        { t: 'p', html: 'Массив — <code>Dim arr(1 To 10) As Long</code> (фиксированный) или динамический <code>Dim arr() As Long</code> + <code>ReDim</code>. Чтение диапазона в массив одной строкой — главный приём производительности: <code>arr = Range("A1:C100").Value</code> — двумерный массив (строки, столбцы).' },
        { t: 'code', code: `Sub БыстроСумма()
    Dim arr As Variant
    arr = Range("A1:A1000").Value

    Dim i As Long, s As Double: s = 0
    For i = 1 To 1000
        s = s + arr(i, 1)
    Next i
    MsgBox s
End Sub` },
        { t: 'p', html: 'Обрати внимание: массив из диапазона всегда двумерный <code>arr(i, 1)</code>, даже для одного столбца. Границы массива — <code>LBound</code> и <code>UBound</code>. Запись массива обратно на лист — тоже одной строкой в обратную сторону.' },
        { t: 'code', code: `Dim out(1 To 5, 1 To 1) As Variant
For i = 1 To 5: out(i, 1) = i * i: Next i
Range("B1:B5").Value = out` },
        { t: 'note', html: 'Чтение-обработка-запись через массив — стандартная оптимизация: 100 000 ячеек обрабатываются за доли секунды вместо минут поклеточного обхода.' }
      ],
      task: {
        type: 'quiz',
        instruction: '<p>Как обратиться к значению ячейки B3 после arr = Range("A1:C10").Value?</p>',
        options: [
          `arr(3, 2)`,
          `arr(2, 3)`,
          `arr("B3")`,
          `arr(3, "B")`
        ],
        correct: 0,
        explain: 'Массив из диапазона индексируется как (строка, столбец): B3 — строка 3, столбец 2, значит arr(3, 2).'
      },
      hints: [
        'Первый индекс — строка, второй — столбец.',
        'B3 = строка 3, столбец B (второй).'
      ],
      solution: `arr(3, 2)`
    },

    {
      id: 'vba-9',
      title: 'Работа с листами и книгами',
      goal: 'Переключаться между листами, копировать данные',
      xp: 55,
      theory: [
        { t: 'p', html: 'Лист — объект <code>Worksheets("Имя")</code> или <code>Sheets(2)</code> по индексу. Полная квалификация <code>Workbooks("Книга1.xlsx").Worksheets("Отчёт").Range("A1")</code> не оставляет двусмысленностей — это профессиональный стиль: код не зависит от того, какой лист активен.' },
        { t: 'code', code: `Sub СобратьОтчёт()
    Dim ws As Worksheet
    Set ws = Worksheets("Данные")

    ws.Range("A1:D100").Copy Destination:= _
        Worksheets("Итог").Range("A1")
End Sub` },
        { t: 'p', html: 'Присваивание объектов — только через <code>Set</code>: <code>Set ws = Worksheets("Данные")</code>. Забытый Set — классическая ошибка «Object required». Копирование — метод <code>.Copy</code> с параметром Destination. Добавить лист — <code>Worksheets.Add</code>, удалить — <code>.Delete</code>.' },
        { t: 'list', items: [
          '<b>Set</b> обязателен для объектов (Range, Worksheet);',
          '<b>.Copy Destination:=</b> — копирование с указанием места;',
          '<b>Worksheets.Add</b> — новый лист, <b>.Name = "…"</b> — переименовать.'
        ] },
        { t: 'note', html: 'Двоеточие-равно <code>:=</code> — передача именованного параметра, отдельный синтаксис VBA. Не путай с обычным присваиванием =' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Вставь пропущенные ключевые слова работы с объектами.</p>',
        code: `Sub Демо()
    {{0}} ws As Worksheet
    {{1}} ws = Worksheets("Данные")
    ws.Range("A1").{{2}} Destination:=Worksheets("Итог").Range("A1")
End Sub`,
        blanks: [
          { answer: 'Dim' },
          { answer: 'Set' },
          { answer: 'Copy' }
        ],
        ci: false
      },
      hints: [
        'Объектная переменная объявляется Dim, присваивается через Set.',
        'Копирование диапазона — метод Copy.'
      ],
      solution: ['Dim', 'Set', 'Copy']
    },

    {
      id: 'vba-10',
      title: 'Проект: автоматический отчёт',
      goal: 'Собрать макрос-конвейер: собрать данные, посчитать, отформатировать',
      xp: 60,
      theory: [
        { t: 'p', html: 'Финальный проект — типовой офисный отчёт: пройтись по строкам данных, выбрать крупные сделки, вывести итоги и оформить. Собирается из уже изученных деталей: цикл по данным, If-фильтр, счётчики, Range-оформление.' },
        { t: 'code', code: `Sub Отчёт()
    Dim r As Long, n As Long
    Dim total As Double: total = 0
    n = 0

    For r = 2 To 100
        If Cells(r, 1).Value <> "" Then
            If Cells(r, 3).Value > 50000 Then
                total = total + Cells(r, 3).Value
                n = n + 1
            End If
        End If
    Next r

    Range("F1").Value = "Крупных сделок:"
    Range("G1").Value = n
    Range("F2").Value = "Сумма:"
    Range("G2").Value = total
    Range("F1:G2").Font.Bold = True
End Sub` },
        { t: 'list', items: [
          '<b>Счётчики n и total</b> накапливают результат;',
          '<b>Вложенные If</b> отсекают пустые и отбирают по сумме;',
          '<b>Финальное оформление</b> — жирный шрифт итогов.'
        ] },
        { t: 'note', html: 'Этот шаблон масштабируется до реальных задач: добавь массивы для скорости, Function для правил расчёта, Select Case для категорий — и получится производственный отчёт. Именно так VBA остаётся языком №1 в офисной автоматизации десятилетиями.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери скелет отчёта: цикл For r = 2 To 100, внутри If проверки: ячейка A не пуста и C больше 50000, счётчик n увеличивается.</p>',
        starter: `For r = 2 To 100
    TODO
Next r`,
        rules: [
          { desc: 'Заглушка убрана', all: ['\\S'], none: ['TODO'] },
          { desc: 'Проверка непустой ячейки', all: ['Cells\\(r,\\s*1\\)\\.Value\\s*<>\\s*""'] },
          { desc: 'Порог по столбцу C', all: ['Cells\\(r,\\s*3\\)\\.Value\\s*>\\s*50000'] },
          { desc: 'Счётчик увеличивается', all: ['n\\s*=\\s*n\\s*\\+\\s*1'] }
        ],
        note: 'Вложенный If внутри If.'
      },
      hints: [
        'Внешний If: непустота A; внутренний: порог C.',
        'Счётчик: n = n + 1 — внутри обоих условий.'
      ],
      solution: `For r = 2 To 100
    If Cells(r, 1).Value <> "" Then
        If Cells(r, 3).Value > 50000 Then
            n = n + 1
        End If
    End If
Next r`
    }
  ]
};
