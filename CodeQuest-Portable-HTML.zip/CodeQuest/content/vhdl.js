'use strict';
/* ============ CodeQuest — курс VHDL ============
   VHDL не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду) и заполнением
   пропусков. Синтаксис — IEEE 1076, библиотека std_logic_1164.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.vhdl = {
  id: 'vhdl',
  title: 'VHDL',
  emoji: '📐',
  color: '#3d8546',
  lang: 'vhdl',
  tagline: 'Железо как код: 6 уровней описания схем FPGA',
  description: 'Язык описания аппаратуры, рождённый программой Министерства обороны США VHSIC в 1980-х и стандартизованный как IEEE 1076. На нём описывают микросхемы FPGA — от счётчика до процессора. За 6 уровней дойдём от каркаса entity/architecture до проекта «Контроллер светофора»: сигналы, процессы, rising_edge и условное присваивание when/else.',

  levels: [

    /* ---------- 1. Entity и Architecture ---------- */
    {
      id: 'vhdl-1',
      title: 'Entity и Architecture',
      goal: 'Собрать каркас модуля VHDL: entity с выходным портом и architecture с назначением сигнала через <=',
      xp: 30,
      theory: [
        { t: 'p', html: 'VHDL расшифровывается как VHSIC Hardware Description Language — язык описания аппаратуры программы VHSIC («сверхбыстрые интегральные схемы»), которой занималось Министерство обороны США. В 1983 году по контракту с DoD язык разрабатывали Intermetrics, IBM и Texas Instruments, а в 1987-м он стал стандартом IEEE 1076 — с обновлениями 1993, 2002, 2008 и 2019 годов. Синтаксис VHDL унаследован от Ada — тоже языка по заказу военных, поэтому он выглядит строго и «паскольно».' },
        { t: 'h', html: 'Минимальный модуль' },
        { t: 'code', code: `library ieee;
use ieee.std_logic_1164.all;

entity blinker is
  port (
    y : out std_logic
  );
end blinker;

architecture rtl of blinker is
begin
  y <= '1';
end rtl;` },
        { t: 'p', html: 'Любое описание на VHDL строится из двух половин. <code>entity</code> — это «чёрный ящик»: имя модуля и его порты, то есть то, что видно снаружи. <code>architecture</code> — реализация: что происходит внутри ящика. У одной сущности может быть несколько архитектур — поведенческая, потоковая, структурная, — и тестбенч переключает их без переписывания портов.' },
        { t: 'list', items: [
          '<b>entity Имя is … end Имя;</b> — интерфейс модуля;',
          '<b>port ( … );</b> — список портов с направлениями и типами;',
          '<b>architecture Имя of Сущность is … begin … end Имя;</b> — реализация;',
          '<b>in / out / inout</b> — направления портов: вход, выход, двунаправленный.'
        ] },
        { t: 'p', html: 'Каждому порту обязательно указывают направление и тип. Направление — это роль провода: вход только читают, выходу только назначают значения. Тип <code>std_logic</code> — стандартный «один бит» из библиотеки <code>ieee.std_logic_1164</code>, две первые строки модуля как раз подключают её.' },
        { t: 'p', html: 'Назначение сигнала пишется стрелкой <code>&lt;=</code> и читается «получает»: <code>y &lt;= &#39;1&#39;</code> означает «на проводе y стоит единица». Одиночный бит записывается в одинарных кавычках — <code>&#39;0&#39;</code> или <code>&#39;1&#39;</code>.' },
        { t: 'warn', html: 'VHDL строг к знакам препинания: каждое объявление порта заканчивается точкой с запятой — даже последнее перед закрывающей скобкой, а после <code>end blinker;</code> точка с запятой обязательна. Имя после <code>end</code> должно совпадать с именем сущности или архитектуры — компилятор проверяет.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Каркас готов наполовину: библиотека подключена. Допиши сущность <code>blinker</code> с одним выходным портом <code>y</code> типа <code>std_logic</code>, затем архитектуру <code>rtl</code>, внутри которой порту назначается <code>&#39;1&#39;</code> через стрелку. Закрой обе конструкции через <code>end Имя;</code> и убери заглушки.</p>',
        starter: `library ieee;
use ieee.std_logic_1164.all;

-- TODO: объяви сущность blinker с выходным портом y типа std_logic

-- TODO: объяви архитектуру rtl и назначь порту значение '1'`,
        rules: [
          { desc: 'Подключена библиотека IEEE: library ieee; use ieee.std_logic_1164.all;', all: ['\\blibrary\\s+ieee\\s*;', '\\buse\\s+ieee\\.std_logic_1164\\.all\\s*;'] },
          { desc: 'Объявлена сущность: entity Имя is', all: ['\\bentity\\s+\\w+\\s+is\\b'] },
          { desc: 'Есть выходной порт: Имя : out std_logic', all: ['\\bout\\s+std_logic\\b'] },
          { desc: 'Архитектура привязана к сущности: architecture Имя of Сущность is', all: ['\\barchitecture\\s+\\w+\\s+of\\s+\\w+\\s+is\\b'] },
          { desc: 'Тело архитектуры открыто и закрыто: begin … end Имя;', all: ['\\bbegin\\b', '\\bend\\s+\\w+\\s*;'] },
          { desc: 'Порту назначен бит через <=', all: ['\\w+\\s*<=\\s*\'[01]\';'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Сущность: entity blinker is port ( y : out std_logic ); end blinker; — не потеряй точку с запятой после скобки.',
        'Архитектура: architecture rtl of blinker is begin ... end rtl;',
        'Внутри begin одна строка: y &lt;= &#39;1&#39;; — стрелка из двух символов и бит в одинарных кавычках.'
      ],
      solution: `library ieee;
use ieee.std_logic_1164.all;

entity blinker is
  port (
    y : out std_logic
  );
end blinker;

architecture rtl of blinker is
begin
  y <= '1';
end rtl;`
    },

    /* ---------- 2. Сигналы и типы ---------- */
    {
      id: 'vhdl-2',
      title: 'Сигналы и типы',
      goal: 'Объявлять сигналы std_logic и std_logic_vector, задавать диапазоны downto и различать := и <=',
      xp: 30,
      theory: [
        { t: 'p', html: 'Сигналы — это внутренние провода архитектуры. Объявляются в декларативной части, до <code>begin</code>: <code>signal имя : тип := стартовое значение;</code>. Начальное значение необязательно, но для счётчиков и регистров полезно — без него в симуляции сигнал стартует с «неизвестного» состояния.' },
        { t: 'code', code: `signal a      : std_logic;             -- одиночный бит
signal data   : std_logic_vector(7 downto 0);  -- шина из 8 бит
signal ready  : std_logic := '0';      -- со стартовым значением` },
        { t: 'p', html: '<code>std_logic</code> — «бит с характером». Кроме <code>&#39;0&#39;</code> и <code>&#39;1&#39;</code> у него есть ещё семь состояний: <code>&#39;Z&#39;</code> — провод отключён (третье состояние), <code>&#39;X&#39;</code> — конфликт двух драйверов, <code>&#39;U&#39;</code> — не инициализирован, <code>&#39;-&#39;</code> — всё равно. Именно из-за этих состояний std_logic предпочитают простому типу <code>bit</code>: он честно моделирует реальное железо.' },
        { t: 'table', head: ['Тип', 'Что хранит', 'Пример'], rows: [
          ['std_logic', 'один бит с 9 состояниями', '&#39;0&#39;, &#39;1&#39;, &#39;Z&#39;'],
          ['std_logic_vector', 'шина из бит', '&quot;1010&quot;, x&quot;2A&quot;'],
          ['integer', 'целое число (можно с range)', '0 to 9'],
          ['boolean', 'логическое значение', 'true / false']
        ] },
        { t: 'p', html: 'Шина объявляется с диапазоном: <code>std_logic_vector(7 downto 0)</code> — восемь бит, старший слева. Слово <code>downto</code> задаёт направление нумерации от старшего к младшему (бывает и <code>to</code> — наоборот, но downto — общепринятый стиль). На шину можно положить сразу байт шестнадцатеричным литералом: <code>data &lt;= x&quot;2A&quot;;</code>.' },
        { t: 'p', html: 'Присваиваний два, и их нельзя путать. Стрелка <code>&lt;=</code> назначает <b>сигналу</b> значение в теле архитектуры — новое значение появится после дельта-задержки, крошечного шага симуляции. Пара <code>:=</code> задаёт начальное значение в объявлении и работает с <b>переменными</b>. Перепутал — компилятор откажется собирать.' },
        { t: 'warn', html: 'Начальное значение пишется только в объявлении: <code>signal ready : std_logic := &#39;0&#39;;</code>. В теле архитектуры сигналу положена только стрелка <code>&lt;=</code>. Попытка написать <code>ready := &#39;1&#39;;</code> в теле — ошибка: так можно обращаться лишь с переменными, а они живут внутри процессов (уровень 3).' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни объявления: впиши тип одиночного бита, тип шины, направление диапазона от старшего к младшему, знак начального значения и знак назначения сигналу в теле. Двоеточие со знаком равенства впиши как единый символ, стрелку — тоже.</p>',
        code: `library ieee;
use ieee.std_logic_1164.all;

architecture rtl of demo is
  signal a : {{0}};                    -- одиночный бит
  signal data : {{1}}(7 {{2}} 0);      -- шина из 8 бит
  signal ready : std_logic {{3}} '0';  -- стартовое значение
begin
  a {{4}} '1';             -- назначение биту
  data <= x"2A";
end rtl;`,
        blanks: [
          { answer: 'std_logic', ci: true },
          { answer: 'std_logic_vector', ci: true },
          { answer: 'downto', ci: true },
          { answer: ':=' },
          { answer: '<=' }
        ],
        ci: false
      },
      hints: [
        'Одиночный бит — std_logic, шина — std_logic_vector, от старшего к младшему — downto.',
        'Начальное значение в объявлении задаётся через :=, а назначение сигналу в теле — стрелкой <=.',
        'Итог должен читаться: signal a : std_logic; и a &lt;= &#39;1&#39;;'
      ],
      solution: ['std_logic', 'std_logic_vector', 'downto', ':=', '<=']
    },

    /* ---------- 3. Process и чувствительность ---------- */
    {
      id: 'vhdl-3',
      title: 'Process и чувствительность',
      goal: 'Описать процесс с списком чувствительности, условием внутри и двумя назначениями сигналам',
      xp: 35,
      theory: [
        { t: 'p', html: 'До сих пор все назначения были параллельными: строки архитектуры «работают одновременно», как провода. <code>process</code> — способ описать последовательную логику: внутри процесса операторы выполняются строго по порядку, как в обычном языке программирования. При этом сам процесс — параллельный элемент: несколько процессов в архитектуре работают одновременно и общаются сигналами.' },
        { t: 'code', code: `process (clk)
begin
  -- последовательные операторы
end process;` },
        { t: 'p', html: 'Список в скобках — <b>список чувствительности</b>: перечисленные сигналы работают триггерами. Изменился любой из них — процесс перезапускается с первой строки. Забудешь сигнал в списке — процесс не среагирует на его изменение, и симуляция «замрёт» со старыми значениями. Синтезатор при этом построит железо по-своему, и получится классическое расхождение «в симуляции работает, на плате нет».' },
        { t: 'h', html: 'Что живёт внутри процесса' },
        { t: 'p', html: 'Условия — привычные: <code>if … then … elsif … else … end if;</code>. Назначения сигналам всё ещё стрелкой <code>&lt;=</code>. А вот переменные объявляются только внутри процесса и получают значения через <code>:=</code> — они меняются мгновенно, в отличие от сигналов, и видны лишь внутри своего процесса.' },
        { t: 'code', code: `process (clk)
  variable tmp : std_logic;
begin
  if clk = '1' then
    tmp := button;      -- переменная — :=
    held <= tmp;        -- сигнал — <=
  end if;
end process;` },
        { t: 'list', items: [
          '<b>process (сигналы)</b> — старт по изменению перечисленных сигналов;',
          '<b>begin … end process;</b> — каркас, точка с запятой после end process обязательна;',
          '<b>variable имя : тип;</b> — локальная переменная процесса (:=);',
          '<b>сигнал &lt;= значение;</b> — назначение сигналу внутри процесса.'
        ] },
        { t: 'warn', html: 'Процесс без списка чувствительности — <code>process begin … end process;</code> — в симуляции закрутится бесконечно: его никто не «будит». Не пиши так, пока не изучил <code>wait</code>. И не забывай точку с запятой после <code>end process</code> — это обычный оператор архитектуры.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Дополни архитектуру <code>sampler</code>: объяви сигнал <code>held</code> типа <code>std_logic</code> со стартовым значением <code>&#39;0&#39;</code>. Затем опиши процесс со списком чувствительности к <code>clk</code>: при <code>clk = &#39;1&#39;</code> запоминай кнопку в <code>held</code>, а после условия выводи <code>held</code> на <code>led</code>. Убери заглушки.</p>',
        starter: `library ieee;
use ieee.std_logic_1164.all;

entity sampler is
  port (
    clk    : in  std_logic;
    button : in  std_logic;
    led    : out std_logic
  );
end sampler;

architecture rtl of sampler is
  -- TODO: объяви сигнал held со стартовым значением '0'
begin
  -- TODO: опиши процесс со списком чувствительности к clk
  -- TODO: при clk = '1' запоминай кнопку в held, затем веди held на led
end rtl;`,
        rules: [
          { desc: 'Внутренний сигнал объявлен со стартовым значением', all: ['\\bsignal\\s+\\w+\\s*:\\s*std_logic\\s*:=\\s*\'[01]\''] },
          { desc: 'Процесс со списком чувствительности к clk', all: ['\\bprocess\\s*\\([^)]*clk[^)]*\\)'] },
          { desc: 'Процесс открыт и закрыт: begin … end process;', all: ['\\bbegin\\b', '\\bend\\s+process\\s*;'] },
          { desc: 'Условие внутри процесса: if clk = \'1\' then', all: ['\\bif\\s+clk\\s*=\\s*\'1\'\\s+then'] },
          { desc: 'Два назначения сигналам через <=', all: ['\\w+\\s*<=\\s*[^;]+;[\\s\\S]*\\w+\\s*<=\\s*[^;]+;'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Сигнал: signal held : std_logic := &#39;0&#39;; — в декларативной части, до begin.',
        'Каркас процесса: process (clk) begin ... end process;',
        'Внутри: if clk = &#39;1&#39; then held &lt;= button; end if; затем вне условия — led &lt;= held;'
      ],
      solution: `library ieee;
use ieee.std_logic_1164.all;

entity sampler is
  port (
    clk    : in  std_logic;
    button : in  std_logic;
    led    : out std_logic
  );
end sampler;

architecture rtl of sampler is
  signal held : std_logic := '0';
begin
  process (clk)
  begin
    if clk = '1' then
      held <= button;
    end if;
    led <= held;
  end process;
end rtl;`
    },

    /* ---------- 4. Счётчик на clk ---------- */
    {
      id: 'vhdl-4',
      title: 'Счётчик на clk',
      goal: 'Построить тактовый счётчик: integer range, if rising_edge(clk), инкремент через <= и сброс по максимуму',
      xp: 35,
      theory: [
        { t: 'p', html: 'Тактовый процесс — сердце любой синхронной схемы. Всё, что стоит внутри <code>if rising_edge(clk) then … end if;</code>, происходит в момент фронта такта. <code>rising_edge</code> — функция из библиотеки <code>ieee.std_logic_1164</code>: она возвращает true ровно один раз за переход сигнала из <code>&#39;0&#39;</code> в <code>&#39;1&#39;</code>.' },
        { t: 'code', code: `process (clk)
begin
  if rising_edge(clk) then
    -- всё это исполнится на фронте такта
  end if;
end process;` },
        { t: 'p', html: 'Почему не проверка <code>clk = &#39;1&#39;</code> из прошлого уровня? Она срабатывает при любом попадании процесса в список чувствительности, пока такт стоит в единице. <code>rising_edge</code> ловит именно фронт. Для регистров, счётчиков и любых «памятных» узлов правило одно: пишем через <code>rising_edge</code>.' },
        { t: 'h', html: 'Счётчик по модулю 10' },
        { t: 'code', code: `signal cnt : integer range 0 to 9 := 0;

process (clk)
begin
  if rising_edge(clk) then
    if cnt = 9 then
      cnt <= 0;
    else
      cnt <= cnt + 1;
    end if;
  end if;
end process;` },
        { t: 'p', html: 'Диапазон <code>range 0 to 9</code> у <code>integer</code> подсказывает синтезатору, что хватит четырёх бит. Сброс по максимуму — <code>if cnt = 9 then cnt &lt;= 0;</code> — превращает счётчик в счёт по модулю 10: после девятки снова ноль.' },
        { t: 'p', html: 'Строка <code>cnt &lt;= cnt + 1;</code> читается так: справа — старое значение, слева — новое, которое появится <b>после</b> фронта. Если внутри одного фронта сигналу назначают несколько раз, победит последнее назначение — порядок строк внутри if важен.' },
        { t: 'warn', html: 'Не смешивай без нужды синхронную и комбинационную логику: всё, что должно обновляться на фронте, держи внутри <code>rising_edge</code>, а «живущее само по себе» — снаружи процесса или в другом процессе. И помни: новое значение <code>cnt</code> в симуляции увидишь только на следующем фронте.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери счётчик по модулю 10: объяви сигнал <code>cnt</code> типа <code>integer range 0 to 9</code> со стартовым нулём. В процессе по <code>clk</code> на фронте такта (<code>rising_edge</code>): если счётчик достиг девяти — сбрось его в ноль и подними <code>tick</code> в единицу, иначе увеличь и опусти <code>tick</code>. Убери заглушки.</p>',
        starter: `library ieee;
use ieee.std_logic_1164.all;

entity counter is
  port (
    clk  : in  std_logic;
    tick : out std_logic
  );
end counter;

architecture rtl of counter is
  -- TODO: объяви счётчик cnt от 0 до 9 со стартовым нулём
begin
  process (clk)
  begin
    -- TODO: на фронте такта: если счётчик равен 9 — сброс и tick='1',
    -- иначе увеличение и tick='0'
  end process;
end rtl;`,
        rules: [
          { desc: 'Счётчик объявлен: signal cnt : integer range 0 to 9 := 0', all: ['\\bsignal\\s+\\w+\\s*:\\s*integer\\s+range\\s+\\d+\\s+to\\s+\\d+\\s*:=\\s*\\d+'] },
          { desc: 'Процесс по clk', all: ['\\bprocess\\s*\\([^)]*clk[^)]*\\)'] },
          { desc: 'Фронт такта: if rising_edge(clk) then', all: ['\\brising_edge\\s*\\(\\s*clk\\s*\\)'] },
          { desc: 'Инкремент счётчика через <=', all: ['\\w+\\s*<=\\s*\\w+\\s*\\+\\s*1\\s*;'] },
          { desc: 'Сброс по максимуму с веткой else', all: ['\\bif\\s+\\w+\\s*=\\s*\\d+\\s+then', '\\belse\\b'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Счётчик: signal cnt : integer range 0 to 9 := 0;',
        'Каркас условия: if rising_edge(clk) then if cnt = 9 then ... else ... end if; end if;',
        'Инкремент — стрелкой: cnt &lt;= cnt + 1; а сброс — cnt &lt;= 0;'
      ],
      solution: `library ieee;
use ieee.std_logic_1164.all;

entity counter is
  port (
    clk  : in  std_logic;
    tick : out std_logic
  );
end counter;

architecture rtl of counter is
  signal cnt : integer range 0 to 9 := 0;
begin
  process (clk)
  begin
    if rising_edge(clk) then
      if cnt = 9 then
        cnt <= 0;
        tick <= '1';
      else
        cnt <= cnt + 1;
        tick <= '0';
      end if;
    end if;
  end process;
end rtl;`
    },

    /* ---------- 5. Условное присваивание: when/else ---------- */
    {
      id: 'vhdl-5',
      title: 'Условное присваивание: when/else',
      goal: 'Читать и собирать параллельные присваивания y <= a when sel else b, включая цепочки условий',
      xp: 40,
      theory: [
        { t: 'p', html: 'Условное присваивание сигнала — параллельный оператор одной строкой: <code>цель &lt;= значение when условие else значение;</code>. Читается как «цель получает первое значение, когда условие истинно, иначе второе». Одна такая строка — целый мультиплексор, селектор каналов.' },
        { t: 'code', code: `y <= a when sel = '1' else b;` },
        { t: 'p', html: 'Условия можно выстраивать цепочкой — каждая следующая ступень через <code>when</code>: <code>state &lt;= &quot;11&quot; when a = &#39;1&#39; else &quot;10&quot; when b = &#39;1&#39; else &quot;00&quot;;</code>. Проверяются они сверху вниз: срабатывает первый истинный вариант. Последний <code>else</code> обязателен — без него значению некуда деться в «дыре» условий.' },
        { t: 'p', html: 'Условие — это <code>boolean</code>: сравнения <code>=</code>, <code>/=</code> (не равно!), <code>&lt;</code>, <code>&lt;=</code>, <code>&gt;</code>, <code>&gt;=</code> и связки <code>and</code>, <code>or</code>, <code>not</code>. Сравнение крепче, чем and, поэтому <code>a = &#39;1&#39; and b = &#39;1&#39;</code> работает без скобок — но для читаемости их ставят.' },
        { t: 'h', html: 'Порт и его режим' },
        { t: 'p', html: 'Режим порта — его роль в жизни модуля. <code>in</code> — вход: значение только читают. <code>out</code> — выход: ему только назначают. <code>inout</code> — двунаправленный, для внешних шин. Хитрость: значение порта <code>out</code> нельзя прочитать внутри модуля — для обратной связи заводят внутренний сигнал и выводят его отдельной строкой.' },
        { t: 'warn', html: 'У when/else нет «elsif»: каждая следующая ступень — новое <code>when</code>. И не переноси этот синтаксис внутрь процесса: там свои <code>if/elsif/else</code>. when/else живёт только параллельно, в теле архитектуры.' },
        { t: 'note', html: 'Весь мультиплексор уровня 3 можно записать одной строкой <code>led &lt;= button when clk = &#39;1&#39; else held;</code> — но помни: это параллельный оператор, он реагирует на изменение любого сигнала справа, без списка чувствительности.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни мультиплексор и кодировщик состояния: впиши режим порта (выход), связки «когда» и «иначе» в двух присваиваниях и логическое «и» в условии третьего. Все ключевые слова — маленькими буквами.</p>',
        code: `library ieee;
use ieee.std_logic_1164.all;

entity mux2 is
  port (
    a, b, sel : in  std_logic;
    y         : {{0}} std_logic
  );
end mux2;

architecture rtl of mux2 is
  signal state : std_logic_vector(1 downto 0);
begin
  y <= a {{1}} sel = '1' {{2}} b;

  state <= "11" {{3}} a = '1' {{4}} b = '1' {{5}} "00";
end rtl;`,
        blanks: [
          { answer: 'out', ci: true },
          { answer: 'when', ci: true },
          { answer: 'else', ci: true },
          { answer: 'when', ci: true },
          { answer: 'else', ci: true },
          { answer: 'and', ci: true }
        ],
        ci: false
      },
      hints: [
        'Режим выхода — out; связка «когда» — when, «иначе» — else.',
        'Условие «a = &#39;1&#39; и b = &#39;1&#39;» соединяется словом and.',
        'Цепочка проверяется сверху вниз, последний вариант — просто else без when.'
      ],
      solution: ['out', 'when', 'else', 'when', 'else', 'and']
    },

    /* ---------- 6. 🚀 Проект: контроллер светофора ---------- */
    {
      id: 'vhdl-6',
      title: '🚀 Проект: контроллер светофора',
      goal: 'Собрать контроллер светофора: entity с clk и тремя выходами, тактовый счётчик и фазы через when/else',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальная практика — контроллер светофора. План: вход <code>clk</code>, три выхода <code>r</code>, <code>y</code>, <code>g</code>; счётчик тактов от нуля до четырёх крутится процессом с <code>rising_edge</code>; фазы раздаются параллельными присваиваниями when/else. Цикл из пяти тактов: 0–1 — красный, 2 — жёлтый, 3–4 — зелёный.' },
        { t: 'code', code: `signal cnt : integer range 0 to 4 := 0;

process (clk)
begin
  if rising_edge(clk) then
    if cnt = 4 then
      cnt <= 0;
    else
      cnt <= cnt + 1;
    end if;
  end if;
end process;` },
        { t: 'code', code: `r <= '1' when cnt < 2 else '0';
y <= '1' when cnt = 2 else '0';
g <= '1' when cnt > 2 else '0';` },
        { t: 'p', html: 'Здесь чистое разделение труда: процесс занимается «механикой времени», а when/else — «логикой света». Захочешь поменять длительности фаз — правишь только счётчик и условия, структура контроллера не трогается. Именно так проектируют настоящие конечные автоматы: счётчик или регистр состояний плюс комбинационная логика выходов.' },
        { t: 'list', items: [
          '<b>entity</b> с портом <code>clk : in std_logic</code> и тремя выходами;',
          '<b>signal cnt : integer range 0 to 4 := 0;</b> — счётчик фазы;',
          '<b>process (clk)</b> с <code>rising_edge</code>, инкрементом и сбросом;',
          '<b>три присваивания when/else</b> — по одному на каждый фонарь.'
        ] },
        { t: 'note', html: 'После зачёта расширяй: сделай красную фазу вдвое длиннее (range до 6 и три условия), добавь «мигание» зелёного через проверку чётности, вынеси границы фаз в константы <code>constant</code>. Чекер смотрит на структуру — смело экспериментируй.' },
        { t: 'warn', html: 'В каждом условном присваивании обязан быть <code>else</code>: если оставить «дыру», синтезатор построит защёлку, а защёлка в тактовом дизайне — плохой тон. И не забудь сброс счётчика, иначе однажды целое переполнится и светофор сломается.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери контроллер светофора целиком: сущность <code>traffic</code> с входом <code>clk</code> и тремя выходами <code>r</code>, <code>y</code>, <code>g</code> (можно списком <code>r, y, g : out std_logic</code>). В архитектуре — счётчик тактов <code>integer range</code>, процесс с <code>rising_edge</code> и сбросом, затем минимум два условных присваивания <code>when/else</code> для фонарей.</p>',
        starter: `library ieee;
use ieee.std_logic_1164.all;

-- TODO: объяви сущность traffic: вход clk и три выхода (красный, жёлтый, зелёный)
-- TODO: архитектура со счётчиком тактов от 0 до 4

-- TODO: тактовый процесс с rising_edge: считай и вовремя сбрасывай счётчик

-- TODO: три фонаря разбуди условным присваиванием when/else`,
        rules: [
          { desc: 'Сущность с входом clk и тремя выходами', all: ['\\bentity\\s+\\w+\\s+is\\b', '\\bclk\\s*:\\s*in\\s+std_logic'], any: ['\\bout\\s+std_logic[\\s\\S]*\\bout\\s+std_logic[\\s\\S]*\\bout\\s+std_logic', '\\b\\w+\\s*,\\s*\\w+\\s*,\\s*\\w+\\s*:\\s*out\\s+std_logic'] },
          { desc: 'Счётчик тактов объявлен с диапазоном', all: ['\\bsignal\\s+\\w+\\s*:\\s*integer\\s+range\\s+\\d+\\s+to\\s+\\d+'] },
          { desc: 'Тактовый процесс с фронтом rising_edge', all: ['\\bprocess\\s*\\([^)]*clk[^)]*\\)', '\\brising_edge\\s*\\(\\s*clk\\s*\\)'] },
          { desc: 'Счётчик увеличивается и сбрасывается по максимуму', all: ['\\w+\\s*<=\\s*\\w+\\s*\\+\\s*1\\s*;', '\\bif\\s+\\w+\\s*=\\s*\\d+\\s+then'] },
          { desc: 'Минимум два условных присваивания when/else', all: ['\\w+\\s*<=\\s*[^;]+\\s+when\\s+[^;]+\\s+else\\s+[^;]+;[\\s\\S]*\\w+\\s*<=\\s*[^;]+\\s+when\\s+[^;]+\\s+else\\s+[^;]+;'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Порты: clk : in std_logic; и r, y, g : out std_logic — три выхода можно перечислить через запятую.',
        'Счётчик и процесс — как в уровне 4, только range 0 to 4 и сброс при cnt = 4.',
        'Фонари: r &lt;= &#39;1&#39; when cnt &lt; 2 else &#39;0&#39;; — и аналогично для y (cnt = 2) и g (cnt &gt; 2).'
      ],
      solution: `library ieee;
use ieee.std_logic_1164.all;

entity traffic is
  port (
    clk     : in  std_logic;
    r, y, g : out std_logic
  );
end traffic;

architecture rtl of traffic is
  signal cnt : integer range 0 to 4 := 0;
begin
  process (clk)
  begin
    if rising_edge(clk) then
      if cnt = 4 then
        cnt <= 0;
      else
        cnt <= cnt + 1;
      end if;
    end if;
  end process;

  r <= '1' when cnt < 2 else '0';
  y <= '1' when cnt = 2 else '0';
  g <= '1' when cnt > 2 else '0';
end rtl;`
    }
  ],

  cheats: [
    { title: 'Каркас модуля', code: `library ieee;
use ieee.std_logic_1164.all;

entity имя is
  port (
    clk : in  std_logic;
    y   : out std_logic
  );
end имя;

architecture rtl of имя is
begin
  y <= '1';
end rtl;` },
    { title: 'Сигналы и типы', list: [
      '<code>signal a : std_logic := \'0\';</code> — бит со стартом',
      '<code>std_logic_vector(7 downto 0)</code> — шина из 8 бит',
      '<code>x"2A"</code> — байт шестнадцатеричным литералом',
      '<code>&lt;=</code> — назначение сигналу; <code>:=</code> — переменным и стартовым значениям',
      '<code>integer range 0 to 9</code> — целое с диапазоном'
    ] },
    { title: 'Процесс', code: `process (clk, rst)
  variable tmp : std_logic;
begin
  if rst = '1' then
    tmp := '0';
  elsif rising_edge(clk) then
    tmp := not tmp;
  end if;
end process;` },
    { title: 'Тактовая логика', code: `if rising_edge(clk) then
  if cnt = 9 then
    cnt <= 0;
  else
    cnt <= cnt + 1;
  end if;
end if;` },
    { title: 'Условное присваивание', code: `y <= a when sel = '1' else b;

state <= "11" when a = '1' else
         "10" when b = '1' else
         "00";` },
    { title: 'Частые ошибки', list: [
      'нет else в when/else — синтезатор построит защёлку',
      ':= для сигнала в теле архитектуры — ошибка',
      'забытый сигнал в списке чувствительности — «замёрзшая» симуляция',
      'точка с запятой после каждого порта, включая последний',
      'чтение значения порта out внутри модуля запрещено'
    ] },
    { title: 'Направления портов', list: [
      '<code>in</code> — вход: только читают',
      '<code>out</code> — выход: только назначают, читать нельзя',
      '<code>inout</code> — двунаправленный (внешние шины)',
      'для обратной связи — внутренний сигнал + отдельный вывод'
    ] }
  ]
};
