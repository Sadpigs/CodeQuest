'use strict';
/* ============ CodeQuest — курс Zig ============
   Zig не запускается в приложении: задания проверяются
   структурным анализом (regex по сырому коду), квизами,
   задачами «предскажи вывод» и заполнением пропусков.
=============================================== */
window.CQ_LANGS = window.CQ_LANGS || {};

window.CQ_LANGS.zig = {
  id: 'zig',
  title: 'Zig',
  emoji: '🦎',
  color: '#f7a41d',
  lang: 'zig',
  tagline: 'Замена C за 10 уровней: comptime и никакой магии',
  description: 'Язык Эндрю Келли (2016): никакого скрытого контроля памяти, неопределённого поведения и макросов. Компилятор Zig умеет собирать даже C-код. За 10 уровней дойдём от pub fn main до проекта «Трекер бюджета»: структуры с методами, срезы и массивы, try/catch и error.OverBudget.',

  levels: [

    /* ---------- 1. Первая программа ---------- */
    {
      id: 'zig-1',
      title: 'Первая программа',
      goal: 'Собрать каркас программы на Zig: @import std, pub fn main() !void и вывод через std.debug.print',
      xp: 30,
      theory: [
        { t: 'p', html: 'Zig — язык Эндрю Келли, начатый в 2016 году как «современный C». Его девиз: ничего скрытого. Нет скрытого управления памятью, нет неопределённого поведения, нет макросов, которые делают вид, что это не код. При этом компилятор Zig собирает и обычный C/C++ — им пользуются как инструментом сборки. Код работает так, как написан: каждая аллокация проходит через твои руки явно.' },
        { t: 'h', html: 'Минимальная программа' },
        { t: 'code', code: `const std = @import("std");

pub fn main() !void {
    std.debug.print("Привет, CodeQuest!\\n", .{});
}` },
        { t: 'p', html: 'Первая строка подключает стандартную библиотеку: <code>@import("std")</code> — встроенная функция импорта (все встроенные в Zig начинаются с <code>@</code>), результат кладём в константу <code>std</code>. Точка входа — <code>pub fn main() !void</code>: <code>pub</code> делает функцию публичной, <code>fn</code> объявляет функцию, а <code>!void</code> означает «возвращает либо ошибку, либо ничего».' },
        { t: 'p', html: 'Вывод делает <code>std.debug.print</code> — печать в поток ошибок, куда смотрит любая отладка. Важная деталь: этот print <b>не добавляет перенос строки сам</b> — его пишут руками как <code>\\n</code> в конце строки. Второй аргумент <code>.{}</code> — анонимный кортеж значений для подстановок; пока он пустой.' },
        { t: 'list', items: [
          '<b>@import("std")</b> — подключение стандартной библиотеки;',
          '<b>pub fn main() !void</b> — публичная точка входа;',
          '<b>std.debug.print</b> — печать без автопереноса;',
          '<b>.{}</b> — кортеж аргументов для подстановок.'
        ] },
        { t: 'warn', html: 'Собирают так: сохрани код в <code>hello.zig</code> и выполни <code>zig build-exe hello.zig</code> — получится исполняемый файл <code>hello</code>. Забудешь <code>\\n</code> в конце строки — следующий вывод прилипнет к предыдущему.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Каркас уже собран — допиши вывод: внутри <code>main</code> вызови <code>std.debug.print</code> со строкой <code>Привет, CodeQuest!</code> (не забудь <code>\\n</code> в конце и <code>.{}</code> вторым аргументом) и убери заглушку.</p>',
        starter: `const std = @import("std");

pub fn main() !void {
    // TODO: выведи приветствие через стандартную печать
}`,
        rules: [
          { desc: 'Подключена стандартная библиотека: const std = @import("std");', all: ['\\bconst\\s+std\\s*=\\s*@import\\s*\\(\\s*"std"\\s*\\)\\s*;'] },
          { desc: 'Есть точка входа: pub fn main() !void {', all: ['\\bpub\\s+fn\\s+main\\s*\\(\\s*\\)', '!\\s*void\\s*\\{'] },
          { desc: 'Вывод через std.debug.print со строкой в кавычках', all: ['std\\.debug\\.print\\s*\\(\\s*"[^"]+"'] },
          { desc: 'В кавычках фраза "Привет, CodeQuest!"', all: ['Привет, CodeQuest!'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Две первые строки (import и pub fn main) уже правильные — их менять не нужно.',
        'Допиши: std.debug.print("Привет, CodeQuest!\\n", .{}); — обратный слэш с n в конце строки.',
        'Второй аргумент — пустой кортеж: точка, фигурные скобки — .{}'
      ],
      solution: `const std = @import("std");

pub fn main() !void {
    std.debug.print("Привет, CodeQuest!\\n", .{});
    std.debug.print("Это моя первая программа на Zig.\\n", .{});
}`
    },

    /* ---------- 2. Переменные и типы ---------- */
    {
      id: 'zig-2',
      title: 'Переменные и типы',
      goal: 'Различать const и var, указывать типы i32, u32, f64, bool и понимать выведение типов',
      xp: 30,
      theory: [
        { t: 'p', html: 'В Zig ровно два вида переменных, и выбор между ними — первое, что ты решаешь в каждой строке. <code>const</code> — неизменяемая: присвоил один раз и всё, попытка изменить — ошибка компиляции. <code>var</code> — изменяемая. Философия языка: по умолчанию бери <code>const</code>, а <code>var</code> — только когда переменная правда будет меняться.' },
        { t: 'code', code: `const std = @import("std");

pub fn main() !void {
    const max_hp: i32 = 100;   // неизменяемая
    var current_hp: i32 = 87;  // изменяемая
    current_hp = current_hp + 5;
    std.debug.print("{}\\n", .{current_hp});
}` },
        { t: 'table', head: ['Тип', 'Хранит', 'Примеры'], rows: [
          ['i32', 'целое со знаком (32 бита)', '-7, 0, 42'],
          ['u32', 'целое без знака (только ≥ 0)', '0, 100, 4000000'],
          ['f64', 'дробное число (64 бита)', '3.14, -0.5'],
          ['bool', 'логическое', 'true, false (маленькими!)']
        ] },
        { t: 'p', html: 'Тип можно указать явно через двоеточие — <code>var ratio: f64 = 0.75;</code> — или оставить компилятору: он выведет тип из значения. <code>true</code> и <code>false</code> пишутся маленькими буквами — это не Pascal. Целые типы бывают разной ширины: <code>i8</code>...<code>i64</code> со знаком и <code>u8</code>...<code>u64</code> без; для дробных — <code>f16</code>...<code>f128</code>. Строка в Zig — это срез байтов <code>[]const u8</code>.' },
        { t: 'p', html: 'Подстановку в печать делает <code>{}</code>: <code>std.debug.print("{}\\n", .{max_hp})</code> — значение из кортежа встанет на место фигурных скобок.' },
        { t: 'warn', html: 'Zig наказывает за лишнее: <code>var</code>, которую ни разу не изменили, — ошибка компиляции «never mutated»; неиспользуемая локальная переменная — тоже ошибка. Объявил — используй и меняй, иначе const.' },
        { t: 'note', html: 'Форма объявления одинаковая для const и var: <code>имя: тип = значение</code>. Разница только в первом слове. Если тип очевиден из значения — смело опускай: <code>const attempts = 3;</code>.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни карточку героя: подставь типы — запас целым со знаком, скорость дробная, флаг логический, попытки целые без знака, а для строки подбери слово, которое запрещает изменение.</p>',
        code: `const std = @import("std");

pub fn main() !void {
    const max_hp: {{0}} = 100;       // целое со знаком
    const speed: {{1}} = 4.5;        // дробное
    var alive: {{2}} = true;         // логическое
    var attempts: {{3}} = 3;         // целое без знака
    {{4}} greeting = "Привет";       // менять не будем
    std.debug.print("{}\\n", .{max_hp});
}`,
        blanks: [
          { answer: 'i32' },
          { answer: 'f64' },
          { answer: 'bool' },
          { answer: 'u32' },
          { answer: 'const' }
        ],
        ci: false
      },
      hints: [
        'Целое со знаком — i32, без знака — u32, дробное — f64, логическое — bool.',
        'Строку менять не будут — значит, объявляем через const.',
        'true и false в Zig пишутся маленькими буквами.'
      ],
      solution: ['i32', 'f64', 'bool', 'u32', 'const']
    },

    /* ---------- 3. Условия и циклы ---------- */
    {
      id: 'zig-3',
      title: 'Условия и циклы',
      goal: 'Предсказать вывод программы с while, break и ветвлением if / else',
      xp: 35,
      theory: [
        { t: 'p', html: 'Цикл <code>while</code> повторяет тело, пока условие истинно: <code>while (count &lt; 3) { ... }</code>. Условие обычно оборачивают в круглые скобки — это стиль Zig, фигурные же скобки вокруг тела <b>обязательны всегда</b>, даже для одной строки.' },
        { t: 'code', code: `var count: u32 = 0;
while (count < 3) {
    count += 1;
}` },
        { t: 'p', html: 'Ветвление — <code>if</code> / <code>else if</code> / <code>else</code>: проверка в скобках, тело в фигурных скобках, ветки идут сверху вниз и срабатывает первая истинная. Внутри цикла <code>break</code> немедленно выходит из него, <code>continue</code> перескакивает к следующей итерации. Комбинация <code>while (true) ... break</code> — стандартный способ «крутимся, пока не случится нужное».' },
        { t: 'code', code: `var i: u32 = 1;
while (true) {
    if (i > 5) {
        break;
    }
    i += 1;
}` },
        { t: 'p', html: 'Печать значений — через <code>{}</code>: <code>std.debug.print("sum = {}\\n", .{sum})</code> подставит значение <code>sum</code> вместо фигурных скобок. Значений может быть несколько: <code>"{} и {}\\n", .{a, b}</code> — они подставляются по порядку.' },
        { t: 'warn', html: 'В Zig нет <code>++</code> и <code>--</code> — инкремент пишется как <code>i += 1;</code>. И помни: в <code>while (true)</code> обязательно должен быть достижимый <code>break</code>, иначе цикл вечный. Код задания не запускается — крутить цикл придётся в голове, шаг за шагом.' },
        { t: 'note', html: 'Условие в while проверяется <b>до</b> тела: если оно ложно сразу, тело не выполнится ни разу. Это помогает в предсказаниях: сначала проверка, потом шаг.' }
      ],
      task: {
        type: 'predict',
        instruction: '<p>Прочитай код и напиши, что он выведет в консоль — по одной строке на каждый вывод, в порядке появления.</p>',
        code: `const std = @import("std");

pub fn main() !void {
    var i: u32 = 1;
    var sum: u32 = 0;

    while (true) {
        if (i > 5) {
            break;
        }
        sum += i;
        i += 1;
    }

    if (sum == 15) {
        std.debug.print("sum = {}\\n", .{sum});
    } else {
        std.debug.print("что-то пошло не так\\n", .{});
    }
}`,
        answer: `sum = 15`
      },
      hints: [
        'Цикл крутится, пока i не превысит 5: суммируются 1 + 2 + 3 + 4 + 5.',
        'Внимательно смотри порядок внутри тела: сначала проверка break, потом sum += i и i += 1.',
        'Если сумма получилась 15, сработает ветка if и напечатает sum = 15.'
      ],
      solution: `sum = 15`
    },

    /* ---------- 4. Функции и ошибки ---------- */
    {
      id: 'zig-4',
      title: 'Функции и ошибки',
      goal: 'Объявлять fn с параметрами и типом возврата, возвращать error.Имя и обрабатывать ошибку через catch',
      xp: 35,
      theory: [
        { t: 'p', html: 'Функции объявляются словом <code>fn</code>: имя, параметры с типами в скобках, тип результата после скобок, тело в фигурных скобках. Возврат — через <code>return</code>. Публичную функцию (доступную из других файлов) помечают <code>pub fn</code>.' },
        { t: 'code', code: `fn double(x: i32) i32 {
    return x * 2;
}` },
        { t: 'h', html: 'Ошибки — часть типа' },
        { t: 'p', html: 'Фирменная черта Zig: ошибки живут прямо в типе результата. Запись <code>!i32</code> читается как «либо i32, либо ошибка» и называется error union. Внутри функции ошибку возвращает конструкция <code>error.Имя</code> — например, <code>error.DivisionByZero</code>. Тип ошибки нельзя потерять: компилятор заставит её обработать.' },
        { t: 'code', code: `fn safeDivide(a: i32, b: i32) !i32 {
    if (b == 0) {
        return error.DivisionByZero;
    }
    return a / b;
}` },
        { t: 'p', html: 'Обрабатывают ошибку через <code>catch</code>: <code>safeDivide(10, 2) catch 0</code> — если функция вернула ошибку, берётся запасное значение 0, иначе — результат. Есть и <code>try</code>: он пробрасывает ошибку наверх, в вызывающую функцию (для этого она тоже должна возвращать error union — поэтому <code>main</code> обычно <code>!void</code>).' },
        { t: 'list', items: [
          '<b>fn имя(x: Тип) Тип</b> — обычная функция;',
          '<b>fn имя(...) !Тип</b> — функция, которая может ошибиться;',
          '<b>return error.Имя;</b> — возврат ошибки;',
          '<b>вызов() catch запасное</b> — обработка на месте.'
        ] },
        { t: 'warn', html: 'Ошибку нельзя молча игнорировать: вызов функции с <code>!</code>-типом без catch или try не скомпилируется. Если ошибка доедет до <code>main</code> необработанной, программа упадёт с паникой и сообщением об ошибке — заметно, но не скрытно.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Объяви две функции: <code>double</code> (принимает <code>x: i32</code>, возвращает <code>x * 2</code>) и <code>safeDivide</code> (принимает два <code>i32</code>, тип результата с ошибкой: делит нацело, а при нулевом делителе возвращает <code>error.DivisionByZero</code>). В <code>main</code> вызови обе и обработай ошибку деления через <code>catch</code>.</p>',
        starter: `const std = @import("std");

// TODO: объяви ниже функцию удвоения и функцию с ошибкой

pub fn main() !void {
    // вызови функции и обработай возможную ошибку
}`,
        rules: [
          { desc: 'Функция double объявлена и что-то возвращает', all: ['\\bfn\\s+double\\s*\\(', '\\breturn\\s+\\S'] },
          { desc: 'Есть функция с ошибкой в типе: fn имя(...) !T (не main)', all: ['\\bfn\\s+(?!main\\b)\\w+\\s*\\([^)]*\\)\\s*!\\s*\\w+'] },
          { desc: 'Ошибка возвращается через error.Имя', all: ['\\berror\\.\\w+'] },
          { desc: 'Ошибка обрабатывается через catch', all: ['\\bcatch\\b'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Обычная функция: fn double(x: i32) i32 { return x * 2; }',
        'Функция с ошибкой: fn safeDivide(a: i32, b: i32) !i32 — внутри return error.DivisionByZero; при b == 0.',
        'В main: const q = safeDivide(10, 2) catch 0; — catch даёт запасное значение.'
      ],
      solution: `const std = @import("std");

fn double(x: i32) i32 {
    return x * 2;
}

fn safeDivide(a: i32, b: i32) !i32 {
    if (b == 0) {
        return error.DivisionByZero;
    }
    return a / b;
}

pub fn main() !void {
    const d = double(21);
    std.debug.print("double(21) = {}\\n", .{d});

    const q = safeDivide(10, 2) catch 0;
    std.debug.print("10 / 2 = {}\\n", .{q});
}`
    },

    /* ---------- 5. Идиомы Zig ---------- */
    {
      id: 'zig-5',
      title: 'Идиомы Zig',
      goal: 'Узнавать defer, errdefer, orelse и идею comptime-вычислений на этапе компиляции',
      xp: 40,
      theory: [
        { t: 'p', html: '<b>defer</b> — отложенное действие: код после defer исполнится при выходе из текущей области видимости — неважно, нормально или по ошибке. Идеальный способ «не забыть почистить за собой»: открыл файл — сразу напиши defer закрыть, и утечка невозможна. Несколько defer в одной области срабатывают в <b>обратном порядке</b>: последний объявленный — первым.' },
        { t: 'code', code: `pub fn main() !void {
    defer std.debug.print("A\\n", .{}); // выполнится последним
    std.debug.print("B\\n", .{});
    defer std.debug.print("C\\n", .{}); // выполнится первым из двух
    std.debug.print("D\\n", .{});
}   // выход из области: C, затем A` },
        { t: 'p', html: '<b>errdefer</b> — вариант defer, который срабатывает только если функция завершилась ошибкой. Типичное применение: аллоцировал память, а дальше что-то не пошло — errdefer освобождает её перед возвратом ошибки.' },
        { t: 'p', html: '<b>orelse</b> распаковывает optional: если значение есть (<code>some</code>) — берём его, если <code>null</code> — подставляем запасное: <code>const name = found orelse "Без имени";</code>. Optional-типы в Zig помечаются знаком вопроса: <code>?i32</code>.' },
        { t: 'p', html: '<b>comptime</b> — концепт, ради которого Zig и придумывался: вычисления на этапе компиляции. Любой код может исполниться во время сборки: <code>comptime</code>-параметры генерируют специализированные версии функций, константы считаются заранее, макросы для этого не нужны — нужен обычный Zig-код, просто запущенный компилятором.' },
        { t: 'list', items: [
          '<b>defer</b> — выполнить при выходе из области (в обратном порядке);',
          '<b>errdefer</b> — то же, но только при ошибке;',
          '<b>orelse</b> — запасное значение для optional;',
          '<b>comptime</b> — вычисления во время компиляции.'
        ] },
        { t: 'warn', html: 'defer привязан к области видимости: defer внутри блока <code>{ ... }</code> или внутри if-ветки сработает при выходе из этого блока, а не из всей функции. В задании ниже считай порядок строк по порядку выхода из main.' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет эта программа (в каком порядке появятся строки)?</p><pre>pub fn main() !void {
    defer std.debug.print("A\\n", .{});
    std.debug.print("B\\n", .{});
    defer std.debug.print("C\\n", .{});
    std.debug.print("D\\n", .{});
}</pre>`,
        options: [
          'A\\nB\\nC\\nD',
          'B\\nD\\nA\\nC',
          'B\\nD\\nC\\nA',
          'B\\nC\\nD\\nA'
        ],
        correct: 2,
        explain: 'Сначала исполняются обычные строки: B, затем D. При выходе из main срабатывают defer в обратном порядке объявления: C объявлен позже A, поэтому сначала C, потом A.',
        solution: 2
      },
      hints: [
        'defer не выполняется там, где написан, — а там, где область видимости заканчивается.',
        'Несколько defer — стек: последний объявленный срабатывает первым.'
      ],
      solution: 2
    },

    /* ---------- 6. 🚀 Проект: калькулятор бюджета ---------- */
    {
      id: 'zig-6',
      title: '🚀 Проект: калькулятор бюджета',
      goal: 'Собрать структуру Item, функцию подсчёта суммы по срезу и ветвление по итогу в main',
      xp: 90,
      theory: [
        { t: 'p', html: 'Финальная практика — калькулятор бюджета поездки: список трат со структурой, функция подсчёта и решение «влезли ли в бюджет». Это типовая связка реального Zig-кода: данные описываются структурой <code>struct</code>, обрабатываются функцией, а результат решает судьбу программы.' },
        { t: 'code', code: `const Item = struct {
    name: []const u8,
    price: i32,
};` },
        { t: 'p', html: '<code>struct</code> — запись с именованными полями: у траты есть название (срез байтов <code>[]const u8</code> — так в Zig выглядит строка) и цена <code>i32</code>. Создаётся значение точечным синтаксисом: <code>.{ .name = "Билет", .price = 4500 }</code>. Список трат — массив <code>[_]Item{ ... }</code>, где <code>[_]</code> просит компилятор посчитать длину самому; в функцию массив передаётся как срез <code>[]const Item</code>.' },
        { t: 'code', code: `fn total(items: []const Item) i32 {
    var sum: i32 = 0;
    for (items) |it| {
        sum += it.price;
    }
    return sum;
}` },
        { t: 'p', html: 'Цикл <code>for (items) |it|</code> — «для каждого элемента»: значение элемента «прилетает» в переменную между вертикальными чертами. Внутри — накопление <code>sum += it.price;</code> и возврат суммы. В main остаётся вызвать <code>total(...)</code>, напечатать результат через <code>{}</code> и сравнить с лимитом бюджета.' },
        { t: 'list', items: [
          '<b>const Item = struct { ... };</b> — структура с полями;',
          '<b>.{ .name = ..., .price = ... }</b> — создание значения;',
          '<b>fn total(items: []const Item) i32</b> — функция со срезом;',
          '<b>for (items) |it|</b> — цикл по элементам.'
        ] },
        { t: 'note', html: 'После зачёта расширяй: добавь поле категории, посчитай отдельную сумму для дорог, верни из функции сразу структуру с итогом и средним. Данные уже в структуре — остаётся добавлять функции.' },
        { t: 'warn', html: 'Сумма в цикле обязана быть <code>var</code> (она меняется!), а вот список трат может оставаться <code>const</code>. Не забудь <code>return sum;</code> — функция без возврата не скомпилируется.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Собери калькулятор бюджета: структуру с целочисленным полем цены (и полем-строкой), функцию, принимающую срез <code>[]const Item</code> и суммирующую цены в цикле <code>for</code> со связыванием <code>|it|</code>, возврат суммы, вывод результата через <code>std.debug.print</code> и сравнение итога с бюджетом через if / else.</p>',
        starter: `const std = @import("std");

// TODO: объяви структуру для траты и функцию подсчёта суммы

pub fn main() !void {
    // создай список трат, посчитай сумму и выведи её
}`,
        rules: [
          { desc: 'Объявлена структура с целочисленным полем', all: ['\\bstruct\\s*\\{', '\\w+\\s*:\\s*i32\\b'] },
          { desc: 'Функция принимает срез: fn имя(items: []const Item) T', all: ['\\bfn\\s+\\w+\\s*\\([^)]*\\[\\]\\s*const[^)]*\\)'] },
          { desc: 'В функции цикл for со связыванием |x|', all: ['\\bfor\\s*\\([^)]*\\)\\s*\\|'] },
          { desc: 'Суммирование через += и возврат результата', all: ['\\+=', '\\breturn\\s+\\S'] },
          { desc: 'Результат выводится через std.debug.print', all: ['std\\.debug\\.print'] },
          { desc: 'Нет пометок TODO', all: ['\\S'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Структура: const Item = struct { name: []const u8, price: i32 };',
        'Функция: fn total(items: []const Item) i32 { var sum: i32 = 0; for (items) |it| { sum += it.price; } return sum; }',
        'В main: массив трат const items = [_]Item{ .{ .name = "Билет", .price = 4500 }, ... }; затем total(items) и печать через std.debug.print("Итого: {}\\n", .{t});'
      ],
      solution: `const std = @import("std");

const Item = struct {
    name: []const u8,
    price: i32,
};

fn total(items: []const Item) i32 {
    var sum: i32 = 0;
    for (items) |it| {
        sum += it.price;
    }
    return sum;
}

pub fn main() !void {
    const items = [_]Item{
        .{ .name = "Билет", .price = 4500 },
        .{ .name = "Отель", .price = 12000 },
        .{ .name = "Еда", .price = 3000 },
    };

    const t = total(items);
    std.debug.print("Итого: {}\\n", .{t});

    if (t > 15000) {
        std.debug.print("Перерасход!\\n", .{});
    } else {
        std.debug.print("В рамках бюджета\\n", .{});
    }
}`
    },

    /* ---------- 7. Структуры и методы: struct + fn с self ---------- */
    {
      id: 'zig-7',
      title: 'Структуры и методы: struct + fn с self',
      goal: 'Объявлять структуры с методами: Self = @This(), pub fn с self: *Self и вызов через точку',
      xp: 50,
      theory: [
        { t: 'p', html: 'Классов в Zig нет — только структуры, но методы есть: достаточно объявить <code>fn</code> внутри тела <code>struct</code>. Первым параметром такой функции обычно идёт <code>self: *Self</code> — указатель на саму структуру, через который метод читает и меняет поля. Вызывается метод через точку, как в языках с классами: <code>c.add(5)</code>.' },
        { t: 'code', code: `const Counter = struct {
    count: i32,

    const Self = @This();

    pub fn add(self: *Self, n: i32) void {
        self.count += n;
    }
};` },
        { t: 'h', html: 'Self = @This()' },
        { t: 'p', html: '<code>@This()</code> — встроенная функция, возвращающая текущий тип; результат по конвенции кладут в константу <code>Self</code>. Слово Self не волшебное — это просто псевдоним, но так пишут почти все Zig-программисты. Если тип переименуют, методы править не придётся: Self всегда означает «именно эту структуру».' },
        { t: 'h', html: 'Почему *Self, а не Self' },
        { t: 'p', html: 'Параметр <code>self: Self</code> передал бы <b>копию</b> структуры: метод менял бы копию, а оригинал оставался бы нетронутым. <code>*Self</code> — указатель: метод работает с оригиналом, поэтому изменения видны снаружи. Если метод только читает данные, можно принять <code>self: Self</code> или <code>self: *const Self</code> — и компилятор проследит, что поля не меняются.' },
        { t: 'p', html: 'Создаётся значение точечным синтаксисом: <code>var c = Counter{ .count = 0 };</code>. Переменную объявляют через <code>var</code>: у const-значения нельзя взять изменяемый указатель, и метод с <code>*Self</code> не скомпилируется. Вызов <code>c.add(5)</code> — сахар для <code>Counter.add(&c, 5)</code>: Zig сам подставит адрес.' },
        { t: 'warn', html: 'Метод — просто функция в пространстве имён структуры: никакого скрытого this у Zig нет, self — обычный параметр с договорённостью об имени. Забыл указать self первым параметром — функция не сможет менять поля. И не забывай pub: без него метод будет виден только внутри файла.' },
        { t: 'note', html: 'Функции без self внутри структуры — тоже норма: <code>pub fn init(n: i32) Self</code> — конвенция конструктора, возвращающего готовое значение. Так в стандартной библиотеке Zig устроены ArrayList, Writer и почти всё остальное.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p>Дополни структуру <code>Counter</code>: объяви метод <code>add</code> с параметром <code>self: *Self</code>, который прибавляет <code>n</code> к полю <code>count</code>. В <code>main</code> вызови <code>c.add(...)</code> дважды с разными числами и выведи итоговое значение через <code>std.debug.print</code>.</p>',
        starter: `const std = @import("std");

const Counter = struct {
    count: i32,

    const Self = @This();

    // TODO: объяви метод add(self: *Self, n: i32) void,
    // прибавляющий n к полю count
};

pub fn main() !void {
    var c = Counter{ .count = 0 };

    // TODO: вызови c.add дважды с разными числами
    // и выведи итоговое значение count
}`, 
        rules: [
          { desc: 'Структура Counter с целочисленным полем объявлена', all: ['\\bconst\\s+Counter\\s*=\\s*struct\\s*\\{', '\\w+\\s*:\\s*i32\\b'] },
          { desc: 'Метод с self: *Self объявлен как pub fn', all: ['\\bpub\\s+fn\\s+\\w+\\s*\\(\\s*self\\s*:\\s*\\*\\s*Self'] },
          { desc: 'Метод меняет поле через self.поле +=', all: ['self\\.\\w+\\s*\\+='] },
          { desc: 'Метод add вызван минимум дважды', all: ['\\.add\\s*\\([^)]*\\)[\\s\\S]*\\.add\\s*\\('] },
          { desc: 'Итог выведен через std.debug.print, заглушек TODO нет', all: ['std\\.debug\\.print'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Метод: pub fn add(self: *Self, n: i32) void { self.count += n; }.',
        'Вызовы: c.add(5); c.add(7); — через точку, счётчик объявляй через var.',
        'Печать: std.debug.print("count = {}\\n", .{c.count});'
      ],
      solution: `const std = @import("std");

const Counter = struct {
    count: i32,

    const Self = @This();

    pub fn add(self: *Self, n: i32) void {
        self.count += n;
    }
};

pub fn main() !void {
    var c = Counter{ .count = 0 };

    c.add(5);
    c.add(7);
    std.debug.print("count = {}\\n", .{c.count});
}`
    },

    /* ---------- 8. Срезы, массивы и for с len ---------- */
    {
      id: 'zig-8',
      title: 'Срезы, массивы и for с len',
      goal: 'Различать массивы [_]u8 и срезы, использовать .len и перебирать элементы через for (…) |x|',
      xp: 45,
      theory: [
        { t: 'p', html: 'Массив — это данные фиксированной длины, известной компилятору: <code>[_]u8{ 10, 20, 30 }</code>. Подчёркивание в квадратных скобках просит компилятор посчитать длину самому — получится тип <code>[3]u8</code>. Длина — часть типа: массивы разной длины это разные типы, и перепутать их не даст компилятор.' },
        { t: 'code', code: `const data = [_]u8{ 10, 20, 30, 40 };

std.debug.print("{}\\n", .{data.len});   // 4` },
        { t: 'h', html: 'Срезы' },
        { t: 'p', html: 'Срез — «окно» в чужие данные: <code>data[1..3]</code> даст элементы с индекса 1 по 2 — конечный индекс не включается. Тип среза — <code>[]u8</code> для изменяемых данных и <code>[]const u8</code> для read-only; у среза тоже есть <code>.len</code>. Именно срезом <code>[]const u8</code> в Zig представляется строка.' },
        { t: 'code', code: `const part = data[1..3];   // 20, 30
std.debug.print("{}\\n", .{part.len});   // 2` },
        { t: 'h', html: 'for по массиву' },
        { t: 'p', html: 'Цикл <code>for (data) |x|</code> перебирает элементы: каждый по очереди попадает в <code>x</code> между вертикальными чертами. Нужен индекс — возьми второй вариант связывания: <code>for (data, 0..) |x, i|</code>. Работает и по массивам, и по срезам — разницы для цикла нет.' },
        { t: 'warn', html: 'Выход за границы Zig ловит сам: обращение <code>data[10]</code> к массиву из четырёх элементов — паника с указанием места, а не тихая порча памяти как в C. То же с срезами: <code>data[0..100]</code> на коротком массиве упадёт. Границы проверяй через <code>.len</code>.' },
        { t: 'note', html: 'Массив копируется при присваивании целиком, срез — лишь взгляд на оригинал: меняя срез, меняешь исходные данные. Это стоит помнить, когда отдаёшь данные в функции: срез дешевле, копия безопаснее.' }
      ],
      task: {
        type: 'fill',
        instruction: '<p>Дополни программу: впиши тип массива с автоподсчётом длины, свойство длины, конечную границу среза (она не включается!) и ключевое слово цикла-перебора.</p>',
        code: `const std = @import("std");

pub fn main() !void {
    const data = {{0}}{ 10, 20, 30, 40 };

    std.debug.print("элементов: {}\\n", .{data{{1}}});

    const part = data[1..{{2}}];   // элементы 20 и 30

    var sum: u32 = 0;
    {{3}} (data) |x| {
        sum += x;
    }
    std.debug.print("сумма: {}\\n", .{sum});
}`, 
        blanks: [
          { answer: '[_]u8' },
          { answer: '.len' },
          { answer: '3' },
          { answer: 'for' }
        ],
        ci: false
      },
      hints: [
        'Массив с автодлиной: [_]u8{ ... } — подчёркивание просит компилятор посчитать.',
        'Длина хранится в .len, а срез data[1..3] не включает элемент 3.',
        'Перебор: for (data) |x| { ... }.'
      ],
      solution: ['[_]u8', '.len', '3', 'for']
    },

    /* ---------- 9. Ошибки: error union !T и try ---------- */
    {
      id: 'zig-9',
      title: 'Ошибки: error union !T и try',
      goal: 'Выбирать между catch (обработка на месте) и try (проброс наверх) для error union !T',
      xp: 50,
      theory: [
        { t: 'p', html: 'Ты уже видел error union: тип <code>!T</code> означает «значение или ошибка», а <code>catch</code> подставляет запасное значение. Второй инструмент — <code>try</code>: он распаковывает значение при успехе, а при ошибке немедленно возвращает ошибку из текущей функции. Это выглядит как отсутствие обработки, но это честная передача ответственности наверх.' },
        { t: 'code', code: `fn check(n: i32) !i32 {
    if (n < 0) return error.Negative;
    return n * 2;
}

const a = try check(5);        // a = 10
const b = check(-3) catch 0;   // b = 0` },
        { t: 'h', html: 'try — проброс наверх' },
        { t: 'p', html: '<code>try x</code> — сокращение для <code>x catch |err| return err</code>: ошибка покидает функцию прямо отсюда. Поэтому try живёт только внутри функции, возвращающей error union — иначе ошибке некуда лететь. Точка входа <code>main() !void</code> как раз для этого: ошибки из неё выпадают уже как паника с трассировкой.' },
        { t: 'h', html: 'catch |err| — ошибка в руках' },
        { t: 'p', html: 'После <code>catch</code> можно поймать само значение ошибки: <code>check(-3) catch |err| 0</code> — внутри err лежит код ошибки. Его можно напечатать через <code>{}</code> или сравнить с конкретной ошибкой: <code>if (err == error.Negative)</code>. А конструкция <code>error{NotFound, Denied}</code> объявляет набор допустимых ошибок — компилятор не даст вернуть ничего сверх списка.' },
        { t: 'warn', html: '<code>try</code> в функции с обычным типом возврата не скомпилируется: ошибке некуда передаваться. И не путай направления: catch — «разбираюсь сам здесь», try — «мне не по силам, решай наверху». Выбор между ними — главное проектное решение обработки ошибок в Zig.' },
        { t: 'note', html: 'В стандартной библиотеке почти каждая операция с файлами и памятью возвращает error union — try и catch встречаются на каждой странице реального кода. Привыкай читать <code>try</code> как знак: «эта функция честно сообщит об ошибке выше».' }
      ],
      task: {
        type: 'quiz',
        instruction: `<p>Что выведет эта программа?</p><pre>const std = @import("std");

fn check(n: i32) !i32 {
    if (n < 0) {
        return error.Negative;
    }
    return n * 2;
}

pub fn main() !void {
    const a = try check(5);
    const b = check(-3) catch 0;
    std.debug.print("{} {}\\n", .{ a, b });
}</pre>`, 
        options: [
          '10 0',
          'программа упадёт: ошибка error.Negative',
          '10 -6',
          '0 0'
        ],
        correct: 0,
        explain: 'check(5) возвращает 10 — try просто распаковывает значение, ошибки нет. check(-3) возвращает error.Negative, но здесь стоит catch 0: ошибка перехвачена на месте и заменена нулём, до паники дело не доходит. А вот если бы и там стоял try, ошибка вылетела бы из main, и программа завершилась бы с сообщением error.Negative.',
        solution: 0
      },
      hints: [
        'try распаковывает значение при успехе и пробрасывает ошибку наверх при неудаче.',
        'catch 0 подменяет ошибку запасным значением — программа продолжает работу.',
        'Посчитай check(5) и check(-3) по отдельности.'
      ],
      solution: 0
    },

    /* ---------- 10. 🚀 Проект: трекер бюджета ---------- */
    {
      id: 'zig-10',
      title: '🚀 Проект: трекер бюджета',
      goal: 'Собрать трекер бюджета: структура Budget с методами add/spend и ошибкой error.OverBudget',
      xp: 110,
      theory: [
        { t: 'p', html: 'Финальный проект — трекер личного бюджета: структура <code>Budget</code> с полем-балансом и два метода: <code>add</code> пополняет счёт, <code>spend</code> тратит — но только если денег хватает, иначе возвращает ошибку <code>error.OverBudget</code>. Это первый проект курса, где данные, методы и обработка ошибок работают как одна система. Так пишут настоящий Zig: методы меняют состояние, ошибки — часть контракта.' },
        { t: 'h', html: 'Структура и методы' },
        { t: 'code', code: `const Budget = struct {
    balance: i32,

    const Self = @This();

    pub fn add(self: *Self, amount: i32) void {
        self.balance += amount;
    }
};` },
        { t: 'p', html: 'Метод <code>add</code> принимает <code>self: *Self</code> — указатель на оригинал, поэтому изменение баланса переживает выход из метода. Переменная бюджета обязана быть <code>var</code>: у const-значения нельзя взять изменяемый указатель, и вызов метода не скомпилируется. Вызовы идут через точку: <code>b.add(30000)</code>.' },
        { t: 'h', html: 'Метод, который может ошибиться' },
        { t: 'code', code: `pub fn spend(self: *Self, amount: i32) !void {
    if (amount > self.balance) {
        return error.OverBudget;
    }
    self.balance -= amount;
}` },
        { t: 'p', html: '<code>spend</code> возвращает <code>!void</code>: либо ничего, либо ошибку — «недостаточно средств» теперь часть типа, потерять её нельзя. В main ошибку перехватываем через <code>catch |err|</code> и печатаем: трата сверх остатка не роняет программу, а просто не проходит. После всех операций печатаем итоговый остаток — отчёт готов.' },
        { t: 'warn', html: 'Соблазн написать <code>try b.spend(...)</code> в main велик, но тогда первая же крупная трата уронит программу с паникой — а мы хотим продолжить и показать остаток. Catch на месте — осознанный выбор для сценария «перерасход не фатален». И помни: необработанная ошибка не пройдёт — язык заставит её перехватить.' },
        { t: 'note', html: 'Развить проект: поле <code>limit</code> и вторая ошибка <code>error.LimitReached</code>, история трат через std.ArrayList, метод <code>reset</code>. Контракт «метод + ошибка в типе» масштабируется на целые библиотеки — так устроен std целиком.' }
      ],
      task: {
        type: 'structure',
        instruction: '<p><b>Проект «Трекер бюджета».</b> Объяви структуру <code>Budget</code> с целочисленным полем-балансом и <code>Self = @This()</code>. Метод <code>add</code> (self: *Self) прибавляет сумму к балансу. Метод <code>spend</code> возвращает <code>!void</code>: если сумма больше баланса — возвращает <code>error.OverBudget</code>, иначе уменьшает баланс. В <code>main</code> создай бюджет, вызови add и spend дважды (одна трата должна превысить остаток), перехвати ошибку через <code>catch</code> и выведи остаток через std.debug.print.</p>',
        starter: `const std = @import("std");

// TODO: трекер бюджета на структуре с методами
// 1. Объяви Budget: поле-баланс (i32) и Self через @This().
// 2. Метод add: прибавляет сумму к балансу (self: *Self).
// 3. Метод spend: если сумма больше баланса — верни ошибку
//    перерасхода, иначе уменьши баланс.

pub fn main() !void {
    // создай бюджет, пополнись, потратись дважды —
    // одна трата должна превысить остаток — и выведи остаток
}`, 
        rules: [
          { desc: 'Структура Budget: поле i32 и Self через @This()', all: ['\\bconst\\s+Budget\\s*=\\s*struct\\s*\\{', '\\w+\\s*:\\s*i32\\b', '\\bconst\\s+Self\\s*=\\s*@This\\s*\\(\\s*\\)\\s*;'] },
          { desc: 'Метод add со self: *Self объявлен', all: ['\\bpub\\s+fn\\s+add\\s*\\(\\s*self\\s*:\\s*\\*\\s*Self'] },
          { desc: 'Метод spend возвращает !void', all: ['\\bpub\\s+fn\\s+spend[^\\r\\n]*!\\s*void'] },
          { desc: 'При нехватке средств возвращается error.OverBudget (с проверкой if)', all: ['error\\.OverBudget', '\\bif\\s*\\('] },
          { desc: 'Методы add и spend вызваны через точку', all: ['\\.add\\s*\\(', '\\.spend\\s*\\('] },
          { desc: 'Ошибка перехвачена catch, итог напечатан, заглушек TODO нет', all: ['\\bcatch\\b', 'std\\.debug\\.print'], none: ['\\bTODO\\b'] }
        ]
      },
      hints: [
        'Каркас: const Budget = struct { balance: i32, const Self = @This(), pub fn add(self: *Self, amount: i32) void { ... } };',
        'spend: pub fn spend(self: *Self, amount: i32) !void — при amount > self.balance верни error.OverBudget, иначе self.balance -= amount;',
        'В main: b.spend(25000) catch |err| { std.debug.print("Ошибка: {}\\n", .{err}); };'
      ],
      solution: `const std = @import("std");

const Budget = struct {
    balance: i32,

    const Self = @This();

    pub fn add(self: *Self, amount: i32) void {
        self.balance += amount;
    }

    pub fn spend(self: *Self, amount: i32) !void {
        if (amount > self.balance) {
            return error.OverBudget;
        }
        self.balance -= amount;
    }
};

pub fn main() !void {
    var b = Budget{ .balance = 0 };

    b.add(30000);
    b.spend(12000) catch |err| {
        std.debug.print("Ошибка: {}\\n", .{err});
    };
    b.spend(25000) catch |err| {
        std.debug.print("Ошибка: {}\\n", .{err});
    };

    std.debug.print("Остаток: {}\\n", .{b.balance});
}`
    }
  ],

  cheats: [
    { title: 'Каркас программы', code: `const std = @import("std");

pub fn main() !void {
    std.debug.print("Привет!\\n", .{});
}
// сборка: zig build-exe hello.zig && ./hello` },
    { title: 'Переменные и типы', list: [
      '<code>const</code> — неизменяемая (по умолчанию)',
      '<code>var</code> — изменяемая (иначе ошибка «never mutated»)',
      '<code>i32</code> / <code>u32</code> — целые со знаком / без',
      '<code>f64</code> — дробное, <code>bool</code> — true / false',
      'строка — срез байтов <code>[]const u8</code>'
    ] },
    { title: 'Условия и циклы', code: `if (i > 5) {
    break;
} else {
    i += 1;     // ++ в Zig нет!
}

while (i < 10) { ... }
while (true) { ... break; }` },
    { title: 'Функции и ошибки', code: `fn double(x: i32) i32 {
    return x * 2;
}

fn safeDivide(a: i32, b: i32) !i32 {
    if (b == 0) return error.DivisionByZero;
    return a / b;
}

const q = safeDivide(10, 2) catch 0;` },
    { title: 'defer / errdefer / orelse', code: `defer f.close();        // при выходе из области
errdefer free(res);     // только при ошибке
const name = found orelse "никто";
const s = comptime 2 + 2;   // посчитал компилятор` },
    { title: 'Частые ошибки', list: [
      'нет ++ и -- — только i += 1',
      'var без изменений — ошибка компиляции',
      'std.debug.print не добавляет \\n сам',
      'ошибку !T нужно обработать (catch / try)',
      'defer внутри блока срабатывает при выходе из блока'
    ] },
    { title: 'Методы структур', code: `const Counter = struct {
    count: i32,
    const Self = @This();

    pub fn init(n: i32) Self {      // конвенция-конструктор
        return Self{ .count = n };
    }
    pub fn inc(self: *Self) void {  // метод меняет поле
        self.count += 1;
    }
};

var c = Counter.init(0);
c.inc();   // сахар для Counter.inc(&c)
// self: *Self — менять; self: Self — копия только на чтение` },
    { title: 'try / catch и наборы ошибок', code: `fn find(id: u32) !u32 {
    if (id == 0) return error.NotFound;
    return id * 10;
}

const a = find(3) catch 0;          // обработка на месте
const b = try find(3);              // проброс наверх (fn !T)
const c = find(0) catch |err| 0;    // err — значение ошибки
// if (err == error.NotFound) { ... }

// error{NotFound, Denied} — набор допустимых ошибок
// try живёт только в функции, возвращающей !T` }
  ]
};
