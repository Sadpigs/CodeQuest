/* ============ CodeQuest — запуск кода и проверка заданий ============ */
(function () {
  'use strict';

  /* ================= Runner: Python (Skulpt) ================= */
  function runPython(code, mode) {
    mode = mode || 'deny';
    return new Promise(function (resolve) {
      var out = '';
      Sk.configure({
        output: function (t) { out += t; },
        read: function (x) {
          if (Sk.builtinFiles === undefined || Sk.builtinFiles['files'][x] === undefined)
            throw 'Модуль не найден: ' + x;
          return Sk.builtinFiles['files'][x];
        },
        __future__: Sk.python3,
        execLimit: 4000,
        inputfun: function () {
          throw new Sk.builtin.RuntimeError('input() отключён в этом задании: используй готовые данные из условия');
        },
        inputfunTakesPrompt: true
      });
      Sk.misceval.asyncToPromise(function () {
        return Sk.importMainWithBody('<stdin>', false, code, true);
      }).then(function () {
        resolve({ ok: true, output: out });
      }).catch(function (e) {
        resolve({ ok: false, output: out, error: String(e && e.message !== undefined ? e.message : e) });
      });
    });
  }

  /* ================= Runner: JavaScript ================= */
  var WORKER_SRC =
    'var fmt=function(a){return a.map(function(x){try{return (typeof x==="object"&&x!==null)?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(" ")};' +
    'self.onmessage=function(e){' +
    'var out="";var cons={log:function(){out+=fmt([].slice.call(arguments))+"\\n"},info:function(){out+=fmt([].slice.call(arguments))+"\\n"},warn:function(){out+=fmt([].slice.call(arguments))+"\\n"},error:function(){out+=fmt([].slice.call(arguments))+"\\n"},table:function(x){out+=fmt([x])+"\\n"},clear:function(){}};' +
    'try{ new Function("console", e.data)(cons); self.postMessage({ok:true,output:out}); }' +
    'catch(err){ self.postMessage({ok:false,output:out,error:String(err)}); }' +
    '};';

  function runJS(code) {
    return new Promise(function (resolve) {
      var done = false;
      var worker = null;
      try {
        var blob = new Blob([WORKER_SRC], { type: 'application/javascript' });
        var url = URL.createObjectURL(blob);
        worker = new Worker(url);
        var to = setTimeout(function () {
          if (done) return; done = true;
          try { worker.terminate(); } catch (e) {}
          resolve({ ok: false, output: '', error: 'Превышено время выполнения (возможно, бесконечный цикл)' });
        }, 3500);
        worker.onmessage = function (ev) {
          if (done) return; done = true;
          clearTimeout(to);
          try { URL.revokeObjectURL(url); } catch (e) {}
          resolve(ev.data);
        };
        worker.onerror = function (ev) {
          if (done) return; done = true;
          clearTimeout(to);
          resolve({ ok: false, output: '', error: (ev && ev.message) ? ev.message : 'Ошибка выполнения' });
        };
        worker.postMessage(code);
      } catch (e) {
        // Фолбэк без Worker
        var out = '';
        var fmt = function (a) { return a.map(function (x) { try { return (typeof x === 'object' && x !== null) ? JSON.stringify(x) : String(x); } catch (e2) { return String(x); } }).join(' '); };
        var cons = { log: function () { out += fmt([].slice.call(arguments)) + '\n'; }, warn: function () { out += fmt([].slice.call(arguments)) + '\n'; }, error: function () { out += fmt([].slice.call(arguments)) + '\n'; }, info: function () { out += fmt([].slice.call(arguments)) + '\n'; } };
        try {
          new Function('console', code)(cons);
          resolve({ ok: true, output: out });
        } catch (err) { resolve({ ok: false, output: out, error: String(err) }); }
      }
    });
  }

  /* ================= Runner: Brainfuck (настоящий интерпретатор) ================= */
  function runBF(code) {
    return new Promise(function (resolve) {
      var out = '', tape = new Array(30000).fill(0), ptr = 0, ip = 0, steps = 0, LIMIT = 5000000;
      // убираем всё, что не является командой BF (комментарии любым текстом — они игнорируются)
      var src = String(code).replace(/[^+\-<>\[\].,]/g, '');
      // пары скобок
      var pairs = [], stack = [];
      for (var i = 0; i < src.length; i++) {
        if (src[i] === '[') stack.push(i);
        else if (src[i] === ']') {
          if (!stack.length) return resolve({ ok: false, output: '', error: 'Непарная закрывающая скобка ]' });
          var open = stack.pop(); pairs[open] = i; pairs[i] = open;
        }
      }
      if (stack.length) return resolve({ ok: false, output: '', error: 'Непарная открывающая скобка [' });
      try {
        while (ip < src.length) {
          if (++steps > LIMIT) return resolve({ ok: false, output: out, error: 'Превышен лимит шагов (возможно, бесконечный цикл)' });
          switch (src[ip]) {
            case '+': tape[ptr] = (tape[ptr] + 1) & 255; break;
            case '-': tape[ptr] = (tape[ptr] + 255) & 255; break;
            case '>': ptr++; if (ptr >= tape.length) return resolve({ ok: false, output: out, error: 'Выход за пределы ленты' }); break;
            case '<': ptr--; if (ptr < 0) return resolve({ ok: false, output: out, error: 'Выход за левый край ленты' }); break;
            case '.': out += String.fromCharCode(tape[ptr]); break;
            case ',': tape[ptr] = 0; break; // ввод отключён
            case '[': if (!tape[ptr]) ip = pairs[ip]; break;
            case ']': if (tape[ptr]) ip = pairs[ip]; break;
          }
          ip++;
        }
        resolve({ ok: true, output: out });
      } catch (e) { resolve({ ok: false, output: out, error: String(e) }); }
    });
  }

  CQ.Runner = {
    python: runPython,
    js: runJS,
    brainfuck: runBF,
    run: function (lang, code) {
      if (lang === 'python') return runPython(code);
      if (lang === 'brainfuck') return runBF(code);
      return runJS(code);
    }
  };

  /* ================= Проверка типов заданий ================= */
  function normJoin(lines) { return CQ.normOut(lines).join('\n'); }

  function codeResultFromRun(run, task) {
    if (!run.ok) {
      return { pass: false, error: run.error, output: run.output,
        tests: [{ name: 'Код выполняется без ошибок', pass: false, detail: String(run.error) }] };
    }
    var expLines = normJoin(task.expected);
    var gotLines = normJoin(run.output);
    var pass = expLines === gotLines;
    var tests = [{ name: 'Вывод совпадает с ожидаемым', pass: pass,
      detail: pass ? 'Совпадает' : 'Ожидалось:\n' + expLines + '\n\nПолучено:\n' + gotLines }];
    if (task.mustInclude && task.mustInclude.length) {
      task.mustInclude.forEach(function (s) {
        var ok = run.output.indexOf(s) !== -1;
        tests.push({ name: 'Вывод содержит «' + s + '»', pass: ok });
        if (!ok) pass = false;
      });
    }
    return { pass: pass, output: run.output, tests: tests };
  }

  var Types = {};

  /* --- stdout: напиши код, вывод сравнивается --- */
  Types.stdout = {
    render: function (mount, task, ctx) {
      ctx.ui = {};
      var ed = CQ.Editor(mount, { lang: ctx.lang, value: task.starter || '', onRun: function () { ctx.onRun && ctx.onRun(); } });
      ctx.ui.editor = ed;
      ctx.getCode = function () { return ed.get(); };
    },
    check: function (task, ctx, codeOverride) {
      var code = codeOverride != null ? codeOverride : ctx.getCode();
      return CQ.Runner.run(ctx.lang, code).then(function (run) {
        return codeResultFromRun(run, task);
      });
    }
  };

  /* --- function: функция проверяется тестами --- */
  Types.function = {
    render: function (mount, task, ctx) {
      ctx.ui = {};
      var ed = CQ.Editor(mount, { lang: ctx.lang, value: task.starter || '', onRun: function () { ctx.onRun && ctx.onRun(); } });
      ctx.ui.editor = ed;
      ctx.getCode = function () { return ed.get(); };
    },
    check: function (task, ctx, codeOverride) {
      var code = codeOverride != null ? codeOverride : ctx.getCode();
      if (ctx.lang === 'js') return checkFnJs(task, code);
      return checkFnPy(task, code);
    }
  };

  function checkFnJs(task, code) {
    return new Promise(function (resolve) {
      var fn;
      try {
        var factory = new Function(code + '\n;return (typeof ' + task.fnName + ' !== "undefined") ? ' + task.fnName + ' : undefined;');
        fn = factory();
      } catch (e) {
        return resolve({ pass: false, error: String(e), tests: [{ name: 'Код выполняется без ошибок', pass: false, detail: String(e) }] });
      }
      if (typeof fn !== 'function') {
        return resolve({ pass: false, error: 'Функция ' + task.fnName + ' не найдена', tests: [{ name: 'Функция ' + task.fnName + ' объявлена', pass: false }] });
      }
      var tests = [], pass = true;
      var i = 0;
      function next() {
        if (i >= task.tests.length) {
          return resolve({ pass: pass, tests: tests });
        }
        var t = task.tests[i++];
        var args;
        try { args = new Function('return [' + t.args + ']')(); }
        catch (e) { args = []; }
        var got;
        try { got = fn.apply(null, args); }
        catch (e) {
          tests.push({ name: t.name || (task.fnName + '(' + t.args + ')'), pass: false, detail: 'Ошибка: ' + e });
          pass = false; return next();
        }
        var ok = (typeof t.expected === 'number' && typeof got === 'number' && isNaN(t.expected) && isNaN(got)) || CQ.deepEqual(got, t.expected);
        tests.push({ name: t.name || (task.fnName + '(' + t.args + ')'), pass: ok,
          detail: ok ? 'Результат: ' + JSON.stringify(got) : 'Ожидалось: ' + JSON.stringify(t.expected) + ', получено: ' + JSON.stringify(got) });
        if (!ok) pass = false;
        next();
      }
      next();
    });
  }

  function checkFnPy(task, code) {
    var glue = '\n';
    task.tests.forEach(function (t, i) {
      glue += 'try:\n    print("@@T' + i + '@@" + repr(' + task.fnName + '(' + t.args + ')))\n';
      glue += 'except Exception as _e:\n    print("@@T' + i + '@@ERR:" + str(_e))\n';
    });
    return runPython(code + glue).then(function (run) {
      if (!run.ok && !run.output) {
        return { pass: false, error: run.error, tests: [{ name: 'Код выполняется без ошибок', pass: false, detail: String(run.error) }] };
      }
      var lines = String(run.output || '').split('\n');
      var results = {};
      lines.forEach(function (l) {
        var m = l.match(/^@@T(\d+)@@(.*)$/);
        if (m) results[m[1]] = m[2];
      });
      var tests = [], pass = true;
      if (results['0'] === undefined && run.error && Object.keys(results).length === 0) {
        return { pass: false, error: run.error, tests: [{ name: 'Код выполняется без ошибок', pass: false, detail: String(run.error) }] };
      }
      task.tests.forEach(function (t, i) {
        var got = results[String(i)];
        if (got === undefined) { tests.push({ name: t.name || (task.fnName + '(' + t.args + ')'), pass: false, detail: 'Тест не выполнен' }); pass = false; return; }
        if (/^ERR:/.test(got)) { tests.push({ name: t.name || (task.fnName + '(' + t.args + ')'), pass: false, detail: 'Ошибка: ' + got.slice(4) }); pass = false; return; }
        var ok = got === t.expected;
        tests.push({ name: t.name || (task.fnName + '(' + t.args + ')'), pass: ok,
          detail: ok ? 'Результат: ' + got : 'Ожидалось: ' + t.expected + ', получено: ' + got });
        if (!ok) pass = false;
      });
      return { pass: pass, output: run.output, tests: tests };
    });
  }

  /* --- quiz --- */
  Types.quiz = {
    render: function (mount, task, ctx) {
      ctx.ui = { sel: null, buttons: [] };
      var box = document.createElement('div');
      task.options.forEach(function (opt, i) {
        var b = document.createElement('button');
        b.className = 'quiz-opt';
        b.innerHTML = '<b>' + String.fromCharCode(65 + i) + '.</b> ' + CQ.esc(opt);
        b.onclick = function () {
          ctx.ui.sel = i;
          ctx.ui.buttons.forEach(function (x, j) { x.classList.toggle('sel', j === i); x.classList.remove('right', 'wrong'); });
        };
        box.appendChild(b);
        ctx.ui.buttons.push(b);
      });
      mount.appendChild(box);
      ctx.getAnswer = function () { return ctx.ui.sel; };
    },
    check: function (task, ctx, ansOverride) {
      var ans = ansOverride != null ? ansOverride : ctx.getAnswer();
      var tests = [], pass = ans === task.correct;
      if (ans == null) return Promise.resolve({ pass: false, error: 'Выбери вариант ответа' });
      if (ctx && ctx.ui && ctx.ui.buttons) ctx.ui.buttons.forEach(function (b, j) { b.classList.remove('right', 'wrong'); if (j === task.correct) b.classList.add('right'); else if (j === ans && !pass) b.classList.add('wrong'); });
      tests.push({ name: 'Ответ правильный', pass: pass, detail: pass ? 'Верно!' : task.explain || '' });
      return Promise.resolve({ pass: pass, tests: tests });
    }
  };

  /* --- predict: предскажи вывод --- */
  Types.predict = {
    render: function (mount, task, ctx) {
      ctx.ui = {};
      var codeBox = document.createElement('div');
      codeBox.className = 'tb-code';
      codeBox.innerHTML = '<pre>' + CQ.highlight(task.code, ctx.lang) + '</pre>';
      mount.appendChild(codeBox);
      var ta = document.createElement('textarea');
      ta.className = 'predict-in';
      ta.placeholder = 'Что выведет этот код? Напиши вывод сюда...';
      mount.appendChild(ta);
      ctx.getAnswer = function () { return ta.value; };
    },
    check: function (task, ctx, ansOverride) {
      var ans = ansOverride != null ? ansOverride : ctx.getAnswer();
      if (!String(ans || '').trim()) return Promise.resolve({ pass: false, error: 'Напиши, что выведет код' });
      var exp = normJoin(task.answer), got = normJoin(ans);
      var pass = exp === got;
      return Promise.resolve({ pass: pass, tests: [{ name: 'Вывод предсказан верно', pass: pass,
        detail: pass ? 'Именно так!' : 'Правильный вывод:\n' + exp + '\n\nТвой ответ:\n' + got }] });
    }
  };

  /* --- fill: вставь пропуски --- */
  Types.fill = {
    render: function (mount, task, ctx) {
      ctx.ui = { inputs: [] };
      var parts = String(task.code).split(/\{\{\s*\d+\s*\}\}/);
      var box = document.createElement('div');
      box.className = 'fill-code';
      parts.forEach(function (p, i) {
        box.appendChild(document.createTextNode(''));
        var span = document.createElement('span');
        span.innerHTML = CQ.esc(p).replace(/\n/g, '<br>') || '&nbsp;';
        if (i > 0) span.innerHTML = span.innerHTML; // part text
        box.appendChild(span);
        if (i < parts.length - 1) {
          var inp = document.createElement('input');
          inp.className = 'fill-blank';
          inp.spellcheck = false;
          inp.style.width = Math.max(70, String((task.blanks[i] && task.blanks[i].answer) || '').length * 9 + 40) + 'px';
          box.appendChild(inp);
          ctx.ui.inputs.push(inp);
        }
      });
      mount.appendChild(box);
      ctx.getAnswer = function () { return ctx.ui.inputs.map(function (i) { return i.value; }); };
    },
    check: function (task, ctx, ansOverride) {
      var vals = ansOverride != null ? ansOverride : ctx.getAnswer();
      var tests = [], pass = true;
      task.blanks.forEach(function (b, i) {
        var got = String(vals[i] == null ? '' : vals[i]).trim();
        var candidates = [b.answer].concat(b.alt || []);
        var ok = candidates.some(function (c) {
          if (b.ci) return got.toLowerCase() === String(c).trim().toLowerCase();
          return got === String(c).trim();
        });
        tests.push({ name: 'Пропуск #' + (i + 1), pass: ok, detail: ok ? '«' + got + '» — верно' : 'Ожидалось: «' + b.answer + '»' });
        if (!ok) pass = false;
      });
      return Promise.resolve({ pass: pass, tests: tests });
    }
  };

  /* --- structure: структурные правила (C++/Java/C#/Go/Rust) --- */
  function compileRules(rules) {
    return rules.map(function (r) {
      var c = { desc: r.desc };
      try {
        c.all = (r.all || []).map(function (x) { return new RegExp(x, 'm'); });
        c.any = (r.any || []).map(function (x) { return new RegExp(x, 'm'); });
        c.none = (r.none || []).map(function (x) { return new RegExp(x, 'm'); });
        c.bad = null;
      } catch (e) { c.bad = String(e); }
      return c;
    });
  }
  function runRules(compiled, text) {
    var tests = [], pass = true;
    compiled.forEach(function (c) {
      if (c.bad) { tests.push({ name: c.desc, pass: false, detail: 'Ошибка правила: ' + c.bad }); pass = false; return; }
      var fail = null;
      for (var i = 0; i < c.all.length; i++) if (!c.all[i].test(text)) { fail = 'В коде нет требуемого фрагмента'; break; }
      if (!fail) for (i = 0; i < c.any.length; i++) { if (c.any[i].test(text)) { fail = null; break; } fail = 'Не найден ни один из допустимых вариантов'; }
      if (!fail) for (i = 0; i < c.none.length; i++) if (c.none[i].test(text)) { fail = 'Найден запрещённый фрагмент'; break; }
      tests.push({ name: c.desc, pass: !fail, detail: fail || 'OK' });
      if (fail) pass = false;
    });
    return { pass: pass, tests: tests };
  }

  Types.structure = {
    render: function (mount, task, ctx) {
      ctx.ui = {};
      var ed = CQ.Editor(mount, { lang: ctx.lang, value: task.starter || '', height: 200, onRun: function () { ctx.onRun && ctx.onRun(); } });
      ctx.ui.editor = ed;
      ctx.getCode = function () { return ed.get(); };
      if (task.note) {
        var n = document.createElement('div');
        n.className = 'tb-note';
        n.innerHTML = CQ.esc(task.note).replace(/\n/g, '<br>');
        mount.insertBefore(n, mount.firstChild);
      }
    },
    check: function (task, ctx, codeOverride) {
      var code = codeOverride != null ? codeOverride : ctx.getCode();
      if (!code.trim()) return Promise.resolve({ pass: false, error: 'Напиши код' });
      return Promise.resolve(runRules(compileRules(task.rules), code));
    }
  };

  /* --- sql: проверка запроса --- */
  Types.sql = {
    render: function (mount, task, ctx) {
      ctx.ui = {};
      if (task.schema) {
        var sch = document.createElement('div');
        sch.className = 'tb-note';
        sch.innerHTML = '<b>Схема БД:</b><br>' + task.schema.map(function (t) { return '<code>' + CQ.esc(t) + '</code>'; }).join('<br>');
        mount.appendChild(sch);
      }
      var ed = CQ.Editor(mount, { lang: 'sql', value: task.starter || '', height: 130, onRun: function () { ctx.onRun && ctx.onRun(); } });
      ctx.ui.editor = ed;
      ctx.getCode = function () { return ed.get(); };
    },
    check: function (task, ctx, codeOverride) {
      var code = codeOverride != null ? codeOverride : ctx.getCode();
      if (!String(code).trim()) return Promise.resolve({ pass: false, error: 'Напиши SQL-запрос' });
      var q = CQ.normQuery(code);
      var rules = [{ desc: 'Запрос соответствует заданию', all: task.must || [], any: [], none: task.mustNot || [] }];
      return Promise.resolve(runRules(compileRules(rules), q));
    }
  };

  /* --- html: живое превью + DOM-проверки --- */
  Types.html = {
    render: function (mount, task, ctx) {
      ctx.ui = {};
      var ed = CQ.Editor(mount, { lang: 'html', value: task.starter || '', height: 230, onRun: function () { ctx.onRun && ctx.onRun(); } });
      ctx.ui.editor = ed;
      ctx.getCode = function () { return ed.get(); };
      var prevWrap = document.createElement('div');
      prevWrap.innerHTML = '<div class="tag" style="margin:10px 0 6px">👁 Живое превью</div>';
      var fr = document.createElement('iframe');
      fr.className = 'preview-frame';
      fr.setAttribute('sandbox', 'allow-same-origin');
      fr.srcdoc = task.starter || '';
      prevWrap.appendChild(fr);
      mount.appendChild(prevWrap);
      ctx.ui.frame = fr;
      ctx.preview = function (code) { fr.srcdoc = code; };
      ctx.getFrameDoc = function () { try { return fr.contentDocument; } catch (e) { return null; } };
    },
    check: function (task, ctx, codeOverride) {
      var code = codeOverride != null ? codeOverride : ctx.getCode();
      ctx.preview(code);
      return new Promise(function (resolve) {
        setTimeout(function () {
          var doc = ctx.getFrameDoc();
          if (!doc) return resolve({ pass: false, error: 'Не удалось открыть превью' });
          var tests = [], pass = true;
          (task.domRules || []).forEach(function (r) {
            var els = [];
            try { els = Array.prototype.slice.call(doc.querySelectorAll(r.selector)); } catch (e) { els = []; }
            var ok = true, detail = 'OK';
            if (r.count != null && els.length !== r.count) { ok = false; detail = 'Найдено элементов: ' + els.length + ', ожидалось: ' + r.count; }
            if (ok && r.text != null) {
              if (!els.length) { ok = false; detail = 'Элемент не найден: ' + r.selector; }
              else if (els.map(function (e) { return (e.textContent || '').trim(); }).indexOf(r.text.trim()) === -1) {
                ok = false; detail = 'Текст не совпадает. Ожидалось: «' + r.text + '»';
              }
            }
            if (ok && r.contains != null) {
              if (!els.length) { ok = false; detail = 'Элемент не найден: ' + r.selector; }
              else if (!els.some(function (e) { return (e.textContent || '').indexOf(r.contains) !== -1; })) { ok = false; detail = 'Не найден текст «' + r.contains + '»'; }
            }
            if (ok && r.attr) {
              if (!els.length) { ok = false; detail = 'Элемент не найден: ' + r.selector; }
              else if (!els.some(function (e) { return e.getAttribute(r.attr.name) === r.attr.value; })) {
                ok = false; detail = 'Нужен атрибут ' + r.attr.name + '="' + r.attr.value + '"';
              }
            }
            if (ok && r.style) {
              if (!els.length) { ok = false; detail = 'Элемент не найден: ' + r.selector; }
              else {
                var cs = doc.defaultView.getComputedStyle(els[0]);
                var got = (cs[r.style.prop] || '').toLowerCase().replace(/\s+/g, ' ');
                var want = String(r.style.value).toLowerCase().replace(/\s+/g, ' ');
                if (got !== want) { ok = false; detail = 'Свойство ' + r.style.prop + ': ожидалось «' + want + '», получено «' + got + '»'; }
              }
            }
            tests.push({ name: r.desc || ('Проверка: ' + r.selector), pass: ok, detail: detail });
            if (!ok) pass = false;
          });
          resolve({ pass: pass, tests: tests });
        }, 350);
      });
    }
  };

  /* ================= Диспетчер ================= */
  CQ.Checker = {
    types: Types,
    // Проверка текущего ответа из UI
    check: function (task, ctx) {
      CQ.Store.bump('checks');
      var t = Types[task.type];
      if (!t) return Promise.resolve({ pass: false, error: 'Неизвестный тип задания: ' + task.type });
      return Promise.resolve().then(function () { return t.check(task, ctx); });
    },
    // Самопроверка решением (для автотестов). ctx можно передать для html-задач.
    checkSolution: function (lang, task, solution, ctxOverride) {
      var t = Types[task.type];
      if (!t) return Promise.resolve({ pass: false, error: 'unknown type' });
      if (task.type === 'quiz') return t.check(task, null, solution);
      if (task.type === 'fill') return t.check(task, null, solution);
      if (task.type === 'predict') return t.check(task, null, solution);
      var ctx = ctxOverride || { lang: lang, getAnswer: function () { return ''; }, ui: {}, preview: function () {}, getFrameDoc: function () { return null; } };
      return t.check(task, ctx, solution);
    }
  };
})();
