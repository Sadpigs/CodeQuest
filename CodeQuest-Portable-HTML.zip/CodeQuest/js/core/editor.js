/* ============ CodeQuest — редактор кода (textarea + подсветка + гуттер) ============ */
(function () {
  'use strict';

  // opts: {lang, value, height, onChange}
  CQ.Editor = function (mount, opts) {
    opts = opts || {};
    var lang = opts.lang || 'python';
    var wrap = document.createElement('div');
    wrap.className = 'editor-wrap';
    wrap.innerHTML =
      '<div class="editor-top"><span class="dot"></span><span class="dot"></span><span class="dot"></span>' +
      '<span class="et-lang">' + CQ.esc(lang) + '</span></div>' +
      '<div class="editor-body">' +
      '<div class="gutter">1</div>' +
      '<div class="ed-stack"><pre class="ed-hl"></pre>' +
      '<textarea class="ed-ta" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off"></textarea></div>' +
      '</div>';
    if (opts.height) wrap.querySelector('.editor-body').style.minHeight = opts.height + 'px';

    var ta = wrap.querySelector('.ed-ta');
    var hl = wrap.querySelector('.ed-hl');
    var gut = wrap.querySelector('.gutter');
    ta.value = opts.value || '';

    /* Оптимизация под слабые ПК: подсветка и гуттер обновляются с лёгким
       дебаунсом (быстрый набор не пересчитывает regex на каждую букву).
       Первый символ после паузы подсвечивается мгновенно, при бурст-наборе
       рендер схлопывается в один. Сам ввод (textarea) всегда мгновенный. */
    var renderTimer = null, lastRender = 0;
    function render() {
      if (renderTimer) { clearTimeout(renderTimer); renderTimer = null; }
      lastRender = Date.now();
      var v = ta.value;
      hl.innerHTML = CQ.highlight(v, lang) + '\n';
      var n = v.split('\n').length;
      var g = '';
      for (var i = 1; i <= n; i++) g += i + '\n';
      gut.textContent = g;
      syncScroll();
    }
    function scheduleRender() {
      if (Date.now() - lastRender > 160) { render(); return; }
      if (renderTimer) return;
      renderTimer = setTimeout(render, 120);
    }
    function syncScroll() {
      hl.scrollTop = ta.scrollTop;
      hl.scrollLeft = ta.scrollLeft;
      gut.scrollTop = ta.scrollTop;
    }
    ta.addEventListener('input', function () { scheduleRender(); if (opts.onChange) opts.onChange(ta.value); });
    ta.addEventListener('scroll', syncScroll);
    ta.addEventListener('keydown', function (e) {
      if (e.key === 'Tab') {
        e.preventDefault();
        var s = ta.selectionStart, epos = ta.selectionEnd;
        ta.value = ta.value.slice(0, s) + '    ' + ta.value.slice(epos);
        ta.selectionStart = ta.selectionEnd = s + 4;
        render(); if (opts.onChange) opts.onChange(ta.value);
      }
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        if (opts.onRun) opts.onRun();
      }
    });
    render();

    mount.appendChild(wrap);

    return {
      el: wrap,
      get: function () { return ta.value; },
      set: function (v) { ta.value = v; render(); },
      focus: function () { ta.focus(); }
    };
  };
})();
