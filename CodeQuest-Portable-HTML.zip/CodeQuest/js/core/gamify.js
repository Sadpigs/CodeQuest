/* ============ CodeQuest — геймификация: звания, ачивки, серия ============ */
(function () {
  'use strict';

  var RANKS = [
    { xp: 0, name: 'Новичок', ico: '🥚' },
    { xp: 300, name: 'Ученик', ico: '🌱' },
    { xp: 800, name: 'Кодер', ico: '💻' },
    { xp: 1600, name: 'Боец', ico: '⚔️' },
    { xp: 3000, name: 'Мастер', ico: '🥋' },
    { xp: 5000, name: 'Гуру', ico: '🧙' },
    { xp: 8000, name: 'Легенда', ico: '🐉' },
    { xp: 12000, name: 'Мифический', ico: '🌌' }
  ];

  var ACH = [
    { id: 'first-step', ico: '🐣', name: 'Первый шаг', desc: 'Пройди первый уровень' },
    { id: 'ten-levels', ico: '🔟', name: 'Разогрев', desc: 'Пройди 10 уровней' },
    { id: 'quarter', ico: '🚀', name: 'На разгоне', desc: 'Пройди 25 уровней' },
    { id: 'fifty', ico: '🏛️', name: 'Полсотни', desc: 'Пройди 50 уровней' },
    { id: 'hundred', ico: '💯', name: 'Сотня!', desc: 'Пройди 100 уровней' },
    { id: 'two-hundred', ico: '🎓', name: 'Двести!', desc: 'Пройди 200 уровней' },
    { id: 'four-hundred', ico: '🧨', name: 'Взрывной темп', desc: 'Пройди 400 уровней' },
    { id: 'six-hundred', ico: '🚁', name: 'На орбите', desc: 'Пройди 600 уровней' },
    { id: 'eight-hundred', ico: '🌠', name: 'Метеор', desc: 'Пройди 800 уровней' },
    { id: 'all-levels', ico: '👑', name: 'Полное очищение', desc: 'Пройди все уровни всех языков' },
    { id: 'first-lang', ico: '🥇', name: 'Первый язык', desc: 'Пройди все уровни одного языка' },
    { id: 'polyglot3', ico: '🗣️', name: 'Полиглот', desc: 'Освой 3 языка полностью' },
    { id: 'polyglot5', ico: '🎭', name: 'Пентаглот', desc: 'Освой 5 языков полностью' },
    { id: 'polyglot10', ico: '🏔️', name: 'Вершина Полиглота', desc: 'Освой 10 языков полностью' },
    { id: 'polyglot-start10', ico: '🌍', name: 'Десятиязычие', desc: 'Начни 10 разных языков (первый уровень)' },
    { id: 'polyglot-start25', ico: '🗺️', name: 'Хождение по мирам', desc: 'Начни 25 разных языков' },
    { id: 'polyglot-start50', ico: '🧭', name: 'Полсотни языков', desc: 'Начни 50 разных языков' },
    { id: 'polyglot-start75', ico: '🛰️', name: 'Энциклопедист', desc: 'Начни 75 разных языков' },
    { id: 'polyglot-start100', ico: '🌌', name: 'Все сто!', desc: 'Начни все 100 языков академии' },
    { id: 'esoteric', ico: '🤯', name: 'Безумный гений', desc: 'Пройди весь курс Brainfuck' },
    { id: 'esoteric-all', ico: '🌀', name: 'Повелитель хаоса', desc: 'Пройди все эзотерические языки: Brainfuck, LOLCODE и Shakespeare' },
    { id: 'streak3', ico: '🔥', name: 'Три дня подряд', desc: 'Серия из 3 дней' },
    { id: 'streak7', ico: '☄️', name: 'Неделя силы', desc: 'Серия из 7 дней' },
    { id: 'streak14', ico: '🌡️', name: 'Две недели огня', desc: 'Серия из 14 дней' },
    { id: 'streak30', ico: '🌋', name: 'Железная воля', desc: 'Серия из 30 дней' },
    { id: 'streak60', ico: '💥', name: 'Два месяца жарa', desc: 'Серия из 60 дней' },
    { id: 'streak100', ico: '🏔️', name: 'Сотня дней', desc: 'Серия из 100 дней — легенда' },
    { id: 'xp1000', ico: '🎖️', name: 'Тысяча XP', desc: 'Набери 1000 XP' },
    { id: 'xp5000', ico: '🏆', name: 'Пять тысяч', desc: 'Набери 5000 XP' },
    { id: 'xp15000', ico: '💎', name: 'Коллекционер XP', desc: 'Набери 15000 XP' },
    { id: 'xp30000', ico: '👑', name: 'Тридцать тысяч', desc: 'Набери 30000 XP' },
    { id: 'xp50000', ico: '🌟', name: 'Сверхновая', desc: 'Набери 50000 XP' },
    { id: 'no-hints-10', ico: '🧠', name: 'Своим умом', desc: '10 уровней без подсказок' },
    { id: 'no-hints-50', ico: '🦾', name: 'Мозголом', desc: '50 уровней без подсказок' },
    { id: 'writer', ico: '📝', name: 'Летописец', desc: 'Создай 5 заметок' },
    { id: 'writer20', ico: '📚', name: 'Библиотекарь', desc: 'Создай 20 заметок' },
    { id: 'night-owl', ico: '🦉', name: 'Ночная сова', desc: 'Пройди уровень с 00:00 до 05:00' },
    { id: 'early-bird', ico: '🌅', name: 'Ранняя пташка', desc: 'Пройди уровень с 05:00 до 08:00' },
    { id: 'weekend', ico: '🏖️', name: 'Выходной герой', desc: 'Пройди уровень в субботу или воскресенье' },
    { id: 'sandboxer', ico: '🧪', name: 'Алхимик', desc: 'Запусти код в песочнице 10 раз' },
    { id: 'sandbox50', ico: '⚗️', name: 'Алхимик-виртуоз', desc: 'Запусти код в песочнице 50 раз' },
    { id: 'runner', ico: '🏃', name: 'Исполнитель', desc: '100 запусков кода в уроках' },
    { id: 'toolmaster', ico: '🧰', name: 'Инструменталист', desc: 'Используй 8 разных встроенных инструментов' },
    { id: 'toolmaster-all', ico: '🧑‍🔧', name: 'Мастер инструментов', desc: 'Используй 16 разных встроенных инструментов' },
    { id: 'deep-30', ico: '🎓', name: 'Специалист', desc: 'Пройди 30 уровней одного языка' },
    { id: 'path-1', ico: '🗺️', name: 'Первый маршрут', desc: 'Пройди траекторию обучения полностью' },
    { id: 'path-3', ico: '🧭', name: 'Профессионал', desc: 'Пройди три траектории обучения' },
    { id: 'path-all', ico: '🌍', name: 'Картограф карьеры', desc: 'Пройди все траектории обучения' },
    { id: 'explorer', ico: '🗺️', name: 'Исследователь', desc: 'Загляни во все разделы приложения' },
    { id: 'cheater', ico: '📋', name: 'Шпаргалочник', desc: 'Открой шпаргалки по любому языку' }
  ];

  function rankOf(xp) {
    var r = RANKS[0];
    for (var i = 0; i < RANKS.length; i++) if (xp >= RANKS[i].xp) r = RANKS[i];
    return r;
  }
  function nextRank(xp) {
    for (var i = 0; i < RANKS.length; i++) if (xp < RANKS[i].xp) return RANKS[i];
    return null;
  }

  // проверка условий ачивок; возвращает список только что выданных
  function checkAll() {
    var s = CQ.Store.get();
    var granted = [];
    function give(id) { if (CQ.Store.grant(id)) granted.push(ACH.find(function (a) { return a.id === id; })); }

    var doneCount = Object.keys(s.levels).filter(function (k) { return s.levels[k].done; }).length;
    if (doneCount >= 1) give('first-step');
    if (doneCount >= 10) give('ten-levels');
    if (doneCount >= 25) give('quarter');
    if (doneCount >= 50) give('fifty');
    if (doneCount >= 100) give('hundred');
    if (doneCount >= 200) give('two-hundred');
    if (doneCount >= 400) give('four-hundred');
    if (doneCount >= 600) give('six-hundred');
    if (doneCount >= 800) give('eight-hundred');

    var langs = CQ.LANGS || {};
    var langIds = Object.keys(langs);
    var totalLevels = 0, doneLangs = 0, startedLangs = 0;
    langIds.forEach(function (lid) {
      var lv = langs[lid].levels || [];
      totalLevels += lv.length;
      var d = lv.filter(function (l) { return CQ.Store.isDone(l.id); }).length;
      if (lv.length && d === lv.length) doneLangs++;
      if (lv.length && d > 0) startedLangs++;
    });
    if (doneLangs >= 1) give('first-lang');
    if (doneLangs >= 3) give('polyglot3');
    if (doneLangs >= 5) give('polyglot5');
    if (doneLangs >= 10) give('polyglot10');
    if (startedLangs >= 10) give('polyglot-start10');
    if (startedLangs >= 25) give('polyglot-start25');
    if (startedLangs >= 50) give('polyglot-start50');
    if (startedLangs >= 75) give('polyglot-start75');
    if (startedLangs >= 100) give('polyglot-start100');
    if (langs.brainfuck && (langs.brainfuck.levels || []).length &&
        langs.brainfuck.levels.every(function (l) { return CQ.Store.isDone(l.id); })) give('esoteric');
    var eso = ['brainfuck', 'lolcode', 'shakespeare'].filter(function (lid) {
      return langs[lid] && (langs[lid].levels || []).length &&
             langs[lid].levels.every(function (l) { return CQ.Store.isDone(l.id); });
    }).length;
    if (eso >= 3) give('esoteric-all');
    if (totalLevels > 0 && doneCount >= totalLevels) give('all-levels');

    if (s.streak.count >= 3) give('streak3');
    if (s.streak.count >= 7) give('streak7');
    if (s.streak.count >= 14) give('streak14');
    if (s.streak.count >= 30) give('streak30');
    if (s.streak.count >= 60) give('streak60');
    if (s.streak.count >= 100) give('streak100');
    if (s.xp >= 1000) give('xp1000');
    if (s.xp >= 5000) give('xp5000');
    if (s.xp >= 15000) give('xp15000');
    if (s.xp >= 30000) give('xp30000');
    if (s.xp >= 50000) give('xp50000');

    var clean = langIds.reduce(function (acc, lid) {
      return acc + (langs[lid].levels || []).filter(function (l) {
        var inf = CQ.Store.levelInfo(l.id);
        return inf && inf.done && !(inf.usedHints > 0);
      }).length;
    }, 0);
    if (clean >= 10) give('no-hints-10');
    if (clean >= 50) give('no-hints-50');

    if (s.notes.length >= 5) give('writer');
    if (s.notes.length >= 20) give('writer20');
    if ((s.stats.sandboxRuns || 0) >= 10) give('sandboxer');
    if ((s.stats.sandboxRuns || 0) >= 50) give('sandbox50');
    if ((s.stats.runs || 0) >= 100) give('runner');

    // инструменты
    var usedTools = Object.keys(s.stats.tools || {});
    if (usedTools.length >= 8) give('toolmaster');
    if (usedTools.length >= 16) give('toolmaster-all');

    // 30 уровней одного языка
    langIds.forEach(function (lid) {
      var lv = langs[lid].levels || [];
      var d = lv.filter(function (l) { return CQ.Store.isDone(l.id); }).length;
      if (d >= 30) give('deep-30');
    });

    // траектории
    if (CQ.PATHS && CQ.pathStats) {
      var donePaths = 0;
      CQ.PATHS.forEach(function (p) {
        var ps = CQ.pathStats(p);
        if (ps.total && ps.done >= ps.total) donePaths++;
      });
      if (donePaths >= 1) give('path-1');
      if (donePaths >= 3) give('path-3');
      if (CQ.PATHS.length && donePaths >= CQ.PATHS.length) give('path-all');
    }

    // время суток и день недели
    var hr = new Date().getHours();
    var dow = new Date().getDay();
    if (doneCount >= 1) {
      if (hr >= 0 && hr < 5) give('night-owl');
      if (hr >= 5 && hr < 8) give('early-bird');
      if (dow === 0 || dow === 6) give('weekend');
    }

    var v = s.stats.visits || {};
    var sections = ['dashboard', 'lang', 'playground', 'notes', 'cheats', 'tools', 'trajectories', 'achievements', 'settings'];
    if (sections.every(function (x) { return v[x] > 0; })) give('explorer');

    return granted;
  }

  function notifyGranted(list) {
    (list || []).forEach(function (a, i) {
      setTimeout(function () {
        CQ.toast('🏅 Достижение: ' + a.name + ' — ' + a.desc, 'gold');
        CQ.confetti();
      }, 600 + i * 1400);
    });
  }

  CQ.Gamify = {
    RANKS: RANKS,
    ACH: ACH,
    rankOf: rankOf,
    nextRank: nextRank,
    checkAll: checkAll,
    notifyGranted: notifyGranted,
    afterLevel: function () {
      var granted = checkAll();
      notifyGranted(granted);
      return granted;
    }
  };
})();
