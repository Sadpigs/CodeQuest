/* ============ CodeQuest — подсветка синтаксиса (регэксп-токенайзер) ============ */
(function () {
  'use strict';
  var KW = {
    python: 'False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield print len range int str float bool list dict set tuple sum min max sorted abs enumerate zip type isinstance input open'.split(' '),
    js: 'break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new return static super switch this throw try typeof var void while with yield true false null undefined async await of console log document window Math JSON Number String Boolean Array Object'.split(' '),
    c: 'alignas alignof and and_eq asm auto bool break case catch char char8_t char16_t char32_t class compl concept const consteval constexpr constinit const_cast continue co_await co_return co_yield decltype default delete do double dynamic_cast else enum explicit export extern false float for friend goto if inline int long mutable namespace new noexcept not not_eq nullptr operator or or_eq private protected public register reinterpret_cast requires return short signed sizeof static static_assert static_cast struct switch template this thread_local throw true try typedef typeid typename union unsigned using virtual void volatile wchar_t while include define std cout cin endl string vector main System println public static String int double boolean char ArrayList List Map printf Scanner final new import package extends implements'.split(' '),
    go: 'break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var nil true false string int int64 float64 bool byte rune len cap append make new panic recover fmt Println Printf Sprintf Errorf range'.split(' '),
    sql: 'select from where and or not in like between is null as order by group having limit offset distinct insert into values update set delete join inner left right full outer on union all case when then else end count sum avg min max create table primary key foreign references alter drop asc desc exists'.split(' '),
    typescript: 'abstract any as asserts async await boolean break case catch class const constructor continue debugger declare default delete do else enum export extends false finally for from function get if implements import in infer instanceof interface is keyof let never new null number object of package private protected public readonly return set static string super switch symbol this throw true try type typeof undefined union unknown var void while with yield console log document window Math JSON Number String Boolean Array Object Record Partial Required Readonly'.split(' '),
    php: 'abstract and array as break callable case catch class clone const continue declare default do echo else elseif empty enddeclare endfor endforeach endif endswitch endwhile enum extends final finally fn for foreach function global goto if implements include include_once instanceof insteadof interface isset list match namespace new or print private protected public readonly require require_once return static switch throw trait try unset use var while xor yield true false null ECHO PRINT print_r var_dump strlen count array_map array_filter str_replace strtoupper strtolower explode implode'.split(' '),
    ruby: 'BEGIN END alias and begin break case class def defined? do else elsif end ensure false for if in module next nil not or redo rescue retry return self super then true undef unless until when while yield attr_accessor attr_reader attr_writer puts print p require require_relative include extend new lambda proc each map select reject reduce times upto upto downto'.split(' '),
    kotlin: 'as break by class continue do else false for fun if in interface is null object package return super this throw true try typealias val var when while import data sealed open override private public internal protected companion init constructor suspend lateinit const var val println listOf mapOf mutableMapOf filter map forEach'.split(' '),
    swift: 'actor associatedtype async await class deinit defer deinit didSet enum extension fallthrough final func get guard if import init inout internal let nil open operator override private public repeat required rethrows return self set static struct subscript super switch throw throws try typealias unowned var weak willSet where while true false print import guard let var func Swift Array Dictionary String Int Double Bool'.split(' '),
    dart: 'abstract as assert async await base break case catch class const continue covariant default deferred do dynamic else enum export extends extension external factory false final finally for get if implements import in interface is late library mixin new null on operator out part required rethrow return sealed set show static super switch sync this throw true try typedef var void when while with yield print List Map String int double bool main'.split(' '),
    r: 'FALSE Inf NA NaN NULL TRUE break else for function if in next repeat while library ggplot2 dplyr readr c print cat mean sd sum length names data frame matrix vector list apply sapply lapply str summary head tail'.split(' '),
    lua: 'and break do else elseif end false for function goto if in local nil not or repeat return then true until while ipairs pairs print string table math io os require require local tostring tonumber type setmetatable getmetatable pcall insert concat'.split(' '),
    perl: 'and cmp do else elsif eq foreach ge gt if last le local lt my ne next no not or our package redo ref require return sub unless until use while xor print printf say chomp split join push shift keys values each sort map grep defined scalar die warn strict warnings'.split(' '),
    bash: 'case do done elif else esac fi for function if in select then time until while alias bg bind break builtin cd command compgen complete continue declare echo eval exec exit export fc fg getopts hash help history jobs kill let local logout popd printf pushd pwd read return set shift shopt source suspend test times trap type typeset ulimit umask unalias unset wait echo read mkdir rm cp mv grep awk sed find chmod sudo apt git curl wget ls cat touch'.split(' '),
    powershell: 'begin break catch class continue data define do dynamicparam else elseif end enum exit filter finally for foreach from function hidden if in param process return static switch throw trap try until using var while workflow Write-Host Get-Content Set-Content Get-Process Get-ChildItem Where-Object ForEach-Object Select-Object Sort-Object Measure-Object Out-Null'.split(' '),
    scala: 'abstract case catch class def do else extends false final finally for forSome if implicit import lazy match new null object override package private protected return sealed super this throw trait true try type val var while with yield print println List Map Array Seq Some None Option filter map foreach reduce fold'.split(' '),
    haskell: 'as case of class data default deriving do else foreign if import in infix infixl infixr instance let module newtype then type where True False Nothing Just Maybe Int Integer Double Float Bool Char String map filter foldr foldl head tail take drop length sum product reverse zip putStrLn print'.split(' '),
    julia: 'abstract as const continue do else elseif end export false finally for function global if import in isa let local macro module mutable new quote return struct true try using while catch println print map filter reduce sum length push pop append sort include String Int Float64 Bool Vector Dict Tuple'.split(' '),
    clojure: 'def let fn if do loop recur when cond case condp defn defn- defmacro defonce declare ns require import use in-ns new set! try catch finally throw quote var quote true false nil first rest cons conj assoc dissoc get map filter reduce apply into str print println count'.split(' '),
    elixir: 'def defp defmodule defmacro defstruct do else end false fn if import in nil quote require super true unless use when and or not case cond with for while receive try catch rescue after raise throw IO Atom Enum Map List String Tuple puts inspect map filter reduce'.split(' '),
    erlang: 'after and andalso band begin bnot bor bsl bsr bxor case catch cond div end fun if let not or orelse receive rem try when xor true false undefined io format lists map foldl module export spawn send'.split(' '),
    fsharp: 'abstract and as assert base begin class default delegate do done downcast downto elif else end exception extern false finally for fun function global if in inherit inline interface internal lazy let let! match member module mutable namespace new not null of open or override private public rec return return! select static struct then to true try type upcast use use! val void when while with yield yield! printfn printf List Map Seq Array Option Some None'.split(' '),
    ocaml: 'and as assert asr begin class constraint do done downto else end exception external false for fun function functor if in include inherit initializer land lazy let lor lsl lsr lxor match method mod module mutable new object of open or private rec sig struct then to true try type val virtual when while with print_endline List Map Option Some None int float string bool unit'.split(' '),
    lisp: 'and append apply atom car cdr cond cons defmacro defun eq eql equal eval funcall function lambda let let* list listp loop mapcar nil not or numberp progn quote return setq t type-of if when unless dolist dotimes format print princ defvar defparameter labels'.split(' '),
    prolog: 'abolish asserta assertz atom atomic call catch throw clause consult dynamic fail findall float functor halt integer is nondet number op print put read repeat retract retractall see seen tell told true false not write nl format bagof setof between assert'.split(' '),
    fortran: 'allocatable allocate assignment backspace block call case character close common complex contains continue cycle data deallocate dimension do double else else if elsewhere end enddo endif entry equivalence exit external format function go goto if implicit in include inquire integer intent interface intrinsic logical module namelist none nullify only open operator optional out parameter pause pointer print private procedure program public read real result return rewind save select sequence stop subroutine target then type use where while write'.split(' '),
    cobol: 'ACCEPT ADD CALL CLOSE COMPUTE CONTINUE DELETE DISPLAY DIVIDE ELSE END-ADD END-COMPUTE END-IF END-READ END-UNSTRING EVALUATE EXIT GOBACK GO IF MOVE MULTIPLY OPEN PERFORM READ SET STOP STRING SUBTRACT UNSTRING WHEN WORKING-STORAGE PROCEDURE DIVISION SECTION PIC VALUE OCCURS TO TIMES IDENTIFICATION PROGRAM-ID AUTHOR ENVIRONMENT DATA until until'.split(' '),
    pascal: 'absolute and array asm begin case const constructor destructor div do downto else end file for function goto if implementation in inherited inline interface label mod nil not object of on operator or packed procedure program record repeat set shl shr string then to type unit until uses var while with xor writeln readln integer real boolean char string true false'.split(' '),
    ada: 'abort abs abstract accept access aliased all and array at begin body case constant declare delay delta digits do else elsif end entry exception exit for function generic goto if in interface is limited loop mod new not null of or others out overriding package pragma private procedure protected raise range record rem renames return reverse select separate some subtype tagged task terminate then type until use when while with xor Put_Line Put Get Integer Float Boolean String True False'.split(' '),
    vb: 'AddHandler And AndAlso As Boolean ByRef Byte ByVal Call Case Catch CBool CByte CChar CDate CDec CDbl Char CInt Class CLng CObj Const Continue CShort CSng CStr CType CUInt Date Decimal Declare Default Delegate Dim DirectCast Do Double Each Else ElseIf End Enum Erase Error Event Exit False Finally For Friend Function Get GetType GetXMLNamespace Global GoTo Handles If Implements Imports In Inherits Integer Interface Is IsNot Let Lib Like Long Loop Me Mod Module MustInherit MustOverride MyBase MyClass Namespace New Next Not Nothing NotInheritable NotOverridable Object Of On Operator Option Optional Or OrElse Overloads Overridable Overrides ParamArray Partial Private Property Protected Public RaiseEvent ReadOnly ReDim REM RemoveHandler Resume Return Select Set Shadows Shared Short Single Static Step Stop String Structure Sub SyncLock Then Throw To True Try TypeOf UInteger ULong Until Using When While Widening With WithEvents WriteOnly Xor Console WriteLine'.split(' '),
    smalltalk: 'true false nil self super ifTrue ifFalse ifTrueifFalse whileTrue whileFalse toDo do collect select reject detect inject into new class instanceVariableNames classVariableNames transcript show cr value at put add includes size'.split(' '),
    tcl: 'after append array break case catch cd clock close concat continue else elseif encoding error eval exec exit expr fconfigure file flush for foreach format gets glob global history if incr info interp join lappend lindex linsert list llength lrange lreplace lsearch lsort namespace open package pid proc puts pwd read regexp regsub rename return scan seek set source split string subst switch tell time trace unknown unset update uplevel upvariable while'.split(' '),
    awk: 'BEGIN END function return if else while for do break continue next nextfile delete print printf getline close system fflush in length split substr index match sub gsub sprintf print $ NR NF FS OFS RS ORS FILENAME'.split(' '),
    zig: 'align allowzero and anyframe anytype asm async await break callconv catch comptime const continue defer else enum errdefer error export extern false fn for if inline noalias nosuspend null or orelse packed pub resume return linksection struct suspend switch test threadlocal true try undefined union unreachable usingnamespace var volatile while panic print std debug StringAllocator u8 u32 i32 f64 bool void'.split(' '),
    nim: 'addr and as asm bind block break case cast concept const continue converter defer discard distinct div do elif else end enum except export finally for from func global if import include interface is isnot iterator let macro method mixin mod nil not notin object of or out proc ptr raise ref return shl shr static template try tuple type using var when while xor yield echo len high low new discard seq array string int float bool true false add contains'.split(' '),
    crystal: 'alias as as? abstract begin break case class def do else elsif end ensure extend false for fun if in include instance_sizeof is_a? lib macro module next nil of offsetof out pointerof private protected require require_relative rescue respond_to? return select self sizeof struct super then true typeof undef unless until when while with yield puts print p gets each map select reject reduce times new'.split(' '),
    solidity: 'abstract address after alias and anonymous apply as assembly auto break case constant catch copyof create default defined delete do else enum event external fallback false final from function hex if import immutable implements in indexed inline interface internal is library literal mapping memory modifier mutable new offer of override payable pragma private public pure receive require revert returns sealed send sizeof state statement storage struct super switch throw this true try type typedef typeof unchecked union using virtual view while with yield constructor emit msg block require'.split(' '),
    gdscript: 'and as assert await break class_name const continue elif else enum extends false for func if in is master mastersync match not null or pass pool_array preload remotesync return self setget signal static super true var void while yield onready export tool print push_error range str int float bool Array Dictionary String Vector2 Node ready process input delta'.split(' '),
    matlab: 'break case catch classdef continue else elseif end for function global if otherwise parfor persistent return spmd switch try while all any abs ceil floor fix mod rem sqrt exp log log10 sin cos tan sum prod mean median std min max length size numel zeros ones eye rand plot plot3 subplot title xlabel ylabel legend hold grid figure disp fprintf sprintf input find sort unique reshape transp zeros'.split(' '),
    elm: 'as case of default exposing if then else import module type alias where let in True False Nothing Just Maybe List String Int Float Bool Char Dict Maybe Tuple map filter foldl foldr append concat length reverse head tail take drop sum product cons'.split(' '),
    coffee: 'and break by catch class continue debugger delete do else export extends false finally for if import in instanceof is isnt let loop new no not of off on or return super switch then this throw true try typeof until var void when while yes await async async await console log document window Math JSON Number String Array Object'.split(' '),
    graphql: 'query mutation subscription fragment on type input interface union enum scalar schema extend implements directive repeatable variable true false null'.split(' '),
    yaml: 'true false null yes no on off'.split(' '),
    toml: 'true false'.split(' '),
    makefile: 'all clean install uninstall CC CFLAGS LDFLAGS PREFIX DIRS TARGET SRCS OBJS include export ifdef ifeq ifneq else endif define endef override unexport private PHONY'.split(' '),
    lolcode: 'HAI KTHXBYE BTW OBTW TLDR VISIBLE GIMMEH IZ ITZ R SUM OF DIFF OF PRODUKT OF QUOSHUNT OF MOD OF BIGGR OF SMALLR OF BOTH OF EITHER OF WON OF ALL OF ANY OF MAEK IS NOW A FAIL MKAY OMG WTF GTFO IM IN YR IM OUTTA YR UPPIN NERFIN TIL WILE HOW IZ I IF U SAY SO FOUND YR GTFO CAN HAS STDIO'.split(' '),
    asm: 'mov add sub mul div inc dec push pop call ret jmp je jne jz jnz jg jl jge jle ja jb jae jbe cmp test and or xor not shl shr lea nop int syscall exit read write open close global extern section data text bss db dw dd dq resb resw resd equ times org bits use16 use32 use64 rax rbx rcx rdx rsi rdi rbp rsp r8 r9 r10 r11 r12 r13 r14 r15 eax ebx ecx edx esi edi esp ebp ax bx cx dx al bl cl dl'.split(' '),
    d: 'abstract alias align asm assert auto body break case cast catch class const continue debug default delegate delete deprecated do else enum export extern false final finally for foreach foreach_reverse function goto if immutable import in inout interface invariant is lazy macro mixin module new nothrow null out override package pragma private protected public pure ref return scope shared static struct super switch synchronized template this throw true try typedef typeof union unittest version void volatile while with writeln int uint long ulong short byte ubyte float double char string bool size_t size_t std conv format immutable auto foreach_reverse'.split(' '),
    v: 'as assert asm break const continue defer else enum false fn for go goto if import in interface is match module mut none offsetof or pub return select shared sizeof static struct true type typeof union unsafe volatile volatile const fn println print dump map string int f64 bool rune array struct interface chan defer lock spawn chan'.split(' '),
    odin: 'as asm assert break case context continue defer distinct do else enum export fallthrough for foreign if import in not_in is map matrix noalias noexcept or package proc return struct switch transmute type_of union using when where bool b8 b16 b32 b64 f16 f32 f64 int uint string rune any rawptr new make len cap append free fmt print println package main main proc'.split(' '),
    vala: 'abstract as assert async base break case catch class const construct continue default delegate do downto dynamic else enum errordomain extern false finally for foreach get if in inline interface internal is lock namespace new null out override owned partial private protected public ref set signal sizeof static struct super switch this throw throws true try typeof unowned using var virtual void volatile weak while yield string int double bool uint64 stdout printf main GLib Gtk Main Loop init quit run'.split(' '),
    haxe: 'abstract as break case cast catch class continue default do else enum extends extern false final for function if implements import in inline interface is macro never new null operator overload override package private public return static super switch this throw trace true try typedef untyped using var while Array Bool Dynamic Float Int String Void Map List Lambda Reflect Std Math trace switch new'.split(' '),
    red: 'about absolute action all alter and any as assert at backdrop bind break case catch caret charset comment compose datatype decode default do either else end equal event exit extend false font for foreach format func get halt handle head help if in indent insert into is length let list loop make max modulo move negate none not null object off on only or parse path probe quit random read rebol redraw remove rename repeat return reverse save seek select set shift skip sort split sum switch tail text then to true try type union unless unset until use value view wait while word write xor zero Rebol send input react face vid layout'.split(' '),
    eiffel: 'agent alias all and as assign attached attribute check class convert create creation Current debug deferred do else elseif end ensure expand export external false feature from frozen if implies inherit inspect invariant is like local loop not obsolete old once only or Precursor redefine rename require rescue retry select separate strip then Void Result create make print put_string put_integer io none separate'.split(' '),
    io: 'Object List Map Sequence Block nil true false clone do while for foreach if else return method call message send proto protos setSlot getSlot hasSlot type print println write coro wait yield Exception raise try catch pass Lobby Date Number String File Directory locals super doString doFile'.split(' '),
    forth: 'dup drop swap over rot nip tuck depth pick roll variable constant allot here cells cell+ fill move cr emit type words see execute immediate literal postpone if else then begin while repeat until again do loop leave exit recurse create does abort number abort0 true false and or xor invert negate abs min max mod true false 2* 2/ lshift rshift space spaces variable constant s d'.split(' '),
    factor: 'USE: IN: USING: FROM: EXCLUDE: RENAME: QUALIFIED: GENERIC: HOOK: ERROR: MATH: PREDICATE: UNION: INTERSECTION: TUPLE: SLOT: CONSTANT: SYMBOL: ALIAS: SINGLETON: MIXIN: main if when unless cond case loop each map filter reduce sum product replicate times assert throw recover cleanup bi tri dup drop swap over rot nip tuck call curry compose keep cleave spread dip spin while until 2array 3array first second third length reverse append concat subset partition index member push pop peek keys values at set-at delete-at all? any? none? shuffle'.split(' '),
    verilog: 'always and assign automatic begin buf case casex casez cell config deassign default defparam design disable edge else end endcase endconfig endfunction endgenerate endmodule endprimitive endspecify endtable endtask event for force forever fork function generate genvar highz0 highz1 if ifnone incdir include initial inout input instance integer join large liblist library localparam macromodule medium module nand negedge nmos nor noshowcancelled not notif0 notif1 or output parameter pmos posedge primitive pull0 pull1 pulldown pullup rcmos real realtime reg release repeat rnmos rpmos rtran rtranif0 rtranif1 scalared showcancelled signed small specify specparam strong0 strong1 supply0 supply1 table task time tran tri tri0 tri1 triand trior trireg unsigned use vectored wait wand weak0 weak1 while wire wor xnor xor input output reg wire module endmodule begin end assign posedge negedge always initial display monitor finish time'.split(' '),
    vhdl: 'abs access after alias all and architecture array assert attribute begin block body buffer bus case component configuration constant disconnect downto else elsif end entity exit file for function generate generic group guarded if impure in inertial inout is label library linkage literal loop map mod nand new next nor not null of on open or others out package port postponed procedure process pure range record register reject rem report return rol ror select severity shared signal sla sll sra srl subtype then to transport type unaffected units until use variable wait when while with xnor xor std_logic std_logic_vector unsigned signed numeric_std ieee work bit bit_vector integer natural positive time boolean character string to_integer to_unsigned rising_edge'.split(' '),
    rexx: 'address arg call do drop else end exit if interpret iterate leave pull push queue say select signal trace upper parse numeric procedure return var value when otherwise nop length substr pos word words subword delword insert overlay strip copies space centre center abbrev verify datatype symbol countstr changestr delstr reverse lastpos xrange random lines chars queued say pull'.split(' '),
    snobol: 'OUTPUT INPUT TERMINAL PATTERN REPLACE IDENT DIFFER LEQ LGE LGT LLE LLT LTE GEQ GT LT NE EQ ANY ARB BAL BREAK LEN SPAN POS RPOS RTAB TAB REM SIZE DUPL SUBSTR INTEGER REAL CONVERT LABEL DATA ARRAY TABLE FUNCTION DEFINE OPSYN BINARY COPY PROTOTYPE SETBREAK SETSPAN END SUCCEED FAIL FENCE ABORT ARBNO SCAN BREAKX NOTANY APPLY COLLECT FREEZE STOPTRACE TRACE VALUE KEY'.split(' '),
    algol: 'abs begin boolean comment div do else elseif end endfile false fix float floor for format frac from goto if in integer lshift long mod normal null op odd open option or out precision precedence proc procedure put putlin random read readlin real ref return rshift short sign skip space standard stop string then to true up while whole print write read get line'.split(' '),
    html: []
  };
  KW.csharp = KW.c;
  KW.java = KW.c;
  KW.cpp = KW.c;
  KW.objc = KW.c;
  KW.rust = ('as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while print println vec Some None Ok Err String i32 i64 u32 u64 f32 f64 bool usize'.split(' ')).concat('fn let mut match impl trait enum struct loop println vec'.split(' '));
  KW.brainfuck = [];
  KW.markdown = [];
  KW.regex = [];
  KW.shakespeare = [];
  KW.xml = [];
  KW.json = [];
  KW.apl = []; // APL — код из спец-глифов, ключевые слова не подсвечиваем

  // Стили комментариев/строк по языкам
  var HASH = /#[^\n]*/;
  var COM = {
    python: HASH, ruby: HASH, perl: HASH, r: HASH, julia: HASH, bash: HASH, powershell: HASH,
    elixir: HASH, crystal: HASH, nim: HASH, awk: HASH, tcl: HASH, makefile: HASH, graphql: HASH,
    yaml: HASH, toml: HASH, gdscript: HASH, coffee: HASH,
    lua: /--[^\n]*/, ada: /--[^\n]*/, haskell: /--[^\n]*/, elm: /--[^\n]*/,
    erlang: /%[^\n]*/, matlab: /%[^\n]*/, prolog: /%[^\n]*/,
    lisp: /;[^\n]*/, clojure: /;[^\n]*/, asm: /;[^\n]*/,
    vb: /'[^\n]*/,
    fortran: /![^\n]*/,
    php: /\/\/[^\n]*|#[^\n]*|\/\*[\s\S]*?\*\//,
    json: /(?!)/, brainfuck: /(?!)/, lolcode: /\bBTW[^\n]*/, shakespeare: /(?!)/, markdown: /(?!)/, regex: /(?!)/,
    sql: /--[^\n]*/, rust: /\/\/[^\n]*|\/\*[\s\S]*?\*\//,
    red: /;[^\n]*/, eiffel: /--[^\n]*/, forth: /\\[^\n]*/, factor: /![^\n]*/,
    apl: /⍝[^\n]*/, vhdl: /--[^\n]*/, rexx: /--[^\n]*/, snobol: /\*[^\n]*/, algol: /#[^\n]*/
  };

  function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

  /* Кэш скомпилированных регэкспов по языку — без него regex собирался бы
     заново на каждом нажатии клавиши в редакторе (заметно на слабых ПК). */
  var RE_CACHE = {};
  function masterFor(lang) {
    if (RE_CACHE[lang]) return RE_CACHE[lang];
    var kw = KW[lang] || KW.c;
    var commentRe = COM[lang] || /\/\/[^\n]*|\/\*[\s\S]*?\*\//;
    var strRe = /`(?:\\.|[^`\\])*`|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'/;
    var kwRe = kw.length ? new RegExp('\\b(?:' + kw.join('|').replace(/[+*?]/g, '\\$&') + ')\\b', 'g') : null;
    var numRe = /\b\d[\d_]*(?:\.\d+)?(?:[eE][+-]?\d+)?\b|\b0x[0-9a-fA-F_]+\b/g;
    var fnRe = /\b[A-Za-z_][A-Za-z0-9_]*(?=\s*\()/g;
    var master = new RegExp([
      '(' + commentRe.source + ')',
      '(' + strRe.source + ')',
      '(' + numRe.source + ')',
      kwRe ? '(' + kwRe.source + ')' : '(\\b\\B)',
      '(' + fnRe.source + ')'
    ].join('|'), 'g');
    RE_CACHE[lang] = master;
    return master;
  }

  // Возвращает HTML с токенами. code НЕ должен содержать уже экранированные сущности.
  function highlight(code, lang) {
    lang = (lang || '').toLowerCase();
    if (lang === 'html' || lang === 'xml') return hlHtml(code);
    var master = masterFor(lang);
    master.lastIndex = 0;

    var out = '', last = 0, m;
    while ((m = master.exec(code)) !== null) {
      out += esc(code.slice(last, m.index));
      if (m[1] != null) out += '<span class="tk-com">' + esc(m[1]) + '</span>';
      else if (m[2] != null) out += '<span class="tk-str">' + esc(m[2]) + '</span>';
      else if (m[3] != null) out += '<span class="tk-num">' + esc(m[3]) + '</span>';
      else if (m[4] != null) out += '<span class="tk-key">' + esc(m[4]) + '</span>';
      else if (m[5] != null) out += '<span class="tk-fn">' + esc(m[5]) + '</span>';
      else out += esc(m[0]);
      last = m.index + m[0].length;
    }
    out += esc(code.slice(last));
    return out;
  }

  var HTML_RE = /(<!--[\s\S]*?-->)|(<\/?[A-Za-z][A-Za-z0-9-]*)((?:[^>"']|"[^"]*"|'[^']*')*)(>)/g;
  function hlHtml(code) {
    var re = HTML_RE;
    re.lastIndex = 0;
    var out = '', last = 0, m;
    while ((m = re.exec(code)) !== null) {
      out += esc(code.slice(last, m.index));
      if (m[1]) out += '<span class="tk-com">' + esc(m[1]) + '</span>';
      else {
        out += '<span class="tk-tag">' + esc(m[2]) + '</span>';
        out += attrs(m[3]) + '<span class="tk-tag">' + esc(m[4]) + '</span>';
      }
      last = m.index + m[0].length;
    }
    out += esc(code.slice(last));
    return out;
    function attrs(s) {
      return s.replace(/([A-Za-z-:]+)(=)("[^"]*"|'[^']*'|[^\s>]+)?/g, function (_, n, eq, v) {
        return '<span class="tk-attr">' + esc(n) + '</span>' + eq + (v ? '<span class="tk-str">' + esc(v) + '</span>' : '');
      });
    }
  }

  CQ.highlight = highlight;
})();
