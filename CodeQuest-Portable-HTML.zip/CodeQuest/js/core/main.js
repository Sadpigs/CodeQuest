/* ============ CodeQuest — загрузка ============ */
(function () {
  'use strict';

  // Контент-файлы регистрируются в window.CQ_LANGS — связываем с ядром
  CQ.LANGS = window.CQ_LANGS || {};

  // Категории языков: вкладки на дашборде + группировка
  CQ.CATEGORIES = [
    { id: 'popular',   name: '🔥 Популярные' },
    { id: 'general',   name: '🧩 Универсальные' },
    { id: 'web',       name: '🌐 Веб' },
    { id: 'mobile',    name: '📱 Мобильные' },
    { id: 'systems',   name: '⚙️ Системные' },
    { id: 'functional', name: 'λ Функциональные и декларативные' },
    { id: 'data',      name: '📊 Данные и наука' },
    { id: 'script',    name: '🐚 Скрипты и шелл' },
    { id: 'business',  name: '🏛️ Классика индустрии' },
    { id: 'gamedev',   name: '🎮 Игры' },
    { id: 'blockchain', name: '⛓️ Блокчейн' },
    { id: 'hardware', name: '🔌 Аппаратное и HDL' },
    { id: 'data-fmt', name: '📄 Форматы и разметка' },
    { id: 'esoteric', name: '🤯 Эзотерика' }
  ];
  CQ.CAT = {
    python: ['popular', 'data'],
    js: ['popular', 'web'],
    htmlcss: ['popular', 'web'],
    typescript: ['popular', 'web'],
    c: ['popular', 'systems'],
    cpp: ['popular', 'systems'],
    java: ['popular', 'general'],
    cs: ['general'],
    go: ['popular', 'systems'],
    rust: ['popular', 'systems'],
    php: ['popular', 'web'],
    ruby: ['general', 'web'],
    kotlin: ['popular', 'mobile'],
    swift: ['popular', 'mobile'],
    dart: ['mobile', 'web'],
    sql: ['popular', 'data'],
    r: ['data'],
    julia: ['data'],
    lua: ['gamedev', 'script'],
    perl: ['script', 'general'],
    bash: ['popular', 'script'],
    powershell: ['script'],
    scala: ['functional', 'general'],
    haskell: ['functional'],
    clojure: ['functional'],
    elixir: ['functional'],
    erlang: ['functional'],
    fsharp: ['functional'],
    ocaml: ['functional'],
    lisp: ['functional'],
    prolog: ['functional'],
    groovy: ['general'],
    objc: ['mobile', 'systems'],
    asm: ['systems'],
    zig: ['systems'],
    nim: ['systems'],
    crystal: ['general'],
    solidity: ['blockchain'],
    gdscript: ['gamedev'],
    matlab: ['data', 'business'],
    fortran: ['business'],
    cobol: ['business'],
    pascal: ['business'],
    ada: ['systems', 'business'],
    vb: ['business'],
    smalltalk: ['business'],
    tcl: ['script'],
    awk: ['script'],
    elm: ['web'],
    coffee: ['web'],
    json: ['data-fmt'],
    yaml: ['data-fmt'],
    toml: ['data-fmt'],
    xml: ['data-fmt'],
    markdown: ['data-fmt'],
    regex: ['data-fmt', 'popular'],
    makefile: ['data-fmt', 'script'],
    graphql: ['data-fmt', 'web'],
    brainfuck: ['esoteric'],
    lolcode: ['esoteric'],
    shakespeare: ['esoteric'],
    d: ['systems'],
    v: ['systems'],
    odin: ['systems', 'gamedev'],
    vala: ['systems'],
    haxe: ['gamedev', 'web'],
    red: ['general'],
    eiffel: ['business'],
    io: ['functional'],
    forth: ['systems', 'business'],
    factor: ['functional'],
    apl: ['data', 'business'],
    verilog: ['hardware'],
    vhdl: ['hardware'],
    rexx: ['business', 'script'],
    snobol: ['business'],
    algol: ['business'],
    scheme: ['functional'],
    racket: ['functional'],
    raku: ['script', 'functional'],
    vba: ['business', 'script'],
    batch: ['script'],
    applescript: ['script'],
    autohotkey: ['script'],
    actionscript: ['web', 'gamedev'],
    purescript: ['functional', 'web'],
    reason: ['functional', 'web'],
    logo: ['business', 'gamedev'],
    icon: ['business', 'script'],
    rebol: ['business', 'script'],
    j: ['data', 'business'],
    q: ['data', 'business'],
    wolfram: ['data'],
    sas: ['data', 'business'],
    plsql: ['business', 'data'],
    abap: ['business'],
    cuda: ['systems', 'hardware'],
    glsl: ['hardware', 'gamedev'],
    processing: ['gamedev', 'web'],
    gml: ['gamedev']
  };
  CQ.langCats = function (id) { return CQ.CAT[id] || ['general']; };

  CQ.applyTheme = function () {
    var t = CQ.Store.get().settings.theme || 'dark';
    document.documentElement.setAttribute('data-theme', t);
    // Режим слабого ПК: убираем анимации (через CSS-атрибут на корне)
    var lite = !!CQ.Store.get().settings.lite;
    if (lite) document.documentElement.setAttribute('data-lite', '1');
    else document.documentElement.removeAttribute('data-lite');
  };

  window.addEventListener('DOMContentLoaded', function () {
    // Авто-включение режима слабого ПК: 1–2 ядра CPU или ≤2 ГБ ОЗУ (один раз)
    try {
      var s0 = CQ.Store.get();
      if (s0.settings.liteAuto === undefined) {
        s0.settings.liteAuto = true;
        if (CQ.isWeakHW()) {
          s0.settings.lite = true;
          CQ.applyTheme();
          setTimeout(function () { CQ.toast('🪶 Включён режим слабого ПК (авто). Отключить — в Настройках.', 'good'); }, 1500);
        }
        CQ.Store.save();
      }
    } catch (e) {}

    CQ.applyTheme();

    // Мобильный свайп для сайдбара (на всякий случай)
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        var m = document.querySelector('.modal-bg');
        if (m) m.remove();
      }
    });

    if (!CQ.LANGS || !Object.keys(CQ.LANGS).length) {
      CQ.$('#view').innerHTML = '<div class="empty" style="padding-top:120px"><div style="font-size:44px">🛠️</div>' +
        '<h1 class="title">Контент загружается…</h1><div class="subtitle">Файлы курсов не найдены. Проверь целостность установки.</div></div>';
      return;
    }

    CQ.Router.start();
    CQ.Gamify.checkAll();

    /* PWA: офлайн-кэш при работе через http(s).
       В Android APK (file://android_asset) и при file:// — не нужен. */
    if (location.protocol === 'https:' || location.protocol === 'http:') {
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('sw.js').catch(function () {});
      }
    }
  });
})();
