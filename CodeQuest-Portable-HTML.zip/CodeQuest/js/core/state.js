/* ============ CodeQuest — хранилище прогресса ============ */
(function () {
  'use strict';
  var KEY = 'codequest_save_v1';

  var DEFAULTS = {
    version: 1,
    xp: 0,
    levels: {},          // id -> {done, tries, usedHints, xp, ts}
    notes: [],           // {id, title, body, ts}
    achievements: {},    // id -> ts
    streak: { count: 0, best: 0, last: null },
    settings: { theme: 'dark', lite: false },
    lastLevel: null,     // 'py-3'
    stats: { checks: 0, runs: 0, sandboxRuns: 0, visits: {}, tools: {}, startedAt: Date.now() }
  };

  var state = null;

  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      state = raw ? JSON.parse(raw) : JSON.parse(JSON.stringify(DEFAULTS));
    } catch (e) {
      state = JSON.parse(JSON.stringify(DEFAULTS));
    }
    // мержим недостающие поля (совместимость версий)
    Object.keys(DEFAULTS).forEach(function (k) {
      if (state[k] === undefined) state[k] = JSON.parse(JSON.stringify(DEFAULTS[k]));
    });
    if (!state.stats || typeof state.stats !== 'object') state.stats = JSON.parse(JSON.stringify(DEFAULTS.stats));
    if (!state.stats.visits) state.stats.visits = {};
    if (!state.stats.tools) state.stats.tools = {};
    if (!state.streak) state.streak = JSON.parse(JSON.stringify(DEFAULTS.streak));
    if (!state.settings) state.settings = { theme: 'dark', lite: false };
    if (state.settings.lite === undefined) state.settings.lite = false;
    return state;
  }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); }
    catch (e) { console.warn('save failed', e); }
    neuSync();
  }

  /* Оптимизация под слабые ПК: статистика (визиты/счётчики) пишется отложенно —
     каждый маршрут не сериализует всё состояние синхронно. Критичные данные
     (XP, уровни, заметки) сохраняются сразу через save(). Сброс буфера —
     при скрытии/закрытии окна. */
  var saveTimer = null;
  function saveSoon() {
    if (saveTimer) return;
    saveTimer = setTimeout(function () { saveTimer = null; save(); }, 400);
  }
  function flushSoon() {
    if (!saveTimer) return;
    clearTimeout(saveTimer); saveTimer = null; save();
  }
  try {
    window.addEventListener('pagehide', flushSoon);
    document.addEventListener('visibilitychange', function () { if (document.hidden) flushSoon(); });
  } catch (e) {}

  /* ==== Мост персистентности для Neutralino (exe-версия) ====
     В Neutralino локальный сервер слушает случайный порт, поэтому
     localStorage-origine меняется между запусками. Прогресс дополнительно
     храним в нативном хранилище Neutralino (.storage) и восстанавливаем на старте. */
  function isNeutralino() {
    return typeof window.Neutralino !== 'undefined' &&
      typeof window.NL_PORT !== 'undefined' &&
      window.Neutralino.storage && typeof window.Neutralino.storage.setData === 'function';
  }
  var neuTimer = null;
  function neuSync() {
    if (!isNeutralino()) return;
    if (neuTimer) return;
    neuTimer = setTimeout(function () {
      neuTimer = null;
      try {
        window.Neutralino.storage.setData('codequest_save_v1', JSON.stringify(state))
          .catch(function (e) { console.warn('neu storage save failed', e); });
      } catch (e) { console.warn('neu storage save failed', e); }
    }, 250);
  }
  function neuRestore() {
    if (!isNeutralino()) return;
    try {
      window.Neutralino.storage.getData('codequest_save_v1').then(function (raw) {
        if (!raw || typeof raw !== 'string' || !raw.trim()) return;
        var data = JSON.parse(raw);
        if (!data || data.version === undefined) return;
        var hadLocal = false;
        try { hadLocal = !!localStorage.getItem(KEY); } catch (e) {}
        if (!hadLocal) {
          state = data;
          Object.keys(DEFAULTS).forEach(function (k) { if (state[k] === undefined) state[k] = JSON.parse(JSON.stringify(DEFAULTS[k])); });
          try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
          if (window.CQ && CQ.applyTheme) CQ.applyTheme();
          if (window.CQ && CQ.Router && CQ.Router.rerender) CQ.Router.rerender();
          if (window.CQ && CQ.toast) CQ.toast('Прогресс восстановлен из локального хранилища ✅', 'good');
        }
      }).catch(function () { /* ключа ещё нет — норм для первого запуска */ });
    } catch (e) { /* игнор */ }
  }

  CQ.Store = {
    get: function () { if (!state) load(); return state; },
    save: save,
    reset: function () { state = JSON.parse(JSON.stringify(DEFAULTS)); save(); CQ.bumpProgressVer(); },
    export: function () { return JSON.stringify(state, null, 2); },
    import: function (json) {
      var data = JSON.parse(json); // бросит ошибку при битом json
      if (!data || typeof data !== 'object' || data.version === undefined) throw new Error('Не похоже на файл CodeQuest');
      state = data;
      load.call; // no-op
      Object.keys(DEFAULTS).forEach(function (k) { if (state[k] === undefined) state[k] = JSON.parse(JSON.stringify(DEFAULTS[k])); });
      save();
      CQ.bumpProgressVer();
      return state;
    },
    // --- уровни ---
    isDone: function (id) { return !!(this.get().levels[id] && this.get().levels[id].done); },
    levelInfo: function (id) { return this.get().levels[id] || null; },
    passLevel: function (id, xp, usedHints, tries) {
      var s = this.get();
      var first = !s.levels[id];
      var prev = s.levels[id] || { done: false };
      var already = prev.done;
      s.levels[id] = {
        done: true,
        tries: tries || 1,
        usedHints: usedHints || 0,
        xp: already ? prev.xp : (xp || 0),
        ts: Date.now()
      };
      if (!already) s.xp += (xp || 0);
      s.lastLevel = id;
      // серия
      var t = CQ.todayStr(), y = CQ.yesterdayStr();
      if (s.streak.last !== t) {
        s.streak.count = (s.streak.last === y) ? s.streak.count + 1 : 1;
        s.streak.last = t;
        if (s.streak.count > (s.streak.best || 0)) s.streak.best = s.streak.count;
      }
      save();
      CQ.bumpProgressVer();
      return { firstTime: first && !already, xpGiven: already ? 0 : (xp || 0) };
    },
    failLevel: function (id) {
      var s = this.get();
      if (!s.levels[id]) s.levels[id] = { done: false, tries: 0, usedHints: 0, xp: 0, ts: 0 };
      s.levels[id].tries = (s.levels[id].tries || 0) + 1;
      save();
    },
    useHint: function (id) {
      var s = this.get();
      if (!s.levels[id]) s.levels[id] = { done: false, tries: 0, usedHints: 0, xp: 0, ts: 0 };
      s.levels[id].usedHints = (s.levels[id].usedHints || 0) + 1;
      save();
    },
    // --- статистика/визиты ---
    visit: function (route) {
      var s = this.get();
      s.stats.visits[route] = (s.stats.visits[route] || 0) + 1;
      saveSoon();
    },
    // --- встроенные инструменты ---
    toolUse: function (id) {
      var s = this.get();
      if (!s.stats.tools) s.stats.tools = {};
      if (!s.stats.tools[id]) s.stats.tools[id] = 0;
      s.stats.tools[id]++;
      saveSoon();
    },
    bump: function (stat) {
      var s = this.get();
      s.stats[stat] = (s.stats[stat] || 0) + 1;
      saveSoon();
    },
    // --- заметки ---
    addNote: function (title, body) {
      var s = this.get();
      s.notes.unshift({ id: 'n' + Date.now() + Math.floor(Math.random() * 999), title: title, body: body, ts: Date.now() });
      save(); return s.notes[0];
    },
    updateNote: function (id, title, body) {
      var s = this.get();
      var n = s.notes.find(function (x) { return x.id === id; });
      if (n) { n.title = title; n.body = body; n.ts = Date.now(); save(); }
      return n;
    },
    delNote: function (id) {
      var s = this.get();
      s.notes = s.notes.filter(function (x) { return x.id !== id; });
      save();
    },
    // --- настройки ---
    setTheme: function (t) { this.get().settings.theme = t; save(); },
    setLite: function (v) { this.get().settings.lite = !!v; save(); },
    // --- ачивки ---
    grant: function (achId) {
      var s = this.get();
      if (!s.achievements[achId]) { s.achievements[achId] = Date.now(); save(); return true; }
      return false;
    }
  };
  load();
  // Восстановление из нативного хранилища (только в exe-версии) — даём клиенту инициализироваться
  setTimeout(neuRestore, 900);
})();
