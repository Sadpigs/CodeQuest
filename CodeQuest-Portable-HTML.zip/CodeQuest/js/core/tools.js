/* ============ CodeQuest v1.2 — встроенные инструменты разработчика ============
   Все инструменты работают офлайн, внутри приложения: без сайтов и интернета. */
(function () {
  'use strict';

  /* ---------- helpers ---------- */
  function h(tag, cls, html) {
    var el = document.createElement(tag);
    if (cls) el.className = cls;
    if (html != null) el.innerHTML = html;
    return el;
  }
  function area(cls, ph) {
    var t = document.createElement('textarea');
    t.className = cls || 'tool-ta';
    t.spellcheck = false;
    t.placeholder = ph || '';
    return t;
  }
  function outBox() {
    var o = h('div', 'tool-out');
    var pre = h('pre', 'tool-pre');
    o.appendChild(pre);
    o._pre = pre;
    o.set = function (txt, cls) { pre.className = 'tool-pre' + (cls ? ' ' + cls : ''); pre.textContent = txt; };
    o.setHtml = function (html) { pre.innerHTML = html; };
    o.appendChild(h('div', 'tool-copy-row', ''));
    var btn = h('button', 'btn sm', '📋 Копировать');
    btn.onclick = function () {
      var txt = pre.textContent;
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(function () { CQ.toast('Скопировано ✅', 'good'); }, function () {});
      else {
        var ta2 = document.createElement('textarea');
        ta2.value = txt; document.body.appendChild(ta2); ta2.select();
        try { document.execCommand('copy'); CQ.toast('Скопировано ✅', 'good'); } catch (e) {}
        ta2.remove();
      }
    };
    o.appendChild(btn);
    return o;
  }
  function row() { return h('div', 'tool-row'); }
  function label(txt) { return h('div', 'tag', txt); }
  function selectOpts(el, opts) {
    opts.forEach(function (o) {
      var op = document.createElement('option');
      op.value = o[0]; op.textContent = o[1];
      el.appendChild(op);
    });
    return el;
  }

  /* ================= JSON ================= */
  function toolJson(mount) {
    mount.appendChild(label('Вставь JSON — отформатируем, проверим и свернём'));
    var ta = area('tool-ta', '{"user":"Аня","skills":["html","css"],"xp":120}');
    var out = outBox();
    var r = row();
    var fmt = h('button', 'btn primary', '✨ Форматировать');
    var min = h('button', 'btn', '🗜 Минифицировать');
    var ind = h('select', 'note-input'); selectOpts(ind, [['2', 'отступ 2'], ['4', 'отступ 4'], ['\t', 'таб']]);
    ind.style.width = '130px';
    r.append(fmt, min, ind);
    mount.append(ta, r, out);
    function run(pretty) {
      var src = ta.value.trim();
      if (!src) { out.set('Вставь JSON выше…', 'dim'); return; }
      try {
        var data = JSON.parse(src);
        var txt = pretty ? JSON.stringify(data, null, ind.value) : JSON.stringify(data);
        out.set(txt);
        var keys = 0; (function c(x) { if (x && typeof x === 'object') { Object.keys(x).forEach(function (k) { keys++; c(x[k]); }); } })(data);
        mount._stat.textContent = '✅ Валидный JSON · ключей: ' + keys + ' · символов: ' + txt.length;
      } catch (e) {
        out.set(String(e.message), 'err');
        mount._stat.textContent = '❌ Ошибка: ' + e.message;
      }
    }
    fmt.onclick = function () { run(true); };
    min.onclick = function () { run(false); };
    ta.addEventListener('input', function () { mount._stat.textContent = 'Жду нажатия кнопки…'; });
    mount._stat = h('div', 'tool-stat', 'Жду нажатия кнопки…');
    mount.appendChild(mount._stat);
    out.set('Результат появится здесь', 'dim');
  }

  /* ================= Regex ================= */
  function toolRegex(mount) {
    mount.appendChild(label('Паттерн и флаги'));
    var r0 = row();
    var pat = document.createElement('input');
    pat.className = 'note-input'; pat.style.flex = '1';
    pat.value = '\\w+@\\w+\\.\\w+';
    pat.placeholder = 'регулярное выражение, например \\d{2,}';
    var fl = '';
    ['g', 'i', 'm', 's', 'u'].forEach(function (f) {
      var lb = h('label', 'tool-chk');
      var cb = document.createElement('input');
      cb.type = 'checkbox'; cb.checked = (f === 'g');
      lb.append(cb, document.createTextNode(f));
      r0.append(lb); fl += f;
      cb.dataset.f = f;
    });
    r0.prepend(pat);
    mount.appendChild(r0);
    mount.appendChild(label('Текст для проверки'));
    var ta = area('tool-ta', 'Пиши на student@mail.ru или на codewars+kpi@gmail.com.\nТелефон: +7 999 123-45-67.');
    ta.value = 'Пиши на student@mail.ru или codewars+kpi@gmail.com.\nТелефон: +7 999 123-45-67. Год: 2026.';
    var out = outBox();
    mount.append(ta, out);
    function run() {
      var flags = '';
      CQ.$$('input[type=checkbox]', r0).forEach(function (c) { if (c.checked) flags += c.dataset.f; });
      try {
        var re = new RegExp(pat.value, flags);
      } catch (e) { out.set('Ошибка в паттерне: ' + e.message, 'err'); return; }
      var text = ta.value;
      if (!text) { out.set('Введи текст для проверки', 'dim'); return; }
      var html = CQ.esc(text), found = [];
      try {
        if (flags.indexOf('g') !== -1) {
          var m, guard = 0;
          while ((m = re.exec(text)) !== null) {
            found.push(m);
            if (++guard > 500) break;
            if (m.index === re.lastIndex) re.lastIndex++;
          }
        } else {
          var m1 = re.exec(text);
          if (m1) found.push(m1);
        }
      } catch (e) { out.set(String(e), 'err'); return; }
      if (!found.length) { out.set('Совпадений нет 🤷', 'dim'); mount._stat.textContent = '0 совпадений'; return; }
      // подсветка: идём с конца, чтобы индексы не съезжали
      html = CQ.esc(text);
      var spans = [];
      found.forEach(function (m) { spans.push({ s: m.index, e: m.index + m[0].length }); });
      spans.sort(function (a, b) { return b.s - a.s; });
      spans.forEach(function (sp) {
        html = html.slice(0, sp.s) + '<mark class="rx-hit">' + html.slice(sp.s, sp.e) + '</mark>' + html.slice(sp.e);
      });
      out.setHtml(html.replace(/\n/g, '<br>'));
      var lines = ['Совпадений: <b>' + found.length + '</b>'];
      found.slice(0, 20).forEach(function (m, i) {
        var gr = m.slice(1).map(function (g, gi) { return g !== undefined ? ' группа ' + (gi + 1) + ': «' + CQ.esc(String(g)) + '»' : ''; }).join('');
        lines.push('<b>#' + (i + 1) + '</b> «' + CQ.esc(m[0]) + '» (индекс ' + m.index + ')' + gr);
      });
      if (found.length > 20) lines.push('… и ещё ' + (found.length - 20));
      mount._stat.innerHTML = lines.join('<br>');
    }
    mount._stat = h('div', 'tool-stat', '');
    mount.appendChild(mount._stat);
    [ta, pat].forEach(function (x) { x.addEventListener('input', run); });
    CQ.$$('input[type=checkbox]', r0).forEach(function (c) { c.addEventListener('change', run); });
    run();
  }

  /* ================= Base64 / URL ================= */
  function b64encode(str) {
    var bytes = new TextEncoder().encode(str), bin = '';
    for (var i = 0; i < bytes.length; i += 0x8000) {
      bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    }
    return btoa(bin);
  }
  function b64decode(b64) {
    var bin = atob(b64.replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/'));
    var bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  }
  function toolB64(mount) {
    mount.appendChild(label('Текст ↔ Base64 (с поддержкой кириллицы и эмодзи)'));
    var ta = area('tool-ta', 'Привет, мир!');
    var r = row();
    var enc = h('button', 'btn primary', '→ Закодировать');
    var dec = h('button', 'btn', '← Декодировать');
    var sw = h('button', 'btn sm', '⇅ Поменять местами');
    r.append(enc, dec, sw);
    var out = outBox();
    mount.append(ta, r, out);
    enc.onclick = function () { out.set(b64encode(ta.value)); };
    dec.onclick = function () {
      try { out.set(b64decode(ta.value)); }
      catch (e) { out.set('Не похоже на Base64: ' + e.message, 'err'); }
    };
    sw.onclick = function () { var t = ta.value; ta.value = out._pre.textContent; out.set(t); };
    out.set('Результат появится здесь', 'dim');
  }
  function toolUrl(mount) {
    mount.appendChild(label('URL-кодирование (например, для ссылок и форм)'));
    var ta = area('tool-ta', 'поиск по сайту?q=привет мир&страница=2');
    var r = row();
    var enc = h('button', 'btn primary', '→ Кодировать');
    var dec = h('button', 'btn', '← Декодировать');
    r.append(enc, dec);
    var out = outBox();
    mount.append(ta, r, out);
    enc.onclick = function () { out.set(encodeURIComponent(ta.value)); };
    dec.onclick = function () {
      try { out.set(decodeURIComponent(ta.value.replace(/\+/g, '%20'))); }
      catch (e) { out.set('Некорректная последовательность: ' + e.message, 'err'); }
    };
    out.set('Результат появится здесь', 'dim');
  }

  /* ================= Хеши ================= */
  // Компактный MD5 (чистый JS, работает везде)
  function md5(str) {
    function rl(n, c) { return (n << c) | (n >>> (32 - c)); }
    function au(x, y) { var l = (x & 0xFFFF) + (y & 0xFFFF), m = (x >> 16) + (y >> 16) + (l >> 16); return (m << 16) | (l & 0xFFFF); }
    function cmn(q, a, b, x, s, t) { return au(rl(au(au(a, q), au(x, t)), s), b); }
    function ff(a, b, c, d, x, s, t) { return cmn((b & c) | (~b & d), a, b, x, s, t); }
    function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & ~d), a, b, x, s, t); }
    function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
    function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | ~d), a, b, x, s, t); }
    var bytes = new TextEncoder().encode(str);
    var nblk = ((bytes.length + 8) >> 6) + 1, blks = new Array(nblk * 16).fill(0);
    for (var i = 0; i < bytes.length; i++) blks[i >> 2] |= bytes[i] << ((i % 4) * 8);
    blks[i >> 2] |= 0x80 << ((i % 4) * 8);
    blks[nblk * 16 - 2] = bytes.length * 8;
    var a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
    for (i = 0; i < blks.length; i += 16) {
      var oa = a, ob = b, oc = c, od = d;
      var x = blks.slice(i, i + 16);
      a = ff(a, b, c, d, x[0], 7, -680876936); d = ff(d, a, b, c, x[1], 12, -389564586);
      c = ff(c, d, a, b, x[2], 17, 606105819); b = ff(b, c, d, a, x[3], 22, -1044525330);
      a = ff(a, b, c, d, x[4], 7, -176418897); d = ff(d, a, b, c, x[5], 12, 1200080426);
      c = ff(c, d, a, b, x[6], 17, -1473231341); b = ff(b, c, d, a, x[7], 22, -45705983);
      a = ff(a, b, c, d, x[8], 7, 1770035416); d = ff(d, a, b, c, x[9], 12, -1958414417);
      c = ff(c, d, a, b, x[10], 17, -42063); b = ff(b, c, d, a, x[11], 22, -1990404162);
      a = ff(a, b, c, d, x[12], 7, 1804603682); d = ff(d, a, b, c, x[13], 12, -40341101);
      c = ff(c, d, a, b, x[14], 17, -1502002290); b = ff(b, c, d, a, x[15], 22, 1236535329);
      a = gg(a, b, c, d, x[1], 5, -165796510); d = gg(d, a, b, c, x[6], 9, -1069501632);
      c = gg(c, d, a, b, x[11], 14, 643717713); b = gg(b, c, d, a, x[0], 20, -373897302);
      a = gg(a, b, c, d, x[5], 5, -701558691); d = gg(d, a, b, c, x[10], 9, 38016083);
      c = gg(c, d, a, b, x[15], 14, -660478335); b = gg(b, c, d, a, x[4], 20, -405537848);
      a = gg(a, b, c, d, x[9], 5, 568446438); d = gg(d, a, b, c, x[14], 9, -1019803690);
      c = gg(c, d, a, b, x[3], 14, -187363961); b = gg(b, c, d, a, x[8], 20, 1163531501);
      a = gg(a, b, c, d, x[13], 5, -1444681467); d = gg(d, a, b, c, x[2], 9, -51403784);
      c = gg(c, d, a, b, x[7], 14, 1735328473); b = gg(b, c, d, a, x[12], 20, -1926607734);
      a = hh(a, b, c, d, x[5], 4, -378558); d = hh(d, a, b, c, x[8], 11, -2022574463);
      c = hh(c, d, a, b, x[11], 16, 1839030562); b = hh(b, c, d, a, x[14], 23, -35309556);
      a = hh(a, b, c, d, x[1], 4, -1530992060); d = hh(d, a, b, c, x[4], 11, 1272893353);
      c = hh(c, d, a, b, x[7], 16, -155497632); b = hh(b, c, d, a, x[10], 23, -1094730640);
      a = hh(a, b, c, d, x[13], 4, 681279174); d = hh(d, a, b, c, x[0], 11, -358537222);
      c = hh(c, d, a, b, x[3], 16, -722521979); b = hh(b, c, d, a, x[6], 23, 76029189);
      a = hh(a, b, c, d, x[9], 4, -640364487); d = hh(d, a, b, c, x[12], 11, -421815835);
      c = hh(c, d, a, b, x[15], 16, 530742520); b = hh(b, c, d, a, x[2], 23, -995338651);
      a = ii(a, b, c, d, x[0], 6, -198630844); d = ii(d, a, b, c, x[7], 10, 1126891415);
      c = ii(c, d, a, b, x[14], 15, -1416354905); b = ii(b, c, d, a, x[5], 21, -57434055);
      a = ii(a, b, c, d, x[12], 6, 1700485571); d = ii(d, a, b, c, x[3], 10, -1894986606);
      c = ii(c, d, a, b, x[10], 15, -1051523); b = ii(b, c, d, a, x[1], 21, -2054922799);
      a = ii(a, b, c, d, x[8], 6, 1873313359); d = ii(d, a, b, c, x[15], 10, -30611744);
      c = ii(c, d, a, b, x[6], 15, -1560198380); b = ii(b, c, d, a, x[13], 21, 1309151649);
      a = ii(a, b, c, d, x[4], 6, -145523070); d = ii(d, a, b, c, x[11], 10, -1120210379);
      c = ii(c, d, a, b, x[2], 15, 718787259); b = ii(b, c, d, a, x[9], 21, -343485551);
      a = au(a, oa); b = au(b, ob); c = au(c, oc); d = au(d, od);
    }
    function hex(n) { var s = ''; for (var j = 0; j < 4; j++) s += ('0' + ((n >> (j * 8)) & 255).toString(16)).slice(-2); return s; }
    return hex(a) + hex(b) + hex(c) + hex(d);
  }
  function toolHash(mount) {
    mount.appendChild(label('Хеш-суммы: MD5, SHA-1, SHA-256, SHA-512'));
    var ta = area('tool-ta', 'Любой текст или пароль…');
    var out = outBox();
    mount.append(ta, out);
    mount._stat = h('div', 'tool-stat', '');
    mount.appendChild(mount._stat);
    function subtleHash(alg, data) {
      if (!(window.crypto && crypto.subtle && crypto.subtle.digest)) return Promise.resolve(null);
      return crypto.subtle.digest(alg, new TextEncoder().encode(data)).then(function (buf) {
        return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
      }).catch(function () { return null; });
    }
    function run() {
      var s = ta.value;
      if (!s) { out.set('Введи текст…', 'dim'); mount._stat.textContent = ''; return; }
      var lines = ['<b>MD5</b>: ' + md5(s)];
      Promise.all([subtleHash('SHA-1', s), subtleHash('SHA-256', s), subtleHash('SHA-512', s)]).then(function (rs) {
        lines[1] = '<b>SHA-1</b>: ' + (rs[0] || '(недоступно в этом окружении)');
        lines[2] = '<b>SHA-256</b>: ' + (rs[1] || '(недоступно)');
        lines[3] = '<b>SHA-512</b>: ' + (rs[2] || '(недоступно)');
        out.setHtml(lines.join('<br>'));
      });
      out.setHtml(lines.join('<br>'));
    }
    ta.addEventListener('input', run);
    run();
  }

  /* ================= UUID / пароли ================= */
  function rnd(n) {
    var a = new Uint32Array(n);
    if (window.crypto && crypto.getRandomValues) crypto.getRandomValues(a);
    else for (var i = 0; i < n; i++) a[i] = Math.floor(Math.random() * 0xFFFFFFFF);
    return a;
  }
  function uuid4() {
    var a = rnd(4);
    var hex = Array.prototype.map.call(new Uint8Array(new Int32Array(a).buffer), function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
    return hex.slice(0, 8) + '-' + hex.slice(8, 12) + '-4' + hex.slice(13, 16) + '-' + ('89ab'[Math.floor(rnd(1)[0] / 0x40000000)]) + hex.slice(17, 20) + '-' + hex.slice(20, 32);
  }
  function toolGen(mount) {
    var out = outBox();
    /* UUID */
    mount.appendChild(label('UUID v4 — уникальный идентификатор'));
    var r1 = row();
    var bu = h('button', 'btn primary', '🎲 Сгенерировать');
    var cnt = h('select', 'note-input'); selectOpts(cnt, [['1', '1 шт.'], ['5', '5 шт.'], ['10', '10 шт.']]);
    cnt.style.width = '90px';
    r1.append(bu, cnt);
    mount.append(r1);
    bu.onclick = function () {
      var n = parseInt(cnt.value, 10), res = [];
      for (var i = 0; i < n; i++) res.push(uuid4());
      out.set(res.join('\n'));
    };
    /* Пароли */
    mount.appendChild(label('Надёжный пароль'));
    var r2 = row();
    var len = h('input', 'note-input'); len.type = 'number'; len.value = '16'; len.min = '6'; len.max = '64'; len.style.width = '80px';
    var cbA = h('label', 'tool-chk'), cbD = h('label', 'tool-chk'), cbS = h('label', 'tool-chk');
    cbA.innerHTML = '<input type="checkbox" checked> A-Za-z';
    cbD.innerHTML = '<input type="checkbox" checked> 0-9';
    cbS.innerHTML = '<input type="checkbox" checked> !@#$%';
    var bp = h('button', 'btn', '🔑 Пароль');
    r2.append(bp, len, cbA, cbD, cbS);
    mount.append(r2);
    bp.onclick = function () {
      var abc = '';
      if (cbA.querySelector('input').checked) abc += 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      if (cbD.querySelector('input').checked) abc += '0123456789';
      if (cbS.querySelector('input').checked) abc += '!@#$%^&*()-_=+[]{};:,.<>?';
      if (!abc) { out.set('Выбери хотя бы один набор символов', 'err'); return; }
      var n = Math.max(6, Math.min(64, parseInt(len.value, 10) || 16)), res = '';
      var r = rnd(n * 2);
      for (var i = 0; i < n; i++) res += abc[r[i] % abc.length];
      out.set(res);
    };
    mount.appendChild(label('Результат'));
    mount.appendChild(out);
  }

  CQ.TOOLBOX_CORE = [
    { id: 'json', ico: '🧾', name: 'JSON-форматер', cat: 'code', desc: 'Форматирование, минификация и проверка JSON прямо здесь.', render: toolJson },
    { id: 'regex', ico: '🧲', name: 'Regex-тестер', cat: 'code', desc: 'Проверь регулярку на тексте: подсветка совпадений и групп.', render: toolRegex },
    { id: 'b64', ico: '🔤', name: 'Base64', cat: 'code', desc: 'Кодирование и декодирование Base64 с кириллицей и эмодзи.', render: toolB64 },
    { id: 'url', ico: '🔗', name: 'URL-кодирование', cat: 'code', desc: 'encodeURIComponent / decodeURIComponent в один клик.', render: toolUrl },
    { id: 'hash', ico: '🔐', name: 'Хеши', cat: 'sec', desc: 'MD5, SHA-1, SHA-256, SHA-512 от любого текста.', render: toolHash },
    { id: 'gen', ico: '🎲', name: 'UUID и пароли', cat: 'sec', desc: 'Генератор UUID v4 и криптостойких паролей.', render: toolGen }
  ];

  /* ================= Цвета ================= */
  function hex2rgb(hx) {
    hx = hx.replace('#', '').trim();
    if (hx.length === 3) hx = hx[0] + hx[0] + hx[1] + hx[1] + hx[2] + hx[2];
    if (!/^[0-9a-fA-F]{6}$/.test(hx)) return null;
    return { r: parseInt(hx.slice(0, 2), 16), g: parseInt(hx.slice(2, 4), 16), b: parseInt(hx.slice(4, 6), 16) };
  }
  function rgb2hex(r, g, b) {
    var c = function (x) { return ('0' + Math.max(0, Math.min(255, Math.round(x))).toString(16)).slice(-2); };
    return '#' + c(r) + c(g) + c(b);
  }
  function rgb2hsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, hsl = { h: 0, s: 0, l: (mx + mn) / 2 };
    if (d) {
      hsl.s = hsl.l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      if (mx === r) hsl.h = ((g - b) / d + (g < b ? 6 : 0));
      else if (mx === g) hsl.h = (b - r) / d + 2;
      else hsl.h = (r - g) / d + 4;
      hsl.h *= 60;
    }
    return { h: Math.round(hsl.h), s: Math.round(hsl.s * 100), l: Math.round(hsl.l * 100) };
  }
  function hsl2rgb(h, s, l) {
    s /= 100; l /= 100;
    var k = function (n) { return (n + h / 30) % 12; };
    var a = s * Math.min(l, 1 - l);
    var f = function (n) { return l - a * Math.max(-1, Math.min(Math.min(k(n) - 3, 9 - k(n)), 1)); };
    return { r: Math.round(f(0) * 255), g: Math.round(f(8) * 255), b: Math.round(f(4) * 255) };
  }
  function toolColor(mount) {
    mount.appendChild(label('Введи цвет: HEX, rgb() или hsl()'));
    var r0 = row();
    var inp = document.createElement('input');
    inp.className = 'note-input'; inp.style.flex = '1'; inp.value = '#58a6ff';
    var pick = document.createElement('input'); pick.type = 'color'; pick.value = '#58a6ff'; pick.style.cssText = 'width:46px;height:38px;border:none;background:none;cursor:pointer;padding:0';
    r0.append(inp, pick);
    var sw = h('div', 'tool-swatch');
    mount.append(r0, sw);
    mount._stat = h('div', 'tool-stat');
    mount.appendChild(mount._stat);
    var out = outBox();
    mount.appendChild(out);
    function parse(s) {
      s = s.trim().toLowerCase();
      var m;
      if (s[0] === '#') return hex2rgb(s);
      if ((m = s.match(/rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/))) return { r: +m[1], g: +m[2], b: +m[3] };
      if ((m = s.match(/hsla?\(\s*(\d+)[,\s]+(\d+)%?[,\s]+(\d+)%?/))) { var c = hsl2rgb(+m[1], +m[2], +m[3]); return c; }
      return null;
    }
    function run(v) {
      var c = parse(v);
      if (!c) { mount._stat.textContent = 'Не похоже на цвет. Примеры: #ff5500, rgb(88 166 255), hsl(212 100 67)'; sw.style.background = 'transparent'; return; }
      var hex = rgb2hex(c.r, c.g, c.b), hsl = rgb2hsl(c.r, c.g, c.b);
      sw.style.background = hex;
      var lum = 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b;
      out.set(
        'HEX: ' + hex + '\n' +
        'RGB: rgb(' + c.r + ', ' + c.g + ', ' + c.b + ')\n' +
        'HSL: hsl(' + hsl.h + ', ' + hsl.s + '%, ' + hsl.l + '%)\n' +
        'Яркость: ' + Math.round(lum) + '/255 → текст лучше ' + (lum > 140 ? 'тёмный' : 'светлый') + '\n' +
        'CSS: background: ' + hex + ';'
      );
      mount._stat.innerHTML = 'Оттенок ' + hsl.h + '° · насыщенность ' + hsl.s + '% · светлота ' + hsl.l + '%';
      if (hex[1] === hex[2] && hex[3] === hex[4] && hex[5] === hex[6]) mount._stat.innerHTML += ' · это «безопасный» короткий HEX';
      inp.value = hex; pick.value = hex;
    }
    inp.addEventListener('input', function () { run(inp.value); });
    pick.addEventListener('input', function () { run(pick.value); });
    run('#58a6ff');
  }

  /* ================= Timestamp ================= */
  function toolTime(mount) {
    var nowBox = h('div', 'tool-stat');
    mount.appendChild(label('Unix-время ↔ обычная дата'));
    mount.appendChild(nowBox);
    var r0 = row();
    var inp = document.createElement('input');
    inp.className = 'note-input'; inp.style.flex = '1'; inp.value = String(Math.floor(Date.now() / 1000));
    var mode = h('select', 'note-input'); selectOpts(mode, [['s', 'секунды'], ['ms', 'миллисекунды']]);
    mode.style.width = '140px';
    var btn = h('button', 'btn primary', 'Перевести');
    r0.append(inp, mode, btn);
    var out = outBox();
    mount.append(r0, out);
    function fmtD(d) {
      return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }) + ', ' +
        d.toLocaleTimeString('ru-RU') + ' · ' + ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'][d.getDay()];
    }
    function tick() { nowBox.innerHTML = 'Сейчас: <b>' + Math.floor(Date.now() / 1000) + '</b> (unix) · ' + fmtD(new Date()); }
    tick(); setInterval(tick, 1000);
    function run() {
      var v = inp.value.trim();
      if (!v) return;
      var n = parseInt(v, 10);
      if (mode.value === 's') n *= 1000;
      var d = new Date(n);
      if (isNaN(d.getTime())) { out.set('Не похоже на число unix-времени', 'err'); return; }
      out.set(
        'Дата: ' + fmtD(d) + '\n' +
        'ISO: ' + d.toISOString() + '\n' +
        'Unix (сек): ' + Math.floor(d.getTime() / 1000) + '\n' +
        'Unix (мс): ' + d.getTime() + '\n' +
        'JS: new Date(' + d.getTime() + ')'
      );
    }
    btn.onclick = run;
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') run(); });
    var lbl2 = label('Дата → unix');
    mount.appendChild(lbl2);
    var r2 = row();
    var d2 = document.createElement('input'); d2.type = 'datetime-local'; d2.className = 'note-input'; d2.style.flex = '1';
    var b2 = h('button', 'btn', '→ unix');
    r2.append(d2, b2);
    var out2 = outBox();
    mount.append(r2, out2);
    b2.onclick = function () {
      if (!d2.value) { out2.set('Выбери дату и время', 'dim'); return; }
      var d = new Date(d2.value);
      out2.set('Unix (сек): ' + Math.floor(d.getTime() / 1000) + '\nUnix (мс): ' + d.getTime());
    };
    var now = new Date(); now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    d2.value = now.toISOString().slice(0, 16);
  }

  /* ================= Регистр текста ================= */
  function toolCase(mount) {
    mount.appendChild(label('Преобразование регистра и чистка текста'));
    var ta = area('tool-ta', 'Вставь текст — получишь все варианты');
    ta.value = 'привет мир CodeQuest';
    var grid = h('div', 'case-grid');
    mount.append(ta, grid);
    var variants = [
      ['UPPERCASE', function (w) { return w.toUpperCase(); }],
      ['lowercase', function (w) { return w.toLowerCase(); }],
      ['Заголовок Каждого Слова', function (w) { return w.replace(/(^|\s|[-–—])(\p{L})/gu, function (_, p, c) { return p + c.toUpperCase(); }); }],
      ['Первое предложение', function (w) { return w.charAt(0).toUpperCase() + w.slice(1); }],
      ['camelCase', null],
      ['PascalCase', null],
      ['snake_case', null],
      ['CONSTANT_CASE', null],
      ['kebab-case', null],
      ['Убрать лишние пробелы', function (w) { return w.replace(/[ \t]+/g, ' ').replace(/ ?\n ?/g, '\n').trim(); }],
      ['Развёрнуть текст наоборот', function (w) { return Array.from(w).reverse().join(''); }]
    ];
    function words(s) { return s.trim().split(/[\s_\-.]+/).filter(Boolean); }
    variants.forEach(function (v) {
      var item = h('div', 'case-item');
      var b = h('button', 'btn sm', v[0]);
      var res = h('div', 'case-res', '');
      b.onclick = function () {
        var s = ta.value;
        var fn = v[1];
        if (fn) res.textContent = fn(s) || '(пусто)';
        else {
          var w = words(s).map(function (x) { return x.toLowerCase(); });
          if (v[0] === 'camelCase') res.textContent = w.map(function (x, i) { return i ? x[0].toUpperCase() + x.slice(1) : x; }).join('') || '(пусто)';
          if (v[0] === 'PascalCase') res.textContent = w.map(function (x) { return x[0].toUpperCase() + x.slice(1); }).join('') || '(пусто)';
          if (v[0] === 'snake_case') res.textContent = w.join('_') || '(пусто)';
          if (v[0] === 'CONSTANT_CASE') res.textContent = w.join('_').toUpperCase() || '(пусто)';
          if (v[0] === 'kebab-case') res.textContent = w.join('-') || '(пусто)';
        }
      };
      item.append(b, res);
      grid.appendChild(item);
    });
    var stat = h('div', 'tool-stat', '');
    ta.addEventListener('input', upd);
    function upd() {
      var s = ta.value;
      stat.innerHTML = 'Символов: <b>' + s.length + '</b> · без пробелов: <b>' + s.replace(/\s/g, '').length + '</b> · слов: <b>' + (s.trim() ? s.trim().split(/\s+/).length : 0) + '</b> · строк: <b>' + (s ? s.split('\n').length : 0) + '</b>';
    }
    upd();
    mount.appendChild(stat);
  }

  /* ================= Markdown ================= */
  function toolMd(mount) {
    mount.appendChild(label('Markdown — предпросмотр в реальном времени'));
    var ta = area('tool-ta', '# Заголовок\nТекст с **жирным** и `кодом`.');
    ta.value = '# Мой конспект\n\nПравила **жирный**, *курсив*, `inline-код`.\n\n- первый пункт\n- второй пункт\n\n```\nprint("Привет!")\n```\n\n> Цитата для запоминания';
    var wrap = h('div', 'md-preview tool-md-out');
    ta.addEventListener('input', function () { wrap.innerHTML = CQ.md(ta.value); });
    mount.append(ta, wrap);
    wrap.innerHTML = CQ.md(ta.value);
  }

  /* ================= Дифф ================= */
  function toolDiff(mount) {
    mount.appendChild(label('Сравнение двух текстов построчно'));
    var r = row();
    var ta1 = area('tool-ta diff-ta', 'Старая версия…');
    var ta2 = area('tool-ta diff-ta', 'Новая версия…');
    ta1.value = 'строка первая\nвторая строка\nтретья строка\nпятая строка';
    ta2.value = 'строка первая\nВТОРАЯ строка\nтретья строка\nчетвёртая строка\nпятая строка';
    r.append(ta1, ta2);
    var btn = h('button', 'btn primary', '🔍 Сравнить');
    var out = outBox();
    mount.append(r, btn, out);
    btn.onclick = function () {
      var A = ta1.value.replace(/\r/g, '').split('\n');
      var B = ta2.value.replace(/\r/g, '').split('\n');
      if (A.length * B.length > 1200000) { out.set('Слишком длинные тексты — сравни по частям', 'err'); return; }
      var n = A.length, m = B.length;
      var dp = [];
      for (var i = 0; i <= n; i++) { dp.push(new Uint16Array(m + 1)); }
      for (i = n - 1; i >= 0; i--) for (var j = m - 1; j >= 0; j--) {
        dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
      var res = [], a = 0, b = 0, adds = 0, dels = 0;
      while (a < n && b < m) {
        if (A[a] === B[b]) { res.push({ t: ' ', s: A[a] }); a++; b++; }
        else if (dp[a + 1][b] >= dp[a][b + 1]) { res.push({ t: '-', s: A[a] }); dels++; a++; }
        else { res.push({ t: '+', s: B[b] }); adds++; b++; }
      }
      while (a < n) { res.push({ t: '-', s: A[a] }); dels++; a++; }
      while (b < m) { res.push({ t: '+', s: B[b] }); adds++; b++; }
      var html = res.slice(0, 800).map(function (x) {
        var cls = x.t === '+' ? 'd-add' : (x.t === '-' ? 'd-del' : 'd-same');
        return '<div class="' + cls + '">' + (x.t === ' ' ? '&nbsp;&nbsp;' : x.t + ' ') + CQ.esc(x.s) + '</div>';
      }).join('');
      out.setHtml((adds || dels) ?
        '<div class="tool-stat" style="margin-bottom:6px">Изменений: +' + adds + ' добавлено, −' + dels + ' удалено</div>' + html :
        'Тексты идентичны ✅');
    };
  }

  /* ================= Экранирование ================= */
  function toolEscape(mount) {
    mount.appendChild(label('Экранирование для HTML и строк JS'));
    var ta = area('tool-ta', '<div class="a">Сказал "привет" & ушёл</div>');
    var grid = h('div', 'case-grid');
    mount.append(ta, grid);
    var ops = [
      ['HTML → безопасно', function (s) { return CQ.esc(s); }],
      ['HTML → обратно', function (s) { var d = document.createElement('textarea'); d.innerHTML = s; return d.value; }],
      ['JS-строка (JSON)', function (s) { try { return JSON.stringify(s); } catch (e) { return '—'; } }],
      ['JS → обратно', function (s) { try { var v = JSON.parse(s); return typeof v === 'string' ? v : 'не строка'; } catch (e) { return 'ошибка: ' + e.message; } }],
      ['Экранировать слэши', function (s) { return s.replace(/\\/g, '\\\\'); }],
      ['Убрать кавычки-опасность', function (s) { return s.replace(/"/g, '\\"'); }]
    ];
    ops.forEach(function (op) {
      var item = h('div', 'case-item');
      var b = h('button', 'btn sm', op[0]);
      var res = h('div', 'case-res', '');
      b.onclick = function () { res.textContent = op[1](ta.value) || '(пусто)'; };
      item.append(b, res);
      grid.appendChild(item);
    });
    mount.appendChild(h('div', 'tool-stat', 'Совет: XSS-атаки начинаются с забытого экранирования HTML. Правило: любой пользовательский текст перед вставкой в страницу — экранируй.'));
  }

  /* ================= JWT ================= */
  function toolJwt(mount) {
    mount.appendChild(label('JWT-декодер: покажет содержимое токена'));
    var ta = area('tool-ta', 'eyJhbGciOi...вставь токен...');
    ta.value = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NSIsIm5hbWUiOiLQkNC90Y8iLCJyb2xlIjoiYWRtaW4iLCJpYXQiOjE3MzU2ODMyMDB9.dQw4w9WgXcQ_signature';
    var btn = h('button', 'btn primary', '🔓 Декодировать');
    var out = outBox();
    mount.append(ta, btn, out);
    mount.appendChild(h('div', 'tool-stat', '⚠ Декодер только читает токен. Подпись он НЕ проверяет — это делает сервер с секретным ключом. Никогда не вставляй настоящие токены в чужие сайты.'));
    btn.onclick = function () {
      var parts = ta.value.trim().split('.');
      if (parts.length < 2) { out.set('В JWT должно быть минимум 2 части через точку: header.payload.signature', 'err'); return; }
      try {
        var head = JSON.parse(b64decode(parts[0]));
        var body = JSON.parse(b64decode(parts[1]));
        var txt = 'HEADER:\n' + JSON.stringify(head, null, 2) + '\n\nPAYLOAD:\n' + JSON.stringify(body, null, 2);
        if (body.exp) {
          var d = new Date(body.exp * 1000), dd = new Date();
          txt += '\n\nИстекает: ' + d.toLocaleString('ru-RU') + (d < dd ? ' (ПРОСРОЧЕН ⚠)' : ' (действителен ✅)');
        }
        if (body.iat) txt += '\nВыдан: ' + new Date(body.iat * 1000).toLocaleString('ru-RU');
        txt += '\n\nПодпись: ' + (parts[2] ? parts[2].slice(0, 12) + '…' : '(нет)');
        out.set(txt);
      } catch (e) {
        out.set('Не удалось декодировать: ' + e.message, 'err');
      }
    };
  }

  /* ================= Калькулятор ================= */
  function toolCalc(mount) {
    mount.appendChild(label('Калькулятор выражений — без eval, свой парсер'));
    var inp = document.createElement('input');
    inp.className = 'note-input'; inp.style.fontSize = '16px';
    inp.value = '2 + 3 * 4 - sqrt(16)';
    var btn = h('button', 'btn primary', '= Посчитать');
    var r = row(); r.append(inp, btn);
    var out = outBox();
    mount.append(r, out);
    mount.appendChild(h('div', 'tool-stat', 'Операторы: + − * / % ^ и скобки. Функции: sqrt abs min max round floor ceil sin cos tan log ln pow. Константы: pi, e. Пример: pow(2, 10) + round(pi, 2)'));

    function tokenize(src) {
      var toks = [], i = 0;
      while (i < src.length) {
        var c = src[i];
        if (/\s/.test(c)) { i++; continue; }
        if (/[0-9.]/.test(c)) {
          var num = '';
          while (i < src.length && /[0-9.]/.test(src[i])) num += src[i++];
          if ((num.match(/\./g) || []).length > 1) throw new Error('Лишняя точка в числе: ' + num);
          toks.push({ t: 'n', v: parseFloat(num) });
          continue;
        }
        if (/[a-zа-я]/i.test(c)) {
          var id = '';
          while (i < src.length && /[\wа-яё]/i.test(src[i])) id += src[i++];
          if (id.toLowerCase() === 'pi') toks.push({ t: 'n', v: Math.PI });
          else if (id.toLowerCase() === 'e') toks.push({ t: 'n', v: Math.E });
          else toks.push({ t: 'f', v: id.toLowerCase() });
          continue;
        }
        if ('+-*/%^(),'.indexOf(c) !== -1) {
          var prev = toks[toks.length - 1];
          if (c === '*' && src[i + 1] === '*') { toks.push({ t: 'o', v: '^' }); i += 2; continue; }
          if (c === '-' && (!prev || prev.t === 'o' || (prev.t === 'p' && prev.v === '('))) { toks.push({ t: 'u', v: '-' }); i++; continue; }
          if (c === ',') { toks.push({ t: 'c', v: ',' }); i++; continue; }
          toks.push(c === '(' || c === ')' ? { t: 'p', v: c } : { t: 'o', v: c });
          i++; continue;
        }
        throw new Error('Непонятный символ: «' + c + '»');
      }
      return toks;
    }
    var PREC = { '+': 1, '-': 1, '*': 2, '/': 2, '%': 2, '^': 3 };
    var FNS = {
      sqrt: Math.sqrt, abs: Math.abs, min: Math.min, max: Math.max,
      round: function (x, d) { var p = Math.pow(10, d || 0); return Math.round(x * p) / p; },
      floor: Math.floor, ceil: Math.ceil, sin: Math.sin, cos: Math.cos, tan: Math.tan,
      log: Math.log10, ln: Math.log, pow: Math.pow
    };
    function toRpn(toks) {
      var out2 = [], st = [];
      toks.forEach(function (tk) {
        if (tk.t === 'c') { /* разделитель аргументов — просто пропускаем */ }
        else if (tk.t === 'n') out2.push(tk.v)
        else if (tk.t === 'f') st.push(tk);
        else if (tk.t === 'u') st.push(tk);
        else if (tk.t === 'o') {
          while (st.length) {
            var top = st[st.length - 1];
            if ((top.t === 'o' && PREC[top.v] >= PREC[tk.v] && tk.v !== '^') || top.t === 'u') out2.push(st.pop());
            else break;
          }
          st.push(tk);
        }
        else if (tk.v === '(') st.push(tk);
        else {
          var found = false;
          while (st.length) {
            var x = st.pop();
            if (x.v === '(') { found = true; break; }
            out2.push(x);
          }
          if (!found) throw new Error('Непарная скобка )');
          if (st.length && st[st.length - 1].t === 'f') out2.push(st.pop());
        }
      });
      while (st.length) { var y = st.pop(); if (y.v === '(') throw new Error('Непарная скобка ('); out2.push(y); }
      return out2;
    }
    function calc(s) {
      var rpn = toRpn(tokenize(s)), st = [];
      for (var i = 0; i < rpn.length; i++) {
        var tk = rpn[i];
        if (typeof tk === 'number') { st.push(tk); continue; }
        if (tk.t === 'u') { st.push(-st.pop()); continue; }
        if (tk.t === 'f') {
          var f = FNS[tk.v];
          if (!f) throw new Error('Неизвестная функция: ' + tk.v);
          var arity = (tk.v === 'min' || tk.v === 'max') ? Math.min(st.length, Math.max(2, st.length)) : (tk.v === 'round' || tk.v === 'pow' ? 2 : 1);
          var args = st.splice(Math.max(0, st.length - arity));
          st.push(f.apply(null, args));
          continue;
        }
        var b = st.pop(), a = st.pop();
        if (a === undefined || b === undefined) throw new Error('Не хватает чисел для операции');
        switch (tk.v) {
          case '+': st.push(a + b); break;
          case '-': st.push(a - b); break;
          case '*': st.push(a * b); break;
          case '/': if (b === 0) throw new Error('Деление на ноль'); st.push(a / b); break;
          case '%': st.push(a % b); break;
          case '^': st.push(Math.pow(a, b)); break;
        }
      }
      if (st.length !== 1) throw new Error('Выражение неполное');
      return st[0];
    }
    function run() {
      try {
        var v = calc(inp.value);
        var nice = Number.isInteger(v) ? String(v) : String(parseFloat(v.toFixed(10)));
        out.set(inp.value + ' = ' + nice);
      } catch (e) { out.set('⚠ ' + e.message, 'err'); }
    }
    btn.onclick = run;
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') run(); });
    run();
  }

  /* ================= Случайные данные ================= */
  function toolRandom(mount) {
    mount.appendChild(label('Генераторы случайных данных'));
    var grid = h('div', 'case-grid');
    var out = outBox();
    mount.append(grid, out);
    var LOREM = 'данные алгоритм функция переменная цикл массив строка объект класс метод модуль библиотека компилятор интерпретатор отладка исключение поток память ссылка структура индекс запрос сервер клиент протокол сокет буфер кэш стек очередь граф дерево узел список словарь множество байт бит символ кодировка регулярный шаблон рекурсия итерация наследование полиморфизм инкапсуляция интерфейс абстракция'.split(' ');
    var NAMES_M = ['Александр', 'Дмитрий', 'Максим', 'Иван', 'Артём', 'Никита', 'Михаил', 'Кирилл', 'Егор', 'Андрей'];
    var NAMES_F = ['Анастасия', 'Мария', 'Дарья', 'Анна', 'Виктория', 'Елизавета', 'Полина', 'София', 'Екатерина', 'Ксения'];
    var SURN = ['Иванов', 'Смирнов', 'Кузнецов', 'Соколов', 'Попов', 'Лебедев', 'Козлов', 'Новиков', 'Морозов', 'Волков'];
    function pick(a) { return a[rnd(1)[0] % a.length]; }
    var ops = [
      ['📄 Абзац «рыбы»', function () {
        var p = [];
        for (var i = 0; i < 28; i++) p.push(pick(LOREM));
        var s = p.join(' ');
        return s[0].toUpperCase() + s.slice(1) + '.';
      }],
      ['👤 Случайное имя', function () {
        var female = rnd(1)[0] % 2 === 0;
        var n = female ? pick(NAMES_F) : pick(NAMES_M);
        var s = pick(SURN) + (female ? 'а' : '');
        return n + ' ' + s + ' · email: ' + 'user' + (rnd(1)[0] % 9000 + 1000) + '@example.com';
      }],
      ['🔢 Список чисел', function () {
        var a = [];
        for (var i = 0; i < 10; i++) a.push(rnd(1)[0] % 100);
        return a.join(', ');
      }],
      ['🎨 HEX-палитра', function () {
        var c = [];
        for (var i = 0; i < 5; i++) c.push(rgb2hex(rnd(1)[0] % 256, rnd(1)[0] % 256, rnd(1)[0] % 256));
        return c.join('  ');
      }],
      ['🎲 Кубик и монетка', function () { return 'Кубик: 🎲 ' + (rnd(1)[0] % 6 + 1) + ' · Монетка: ' + (rnd(1)[0] % 2 ? 'орёл' : 'решка'); }],
      ['📦 JSON-мок', function () {
        return JSON.stringify({
          id: rnd(1)[0], name: pick(NAMES_M) + ' ' + pick(SURN) + 'ов' ? pick(NAMES_M) + ' ' + pick(SURN) : '',
          age: 18 + rnd(1)[0] % 30, active: rnd(1)[0] % 2 === 0,
          tags: [pick(LOREM), pick(LOREM)]
        }, null, 2);
      }],
      ['📅 Случайная дата 2026', function () {
        var m = rnd(1)[0] % 12, d = 1 + rnd(1)[0] % 28;
        return new Date(2026, m, d).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' });
      }]
    ];
    ops.forEach(function (op) {
      var b = h('button', 'btn sm', op[0]);
      b.onclick = function () { out.set(op[1]()); };
      grid.appendChild(b);
    });
    out.set('Выбери генератор выше 👆', 'dim');
  }

  /* ================= ASCII ================= */
  function toolAscii(mount) {
    mount.appendChild(label('Таблица ASCII — коды символов (32–127)'));
    var grid = h('div', 'ascii-grid');
    var hint = h('div', 'tool-stat', 'Клик по символу — копировать. Код в десятичной (dec), шестнадцатеричной (hex) и двоичной (bin) системах.');
    mount.append(grid, hint);
    var frag = document.createDocumentFragment();
    for (var code = 32; code <= 127; code++) {
      var ch = String.fromCharCode(code);
      var cell = h('div', 'ascii-cell');
      cell.innerHTML = '<b>' + (ch === ' ' ? '␣' : CQ.esc(ch)) + '</b><span>' + code + ' · 0x' + code.toString(16) + '</span>';
      cell.title = 'bin: ' + code.toString(2);
      cell.onclick = function () {
        var t = this.querySelector('b').textContent;
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t === '␣' ? ' ' : t);
        CQ.toast('Скопировано: ' + (t === '␣' ? 'пробел' : t), 'good');
      };
      frag.appendChild(cell);
    }
    grid.appendChild(frag);
  }

  CQ.TOOLBOX_CORE.push(
    { id: 'color', ico: '🎨', name: 'Цвета HEX/RGB/HSL', cat: 'code', desc: 'Конвертер цветов с живым примером и яркостью.', render: toolColor },
    { id: 'time', ico: '⏰', name: 'Timestamp', cat: 'code', desc: 'Unix-время ↔ дата, живые «сейчас» и обратный перевод.', render: toolTime },
    { id: 'case', ico: '🔠', name: 'Регистр текста', cat: 'text', desc: 'camelCase, snake_case, kebab и чистка пробелов + счётчики.', render: toolCase },
    { id: 'md', ico: '📝', name: 'Markdown-предпросмотр', cat: 'text', desc: 'Пиши Markdown — сразу видишь, как он будет выглядеть.', render: toolMd },
    { id: 'diff', ico: '🟰', name: 'Сравнение текстов', cat: 'text', desc: 'Построчный дифф двух версий: что добавлено и удалено.', render: toolDiff },
    { id: 'esc', ico: '🛡️', name: 'Экранирование', cat: 'text', desc: 'HTML/JS-экранирование и обратно — против XSS-ошибок.', render: toolEscape },
    { id: 'jwt', ico: '🎫', name: 'JWT-декодер', cat: 'sec', desc: 'Читает содержимое токена: header, payload, сроки.', render: toolJwt }
  );

  CQ.TOOLBOX_CORE.push(
    { id: 'calc', ico: '🧮', name: 'Калькулятор', cat: 'gen', desc: 'Вычислитель выражений со скобками, функциями и константами.', render: toolCalc },
    { id: 'rand', ico: '🎰', name: 'Случайные данные', cat: 'gen', desc: 'Рыба, имена, числа, палитры, мок-JSON — для тестов и макетов.', render: toolRandom },
    { id: 'ascii', ico: '🔠', name: 'ASCII-таблица', cat: 'gen', desc: 'Коды символов в dec/hex/bin с копированием по клику.', render: toolAscii }
  );

  CQ.TOOLBOX = CQ.TOOLBOX_CORE;

  CQ.TOOLCATS = [
    { id: 'code', name: '🧩 Код и данные' },
    { id: 'text', name: '📄 Текст' },
    { id: 'sec', name: '🔐 Безопасность' },
    { id: 'gen', name: '🎲 Генераторы и справка' }
  ];
})();
