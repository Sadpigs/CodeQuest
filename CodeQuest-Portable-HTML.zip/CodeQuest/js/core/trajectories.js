/* ============ CodeQuest v1.2 — траектории обучения (карьерные пути) ============
   Траектория = последовательность курсов, ведущая к профессии.
   Прогресс считается по пройденным уровням внутри каждого этапа. */
(function () {
  'use strict';

  var PATHS = [
    {
      id: 'frontend', emoji: '🎨', color: '#e34c26',
      title: 'Frontend-разработчик',
      tagline: 'Сайты и интерфейсы, которые видят пользователи',
      about: 'Фронтендер превращает макет в живой сайт: вёрстка, интерактив, анимации, работа с данными сервера. Это самая быстрая точка входа в ИТ — первые заказы возможны уже после HTML/CSS и JavaScript. Дальше — TypeScript, фреймворки (React/Vue) и зарплаты senior-уровня.',
      salary: ' junior 60–120 тыс. ₽ · middle 150–250 тыс. ₽ · senior 300+ тыс. ₽',
      jobs: ['Верстальщик', 'Junior Frontend', 'Frontend-разработчик', 'Фриланс: сайты на заказ'],
      skills: ['HTML и CSS на уровне «делаю макет с нуля»', 'JavaScript без шпаргалок', 'Типизация через TypeScript', 'Работа с JSON и API'],
      stages: [
        { lang: 'htmlcss', label: 'Вёрстка: HTML и CSS' },
        { lang: 'javascript', label: 'Интерактив: JavaScript' },
        { lang: 'typescript', label: 'Надёжность: TypeScript' },
        { lang: 'json', label: 'Данные: JSON' }
      ],
      extras: ['regex', 'markdown']
    },
    {
      id: 'python-backend', emoji: '🐍', color: '#3572A5',
      title: 'Python-бэкенд и автоматизация',
      tagline: 'Серверы, скрипты, боты и работа с данными',
      about: 'Python — язык-мультитул: API-серверы, Telegram-боты, парсеры, автоматизация рутины, скрипты для анализа. Курс по SQL добавляет базы данных — без них бэкенд не бывает. Bash и регулярки замыкают набор ежедневных инструментов работающего разработчика.',
      salary: ' junior 70–130 тыс. ₽ · middle 160–280 тыс. ₽ · senior 300+ тыс. ₽',
      jobs: ['Junior Python-разработчик', 'Backend-разработчик', 'Автоматизатор', 'Разработчик ботов'],
      skills: ['Python: от функций до ООП и файлов', 'SQL: сложные запросы и JOIN', 'Bash: работа с сервером через терминал', 'Регулярки для обработки текста'],
      stages: [
        { lang: 'python', label: 'Ядро: Python' },
        { lang: 'sql', label: 'Базы данных: SQL' },
        { lang: 'bash', label: 'Терминал: Bash' },
        { lang: 'regex', label: 'Текст: регулярные выражения' }
      ],
      extras: ['json', 'yaml']
    },
    {
      id: 'fullstack', emoji: '🧩', color: '#bc8cff',
      title: 'Fullstack-разработчик',
      tagline: 'И фронт, и бэк — ценик за самостоятельность',
      about: 'Фулстек делает продукт целиком: от вёрстки до сервера и базы. Такие специалисты особенно ценятся в стартапах и на фрилансе — один человек закрывает весь цикл. Траектория собирает минимальный полный набор: интерфейс, логика на JS, сервер на Python и данные в SQL.',
      salary: ' junior 80–140 тыс. ₽ · middle 180–300 тыс. ₽ · senior 350+ тыс. ₽',
      jobs: ['Fullstack-разработчик', 'Продуктовый разработчик', 'Фриланс: веб-приложения'],
      skills: ['Вёрстка и клиентская логика', 'Серверная разработка на Python', 'Проектирование таблиц и запросов', 'Понимание всего цикла продукта'],
      stages: [
        { lang: 'htmlcss', label: 'Интерфейс: HTML/CSS' },
        { lang: 'javascript', label: 'Клиент: JavaScript' },
        { lang: 'python', label: 'Сервер: Python' },
        { lang: 'sql', label: 'Данные: SQL' }
      ],
      extras: ['typescript', 'json']
    },
    {
      id: 'mobile', emoji: '📱', color: '#7F52FF',
      title: 'Мобильный разработчик',
      tagline: 'Android, iOS и кроссплатформа',
      about: 'Мобильные разработчики создают приложения, которые живут в карманах миллиардов людей. Kotlin — официальный язык Android, Swift — язык iOS, Dart с Flutter позволяет писать сразу для обеих платформ. Пройдя все три этапа, ты сможешь выбрать платформу осознанно — или остаться кроссплатформенником.',
      salary: ' junior 90–150 тыс. ₽ · middle 180–320 тыс. ₽ · senior 350+ тыс. ₽',
      jobs: ['Junior Android (Kotlin)', 'Junior iOS (Swift)', 'Flutter-разработчик'],
      skills: ['Kotlin: современный язык Android', 'Swift: язык экосистемы Apple', 'Dart/Flutter: одна кодовая база на две платформы'],
      stages: [
        { lang: 'kotlin', label: 'Android: Kotlin' },
        { lang: 'swift', label: 'iOS: Swift' },
        { lang: 'dart', label: 'Кроссплатформа: Dart' }
      ],
      extras: ['objc', 'cs']
    },
    {
      id: 'data', emoji: '📊', color: '#f2a33c',
      title: 'Data Science и аналитика',
      tagline: 'От таблиц к выводам, от данных к решениям',
      about: 'Аналитик данных превращает сырые таблицы в ответы на бизнес-вопросы. Python обрабатывает данные, SQL достаёт их из хранилищ, R силён в статистике. Эта траектория — фундамент, на который дальше ставятся pandas, визуализация и машинное обучение.',
      salary: ' junior 70–130 тыс. ₽ · middle 150–280 тыс. ₽ · senior 300+ тыс. ₽',
      jobs: ['Аналитик данных', 'Data-инженер (джун)', 'Data Scientist (после ML-курсов)'],
      skills: ['Python: обработка и автоматизация', 'SQL: агрегации и оконные функции', 'R: статистика и графики'],
      stages: [
        { lang: 'python', label: 'Инструмент: Python' },
        { lang: 'sql', label: 'Хранилище: SQL' },
        { lang: 'r', label: 'Статистика: R' }
      ],
      extras: ['julia', 'matlab', 'markdown']
    },
    {
      id: 'gamedev', emoji: '🎮', color: '#83c65d',
      title: 'Разработчик игр',
      tagline: 'C++, C# и Lua — три столпа игровой индустрии',
      about: 'В играх C++ — движки (Unreal, собственные движки), C# — Unity и серверы, Lua — скриптование игровой логики, которое используют почти все студии. Траектория даёт полный набор: производительность, удобство и гибкость в одном пакете.',
      salary: ' junior 80–140 тыс. ₽ · middle 160–300 тыс. ₽ · senior/lead 350+ тыс. ₽',
      jobs: ['Unity-разработчик (C#)', 'Движковый программист (C++)', 'Скриптер геймплея (Lua)'],
      skills: ['C++: память, указатели, производительность', 'C#: компоненты Unity, ООП', 'Lua: быстрые скрипты игровой логики'],
      stages: [
        { lang: 'cpp', label: 'Производительность: C++' },
        { lang: 'cs', label: 'Движки: C#' },
        { lang: 'lua', label: 'Скрипты: Lua' }
      ],
      extras: ['gdscript', 'haxe']
    },
    {
      id: 'devops', emoji: '🛠️', color: '#3ddc84',
      title: 'DevOps и SRE',
      tagline: 'Чтобы всё работало: автоматизация, серверы, надёжность',
      about: 'DevOps-инженер автоматизирует сборку, тестирование и развёртывание. Ядро профессии — Linux и Bash, Windows-мир требует PowerShell, инструменты вроде Docker и Kubernetes написаны на Go. YAML — язык всех конфигов от CI до оркестрации.',
      salary: ' junior 90–150 тыс. ₽ · middle 180–320 тыс. ₽ · senior 350+ тыс. ₽',
      jobs: ['DevOps-инженер', 'SRE', 'Инженер CI/CD', 'Системный администратор 2.0'],
      skills: ['Bash: скрипты и автоматизация', 'PowerShell: Windows-мир', 'Go: инструменты и сервисы', 'YAML: конфиги CI/CD'],
      stages: [
        { lang: 'bash', label: 'Терминал: Bash' },
        { lang: 'powershell', label: 'Windows: PowerShell' },
        { lang: 'go', label: 'Инструменты: Go' },
        { lang: 'yaml', label: 'Конфиги: YAML' }
      ],
      extras: ['python', 'makefile']
    },
    {
      id: 'enterprise', emoji: '🏛️', color: '#b07219',
      title: 'Энтерпрайз-разработчик',
      tagline: 'Java, C# и SQL — мир больших компаний и банков',
      about: 'Крупные системы — банки, страхование, ритейл, госуслуги — построены на Java и C# с данными в SQL. Это самый «стабильный» сегмент рынка: проекты живут годами, команды большие, а требования к надёжности кода выше, чем где-либо.',
      salary: ' junior 80–140 тыс. ₽ · middle 170–300 тыс. ₽ · senior 320+ тыс. ₽',
      jobs: ['Java-разработчик', '.NET-разработчик', 'Разработчик БД'],
      skills: ['Java: ООП, коллекции, потоки', 'C#: платформа .NET', 'SQL: сложные запросы и проектирование схем'],
      stages: [
        { lang: 'java', label: 'Платформа: Java' },
        { lang: 'cs', label: '.NET: C#' },
        { lang: 'sql', label: 'Данные: SQL' }
      ],
      extras: ['kotlin', 'cobol']
    },
    {
      id: 'security', emoji: '🛡️', color: '#ff5d73',
      title: 'Специалист по кибербезопасности',
      tagline: 'Понимать машины глубже, чем взломщик',
      about: 'Безопасность начинается с умения читать чужой код и понимать, как программа устроена «под капотом»: Python для инструментов и эксплойтов, C для понимания памяти, Bash для работы в системе, ассемблер — чтобы видеть то, что скрыто за компиляцией.',
      salary: ' junior 80–150 тыс. ₽ · middle 180–320 тыс. ₽ · senior 350+ тыс. ₽',
      jobs: ['Пентестер', 'Аналитик SOC', 'Исследователь уязвимостей', 'Security-инженер'],
      skills: ['Python: инструменты и скрипты', 'C: переполнения и память', 'Bash: командная строка систем', 'Ассемблер: реверс-инжиниринг'],
      stages: [
        { lang: 'python', label: 'Инструменты: Python' },
        { lang: 'c', label: 'Память: C' },
        { lang: 'bash', label: 'Система: Bash' },
        { lang: 'asm', label: 'Реверс: ассемблер' }
      ],
      extras: ['regex']
    },
    {
      id: 'web3', emoji: '⛓️', color: '#f7931a',
      title: 'Web3 и блокчейн-разработчик',
      tagline: 'Смарт-контракты и децентрализованные приложения',
      about: 'Блокчейн-сектор сочетает высокий порог входа и высокие чеки. Solidity — язык смарт-контрактов Ethereum, JavaScript связывает контракты с интерфейсом dApp, Rust силён в Solana и высокопроизводительных цепочках. Особенность профессии: ошибка в коде стоит реальных денег, поэтому дисциплина типов обязательна.',
      salary: ' junior 120–200 тыс. ₽ · middle 250–400 тыс. ₽ · senior 500+ тыс. ₽',
      jobs: ['Solidity-разработчик', 'Web3-разработчик dApp', 'Аудитор смарт-контрактов'],
      skills: ['Solidity: смарт-контракты EVM', 'JavaScript: dApp-интерфейсы', 'Rust: Solana и производительные цепочки'],
      stages: [
        { lang: 'javascript', label: 'Клиент: JavaScript' },
        { lang: 'solidity', label: 'Контракты: Solidity' },
        { lang: 'rust', label: 'Производительность: Rust' }
      ],
      extras: ['typescript']
    },
    {
      id: 'qa', emoji: '🧪', color: '#4bc0c0',
      title: 'QA-инженер (автоматизация)',
      tagline: 'Тестировщик, который пишет код',
      about: 'Ручное тестирование — вход в ИТ, а автоматизация — карьерный прыжок. АвтоТА-инженер пишет тесты на Python, проверяет данные через SQL и управляет окружением через Bash. Это самая дружелюбная к новичку траектория с реальным спросом на рынке.',
      salary: ' junior 60–110 тыс. ₽ · middle 130–220 тыс. ₽ · senior/SDET 280+ тыс. ₽',
      jobs: ['QA-инженер', 'Автоматизатор тестирования', 'SDET'],
      skills: ['Python: фреймворки тестов', 'SQL: проверка данных в БД', 'Bash: окружение и CI'],
      stages: [
        { lang: 'python', label: 'Язык тестов: Python' },
        { lang: 'sql', label: 'Данные: SQL' },
        { lang: 'bash', label: 'Окружение: Bash' }
      ],
      extras: ['json', 'yaml', 'regex']
    },
    {
      id: 'ml', emoji: '🤖', color: '#c65dd4',
      title: 'ML-инженер и нейросети',
      tagline: 'Машинное обучение: математика + код',
      about: 'ML-инженер учит машины распознавать, предсказывать и генерировать. Python — главный язык ML-экосистемы, MATLAB остаётся учебной классикой для математики моделей, R силён в статистике. После этой траектории логичный шаг — библиотеки PyTorch и TensorFlow.',
      salary: ' junior 100–160 тыс. ₽ · middle 200–350 тыс. ₽ · senior 400+ тыс. ₽',
      jobs: ['ML-инженер', 'Data Scientist', 'Исследователь (Research)'],
      skills: ['Python: язык всей ML-экосистемы', 'MATLAB: математика моделей', 'R: статистика и эксперименты'],
      stages: [
        { lang: 'python', label: 'Ядро: Python' },
        { lang: 'matlab', label: 'Математика: MATLAB' },
        { lang: 'r', label: 'Статистика: R' }
      ],
      extras: ['julia', 'fortran']
    }
  ];

  /* ---------- прогресс ---------- */
  function stageStats(st) {
    var l = (CQ.LANGS || {})[st.lang];
    if (!l) return { total: 0, done: 0, pct: 0, lang: st.lang, missing: true };
    var total = (l.levels || []).length, done = 0;
    (l.levels || []).forEach(function (lv) { if (CQ.Store.isDone(lv.id)) done++; });
    return { total: total, done: done, pct: total ? Math.round(done / total * 100) : 0, lang: l.id, emoji: l.emoji, title: l.title, color: l.color, missing: false };
  }
  function pathStats(p) {
    var total = 0, done = 0;
    var stages = p.stages.map(function (st) {
      var s = stageStats(st);
      total += s.total; done += s.done;
      return s;
    });
    return { stages: stages, total: total, done: done, pct: total ? Math.round(done / total * 100) : 0 };
  }
  function nextStep(p) {
    for (var i = 0; i < p.stages.length; i++) {
      var st = p.stages[i];
      var l = (CQ.LANGS || {})[st.lang];
      if (!l) continue;
      for (var j = 0; j < (l.levels || []).length; j++) {
        if (!CQ.Store.isDone(l.levels[j].id)) return { lang: l.id, idx: j + 1, stageIdx: i };
      }
    }
    return null;
  }

  CQ.PATHS = PATHS;
  CQ.pathStats = pathStats;
  CQ.pathNextStep = nextStep;

  /* ---------- вид: список траекторий ---------- */
  CQ.ROUTES.trajectories = function (view) {
    var totalPaths = PATHS.length, donePaths = 0;
    var cards = PATHS.map(function (p) {
      var st = pathStats(p);
      if (st.total && st.done === st.total) donePaths++;
      var stageChips = st.stages.map(function (s) {
        return '<span class="chip' + (s.pct === 100 ? ' gold' : ' blue') + '">' + (s.emoji || '❓') + ' ' + s.pct + '%</span>';
      }).join(' ');
      var label = st.done === 0 ? 'Старт' : (st.pct === 100 ? '🏆 Пройдена' : 'Продолжить');
      return '<div class="path-card" style="--pc:' + p.color + '" data-path="' + p.id + '">' +
        (st.pct === 100 ? '<div class="done-mark">✅</div>' : '') +
        '<div class="pc-top"><div class="pc-emoji">' + p.emoji + '</div><div><b>' + p.title + '</b>' +
        '<div class="lc-sub">' + p.tagline + '</div></div></div>' +
        '<div class="progress-bar"><i style="width:' + st.pct + '%;background:linear-gradient(90deg,' + p.color + ',var(--accent2))"></i></div>' +
        '<div class="lc-meta"><span>' + st.done + ' / ' + st.total + ' уровней</span><span>' + st.pct + '%</span></div>' +
        '<div class="pc-chips">' + stageChips + '</div>' +
        '<div class="pc-cta">' + label + ' →</div></div>';
    }).join('');

    view.innerHTML =
      '<h1 class="title">🗺️ Траектории обучения</h1>' +
      '<div class="subtitle">Готовые маршруты к профессии: какие языки, в каком порядке и зачем. Открыто ' + donePaths + ' из ' + totalPaths + '. Прогресс считается автоматически по пройденным уровням.</div>' +
      '<div class="lang-grid path-grid">' + cards + '</div>' +
      '<div class="card" style="margin-top:16px"><h3 style="margin-bottom:8px">🧭 Как выбрать траекторию</h3>' +
      '<div class="tb-p">Хочешь видеть результат быстро — бери Frontend или Python-бэкенд. Нравится стабильность и большие команды — Энтерпрайз. Любишь математику — Data Science и ML. Тянет к железу и низкоуровневой магии — Кибербезопасность или Геймдев. Пройти можно несколько траекторий: языки-фундаменты (Python, SQL, JavaScript) зачитываются во всех сразу.</div></div>';

    CQ.$$('[data-path]', view).forEach(function (c) {
      c.addEventListener('click', function () { CQ.Router.nav('trajectory/' + c.getAttribute('data-path')); });
    });
  };

  /* ---------- вид: одна траектория ---------- */
  CQ.ROUTES.trajectory = function (view, parts) {
    var p = PATHS.find(function (x) { return x.id === parts[1]; });
    if (!p) { view.innerHTML = '<div class="empty">Траектория не найдена</div>'; return; }
    var st = pathStats(p);
    var step = nextStep(p);
    var complete = st.total > 0 && st.done >= st.total;

    var stagesHtml = st.stages.map(function (s, i) {
      var l = (CQ.LANGS || {})[s.lang];
      var target = s.label || (l ? l.title : s.lang);
      var nextBtn = '';
      if (l && s.done < s.total) {
        var firstUndone = (l.levels || []).find(function (lv) { return !CQ.Store.isDone(lv.id); });
        var idx = l.levels.indexOf(firstUndone) + 1;
        nextBtn = '<button class="btn sm primary" data-go="' + l.id + '/' + idx + '">▶ Уровень ' + idx + '</button>';
      } else if (l) {
        nextBtn = '<span class="chip gold">✅ этап закрыт</span>';
      }
      return '<div class="stage-item"><div class="stg-ico">' + (s.emoji || '📘') + '</div>' +
        '<div class="stg-body"><div class="stg-head"><b>Этап ' + (i + 1) + ': ' + target + '</b>' +
        '<span class="chip blue">' + s.done + '/' + s.total + '</span></div>' +
        '<div class="progress-bar" style="margin:7px 0"><i style="width:' + s.pct + '%;background:' + (s.color || p.color) + '"></i></div></div>' +
        '<div class="stg-act">' + nextBtn + '</div></div>';
    }).join('');

    var extrasHtml = (p.extras || []).filter(function (id) { return CQ.LANGS[id]; }).map(function (id) {
      var l = CQ.LANGS[id];
      return '<span class="chip blue" data-nav="lang/' + id + '" style="cursor:pointer">' + l.emoji + ' ' + l.title + ' · по желанию</span>';
    }).join(' ');

    view.innerHTML =
      '<div class="crumb"><span class="link" data-nav="trajectories">← Все траектории</span></div>' +
      '<div class="lang-head"><div class="lh-emoji" style="background:' + p.color + '22">' + p.emoji + '</div>' +
      '<div><h1 class="title" style="font-size:24px">' + p.title + '</h1>' +
      '<div class="subtitle" style="margin:0">' + p.tagline + '</div></div>' +
      '<div class="lh-actions"><span class="chip gold">' + st.done + '/' + st.total + ' уровней</span>' +
      (complete ? '<span class="chip gold">🏆 пройдена</span>' : (step ? '<button class="btn primary sm" id="btnStep">▶ Продолжить</button>' : '')) +
      '</div></div>' +
      '<div style="margin:14px 0 6px" class="progress-bar"><i style="width:' + st.pct + '%;background:linear-gradient(90deg,' + p.color + ',var(--accent2))"></i></div>' +
      '<div class="lc-meta" style="margin-bottom:16px"><span>Прогресс траектории</span><span>' + st.pct + '%</span></div>' +

      (complete ? '<div class="win-panel" style="margin-bottom:16px"><b>🏆 Траектория пройдена полностью!</b><div style="font-size:13px;margin-top:4px">Ты прошёл ' + st.total + ' уровней по профессии «' + p.title + '». Загляни в раздел «по желанию» и добавь проекты в портфолио.</div></div>' : '') +

      '<div class="lesson-grid" style="grid-template-columns: 1.6fr 1fr"><div>' +
      '<h3 style="margin:4px 0 10px">Этапы маршрута</h3>' + stagesHtml +
      ((p.extras || []).length ? '<h3 style="margin:16px 0 10px">Дополнительно по желанию</h3><div class="pc-chips" style="margin-bottom:6px">' + extrasHtml + '</div>' : '') +
      '</div><div class="card" style="align-self:start">' +
      '<h3 style="margin-bottom:8px">💼 О профессии</h3><div class="tb-p">' + p.about + '</div>' +
      '<h3 style="margin:14px 0 6px">💰 Зарплаты (RU, ориентиры 2025–2026)</h3>' +
      '<div class="tb-p salary-line">' + p.salary + '</div>' +
      '<h3 style="margin:14px 0 6px">🧑‍💼 Кем работать</h3><div class="pc-chips">' + p.jobs.map(function (j) { return '<span class="chip blue">' + j + '</span>'; }).join(' ') + '</div>' +
      '<h3 style="margin:14px 0 6px">🎯 Что будешь уметь</h3><ul class="tb-list">' + p.skills.map(function (s) { return '<li>' + s + '</li>'; }).join('') + '</ul>' +
      '</div></div>';

    var bs = CQ.$('#btnStep', view);
    if (bs) bs.addEventListener('click', function () {
      if (step) CQ.Router.nav('lang/' + step.lang + '/' + step.idx);
    });
    CQ.$$('[data-go]', view).forEach(function (b) {
      b.addEventListener('click', function () { CQ.Router.nav('lang/' + b.getAttribute('data-go')); });
    });
    CQ.$$('[data-nav="trajectories"]', view).forEach(function (a) {
      a.addEventListener('click', function () { CQ.Router.nav('trajectories'); });
    });
    CQ.$$('.pc-chips [data-nav]', view).forEach(function (a) {
      a.addEventListener('click', function () { CQ.Router.nav(a.getAttribute('data-nav')); });
    });
  };
})();
