/* ============ CodeQuest — роутер, дашборд, карта языка, урок ============ */
(function () {
  'use strict';

  function langById(id) { return (CQ.LANGS || {})[id] || null; }
  function langProgress(l) {
    var total = (l.levels || []).length;
    var done = (l.levels || []).filter(function (x) { return CQ.Store.isDone(x.id); }).length;
    return { total: total, done: done, pct: total ? Math.round(done / total * 100) : 0 };
  }

  /* ================= Роутер ================= */
  var ROUTES = {};
  function parseHash() {
    var h = location.hash.replace(/^#\/?/, '');
    return h.split('/').filter(Boolean);
  }
  function nav(path) { location.hash = path; }

  CQ.Router = {
    nav: nav,
    start: function () {
      window.addEventListener('hashchange', render);
      render();
    },
    rerender: render
  };

  function render() {
    var parts = parseHash();
    var view = CQ.$('#view');
    CQ.buildSidebar();
    var routeKey = parts[0] || 'dashboard';
    CQ.Store.visit(routeKey === 'lang' ? 'lang' : routeKey);
    var fn = ROUTES[routeKey] || ROUTES.dashboard;
    if (routeKey === 'lang' && parts.length >= 3 && ROUTES.lesson) fn = ROUTES.lesson;
    view.innerHTML = '';
    view.scrollTop = 0;
    fn(view, parts);
    CQ.Gamify.checkAll();
    var ab = CQ.$('#sidebar');
    if (ab.classList.contains('open')) CQ.closeSidebar();
  }

  /* ================= Сайдбар + мобильный топбар =================
     Оптимизация под слабые ПК: сайдбар больше не пересобирается целиком
     на каждом рендере (раньше — прогресс всех языков + полный HTML).
     Обновляются только чипы пользователя и активный пункт; список языков
     перестраивается только при изменении прогресса (CQ.progressVer). */
  var SB = { built: false, ver: null };

  /* Мобильный сайдбар: открытие/закрытие + затемнение */
  CQ.closeSidebar = function () {
    var sb = CQ.$('#sidebar');
    if (sb) sb.classList.remove('open');
    var bd = CQ.$('#sbBackdrop');
    if (bd) bd.classList.remove('show');
  };
  CQ.openSidebar = function () {
    var sb = CQ.$('#sidebar');
    if (sb) sb.classList.add('open');
    var bd = CQ.$('#sbBackdrop');
    if (bd) bd.classList.add('show');
  };

  CQ.buildSidebar = function () {
    var s = CQ.Store.get();
    var rank = CQ.Gamify.rankOf(s.xp);
    var parts = parseHash();
    var cur = parts[0] || 'dashboard';
    var el = CQ.$('#sidebar');
    var langCount = Object.keys(CQ.LANGS || {}).length;
    var ver = CQ.progressVer + ':' + langCount;

    if (!SB.built) {
      var items = [
        ['dashboard', '🏠', 'Главная'],
        ['trajectories', '🗺️', 'Траектории'],
        ['playground', '🧪', 'Песочница'],
        ['notes', '📝', 'Заметки'],
        ['cheats', '📋', 'Шпаргалки'],
        ['tools', '🧰', 'Инструменты'],
        ['achievements', '🏅', 'Достижения'],
        ['search', '🔍', 'Поиск'],
        ['settings', '⚙️', 'Настройки']
      ];
      el.innerHTML =
        '<div class="logo"><div class="logo-badge">⚡</div><div><b>CodeQuest</b><small>академия кода</small></div></div>' +
        '<div class="sb-user">' +
        '<span class="chip blue" id="sbRank">' + rank.ico + ' ' + rank.name + '</span>' +
        '<span class="chip gold" id="sbXp">✨ ' + s.xp + ' XP</span>' +
        '<span class="chip fire" id="sbStreak">🔥 ' + (s.streak.count || 0) + '</span>' +
        '</div>' +
        '<div class="sb-label">Навигация</div>' +
        items.map(function (it) {
          return '<a class="nav-item' + (cur === it[0] ? ' active' : '') + '" data-nav="' + it[0] + '"><span class="ni-ico">' + it[1] + '</span>' + it[2] + '</a>';
        }).join('') +
        '<div class="sb-label" id="sbLangLabel">Языки · ' + langCount + '</div>' +
        '<div class="side-langs" id="sbLangs"></div>' +
        '<div style="margin-top:auto;padding:10px 8px 2px;color:var(--muted);font-size:11px">v1.5 · <span id="sbFootCount">' + langCount + '</span> языков · офлайн · ' +
        '<span class="link" id="themeQuick"></span></div>';

      SB.built = true;

      CQ.$$('.nav-item[data-nav]', el).forEach(function (a) {
        a.addEventListener('click', function () { nav(a.getAttribute('data-nav')); });
      });

      /* Мобильное меню: burger, затемнение, свайп влево для закрытия */
      var burger = CQ.$('#btnBurger');
      if (burger) burger.addEventListener('click', function () {
        var sb = CQ.$('#sidebar');
        if (sb.classList.contains('open')) CQ.closeSidebar(); else CQ.openSidebar();
      });
      var bd0 = CQ.$('#sbBackdrop');
      if (bd0) bd0.addEventListener('click', CQ.closeSidebar);
      var sbEl = CQ.$('#sidebar');
      if (sbEl) {
        var x0 = null;
        sbEl.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
        sbEl.addEventListener('touchmove', function (e) {
          if (x0 !== null && x0 - e.touches[0].clientX > 48) { CQ.closeSidebar(); x0 = null; }
        }, { passive: true });
        sbEl.addEventListener('touchend', function () { x0 = null; }, { passive: true });
      }
      var tq = CQ.$('#themeQuick', el);
      tq.addEventListener('click', function () {
        CQ.toggleTheme();
        tq.textContent = document.documentElement.getAttribute('data-theme') === 'dark' ? '🌙 тема' : '☀️ тема';
      });
    } else {
      // точечные обновления вместо полной пересборки
      var c1 = CQ.$('#sbRank', el); if (c1) c1.textContent = rank.ico + ' ' + rank.name;
      var c2 = CQ.$('#sbXp', el); if (c2) c2.textContent = '✨ ' + s.xp + ' XP';
      var c3 = CQ.$('#sbStreak', el); if (c3) c3.textContent = '🔥 ' + (s.streak.count || 0);
      CQ.$$('.nav-item[data-nav]', el).forEach(function (a) {
        a.classList.toggle('active', a.getAttribute('data-nav') === cur);
      });
      var label = CQ.$('#sbLangLabel', el); if (label) label.textContent = 'Языки · ' + langCount;
      var fc = CQ.$('#sbFootCount', el); if (fc) fc.textContent = langCount;
    }

    // список языков — только когда реально изменился прогресс
    if (SB.ver !== ver) {
      SB.ver = ver;
      var box = CQ.$('#sbLangs', el);
      box.innerHTML = Object.keys(CQ.LANGS || {}).map(function (id) {
        var l = CQ.LANGS[id];
        var p = langProgress(l);
        return '<div class="side-lang" data-nav="lang/' + id + '">' +
          '<span class="sl-emoji">' + l.emoji + '</span><span>' + l.title + '</span>' +
          '<span class="sl-bar"><i style="width:' + p.pct + '%;background:' + l.color + '"></i></span>' +
          '<span class="sl-pct">' + p.pct + '%</span></div>';
      }).join('');
      CQ.$$('.side-lang[data-nav]', box).forEach(function (a) {
        a.addEventListener('click', function () { nav(a.getAttribute('data-nav')); });
      });
    }

    var tq2 = CQ.$('#themeQuick', el);
    if (tq2 && !tq2.textContent) tq2.textContent = document.documentElement.getAttribute('data-theme') === 'dark' ? '🌙 тема' : '☀️ тема';

    /* Мобильный топбар: чипы XP/стрик синхронно с сайдбаром */
    var tx = CQ.$('#tbXp'); if (tx) tx.textContent = '✨ ' + s.xp + ' XP';
    var ts = CQ.$('#tbStreak'); if (ts) ts.textContent = '🔥 ' + (s.streak.count || 0);
  };

  /* ================= Дашборд ================= */
  var DASH = { cat: 'all', q: '' };
  ROUTES.dashboard = function (view) {
    var s = CQ.Store.get();
    var rank = CQ.Gamify.rankOf(s.xp);
    var nr = CQ.Gamify.nextRank(s.xp);
    var langs = CQ.LANGS || {};
    var ids = Object.keys(langs);
    var totalLevels = 0, doneLevels = 0;
    ids.forEach(function (id) {
      var p = langProgress(langs[id]);
      totalLevels += p.total; doneLevels += p.done;
    });
    var pct = totalLevels ? Math.round(doneLevels / totalLevels * 100) : 0;
    var rPct = nr ? Math.min(100, Math.round((s.xp - rank.xp) / (nr.xp - rank.xp) * 100)) : 100;
    // куда продолжить
    var cont = null;
    if (s.lastLevel) {
      var parts = s.lastLevel.split('-');
      var lid = parts[0];
      // id уровня = '<langid>-N', но у htmlcss id 'htmlcss-N' — вычисляем по префиксу
      var found = null;
      ids.forEach(function (id) { if (s.lastLevel.indexOf(id + '-') === 0) found = id; });
      if (found) {
        var l = langs[found];
        var lv = (l.levels || []).find(function (x) { return x.id === s.lastLevel; });
        if (lv && !CQ.Store.isDone(lv.id)) cont = { lang: found, idx: l.levels.indexOf(lv) + 1, title: lv.title };
        else {
          var next = (l.levels || []).find(function (x) { return !CQ.Store.isDone(x.id); });
          if (next) cont = { lang: found, idx: l.levels.indexOf(next) + 1, title: next.title };
        }
      }
    }
    if (!cont && ids.length) {
      for (var i = 0; i < ids.length && !cont; i++) {
        var l2 = langs[ids[i]];
        var next2 = (l2.levels || []).find(function (x) { return !CQ.Store.isDone(x.id); });
        if (next2) cont = { lang: ids[i], idx: l2.levels.indexOf(next2) + 1, title: next2.title };
      }
    }

    var ring = '<div class="ring-wrap"><svg width="120" height="120"><circle cx="60" cy="60" r="52" fill="none" stroke="var(--card2)" stroke-width="10"/>' +
      '<circle cx="60" cy="60" r="52" fill="none" stroke="url(#gr)" stroke-width="10" stroke-linecap="round" stroke-dasharray="' + (2 * Math.PI * 52) + '" stroke-dashoffset="' + (2 * Math.PI * 52 * (1 - pct / 100)) + '"/>' +
      '<defs><linearGradient id="gr" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#58a6ff"/><stop offset="1" stop-color="#bc8cff"/></linearGradient></defs></svg>' +
      '<div class="ring-txt"><b>' + pct + '%</b><span>весь курс</span></div></div>';

    var langCards = ids.filter(function (id) {
      if (DASH.cat !== 'all' && CQ.langCats(id).indexOf(DASH.cat) === -1) return false;
      if (DASH.q) {
        var l0 = langs[id];
        var hay = (l0.title + ' ' + (l0.tagline || '') + ' ' + (l0.description || '')).toLowerCase();
        if (hay.indexOf(DASH.q) === -1) return false;
      }
      return true;
    }).map(function (id) {
      var l = langs[id], p = langProgress(l);
      return '<div class="lang-card" style="--lc:' + l.color + '" data-lang="' + id + '">' +
        (p.total && p.done === p.total ? '<div class="done-mark">✅</div>' : '') +
        '<div class="lc-top"><div class="lc-emoji">' + l.emoji + '</div>' +
        '<div><b>' + l.title + '</b><div class="lc-sub">' + CQ.esc(l.tagline || '') + '</div></div></div>' +
        '<div class="progress-bar"><i style="width:' + p.pct + '%;background:linear-gradient(90deg,' + l.color + ',var(--accent2))"></i></div>' +
        '<div class="lc-meta"><span>' + p.done + ' / ' + p.total + ' уровней</span><span>' + p.pct + '%</span></div></div>';
    }).join('');

    var catCounts = {};
    ids.forEach(function (id) { CQ.langCats(id).forEach(function (c) { catCounts[c] = (catCounts[c] || 0) + 1; }); });
    var catTabs = '<button class="tab' + (DASH.cat === 'all' ? ' active' : '') + '" data-cat="all">🌍 Все · ' + ids.length + '</button>' +
      CQ.CATEGORIES.filter(function (c) { return catCounts[c.id]; }).map(function (c) {
        return '<button class="tab' + (DASH.cat === c.id ? ' active' : '') + '" data-cat="' + c.id + '">' + c.name + ' · ' + catCounts[c.id] + '</button>';
      }).join('');

    view.innerHTML =
      '<div class="hero"><div class="h-left"><h1>👋 Продолжай путь, кодер!</h1>' +
      '<p>Теория → практика → проверка. Уровень не откроется, пока не решишь текущий. Как в игре.</p>' +
      '<div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap">' +
      (cont ? '<button class="btn primary" id="btnContinue">▶ Продолжить: ' + CQ.esc(langs[cont.lang].title) + ' · ур. ' + cont.idx + '</button>' : '<button class="btn good" id="btnContinue">🏆 Всё пройдено! Повторяй любое</button>') +
      '<button class="btn" id="btnSandbox">🧪 Песочница</button></div></div>' + ring + '</div>' +

      '<div class="rank-track"><span class="rank-ico">' + rank.ico + '</span><div><b>' + rank.name + '</b><div style="font-size:12px;color:var(--muted)">' +
      (nr ? 'До звания «' + nr.name + '»: ' + (nr.xp - s.xp) + ' XP' : 'Максимальное звание!') + '</div></div>' +
      '<div class="rt-bar progress-bar"><i style="width:' + rPct + '%"></i></div></div>' +

      (function () {
        if (!CQ.PATHS) return '';
        var cards = CQ.PATHS.map(function (p) {
          var ps = CQ.pathStats(p);
          return '<div class="mini-path" style="--pc:' + p.color + '" data-path="' + p.id + '">' +
            '<span class="mp-ico">' + p.emoji + '</span><div class="mp-body"><b>' + p.title + '</b>' +
            '<div class="progress-bar" style="margin-top:4px"><i style="width:' + ps.pct + '%;background:' + p.color + '"></i></div></div>' +
            '<span class="mp-pct">' + ps.pct + '%</span></div>';
        }).join('');
        return '<h1 class="title" style="font-size:19px;margin:16px 0 10px">🗺️ Траектории к профессии</h1>' +
          '<div class="mini-path-grid">' + cards + '</div>';
      })() +

      '<div class="stat-row">' +
      '<div class="stat"><span class="st-ico">✨</span><div><b>' + s.xp + '</b><span>XP всего</span></div></div>' +
      '<div class="stat"><span class="st-ico">🔥</span><div><b>' + (s.streak.count || 0) + '</b><span>дней подряд (рекорд ' + (s.streak.best || 0) + ')</span></div></div>' +
      '<div class="stat"><span class="st-ico">🎯</span><div><b>' + doneLevels + '</b><span>из ' + totalLevels + ' уровней</span></div></div>' +
      '<div class="stat"><span class="st-ico">🧠</span><div><b>' + (s.notes.length || 0) + '</b><span>заметок</span></div></div>' +
      '<div class="stat"><span class="st-ico">🌍</span><div><b>' + ids.length + '</b><span>языков доступно</span></div></div>' +
      '</div>' +
      '<h1 class="title" style="font-size:19px;margin-bottom:12px">Языки программирования</h1>' +
      '<input class="note-input" id="dashQ" placeholder="🔍 Найти язык: циклы, байты, смарт-контракт…" value="' + CQ.esc(DASH.q) + '" style="margin-bottom:10px">' +
      '<div class="tabs" id="dashCats" style="margin-bottom:14px">' + catTabs + '</div>' +
      '<div class="lang-grid">' + (langCards || '<div class="empty" style="grid-column:1/-1">Ничего не найдено — попробуй другой фильтр</div>') + '</div>';

    CQ.$$('[data-lang]', view).forEach(function (c) {
      c.addEventListener('click', function () { nav('lang/' + c.getAttribute('data-lang')); });
    });
    CQ.$$('[data-path]', view).forEach(function (c) {
      c.addEventListener('click', function () { nav('trajectory/' + c.getAttribute('data-path')); });
    });
    CQ.$$('#dashCats .tab', view).forEach(function (t) {
      t.addEventListener('click', function () { DASH.cat = t.getAttribute('data-cat'); ROUTES.dashboard(view); });
    });
    var dq = CQ.$('#dashQ', view);
    dq.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { DASH.q = dq.value.trim().toLowerCase(); ROUTES.dashboard(view); }
    });
    var bc = CQ.$('#btnContinue', view);
    if (bc) bc.addEventListener('click', function () {
      if (cont) nav('lang/' + cont.lang + '/' + cont.idx); else nav('lang/' + ids[0] + '/1');
    });
    CQ.$('#btnSandbox', view).addEventListener('click', function () { nav('playground'); });
  };

  /* ================= Карта уровней языка ================= */
  ROUTES.lang = function (view, parts) {
    var l = langById(parts[1]);
    if (!l) { view.innerHTML = '<div class="empty">Язык не найден 😕</div>'; return; }
    var p = langProgress(l);
    var doneAll = p.total > 0 && p.done === p.total;

    var nodes = (l.levels || []).map(function (lv, i) {
      var done = CQ.Store.isDone(lv.id);
      var unlocked = i === 0 || CQ.Store.isDone(l.levels[i - 1].id);
      var st = done ? 'done' : (unlocked ? 'current' : 'locked');
      return '<div class="level-node ' + st + '" data-i="' + (i + 1) + '">' +
        '<div class="ln-rail"><div class="ln-dot">' + (done ? '✓' : (unlocked ? (i + 1) : '🔒')) + '</div>' +
        (i < l.levels.length - 1 ? '<div class="ln-line"></div>' : '') + '</div>' +
        '<div class="ln-info"><div class="ln-title">' + CQ.esc(lv.title) + '</div>' +
        '<div class="ln-goal">' + CQ.esc(lv.goal || '') + '</div>' +
        '<div class="ln-xp">+' + (lv.xp || 50) + ' XP' + (lv.type === 'project' || lv.project ? ' · 🚀 проект' : '') + '</div></div></div>';
    }).join('');

    view.innerHTML =
      '<div class="crumb"><span class="link" data-nav="dashboard">← Главная</span></div>' +
      '<div class="lang-head"><div class="lh-emoji">' + l.emoji + '</div>' +
      '<div><h1 class="title" style="font-size:24px">' + l.title + '</h1>' +
      '<div class="subtitle" style="margin:0">' + CQ.esc(l.description || '') + '</div></div>' +
      '<div class="lh-actions"><span class="chip blue">' + p.done + '/' + p.total + ' уровней</span>' +
      '<button class="btn sm" id="btnCheat">📋 Шпаргалка</button>' +
      '<button class="btn sm danger" id="btnResetLang">♻️ Сбросить язык</button></div></div>' +
      '<div style="margin:14px 0 20px" class="progress-bar"><i style="width:' + p.pct + '%;background:linear-gradient(90deg,' + l.color + ',var(--accent2))"></i></div>' +
      '<div class="map-grid"><div class="level-path">' + nodes + '</div>' +
      '<div class="card">' +
      '<h3 style="margin-bottom:8px">ℹ️ Как это работает</h3>' +
      '<div class="tb-p" style="font-size:13px">Открывай уровни сверху вниз. Внутри — короткая теория и задание. ' +
      'Решишь задание — откроется следующий уровень, получишь XP и продвинешь полоску прогресса.</div>' +
      '<div class="tb-p" style="font-size:13px">Застрял? Открывай 🧠 подсказки (на XP не влияют), а решение показывается после первой неудачной проверки.</div>' +
      (doneAll ? '<div class="win-panel" style="margin-top:12px"><b>🏆 Язык пройден полностью!</b><div style="font-size:13px;margin-top:4px">Загляни в Шпаргалки и Песочницу, чтобы закрепить.</div></div>' : '') +
      '</div></div>';

    CQ.$$('.level-node', view).forEach(function (n) {
      n.addEventListener('click', function () {
        var i = parseInt(n.getAttribute('data-i'), 10);
        var unlocked = i === 1 || CQ.Store.isDone(l.levels[i - 2].id);
        if (!unlocked) { CQ.toast('🔒 Сначала пройди предыдущий уровень!', 'bad'); return; }
        nav('lang/' + l.id + '/' + i);
      });
    });
    CQ.$('#btnCheat', view).addEventListener('click', function () { nav('cheats/' + l.id); });
    CQ.$('#btnResetLang', view).addEventListener('click', function () {
      CQ.modal('<h3>Сбросить прогресс по «' + CQ.esc(l.title) + '»?</h3><div class="tb-p">Все уровни языка станут непройденными. Заработанный XP останется.</div>' +
        '<div class="m-actions"><button class="btn" id="mCancel">Отмена</button><button class="btn danger" id="mOk">Сбросить</button></div>', function (bg) {
        bg.querySelector('#mCancel').onclick = function () { bg.remove(); };
        bg.querySelector('#mOk').onclick = function () {
          var s = CQ.Store.get();
          (l.levels || []).forEach(function (lv) { delete s.levels[lv.id]; });
          CQ.Store.save(); CQ.bumpProgressVer(); bg.remove(); CQ.Router.rerender(); CQ.toast('Прогресс языка сброшен');
        };
      });
    });
    CQ.$$('[data-nav="dashboard"]', view).forEach(function (a) { a.addEventListener('click', function () { nav('dashboard'); }); });
  };

  /* ================= Урок ================= */
  ROUTES.lesson = function (view, parts) {
    var l = langById(parts[1]);
    if (!l) { view.innerHTML = '<div class="empty">Язык не найден</div>'; return; }
    var idx = parseInt(parts[2], 10) || 1;
    var lv = (l.levels || [])[idx - 1];
    if (!lv) { view.innerHTML = '<div class="empty">Уровень не найден</div>'; return; }
    var unlocked = idx === 1 || CQ.Store.isDone(l.levels[idx - 2].id);
    if (!unlocked) {
      view.innerHTML = '<div class="crumb"><span class="link" data-nav="lang/' + l.id + '">← ' + CQ.esc(l.title) + '</span></div>' +
        '<div class="empty" style="padding:80px 0"><div style="font-size:44px">🔒</div><h1 class="title">Уровень закрыт</h1>' +
        '<div class="subtitle">Сначала пройди предыдущий уровень — так работает правило «сначала задание, потом дальше».</div>' +
        '<button class="btn primary" id="btnBack">К карте уровней</button></div>';
      CQ.$('#btnBack', view).onclick = function () { nav('lang/' + l.id); };
      return;
    }

    var ctx = { lang: l.lang || l.id, levelId: lv.id, onRun: null, usedHintsOpened: 0, fails: 0 };
    var prevDone = idx > 1 && CQ.Store.isDone(l.levels[idx - 2].id);
    var alreadyDone = CQ.Store.isDone(lv.id);

    var theoryHtml = (lv.theory || []).map(function (b) {
      if (b.t === 'p') return '<div class="tb-p">' + b.html + '</div>';
      if (b.t === 'h') return '<h3>' + b.html + '</h3>';
      if (b.t === 'note') return '<div class="tb-note">' + b.html + '</div>';
      if (b.t === 'warn') return '<div class="tb-warn">' + b.html + '</div>';
      if (b.t === 'list') return '<ul class="tb-list">' + b.items.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>';
      if (b.t === 'code') return '<div class="tb-code"><pre>' + CQ.highlight(b.code, b.lang || l.lang || l.id) + '</pre></div>';
      if (b.t === 'table') return '<table class="tb-table"><tr>' + (b.head || []).map(function (h) { return '<th>' + h + '</th>'; }).join('') + '</tr>' +
        (b.rows || []).map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + c + '</td>'; }).join('') + '</tr>'; }).join('') + '</table>';
      return '';
    }).join('');

    view.innerHTML =
      '<div class="crumb"><span class="link" data-nav="dashboard">🏠</span><span>›</span>' +
      '<span class="link" data-nav="lang">' + l.emoji + ' ' + CQ.esc(l.title) + '</span><span>›</span>' +
      '<span>Уровень ' + idx + ' из ' + l.levels.length + '</span></div>' +
      '<h1 class="title" style="font-size:22px;margin-bottom:2px">' + CQ.esc(lv.title) + '</h1>' +
      '<div class="subtitle">' + CQ.esc(lv.goal || '') + '</div>' +
      '<div class="lesson-grid"><div class="theory"><h2>📖 Теория</h2>' + theoryHtml + '</div>' +
      '<div class="task-panel"><h3>🎯 Задание <span class="tag">+' + (lv.xp || 50) + ' XP</span></h3>' +
      '<div class="task-instr">' + (lv.task.instruction || '') + '</div>' +
      '<div id="taskMount"></div>' +
      '<div class="task-actions">' +
      (['stdout', 'function', 'html'].indexOf(lv.task.type) !== -1 || ctx.lang === 'python' || ctx.lang === 'js' ? '<button class="btn" id="btnRun">▶ Запустить</button>' : '') +
      '<button class="btn good" id="btnCheck">✓ Проверить</button>' +
      '<button class="btn sm" id="btnReset">↺ Сбросить</button></div>' +
      '<div id="consoleBox" class="console" style="display:none"></div>' +
      '<div id="testBox" class="test-res"></div>' +
      '<div id="winMount"></div>' +
      '<div id="hintsMount"></div>' +
      '<div id="solMount"></div>' +
      '</div></div>';

    // блокировки повторного клика
    var busy = false;

    function showConsole() {
      var c = CQ.$('#consoleBox', view);
      c.style.display = 'block'; c.innerHTML = '';
      return c;
    }
    function printTo(cons, text, cls) {
      var sp = document.createElement('div');
      if (cls) sp.className = cls;
      sp.textContent = text;
      cons.appendChild(sp);
      cons.scrollTop = cons.scrollHeight;
    }

    // рендер ввода задания
    var mount = CQ.$('#taskMount', view);
    var T = CQ.Checker.types[lv.task.type];
    if (!T) { mount.innerHTML = '<div class="tb-warn">Неизвестный тип задания</div>'; return; }
    T.render(mount, lv.task, ctx);

    var cons2 = showConsole;
    ctx.onRun = function () {
      CQ.Store.bump('runs');
      var box = cons2();
      if (lv.task.type === 'html') {
        box.style.display = 'none';
        ctx.preview(ctx.getCode());
        return;
      }
      CQ.Runner.run(ctx.lang, ctx.getCode()).then(function (run) {
        box.innerHTML = '';
        if (run.output) printTo(box, run.output.replace(/\n$/, ''));
        if (!run.ok) printTo(box, '⚠ ' + run.error, 'err');
        if (!run.output && run.ok) printTo(box, '(программа ничего не вывела)', 'dim');
      });
    };

    // Кнопка «Запустить» есть только у исполняемых заданий (stdout/function/html/python/js)
    var runBtn = CQ.$('#btnRun', view);
    if (runBtn) runBtn.addEventListener('click', ctx.onRun);

    CQ.$('#btnReset', view).addEventListener('click', function () {
      mount.innerHTML = '';
      T.render(mount, lv.task, ctx);
      CQ.$('#testBox', view).innerHTML = '';
      CQ.$('#winMount', view).innerHTML = '';
      CQ.toast('Редактор сброшен');
    });

    CQ.$('#btnCheck', view).addEventListener('click', function () {
      if (busy) return; busy = true;
      var btn = this; btn.disabled = true;
      var tb = CQ.$('#testBox', view);
      CQ.Checker.check(lv.task, ctx).then(function (res) {
        busy = false; btn.disabled = false;
        tb.innerHTML = '';
        if (res.tests) {
          res.tests.forEach(function (t) {
            var d = document.createElement('div');
            d.className = 'tr-item' + (t.pass ? '' : ' fail');
            d.innerHTML = '<span class="tri-ico">' + (t.pass ? '✅' : '❌') + '</span><div><b>' + CQ.esc(t.name) + '</b>' +
              (t.detail && !t.pass ? '<div style="white-space:pre-wrap;color:var(--muted);margin-top:3px">' + CQ.esc(t.detail) + '</div>' : '') +
              (t.detail && t.pass && String(t.detail).length < 60 ? '<div style="color:var(--muted);margin-top:2px">' + CQ.esc(t.detail) + '</div>' : '') + '</div>';
            tb.appendChild(d);
          });
        }
        if (!res.pass) {
          ctx.fails++;
          CQ.Store.failLevel(lv.id);
          printTo(CQ.$('#consoleBox', view), '', '');
          var c = CQ.$('#consoleBox', view);
          if (res.output) { c.style.display = 'block'; c.innerHTML = ''; printTo(c, res.output.replace(/\n$/, '')); }
          if (res.error) { c.style.display = 'block'; printTo(c, '⚠ ' + res.error, 'err'); }
          renderHintsAndSolution();
        } else {
          passLevel();
        }
      });
    });

    function renderHintsAndSolution() {
      var hm = CQ.$('#hintsMount', view);
      if (!hm.dataset.rendered) {
        hm.innerHTML = (lv.hints || []).map(function (h, i) {
          return '<details class="hintbox" data-h="' + i + '"><summary>' + (i + 1) + ' из ' + (lv.hints || []).length + '</summary>' +
            '<div class="hb-body">' + h + '</div></details>';
        }).join('');
        hm.dataset.rendered = '1';
        CQ.$$('details.hintbox', hm).forEach(function (d) {
          d.addEventListener('toggle', function () {
            if (d.open) { CQ.Store.useHint(lv.id); ctx.usedHintsOpened++; }
          });
        });
      }
      var sm = CQ.$('#solMount', view);
      if (ctx.fails >= 1 && !sm.dataset.rendered) {
        sm.dataset.rendered = '1';
        var solText = typeof lv.solution === 'string' ? lv.solution : JSON.stringify(lv.solution);
        sm.innerHTML = '<details class="solbox"><summary>👁 Показать решение</summary><div class="hb-body"><div class="tb-code"><pre>' +
          CQ.highlight(solText, ctx.lang) + '</pre>' +
          '<div class="tb-p" style="font-size:12.5px;color:var(--muted)">Разбери решение, но введи его в редактор сам — так мозг запомнит. 😉</div></div></div>';
      }
    }
    renderHintsAndSolution();

    function passLevel() {
      var r = CQ.Store.passLevel(lv.id, lv.xp || 50, ctx.usedHintsOpened, ctx.fails + 1);
      CQ.confetti();
      var next = l.levels[idx];
      var wm = CQ.$('#winMount', view);
      wm.innerHTML =
        '<div class="win-panel"><b>🎉 Уровень пройден!' + (r.xpGiven ? ' +' + r.xpGiven + ' XP' : ' (уже был пройден)') + '</b>' +
        '<div style="font-size:13px;margin-top:4px">' + (next ? 'Открыт следующий уровень: <b>' + CQ.esc(next.title) + '</b>' : 'Это был последний уровень языка! 🏆') + '</div>' +
        '<div class="wp-row">' +
        (next ? '<button class="btn primary" id="btnNext">Следующий уровень →</button>' :
          '<button class="btn primary" id="btnMap">🏆 Вернуться к карте</button>') +
        '<button class="btn" id="btnMap2">📋 К карте уровней</button>' +
        '</div></div>';
      var bn = CQ.$('#btnNext', view);
      if (bn) bn.onclick = function () { nav('lang/' + l.id + '/' + (idx + 1)); };
      CQ.$('#btnMap', view) && (CQ.$('#btnMap', view).onclick = function () { nav('lang/' + l.id); });
      CQ.$('#btnMap2', view).onclick = function () { nav('lang/' + l.id); };
      CQ.Gamify.afterLevel();
      var granted = CQ.Gamify.checkAll();
      CQ.Gamify.notifyGranted(granted);
      CQ.buildSidebar();
    }

    CQ.$$('[data-nav]', view).forEach(function (a) {
      a.addEventListener('click', function () { nav(a.getAttribute('data-nav')); });
    });

    // Если уровень уже пройден — покажем бейдж
    if (alreadyDone) {
      var wm2 = CQ.$('#winMount', view);
      wm2.innerHTML = '<div class="win-panel"><b>✅ Уровень уже пройден</b><div style="font-size:13px;margin-top:4px">Можешь перепройти для повторения — новые XP за него не начисляются.</div></div>';
    }
  };

  CQ.ROUTES = ROUTES;
  CQ.langProgress = langProgress;
})();
