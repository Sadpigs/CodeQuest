/* ============ CodeQuest — утилиты ============ */
window.CQ = window.CQ || {};
/* Версия прогресса: растёт при изменении пройденных уровней.
   Сайдбар использует её, чтобы не пересчитывать проценты всех языков
   на каждом рендере (оптимизация под слабые ПК). */
CQ.progressVer = 0;
CQ.bumpProgressVer = function () { CQ.progressVer++; };
(function () {
  'use strict';

  CQ.$ = function (sel, root) { return (root || document).querySelector(sel); };
  CQ.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  CQ.esc = function (s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };

  // Рендер простого markdown для заметок/шпаргалок
  CQ.md = function (src) {
    var s = CQ.esc(src);
    var lines = s.split('\n'), out = [], inCode = false, inList = false, buf = [];
    function flushList() { if (inList) { out.push('<ul>' + buf.join('') + '</ul>'); buf = []; inList = false; } }
    for (var i = 0; i < lines.length; i++) {
      var ln = lines[i];
      if (/^```/.test(ln)) {
        if (inCode) { out.push('<pre>' + buf.join('\n') + '</pre>'); buf = []; inCode = false; }
        else { flushList(); inCode = true; }
        continue;
      }
      if (inCode) { buf.push(ln); continue; }
      var h = ln.match(/^(#{1,3})\s+(.*)$/);
      if (h) { flushList(); out.push('<h' + h[1].length + '>' + inline(h[2]) + '</h' + h[1].length + '>'); continue; }
      if (/^\s*[-*]\s+/.test(ln)) { if (!inList) { flushList(); inList = true; } buf.push('<li>' + inline(ln.replace(/^\s*[-*]\s+/, '')) + '</li>'); continue; }
      if (/^\s*>\s?/.test(ln)) { flushList(); out.push('<blockquote>' + inline(ln.replace(/^\s*>\s?/, '')) + '</blockquote>'); continue; }
      if (ln.trim() === '') { flushList(); continue; }
      flushList(); out.push('<p>' + inline(ln) + '</p>');
    }
    if (inCode) out.push('<pre>' + buf.join('\n') + '</pre>');
    flushList();
    function inline(t) {
      return t
        .replace(/`([^`]+)`/g, '<code>$1</code>')
        .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
        .replace(/\*([^*]+)\*/g, '<i>$1</i>')
        .replace(/\[\[([^\]]+)\]\]/g, '<span class="link" data-note-link="$1">$1</span>');
    }
    return out.join('\n');
  };

  // Нормализация вывода для сравнения
  CQ.normOut = function (s) {
    var lines = String(s == null ? '' : s).replace(/\r\n?/g, '\n').split('\n')
      .map(function (l) { return l.replace(/\s+$/g, ''); });
    while (lines.length && lines[0] === '') lines.shift();
    while (lines.length && lines[lines.length - 1] === '') lines.pop();
    return lines;
  };

  CQ.normQuery = function (s) {
    return String(s || '')
      .replace(/--[^\n]*/g, ' ')
      .replace(/\s+/g, ' ')
      .replace(/\s*([(),;=<>])\s*/g, '$1')
      .trim().toUpperCase();
  };

  CQ.todayStr = function () {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  };
  CQ.yesterdayStr = function () {
    var d = new Date(); d.setDate(d.getDate() - 1);
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  };
  CQ.timeAgo = function (ts) {
    var diff = Date.now() - ts, m = Math.floor(diff / 60000);
    if (m < 1) return 'только что';
    if (m < 60) return m + ' мин назад';
    var h = Math.floor(m / 60); if (h < 24) return h + ' ч назад';
    var d = Math.floor(h / 24); if (d < 30) return d + ' дн назад';
    return new Date(ts).toLocaleDateString('ru-RU');
  };

  CQ.toast = function (msg, kind) {
    var box = CQ.$('#toasts');
    var t = document.createElement('div');
    t.className = 'toast ' + (kind || '');
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(function () { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; }, 3400);
    setTimeout(function () { t.remove(); }, 3800);
  };

  // Слабое железо — определяем один раз (для авто-режима и конфетти)
  var WEAK_HW = false;
  try {
    WEAK_HW = (navigator.hardwareConcurrency !== undefined && navigator.hardwareConcurrency <= 2) ||
              (navigator.deviceMemory !== undefined && navigator.deviceMemory <= 2);
  } catch (e) {}

  CQ.isWeakHW = function () { return WEAK_HW; };
  CQ.isLite = function () {
    try { return !!(CQ.Store.get().settings.lite); } catch (e) { return false; }
  };

  CQ.confetti = function () {
    if (CQ.isLite()) return; // в режиме слабого ПК конфетти отключено
    var chars = ['🎉', '⭐', '✨', '🎊', '💚', '💙', '🟣', '🟡'];
    var count = WEAK_HW ? 10 : 26; // на слабом железе — вдвое меньше частиц
    for (var i = 0; i < count; i++) {
      var el = document.createElement('div');
      el.className = 'confetti';
      el.textContent = chars[Math.floor(Math.random() * chars.length)];
      el.style.left = (Math.random() * 96) + 'vw';
      el.style.animationDuration = (1.4 + Math.random() * 1.6) + 's';
      el.style.animationDelay = (Math.random() * 0.4) + 's';
      document.body.appendChild(el);
      setTimeout(function (e) { return function () { e.remove(); }; }(el), 3600);
    }
  };

  CQ.modal = function (html, onOpen) {
    var bg = document.createElement('div');
    bg.className = 'modal-bg';
    bg.innerHTML = '<div class="modal">' + html + '</div>';
    bg.addEventListener('click', function (e) { if (e.target === bg) bg.remove(); });
    document.body.appendChild(bg);
    if (onOpen) onOpen(bg);
    return bg;
  };

  CQ.download = function (filename, text, mime) {
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: mime || 'text/plain;charset=utf-8' }));
    a.download = filename;
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 600);
  };

  CQ.deepEqual = function (a, b) {
    if (a === b) return true;
    if (typeof a !== typeof b) return false;
    if (a == null || b == null) return a === b;
    if (Array.isArray(a) && Array.isArray(b)) {
      if (a.length !== b.length) return false;
      for (var i = 0; i < a.length; i++) if (!CQ.deepEqual(a[i], b[i])) return false;
      return true;
    }
    if (typeof a === 'object' && typeof b === 'object') {
      var ka = Object.keys(a).sort(), kb = Object.keys(b).sort();
      if (!CQ.deepEqual(ka, kb)) return false;
      for (var k in a) if (!CQ.deepEqual(a[k], b[k])) return false;
      return true;
    }
    return false;
  };
})();
