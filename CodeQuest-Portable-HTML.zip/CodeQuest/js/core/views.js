/* ============ CodeQuest — песочница, заметки, шпаргалки, инструменты, ачивки, настройки, поиск ============ */
(function () {
  'use strict';
  var ROUTES = function () { return CQ.ROUTES; }();
  function langById(id) { return (CQ.LANGS || {})[id] || null; }

  /* ================= Песочница ================= */
  var PG = { lang: 'python', code: {} };
  ROUTES.playground = function (view) {
    view.innerHTML =
      '<h1 class="title">🧪 Песочница</h1>' +
      '<div class="subtitle">Пиши любой код и сразу запускай — без правил и заданий. Идеально для экспериментов из уроков.</div>' +
      '<div class="tabs" id="pgTabs">' +
      '<button class="tab' + (PG.lang === 'python' ? ' active' : '') + '" data-l="python">🐍 Python</button>' +
      '<button class="tab' + (PG.lang === 'js' ? ' active' : '') + '" data-l="js">🟨 JavaScript</button>' +
      '<button class="tab' + (PG.lang === 'brainfuck' ? ' active' : '') + '" data-l="brainfuck">🤯 Brainfuck</button></div>' +
      '<div class="pg-grid"><div>' +
      '<div id="pgEditor"></div>' +
      '<div style="margin-top:10px;display:flex;gap:9px"><button class="btn primary" id="pgRun">▶ Запустить <kbd>Ctrl+Enter</kbd></button>' +
      '<button class="btn sm" id="pgClear">Очистить вывод</button></div></div>' +
      '<div><div class="tag" style="margin-bottom:6px">Вывод</div>' +
      '<div class="console" id="pgOut" style="min-height:260px;max-height:60vh">Нажми «Запустить», чтобы увидеть результат…</div></div></div>';

    var starters = {
      python: '# Добро пожаловать в песочницу Python!\n# Меняй код и жми Запустить (или Ctrl+Enter)\n\nname = "кодер"\nfor i in range(1, 4):\n    print(i, "- й шаг сделан,", name)\n\nprint("Сумма 2+2 =", 2 + 2)\n',
      js: '// Добро пожаловать в песочницу JavaScript!\n// Меняй код и жми Запустить (или Ctrl+Enter)\n\nconst name = "кодер";\nfor (let i = 1; i <= 3; i++) {\n  console.log(i + "- й шаг сделан,", name);\n}\n\nconsole.log("Сумма 2+2 =", 2 + 2);\n',
      brainfuck: 'Добро пожаловать в песочницу Brainfuck!\nЭти строки — комментарии: BF читает только 8 символов-команд.\n\nЭтот код печатает Hello World! (каждая пачка «+» — код символа):\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++.+++++++++++++++++++++++++++++.+++++++..+++.-------------------------------------------------------------------------------.+++++++++++++++++++++++++++++++++++++++++++++++++++++++.++++++++++++++++++++++++.+++.------.--------.-------------------------------------------------------------------.\n'
    };
    var ed = CQ.Editor(CQ.$('#pgEditor', view), {
      lang: PG.lang, value: PG.code[PG.lang] || starters[PG.lang], height: 320,
      onRun: run, onChange: function (v) { PG.code[PG.lang] = v; }
    });

    CQ.$$('#pgTabs .tab', view).forEach(function (t) {
      t.addEventListener('click', function () {
        PG.lang = t.getAttribute('data-l');
        ROUTES.playground(view);
      });
    });
    function run() {
      CQ.Store.bump('sandboxRuns');
      var out = CQ.$('#pgOut', view);
      out.textContent = '';
      CQ.Runner.run(PG.lang, ed.get()).then(function (r) {
        if (r.output) out.textContent = r.output.replace(/\n$/, '');
        if (!r.ok) {
          var e = document.createElement('div');
          e.className = 'err';
          e.textContent = '⚠ ' + r.error;
          out.appendChild(e);
        }
        if (!r.output && r.ok) out.textContent = '(программа ничего не вывела)';
        CQ.Gamify.afterLevel();
      });
    }
    CQ.$('#pgRun', view).addEventListener('click', run);
    CQ.$('#pgClear', view).addEventListener('click', function () { CQ.$('#pgOut', view).textContent = ''; });
  };

  /* ================= Заметки ================= */
  var CUR_NOTE = null;
  ROUTES.notes = function (view) {
    var s = CQ.Store.get();
    if (!CUR_NOTE && s.notes.length) CUR_NOTE = s.notes[0].id;

    var list = s.notes.map(function (n) {
      return '<div class="note-item' + (n.id === CUR_NOTE ? ' active' : '') + '" data-id="' + n.id + '">' +
        '<b>' + CQ.esc(n.title || 'Без названия') + '</b><span>' + CQ.esc((n.body || '').slice(0, 60) || 'пусто') + '</span></div>';
    }).join('');

    var cur = s.notes.find(function (n) { return n.id === CUR_NOTE; });

    view.innerHTML =
      '<h1 class="title">📝 Мои заметки</h1>' +
      '<div class="subtitle">Твои конспекты — как личная вики (в духе Obsidian). Поддерживается разметка: <code class="inline"># заголовки</code>, <code class="inline">**жирный**</code>, <code class="inline">`код`</code>, списки, <code class="inline">[[ссылки на заметки]]</code>.</div>' +
      '<div class="notes-layout"><div>' +
      '<button class="btn primary" id="nAdd" style="width:100%;margin-bottom:10px">＋ Новая заметка</button>' +
      '<button class="btn sm" id="nExport" style="width:100%;margin-bottom:12px">⬇️ Экспорт всех заметок (.md)</button>' +
      '<div id="nList">' + (list || '<div class="empty" style="padding:20px 0">Пока нет заметок.<br>Создай первую — запиши, что понял из урока!</div>') + '</div>' +
      '</div><div id="nEditor">' +
      (cur ?
        '<input class="note-input" id="nTitle" value="' + CQ.esc(cur.title) + '" placeholder="Название заметки">' +
        '<div style="margin:9px 0;display:flex;gap:8px">' +
        '<button class="btn sm good" id="nSave">💾 Сохранить</button>' +
        '<button class="btn sm" id="nPrev">👁 Предпросмотр</button>' +
        '<button class="btn sm danger" id="nDel">🗑 Удалить</button></div>' +
        '<textarea class="note-area" id="nBody" placeholder="Пиши конспект своими словами — так запоминается лучше всего…">' + CQ.esc(cur.body) + '</textarea>' +
        '<div class="md-preview" id="nMd" style="display:none"></div>'
        : '<div class="empty">Выбери заметку слева или создай новую</div>') +
      '</div></div>';

    CQ.$$('#nList .note-item', view).forEach(function (n) {
      n.addEventListener('click', function () { CUR_NOTE = n.getAttribute('data-id'); ROUTES.notes(view); });
    });
    CQ.$('#nAdd', view).addEventListener('click', function () {
      var n = CQ.Store.addNote('Новая заметка', '');
      CUR_NOTE = n.id;
      ROUTES.notes(view);
      CQ.Gamify.afterLevel();
    });
    CQ.$('#nExport', view).addEventListener('click', function () {
      if (!s.notes.length) { CQ.toast('Нет заметок для экспорта', 'bad'); return; }
      var md = s.notes.map(function (n) { return '# ' + n.title + '\n\n' + n.body + '\n\n---\n'; }).join('\n');
      CQ.download('codequest-notes.md', md, 'text/markdown;charset=utf-8');
      CQ.toast('Заметки выгружены в .md файл', 'good');
    });
    if (cur) {
      CQ.$('#nSave', view).addEventListener('click', function () {
        CQ.Store.updateNote(CUR_NOTE, CQ.$('#nTitle', view).value, CQ.$('#nBody', view).value);
        CQ.toast('Заметка сохранена ✅', 'good');
        CQ.Gamify.afterLevel();
        ROUTES.notes(view);
      });
      CQ.$('#nPrev', view).addEventListener('click', function () {
        var md = CQ.$('#nMd', view), ta = CQ.$('#nBody', view);
        if (md.style.display === 'none') {
          md.innerHTML = CQ.md(ta.value);
          md.style.display = 'block'; ta.style.display = 'none';
          CQ.$$('#nMd .link[data-note-link]', view).forEach(function (a) {
            a.addEventListener('click', function () {
              var t = a.getAttribute('data-note-link');
              var st = CQ.Store.get();
              var found = st.notes.find(function (n) { return n.title === t; });
              if (found) CUR_NOTE = found.id;
              else { var nn = CQ.Store.addNote(t, ''); CUR_NOTE = nn.id; }
              ROUTES.notes(view);
            });
          });
          CQ.$('#nPrev', view).textContent = '✏️ Редактировать';
        } else {
          md.style.display = 'none'; ta.style.display = 'block';
          CQ.$('#nPrev', view).textContent = '👁 Предпросмотр';
        }
      });
      CQ.$('#nDel', view).addEventListener('click', function () {
        CQ.modal('<h3>Удалить заметку?</h3><div class="tb-p">Действие необратимо.</div>' +
          '<div class="m-actions"><button class="btn" id="mc">Отмена</button><button class="btn danger" id="md">Удалить</button></div>', function (bg) {
          bg.querySelector('#mc').onclick = function () { bg.remove(); };
          bg.querySelector('#md').onclick = function () { CQ.Store.delNote(CUR_NOTE); CUR_NOTE = null; bg.remove(); ROUTES.notes(view); };
        });
      });
    }
  };

  /* ================= Шпаргалки ================= */
  ROUTES.cheats = function (view, parts) {
    var cur = parts[1] || Object.keys(CQ.LANGS)[0];
    var l = langById(cur) || Object.values(CQ.LANGS)[0];
    CQ.Store.grant('cheater');
    var catOf = function (id) { return CQ.langCats(id)[0] || 'general'; };
    var catName = {};
    (CQ.CATEGORIES || []).forEach(function (c) { catName[c.id] = c.name; });
    var byCat = {};
    Object.keys(CQ.LANGS).forEach(function (id) {
      var c = catOf(id);
      (byCat[c] = byCat[c] || []).push(id);
    });
    var opts = Object.keys(byCat).map(function (c) {
      return '<optgroup label="' + (catName[c] || c) + '">' + byCat[c].map(function (id) {
        return '<option value="' + id + '"' + (id === l.id ? ' selected' : '') + '>' + CQ.LANGS[id].emoji + ' ' + CQ.LANGS[id].title + '</option>';
      }).join('') + '</optgroup>';
    }).join('');
    var body = (l.cheats || []).map(function (c) {
      return '<div class="cheat-group"><h3>' + CQ.esc(c.title) + '</h3>' +
        (c.code ? '<div class="tb-code"><pre>' + CQ.highlight(c.code, l.lang || l.id) + '</pre></div>' : '') +
        (c.list ? '<ul class="tb-list">' + c.list.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>' : '') +
        '</div>';
    }).join('') || '<div class="empty">Шпаргалка скоро появится</div>';

    view.innerHTML =
      '<h1 class="title">📋 Шпаргалки</h1>' +
      '<div class="subtitle">Всё главное по языку на одной странице — открывай, когда забыл синтаксис.</div>' +
      '<select class="note-input" id="cheatSel" style="margin-bottom:14px;cursor:pointer">' + opts + '</select>' + body;

    CQ.$('#cheatSel', view).addEventListener('change', function () {
      nav('cheats/' + this.value);
    });
  };

  /* ================= Инструменты ================= */
  var CUR_TOOL = null;
  var TOOL_TAB = 'builtin';
  ROUTES.tools = function (view) {
    var builtin = CQ.TOOLBOX || [];
    var html;
    if (TOOL_TAB === 'builtin') {
      html = '<h1 class="title">🧰 Встроенные инструменты</h1>' +
        '<div class="subtitle">' + builtin.length + ' рабочих инструментов прямо в приложении: работают офлайн, без сайтов и регистрации. Всё, что раньше открывалось в браузере, — теперь здесь.</div>';
      html += '<div class="tabs" id="toolCats" style="margin-bottom:12px">';
      html += '<button class="tab' + (TOOLS.cat === 'all' ? ' active' : '') + '" data-tc="all">🌍 Все · ' + builtin.length + '</button>';
      (CQ.TOOLCATS || []).forEach(function (c) {
        var n = builtin.filter(function (t) { return t.cat === c.id; }).length;
        if (n) html += '<button class="tab' + (TOOLS.cat === c.id ? ' active' : '') + '" data-tc="' + c.id + '">' + c.name + ' · ' + n + '</button>';
      });
      html += '</div>';
      html += '<div class="tools-layout"><div class="tools-nav">';
      var usedToolsMap = CQ.Store.get().stats.tools || {};
      builtin.filter(function (t) { return TOOLS.cat === 'all' || t.cat === TOOLS.cat; }).forEach(function (t) {
        html += '<button class="tool-btn' + (CUR_TOOL === t.id ? ' active' : '') + '" data-tool="' + t.id + '">' +
          '<span class="tb-ico">' + t.ico + '</span><span class="tb-name">' + t.name + '</span>' +
          (usedToolsMap[t.id] ? '<span class="tb-used">✓</span>' : '') + '</button>';
      });
      html += '</div><div class="tool-panel" id="toolPanel"></div></div>';
    } else {
      html = '<h1 class="title">🧰 Полезные инструменты</h1>' +
        '<div class="subtitle">Это вторая, «внешняя» подборка: проверенные сайты и программы для дальнейшего роста. Основные инструменты уже встроены в приложение — вкладка «Встроенные».</div>';
      CQ.TOOLS.forEach(function (cat) {
        html += '<div class="tool-cat"><h3 style="margin-bottom:10px">' + cat.cat + '</h3><div class="tool-grid">';
        cat.items.forEach(function (t) {
          html += '<div class="tool-card"><div class="t-ico">' + t.ico + '</div><div><b>' + CQ.esc(t.name) + '</b>' +
            '<div class="t-desc">' + CQ.esc(t.desc) + '</div>' +
            '<div class="t-desc" style="color:var(--text)">' + CQ.esc(t.why || '') + '</div>' +
            (t.url ? '<a class="t-url" href="' + t.url + '" target="_blank" rel="noopener">' + t.url + '</a>' : '') +
            '</div></div>';
        });
        html += '</div></div>';
      });
    }
    html += '<div class="tabs" style="margin-top:18px" id="toolTabs">' +
      '<button class="tab' + (TOOL_TAB === 'builtin' ? ' active' : '') + '" data-tt="builtin">🧰 Встроенные (' + builtin.length + ')</button>' +
      '<button class="tab' + (TOOL_TAB === 'online' ? ' active' : '') + '" data-tt="online">🌐 Внешняя подборка</button></div>';
    view.innerHTML = html;

    CQ.$$('#toolTabs .tab', view).forEach(function (t) {
      t.addEventListener('click', function () { TOOL_TAB = t.getAttribute('data-tt'); ROUTES.tools(view); });
    });
    CQ.$$('#toolCats .tab', view).forEach(function (t) {
      t.addEventListener('click', function () { TOOLS.cat = t.getAttribute('data-tc'); ROUTES.tools(view); });
    });
    CQ.$$('[data-tool]', view).forEach(function (b) {
      b.addEventListener('click', function () {
        CUR_TOOL = b.getAttribute('data-tool');
        CQ.Store.toolUse(CUR_TOOL);
        ROUTES.tools(view);
      });
    });
    // рендер активного инструмента
    if (TOOL_TAB === 'builtin') {
      var panel = CQ.$('#toolPanel', view);
      var t = builtin.find(function (x) { return x.id === CUR_TOOL; }) || builtin[0];
      if (t) {
        CUR_TOOL = t.id;
        var head = document.createElement('div');
        head.className = 'tool-head';
        head.innerHTML = '<div class="th-ico">' + t.ico + '</div><div><b>' + t.name + '</b><div class="t-desc">' + t.desc + '</div></div>';
        panel.appendChild(head);
        try { t.render(panel); }
        catch (e) {
          panel.innerHTML += '<div class="tb-warn">Инструмент упал с ошибкой: ' + CQ.esc(String(e.message)) + '</div>';
        }
        var hint = document.createElement('div');
        hint.className = 'tool-stat';
        hint.innerHTML = 'Инструмент №' + (builtin.indexOf(t) + 1) + ' из ' + builtin.length + ' · открой 8 разных, чтобы получить ачивку «Инструменталист» 🧰';
        panel.appendChild(hint);
      }
    }
  };
  var TOOLS = { cat: 'all' };

  /* ================= Достижения ================= */
  ROUTES.achievements = function (view) {
    var s = CQ.Store.get();
    var un = Object.keys(s.achievements).length;
    var html = '<h1 class="title">🏅 Достижения</h1>' +
      '<div class="subtitle">Открыто ' + un + ' из ' + CQ.Gamify.ACH.length + '. Продолжай в том же духе!</div><div class="ach-grid">';
    CQ.Gamify.ACH.forEach(function (a) {
      var ts = s.achievements[a.id];
      html += '<div class="ach' + (ts ? ' unlocked' : '') + '"><div class="a-ico">' + a.ico + '</div><b>' + a.name + '</b><span>' + a.desc + '</span>' +
        (ts ? '<span class="a-date">📅 ' + new Date(ts).toLocaleDateString('ru-RU') + '</span>' : '<span class="a-date">🔒 не открыто</span>') + '</div>';
    });
    html += '</div>';
    view.innerHTML = html;
  };

  /* ================= Поиск =================
     Оптимизация под слабые ПК: индекс по всем уровням строится один раз
     (раньше при каждом поиске заново склеивалась вся теория ~700 уровней). */
  var SEARCH_INDEX = null;
  function searchIndex() {
    if (SEARCH_INDEX) return SEARCH_INDEX;
    var idx = [];
    Object.keys(CQ.LANGS).forEach(function (id) {
      var l = CQ.LANGS[id];
      (l.levels || []).forEach(function (lv, i) {
        var text = (lv.title + ' ' + (lv.goal || '') + ' ' + (lv.theory || []).map(function (b) {
          return b.html || b.code || (b.items || []).join(' ') || '';
        }).join(' ')).toLowerCase();
        idx.push({ lang: l, idx: i + 1, title: lv.title, goal: lv.goal, text: text });
      });
    });
    SEARCH_INDEX = idx;
    return idx;
  }

  ROUTES.search = function (view, parts) {
    var q = parts[1] ? decodeURIComponent(parts[1]) : '';
    view.innerHTML = '<h1 class="title">🔍 Поиск</h1>' +
      '<div class="subtitle">Ищи уроки по темам: циклы, функции, списки…</div>' +
      '<input class="note-input" id="sIn" placeholder="Введите запрос и нажмите Enter" value="' + CQ.esc(q) + '" style="margin-bottom:16px">' +
      '<div id="sRes"></div>';
    var inp = CQ.$('#sIn', view);
    inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') nav('search/' + encodeURIComponent(inp.value.trim()));
    });
    if (!q) return;
    var res = [];
    var ql = q.toLowerCase();
    var MAX_SHOW = 120;
    var idx = searchIndex();
    for (var i = 0; i < idx.length && res.length <= MAX_SHOW; i++) {
      if (idx[i].text.indexOf(ql) !== -1) res.push(idx[i]);
    }
    var out = CQ.$('#sRes', view);
    if (!res.length) { out.innerHTML = '<div class="empty">Ничего не найдено 😔 Попробуй другое слово</div>'; return; }
    out.innerHTML = '<div class="subtitle">Найдено уровней: ' + res.length + (res.length > MAX_SHOW ? ' (показаны первые ' + MAX_SHOW + ')' : '') + '</div>' + res.map(function (r) {
      var unlocked = r.idx === 1 || CQ.Store.isDone(r.lang.levels[r.idx - 2].id);
      return '<div class="note-item" data-go="' + r.lang.id + '/' + r.idx + '"><b>' + r.lang.emoji + ' ' + CQ.esc(r.lang.title) + ' · Уровень ' + r.idx + ' · ' + CQ.esc(r.title) + '</b>' +
        '<span>' + CQ.esc(r.goal || '') + (unlocked ? '' : ' · 🔒 закрыт') + '</span></div>';
    }).join('');
    CQ.$$('[data-go]', view).forEach(function (n) {
      n.addEventListener('click', function () { nav('lang/' + n.getAttribute('data-go')); });
    });
  };

  /* ================= Настройки ================= */
  ROUTES.settings = function (view) {
    var s = CQ.Store.get();
    var theme = document.documentElement.getAttribute('data-theme');
    var lite = !!s.settings.lite;
    view.innerHTML =
      '<h1 class="title">⚙️ Настройки</h1><div class="subtitle">Внешний вид, резервные копии и данные приложения.</div>' +
      '<div class="card" style="margin-bottom:14px"><h3 style="margin-bottom:10px">🎨 Тема оформления</h3>' +
      '<div class="tabs" style="margin:0">' +
      '<button class="tab' + (theme === 'dark' ? ' active' : '') + '" data-t="dark">🌙 Тёмная</button>' +
      '<button class="tab' + (theme === 'light' ? ' active' : '') + '" data-t="light">☀️ Светлая</button></div></div>' +

      '<div class="card" style="margin-bottom:14px"><h3 style="margin-bottom:8px">🪶 Режим слабого ПК ' + (lite ? '<span class="tag">включён</span>' : '') + '</h3>' +
      '<div class="tb-p" style="font-size:13.5px">Убирает анимации и конфетти, ускоряет подсветку кода при вводе. ' +
      'Стоит включить, если компьютер слабый или приложение тормозит: все функции обучения остаются, становится только быстрее.</div>' +
      '<div style="margin-top:10px"><button class="btn ' + (lite ? 'good' : '') + '" id="setLite">' + (lite ? '✓ Включено — выключить' : 'Включить режим слабого ПК') + '</button></div></div>' +

      '<div class="card" style="margin-bottom:14px"><h3 style="margin-bottom:8px">💾 Резервная копия прогресса</h3>' +
      '<div class="tb-p" style="font-size:13.5px">Сохраняй прогресс в файл перед переустановкой системы или переносом на другой компьютер — и восстанавливай оттуда.</div>' +
      '<div style="display:flex;gap:9px;margin-top:10px;flex-wrap:wrap">' +
      '<button class="btn primary" id="setExport">⬇️ Экспортировать прогресс</button>' +
      '<button class="btn" id="setImportBtn">⬆️ Импортировать из файла</button>' +
      '<input type="file" id="setImport" accept=".json,application/json" style="display:none"></div></div>' +

      '<div class="card" style="margin-bottom:14px"><h3 style="margin-bottom:8px">📊 Статистика</h3>' +
      '<div class="stat-row" style="margin:0">' +
      '<div class="stat"><span class="st-ico">✅</span><div><b>' + Object.values(s.levels).filter(function (x) { return x.done; }).length + '</b><span>уровней пройдено</span></div></div>' +
      '<div class="stat"><span class="st-ico">▶️</span><div><b>' + (s.stats.runs || 0) + '</b><span>запусков кода</span></div></div>' +
      '<div class="stat"><span class="st-ico">🧪</span><div><b>' + (s.stats.sandboxRuns || 0) + '</b><span>запусков в песочнице</span></div></div>' +
      '<div class="stat"><span class="st-ico">📅</span><div><b>' + new Date(s.stats.startedAt).toLocaleDateString('ru-RU') + '</b><span>в CodeQuest с</span></div></div>' +
      '</div></div>' +

      '<div class="card"><h3 style="margin-bottom:8px">⚠️ Опасная зона</h3>' +
      '<div class="tb-p" style="font-size:13.5px">Полный сброс удалит весь прогресс, XP, достижения и заметки. Обратно не вернуть (если нет резервной копии!).</div>' +
      '<button class="btn danger" id="setReset" style="margin-top:8px">🗑 Сбросить всё</button></div>' +

      '<div class="card" style="margin-top:14px"><h3 style="margin-bottom:8px">ℹ️ О программе</h3>' +
      '<div class="tb-p" style="font-size:13.5px"><b>CodeQuest</b> v1.3 — офлайн-академия программирования: ' +
      (function () {
        var nLangs = Object.keys(CQ.LANGS || {}).length;
        var nLv = 0; Object.keys(CQ.LANGS || {}).forEach(function (id) { nLv += (CQ.LANGS[id].levels || []).length; });
        var nTools = (CQ.TOOLBOX || []).length;
        var nPaths = (CQ.PATHS || []).length;
        return '<b>' + nLangs + ' языков</b> и ' + nLv + ' уровней, <b>' + nPaths + ' карьерных траекторий</b>, ' + nTools + ' встроенных инструментов разработчика и 28 достижений.';
      })() +
      ' Работает полностью без интернета: Python запускается через встроенный интерпретатор (Skulpt), JavaScript — через песочницу браузера, HTML/CSS — живое превью, Brainfuck — собственным интерпретатором. Остальные языки проверяются анализом структуры кода, квизами и задачами «предскажи вывод». Все инструменты (JSON, регулярки, Base64, хеши и другие) встроены прямо в приложение. Данные хранятся локально на этом компьютере.</div></div>';

    CQ.$$('.tab[data-t]', view).forEach(function (t) {
      t.addEventListener('click', function () {
        CQ.Store.setTheme(t.getAttribute('data-t'));
        CQ.applyTheme();
        ROUTES.settings(view);
      });
    });
    CQ.$('#setLite', view).addEventListener('click', function () {
      var nv = !CQ.Store.get().settings.lite;
      CQ.Store.setLite(nv);
      CQ.applyTheme();
      CQ.toast(nv ? '🪶 Режим слабого ПК включён' : '🪶 Режим слабого ПК выключен');
      ROUTES.settings(view);
    });
    CQ.$('#setExport', view).addEventListener('click', function () {
      CQ.download('codequest-progress.json', CQ.Store.export(), 'application/json');
      CQ.toast('Прогресс сохранён в файл ✅', 'good');
    });
    var fi = CQ.$('#setImport', view);
    CQ.$('#setImportBtn', view).addEventListener('click', function () { fi.click(); });
    fi.addEventListener('change', function () {
      var f = fi.files[0];
      if (!f) return;
      var rd = new FileReader();
      rd.onload = function () {
        try {
          CQ.Store.import(String(rd.result));
          CQ.toast('Прогресс восстановлен 🎉', 'good');
          CQ.Router.rerender();
        } catch (e) { CQ.toast('Ошибка файла: ' + e.message, 'bad'); }
      };
      rd.readAsText(f);
    });
    CQ.$('#setReset', view).addEventListener('click', function () {
      CQ.modal('<h3>Точно сбросить ВСЁ?</h3><div class="tb-p">Прогресс, XP, ачивки и заметки будут удалены безвозвратно.</div>' +
        '<div class="m-actions"><button class="btn" id="mc">Отмена</button><button class="btn danger" id="md">Да, удалить всё</button></div>', function (bg) {
        bg.querySelector('#mc').onclick = function () { bg.remove(); };
        bg.querySelector('#md').onclick = function () {
          CQ.Store.reset(); CQ.applyTheme(); bg.remove();
          CQ.toast('Приложение сброшено. С чистого листа! 🌱');
          CQ.Router.rerender();
        };
      });
    });
  };

  function nav(path) { location.hash = path; }
})();
