/* CodeQuest Service Worker — полное офлайн-кэширование.
   Активен только при работе через http(s) (хостинг, PWA-установка).
   При file:// и в Android APK — не регистрируется (там всё и так локально). */
var CACHE = 'codequest-v15';
var CORE = [
  './',
  './index.html',
  './manifest.json',
  './css/style.css',
  './vendor/skulpt.min.js',
  './vendor/skulpt-stdlib.js',
  './icons/icon-192.png',
  './icons/icon-512.png'
];
var CORE_JS = [
  'js/neutralino.js',
  'js/core/util.js', 'js/core/state.js', 'js/core/gamify.js',
  'js/core/highlight.js', 'js/core/checker.js', 'js/core/editor.js',
  'js/core/data_tools.js', 'js/core/ui.js', 'js/core/views.js',
  'js/core/tools.js', 'js/core/trajectories.js', 'js/core/main.js'
];
var LANGS = [
  'python','javascript','htmlcss','typescript','c','cpp','java','cs','go','rust',
  'php','ruby','kotlin','swift','dart','sql','r','julia','lua','perl','bash',
  'powershell','scala','haskell','clojure','elixir','erlang','fsharp','ocaml',
  'lisp','prolog','groovy','objc','asm','zig','nim','crystal','solidity',
  'gdscript','matlab','fortran','cobol','pascal','ada','vb','smalltalk','tcl',
  'awk','elm','coffee','json','yaml','toml','xml','markdown','regex','makefile',
  'graphql','brainfuck','lolcode','shakespeare','d','v','odin','vala','haxe',
  'red','eiffel','io','forth','factor','apl','verilog','vhdl','rexx','snobol','algol',
  'scheme','racket','raku','vba','batch','applescript','autohotkey','actionscript','purescript','reason','logo','icon','rebol','j','q','wolfram','sas','plsql','abap','cuda','glsl','processing','gml'
];
var ALL = CORE
  .concat(CORE_JS.map(function (p) { return './' + p; }))
  .concat(LANGS.map(function (p) { return './content/' + p + '.js'; }));

self.addEventListener('install', function (e) {
  e.waitUntil(
    caches.open(CACHE).then(function (c) {
      return c.addAll(ALL).then(function () { return self.skipWaiting(); });
    })
  );
});

self.addEventListener('activate', function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (k) { return k !== CACHE; })
        .map(function (k) { return caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});

/* Cache-first: приложение полностью локальное, сеть нужна только впервые */
self.addEventListener('fetch', function (e) {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request, { ignoreSearch: true }).then(function (hit) {
      return hit || fetch(e.request).then(function (resp) {
        var copy = resp.clone();
        caches.open(CACHE).then(function (c) { try { c.put(e.request, copy); } catch (err) {} });
        return resp;
      }).catch(function () {
        if (e.request.mode === 'navigate') return caches.match('./index.html');
      });
    })
  );
});
