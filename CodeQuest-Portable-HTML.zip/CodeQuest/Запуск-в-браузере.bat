@echo off
rem ===== CodeQuest: запуск в отдельном окне браузера (как приложение) =====
set "EDGE86=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
set "EDGE64=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
set "CHROME86=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"

if exist "%EDGE86%" ( start "" "%EDGE86%" --app="file:///%~dp0index.html" & exit /b )
if exist "%EDGE64%" ( start "" "%EDGE64%" --app="file:///%~dp0index.html" & exit /b )
if exist "%CHROME%" ( start "" "%CHROME%" --app="file:///%~dp0index.html" & exit /b )
if exist "%CHROME86%" ( start "" "%CHROME86%" --app="file:///%~dp0index.html" & exit /b )

rem Если ни Edge, ни Chrome не найдены — открываем стандартным браузером
start "" "%~dp0index.html"
