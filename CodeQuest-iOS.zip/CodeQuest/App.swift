// CodeQuest — нативная iOS-обёртка (WKWebView) для офлайн веб-приложения.
// Весь веб-контент лежит в папке www/ внутри бандла и раздаётся через
// собственную схему cq://localhost — так localStorage работает как «первосторонний»
// (first-party), прогресс пользователя сохраняется на устройстве.

import SwiftUI
import WebKit

// MARK: - Раздача файлов приложения по схеме cq://

final class CQSchemeHandler: NSObject, WKURLSchemeHandler {

    private let root: URL

    override init() {
        // Folder reference «www» копируется в корень бандла как есть
        self.root = Bundle.main.bundleURL.appendingPathComponent("www")
        super.init()
    }

    private static let mimes: [String: String] = [
        "html": "text/html", "htm": "text/html",
        "js": "application/javascript", "mjs": "application/javascript",
        "css": "text/css",
        "json": "application/json", "webmanifest": "application/manifest+json",
        "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
        "gif": "image/gif", "svg": "image/svg+xml", "ico": "image/x-icon",
        "webp": "image/webp",
        "woff": "font/woff", "woff2": "font/woff2",
        "ttf": "font/ttf", "otf": "font/otf",
        "mp3": "audio/mpeg", "wav": "audio/wav", "ogg": "audio/ogg", "mp4": "video/mp4",
        "txt": "text/plain", "md": "text/plain", "xml": "application/xml",
        "pdf": "application/pdf"
    ]

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }

        var relPath = url.path
        if relPath.hasPrefix("/") { relPath.removeFirst() }
        if relPath.isEmpty { relPath = "index.html" }

        // Защита от выхода за пределы папки www
        let fileURL = root.appendingPathComponent(relPath).standardizedFileURL
        guard fileURL.path.hasPrefix(root.path) else {
            respond(urlSchemeTask, url: url, data: Data(), status: 403, mime: "text/plain")
            return
        }

        var data = try? Data(contentsOf: fileURL)

        // SPA-фолбэк: пути без расширения отдаём index.html (hash-роутер приложения)
        if data == nil, !relPath.contains(".") {
            data = try? Data(contentsOf: root.appendingPathComponent("index.html"))
        }

        guard let payload = data else {
            respond(urlSchemeTask, url: url, data: Data(), status: 404, mime: "text/plain")
            return
        }

        let ext = fileURL.pathExtension.lowercased()
        let mime = CQSchemeHandler.mimes[ext] ?? "application/octet-stream"
        respond(urlSchemeTask, url: url, data: payload, status: 200, mime: mime)
    }

    private func respond(_ task: WKURLSchemeTask, url: URL, data: Data, status: Int, mime: String) {
        let headers = [
            "Content-Type": mime,
            "Content-Length": String(data.count),
            "Cache-Control": "no-cache",
            "Access-Control-Allow-Origin": "*"
        ]
        let response = HTTPURLResponse(url: url,
                                       statusCode: status,
                                       httpVersion: "HTTP/1.1",
                                       headerFields: headers) ?? URLResponse(url: url, mimeType: mime, expectedContentLength: data.count, textEncodingName: "utf-8")
        task.didReceive(response)
        task.didReceive(data)
        task.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {
        // Запросы обслуживаются мгновенно из памяти/диска — отменять нечего
    }
}

// MARK: - UIViewController с полноэкранным WKWebView

final class WebViewController: UIViewController, WKUIDelegate {

    private var webView: WKWebView!
    private var bottomConstraint: NSLayoutConstraint!

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.051, green: 0.067, blue: 0.090, alpha: 1) // #0d1117

        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(CQSchemeHandler(), forURLScheme: "cq")
        cfg.websiteDataStore = .default()          // localStorage переживает перезапуски
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserAction = []

        webView = WKWebView(frame: .zero, configuration: cfg)
        webView.uiDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.isScrollEnabled = false   // скроллят внутренние панели приложения
        webView.scrollView.bounces = false
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)

        bottomConstraint = webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomConstraint
        ])

        // Клавиатура: сжимаем вебвью снизу, чтобы редактор кода всегда был виден
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardChanged(_:)),
                                               name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardChanged(_:)),
                                               name: UIResponder.keyboardWillHideNotification, object: nil)

        if let url = URL(string: "cq://localhost/index.html") {
            webView.load(URLRequest(url: url))
        }
    }

    @objc private func keyboardChanged(_ note: Notification) {
        let endFrame = (note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue ?? .zero
        let hiding = note.name == UIResponder.keyboardWillHideNotification
        let bottomOffset: CGFloat = hiding ? 0 : max(0, view.bounds.height - view.convert(endFrame, from: nil).minY)
        UIView.animate(withDuration: 0.25, delay: 0, options: [.curveEaseOut, .beginFromCurrentState]) {
            self.bottomConstraint.constant = bottomOffset
            self.view.layoutIfNeeded()
        }
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate(alongsideTransition: nil) { _ in
            self.webView.evaluateJavaScript("window.dispatchEvent(new Event('resize'))", completionHandler: nil)
        }
    }
}

// MARK: - SwiftUI-точка входа

struct ContentView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> WebViewController { WebViewController() }
    func updateUIViewController(_ uiViewController: WebViewController, context: Context) {}
}

@main
struct CodeQuestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .ignoresSafeArea(.all) // приложение само учитывает safe-area через CSS
        }
    }
}
