# ⚡ CodeQuest для iOS — нативное приложение (Xcode)

**CodeQuest** — офлайн-академия программирования: **100 языков, 1163 уровня,
50 достижений, 16 встроенных инструментов, 12 траекторий обучения**.

Это папка исходников **нативного iOS-приложения**: Xcode-проект с WebView-обёрткой,
в которую встроено всё веб-приложение целиком. Собирается в iPhone/iPad-приложение
за один Run в Xcode — или бесплатно на облачном Mac'е через GitHub Actions
(без своего Mac!).

```
CodeQuest.xcodeproj              — проект Xcode (открыть двойным кликом)
CodeQuest/App.swift              — Swift-код: WKWebView + схема cq:// + клавиатура
CodeQuest/www/                   — всё приложение (index.html, js, css, content/×100)
CodeQuest/Info.plist             — метаданные приложения
CodeQuest/Assets.xcassets        — иконка 1024px, акцентный цвет, фон запуска
CodeQuest/PrivacyInfo.xcprivacy  — манифест приватности (Data Not Collected)
.github/workflows/build-ios.yml  — сборка неподписанного IPA на macOS-раннере
.github/workflows/deploy-pwa.yml — деплой PWA-версии на GitHub Pages
INSTALL-iPhone.md                — 4 способа поставить приложение на iPhone
APP-STORE-GUIDE.md               — публикация в App Store по шагам
Собрать-IPA.command              — локальная сборка IPA одной командой (на Mac)
```

## Быстрый старт

| Цель | Что делать |
|---|---|
| Поставить на iPhone прямо сейчас | `INSTALL-iPhone.md` → Способ 1 (PWA, 2 минуты) |
| Собрать .ipa без Mac | `INSTALL-iPhone.md` → Способ 2 (GitHub Actions + Sideloadly) |
| Собрать на Mac | Открыть `CodeQuest.xcodeproj` → выбрать Team → ▶ Run |
| Выложить в App Store | `APP-STORE-GUIDE.md` (нужен Apple Developer $99/год) |

## Технические детали

- **Bundle ID:** `ru.codequest.app` · версия 1.5.0 (build 1)
- **iOS 14.0+**, iPhone и iPad (`TARGETED_DEVICE_FAMILY = 1,2`)
- Контент раздаётся через собственную схему `cq://localhost` — localStorage
  работает как first-party, прогресс сохраняется на устройстве между запусками
- Клавиатура не перекрывает редактор кода (WebView сжимается снизу с анимацией)
- Никаких разрешений, никакой сети, ноль сбора данных
- Service Worker внутри WebView не регистрируется (не нужен — всё уже офлайн)

## Синхронизация контента

Веб-приложение живёт в `CodeQuest/www/`. При обновлении курсов просто
скопируйте новую версию папки приложения сюда — пересборка не требует
правок Swift-кода.

© 2026 CodeQuest · v1.5.0
