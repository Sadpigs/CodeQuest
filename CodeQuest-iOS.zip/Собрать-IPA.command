#!/bin/bash
# Собирает неподписанный IPA локально на Mac'е (без Xcode GUI).
# Запуск: двойной клик по файлу ИЛИ в Терминале: bash Собрать-IPA.command
set -e
cd "$(dirname "$0")"

echo "==> Архивация CodeQuest.app..."
xcodebuild -project CodeQuest.xcodeproj \
           -scheme CodeQuest \
           -configuration Release \
           -destination "generic/platform=iOS" \
           -archivePath build/CodeQuest.xcarchive \
           archive \
           CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY=""

echo "==> Упаковка IPA..."
rm -rf build/Payload && mkdir -p build/Payload
cp -R "build/CodeQuest.xcarchive/Products/Applications/CodeQuest.app" build/Payload/
cd build && zip -qry CodeQuest-unsigned.ipa Payload && cd ..

echo ""
echo "✅ Готово: $(pwd)/build/CodeQuest-unsigned.ipa"
echo "   Дальше — см. INSTALL-iPhone.md (Sideloadly / Xcode / App Store)"
open -R "$(pwd)/build/CodeQuest-unsigned.ipa" 2>/dev/null || true
